/* global pdfjsLib */

document.addEventListener('DOMContentLoaded', () => {
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

    const importZone = document.getElementById('pdfImportZone');
    const pdfViewer = document.getElementById('pdfViewer');
    const pdfFileInput = document.getElementById('pdfFileInput');
    if (!importZone || !pdfViewer || !pdfFileInput) return;
    const pdfSelectBtn = document.getElementById('pdfSelectBtn');
    const pdfPages = document.getElementById('pdfPages');
    const pdfToolbar = document.querySelector('.pdf-toolbar');
    const pdfPrevPage = document.getElementById('pdfPrevPage');
    const pdfNextPage = document.getElementById('pdfNextPage');
    const pdfPageInfo = document.getElementById('pdfPageInfo');
    const pdfCloseBtn = document.getElementById('pdfCloseBtn');
    const pdfFilename = document.getElementById('pdfFilename');

    let pdfDoc = null;
    let currentPage = 1;
    let totalPages = 0;
    let currentFilename = '';
    let allPageTexts = [];

    // Служебные строки OKULYK и подобные — убираем с каждой страницы
    const BOILERPLATE_PATTERNS = [
        /^.*учебники\s+Казахстана.*OKULYK/i,
        /^.*OKULYK\.(COM|KZ).*$/i,
        /^\*?\s*Книга предоставлена исключительно в образовательных целях\s*$/i,
        /^согласно Приказа Министра образования и науки.*Казахстан/i
    ];

    function filterBoilerplate(text) {
        if (!text || typeof text !== 'string') return text;
        return text
            .split(/\n+/)
            .filter(line => {
                const trimmed = line.trim();
                if (!trimmed) return false;
                return !BOILERPLATE_PATTERNS.some(p => p.test(trimmed));
            })
            .join('\n')
            .trim();
    }

    function showImportZone() {
        importZone.style.display = 'flex';
        pdfViewer.style.display = 'none';
        pdfDoc = null;
        allPageTexts = [];
        window.currentBookText = '';
    }

    function showViewer() {
        importZone.style.display = 'none';
        pdfViewer.style.display = 'block';
        pdfFilename.textContent = currentFilename;
    }

    function buildTextContent() {
        pdfPages.innerHTML = '';
        allPageTexts.forEach((pageText, index) => {
            const pageNum = index + 1;
            const section = document.createElement('section');
            section.className = 'pdf-text-page';
            section.setAttribute('data-assistant', `Страница ${pageNum} из ${totalPages}. ${pageText.trim().slice(0, 200)}`);

            const heading = document.createElement('h2');
            heading.className = 'pdf-page-heading';
            heading.textContent = `Страница ${pageNum}`;
            heading.setAttribute('data-assistant', `Страница ${pageNum}`);

            const content = document.createElement('div');
            content.className = 'pdf-text-content';

            const lines = pageText.split(/\n+/).filter(s => s.trim());
            lines.forEach(line => {
                const p = document.createElement('p');
                p.textContent = line.trim();
                p.setAttribute('data-assistant', line.trim());
                content.appendChild(p);
            });

            if (lines.length === 0) {
                const p = document.createElement('p');
                p.textContent = '(На этой странице нет извлекаемого текста)';
                p.setAttribute('data-assistant', 'На этой странице нет извлекаемого текста');
                content.appendChild(p);
            }

            section.appendChild(heading);
            section.appendChild(content);
            pdfPages.appendChild(section);
        });

        pdfPageInfo.textContent = `1 / ${totalPages}`;
        currentPage = 1;
        pdfPrevPage.disabled = true;
        pdfNextPage.disabled = totalPages <= 1;
    }

    function showPage(num) {
        const sections = pdfPages.querySelectorAll('.pdf-text-page');
        sections.forEach((s, i) => {
            s.style.display = i + 1 === num ? 'block' : 'none';
        });
        pdfPageInfo.textContent = `${num} / ${totalPages}`;
        currentPage = num;
        pdfPrevPage.disabled = num <= 1;
        pdfNextPage.disabled = num >= totalPages;
        pdfPages.scrollTop = 0;
    }

    async function loadPDF(file) {
        const arrayBuffer = await file.arrayBuffer();
        pdfDoc = await pdfjsLib.getDocument(arrayBuffer).promise;
        totalPages = pdfDoc.numPages;
        currentFilename = file.name;
        allPageTexts = [];

        for (let i = 1; i <= totalPages; i++) {
            const page = await pdfDoc.getPage(i);
            const textContent = await page.getTextContent();
            const lines = [];
            let line = [];
            textContent.items.forEach(item => {
                line.push(item.str);
                if (item.hasEOL) {
                    lines.push(line.join('').trim());
                    line = [];
                }
            });
            if (line.length) lines.push(line.join('').trim());
            const pageTextRaw = lines.join('\n');
            allPageTexts.push(filterBoilerplate(pageTextRaw) || pageTextRaw);
        }

        showViewer();
        buildTextContent();
        window.currentBookText = allPageTexts.join('\n\n');

        if (totalPages > 1) {
            pdfToolbar.style.display = '';
            showPage(1);
        } else {
            pdfToolbar.style.display = 'none';
        }
    }

    pdfSelectBtn.addEventListener('click', () => pdfFileInput.click());
    pdfFileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file && file.type === 'application/pdf') loadPDF(file);
        e.target.value = '';
    });

    importZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        importZone.classList.add('pdf-drag-over');
    });
    importZone.addEventListener('dragleave', () => {
        importZone.classList.remove('pdf-drag-over');
    });
    importZone.addEventListener('drop', (e) => {
        e.preventDefault();
        importZone.classList.remove('pdf-drag-over');
        const file = e.dataTransfer.files[0];
        if (file && file.type === 'application/pdf') loadPDF(file);
    });
    importZone.addEventListener('click', (e) => {
        if (e.target === importZone || e.target.closest('.pdf-import-inner')) {
            if (!e.target.closest('.pdf-import-btn')) pdfFileInput.click();
        }
    });

    pdfPrevPage.addEventListener('click', () => {
        if (currentPage > 1) showPage(currentPage - 1);
    });
    pdfNextPage.addEventListener('click', () => {
        if (currentPage < totalPages) showPage(currentPage + 1);
    });
    pdfCloseBtn.addEventListener('click', showImportZone);
});
