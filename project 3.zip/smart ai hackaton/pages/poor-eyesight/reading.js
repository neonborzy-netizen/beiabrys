document.addEventListener('DOMContentLoaded', () => {
    const readBtn = document.getElementById('readingModeBtn');
    if (readBtn) {
        readBtn.addEventListener('click', () => {
            document.body.classList.toggle('reading-active');
            readBtn.textContent = document.body.classList.contains('reading-active') ? 'Выйти из чтения' : '📖 Режим чтения';
        });
    }
});