document.addEventListener('DOMContentLoaded', () => {
    const cursor = document.getElementById('customCursor');
    const toggle = document.getElementById('cursorToggle');

    if (toggle) {
        toggle.addEventListener('change', (e) => {
            document.body.classList.toggle('super-cursor', e.target.checked);
        });
    }

    document.addEventListener('mousemove', (e) => {
        if (cursor && document.body.classList.contains('super-cursor')) {
            cursor.style.left = e.clientX + 'px';
            cursor.style.top = e.clientY + 'px';
        }
    });
});