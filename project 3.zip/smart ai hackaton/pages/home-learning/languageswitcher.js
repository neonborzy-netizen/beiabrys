const translations = {
    kz: {
        heroTitle: "Оқытудың жаңа форматы",
        heroDesc: "Балаңыздың оқу стилін анықтап, жеке білім жолын бастаңыз.",
        testCard: "Ойлау тесті",
        booksCard: "Оқулықтар",
        achieveCard: "Жетістіктер",
        bannerT: "Тесттен әлі өткен жоқсыз ба?",
        bannerBtn: "Тестті бастау",
        selectTitle: "Оқулықты таңдаңыз",
        selectDesc: "Өзіңізге қажетті пәнді таңдап, оқуды бастаңыз",
        math: "Математика",
        kazLang: "Қазақ тілі",
        rusLang: "Орыс тілі",
        engLang: "Ағылшын тілі",
        backBtn: "Артқа",
        styleLabel: "Бейімделген стиль:",
        checkBtn: "Тексеру"
    },
    ru: {
        heroTitle: "Новый формат обучения",
        heroDesc: "Определите стиль обучения вашего ребенка и начните индивидуальный путь.",
        testCard: "Тест мышления",
        booksCard: "Учебники",
        achieveCard: "Достижения",
        bannerT: "Еще не прошли тест?",
        bannerBtn: "Начать тест",
        selectTitle: "Выберите учебник",
        selectDesc: "Выберите нужный предмет и начните обучение",
        math: "Математика",
        kazLang: "Казахский язык",
        rusLang: "Русский язык",
        engLang: "Английский язык",
        backBtn: "Назад",
        styleLabel: "Адаптированный стиль:",
        checkBtn: "Проверить"
    }
};

function setLanguage(lang) {
    localStorage.setItem('language', lang);
    location.reload();
}

function applyTranslations() {
    const lang = localStorage.getItem('language') || 'kz';
    const t = translations[lang];

    // Маппинг ID элементов на перевод
    const map = {
        'hero-title': t.heroTitle, 'hero-desc': t.heroDesc,
        'card-test-t': t.testCard, 'card-books-t': t.booksCard,
        'card-achieve-t': t.achieveCard, 'banner-t': t.bannerT,
        'banner-btn': t.bannerBtn, 'select-title': t.selectTitle,
        'select-desc': t.selectDesc, 'txt-math': t.math,
        'txt-kaz': t.kazLang, 'txt-rus': t.rusLang,
        'txt-eng': t.engLang, 'btn-back-text': t.backBtn,
        'style-label-text': t.styleLabel, 'btn-check': t.checkBtn
    };

    for (let id in map) {
        const el = document.getElementById(id);
        if (el && map[id]) el.innerText = map[id];
    }
    
    updateSwitcherStyles(lang);
}

function updateSwitcherStyles(lang) {
    const ruBtn = document.getElementById('lang-ru');
    const kzBtn = document.getElementById('lang-kz');
    if (!ruBtn || !kzBtn) return;

    const active = "bg-gradient-to-r from-[#6d28d9] to-[#3b82f6] text-white shadow-md";
    const inactive = "text-gray-600 hover:text-gray-900";

    ruBtn.className = `px-6 py-2 rounded-full transition-all font-bold text-sm ${lang === 'ru' ? active : inactive}`;
    kzBtn.className = `px-6 py-2 rounded-full transition-all font-bold text-sm ${lang === 'kz' ? active : inactive}`;
}

document.addEventListener('DOMContentLoaded', applyTranslations);