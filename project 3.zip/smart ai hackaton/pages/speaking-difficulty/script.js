let score = 0;

/**
 * Жаттығуды бастау және таймерді қосу
 */
function startExercise(btn, seconds) {
    let timeLeft = seconds;
    const originalText = btn.innerText;
    
    // Батырма күйін өзгерту
    btn.disabled = true;
    btn.classList.add('btn-active');
    
    // Дыбыстық сигнал (басталғаны туралы)
    playTone(440, 0.1); 

    const timer = setInterval(() => {
        btn.innerText = `Қалды: ${timeLeft}с`;
        timeLeft--;

        if (timeLeft < 0) {
            clearInterval(timer);
            btn.innerText = "КЕРЕМЕТ! +50 XP";
            btn.classList.remove('btn-active');
            btn.classList.add('bg-green-500', 'text-white');
            
            // Ұпай қосу
            addScore(50);
            playTone(880, 0.2);

            // 3 секундтан кейін батырманы қалпына келтіру
            setTimeout(() => {
                btn.disabled = false;
                btn.innerText = originalText;
                btn.classList.remove('bg-green-500', 'text-white');
            }, 3000);
        }
    }, 1000);
}

/**
 * Ұпайды жаңарту
 */
function addScore(points) {
    score += points;
    document.getElementById('global-score').innerText = score;
}

/**
 * Қарапайым дыбыстық эффект (Beep)
 */
function playTone(freq, duration) {
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();

    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(freq, audioCtx.currentTime);
    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);

    oscillator.start();
    gainNode.gain.exponentialRampToValueAtTime(0.00001, audioCtx.currentTime + duration);
    oscillator.stop(audioCtx.currentTime + duration);
}

// Иконкаларды іске қосу
document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();
});