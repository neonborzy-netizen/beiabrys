// --- 1. ДИАГНОСТИКА БЛОГЫ ---

const diagnosticWords = [
    { word: 'Радуга', sound: 'Р' }, 
    { word: 'Шоколад', sound: 'Ш' }, 
    { word: 'Лампа', sound: 'Л' }, 
    { word: 'Жираф', sound: 'Ж' },
    { word: 'Солнце', sound: 'С' },
    { word: 'Часы', sound: 'Ч' }
];

// Тестті бастау функциясы
function initTest() {
    // Егер сөздер бітсе, нәтижені көрсету
    if(state.currentIndex >= diagnosticWords.length) {
        showResults();
        return;
    }
    
    // Экранға сөз шығару
    const current = diagnosticWords[state.currentIndex];
    document.getElementById('target-word').innerText = current.word;
    
    // Stepper (нүктелер) сызу
    const stepper = document.getElementById('test-stepper');
    stepper.innerHTML = diagnosticWords.map((_, i) => 
        `<div class="step-dot ${i === state.currentIndex ? 'active' : ''}"></div>`
    ).join('');
}

// Микрофонды қосу және тексеру
function handleMic() {
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) {
        alert('Сіздің браузеріңіз микрофонды қолдамайды');
        return;
    }
    const rec = new Recognition();
    rec.lang = 'ru-RU';
    
    const btn = document.getElementById('record-btn');
    
    // Батырма түсін өзгерту (Recording...)
    btn.classList.replace('btn-primary', 'bg-red-500');
    btn.classList.add('text-white');
    btn.innerText = 'Тыңдап тұрмын...';

    rec.onresult = (e) => {
        const text = e.results[0][0].transcript.toLowerCase();
        const target = diagnosticWords[state.currentIndex].word.toLowerCase();

        // Салыстыру
        if (text.includes(target)) {
            state.correct++;
            state.score += 50; // 50 ұпай қосу
            document.getElementById('global-score').innerText = state.score + ' XP';
        } else {
            state.errors.push(diagnosticWords[state.currentIndex]);
        }
        
        // Келесі сөзге өту
        state.currentIndex++;
        initTest();
    };

    rec.onend = () => {
        // Батырманы қалпына келтіру
        btn.classList.replace('bg-red-500', 'btn-primary');
        btn.innerHTML = `<i data-lucide="mic" size="20"></i> Записать`;
        lucide.createIcons();
    };
    rec.start();
}

// Сөзді дыбыстап беру (Робот дауысы)
function playWord() {
    const word = diagnosticWords[state.currentIndex].word;
    const u = new SpeechSynthesisUtterance(word);
    u.lang = 'ru-RU';
    window.speechSynthesis.speak(u);
}