// --- 2. ГИМНАСТИКА БЛОГЫ ---

const gymExercises = [
    { id: 1, name: 'Заборчик', desc: 'Растяните губы в улыбке.', time: 10, icon: 'smile', type: 'anim-smile' },
    { id: 2, name: 'Трубочка', desc: 'Вытяните губы вперед.', time: 10, icon: 'circle', type: 'anim-tube' },
    { id: 3, name: 'Качели', desc: 'Язык вверх и вниз.', time: 15, icon: 'move-vertical', type: 'anim-swing' },
    { id: 4, name: 'Часики', desc: 'Язык влево-вправо.', time: 15, icon: 'clock', type: 'anim-clock' },
    { id: 5, name: 'Лошадка', desc: 'Цокайте языком.', time: 20, icon: 'rocking-chair', type: 'anim-horse' },
    { id: 6, name: 'Блинчик', desc: 'Расслабьте язык.', time: 15, icon: 'minus-circle', type: 'anim-pancake' }
];

function initGym() {
    const container = document.getElementById('sec-gym');
    // Карточкаларды шығару
    container.innerHTML = gymExercises.map(ex => `
        <div class="gym-card ${ex.type}">
            <div class="flex justify-between items-start mb-4">
                <div class="gym-icon"><i data-lucide="${ex.icon}" size="32"></i></div>
                <span class="text-xs font-bold bg-gray-100 px-2 py-1 rounded">${ex.time} сек</span>
            </div>
            <h4 class="text-lg font-bold mb-2">${ex.name}</h4>
            <p class="text-sm text-gray-500 mb-6">${ex.desc}</p>
            <button onclick="startTimer(this, ${ex.time})" class="w-full py-3 border border-slate-200 rounded-lg hover:bg-slate-900 hover:text-white transition">
                Начать
            </button>
        </div>
    `).join('');
    lucide.createIcons();
}

// Таймер логикасы
function startTimer(btn, seconds) {
    let timeLeft = seconds;
    const originalText = btn.innerText;
    
    if(btn.disabled) return;
    btn.disabled = true;
    btn.classList.add('bg-slate-900', 'text-white');

    const interval = setInterval(() => {
        btn.innerText = `${timeLeft} сек...`;
        timeLeft--;
        if (timeLeft < 0) {
            clearInterval(interval);
            btn.innerText = "Готово! ✓";
            btn.classList.replace('bg-slate-900', 'bg-green-600');
            
            // 2 секундтан кейін қайтадан қалпына келу
            setTimeout(() => {
                btn.innerText = originalText;
                btn.disabled = false;
                btn.classList.remove('bg-green-600', 'text-white');
            }, 2000);

            // Ұпай қосу
            state.score += 10;
            document.getElementById('global-score').innerText = state.score + ' XP';
        }
    }, 1000);
}