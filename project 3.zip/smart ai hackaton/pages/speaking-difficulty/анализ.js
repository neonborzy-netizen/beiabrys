// --- 3. АНАЛИЗ БЛОГЫ ---

let vizInt; // Интервал ID

function startVisualizer() {
    const cont = document.getElementById('viz-container');
    // 20 бағана жасаймыз
    cont.innerHTML = Array(20).fill(0).map(() => `<div class="bar" style="height: 5px"></div>`).join('');
    
    // Ескі интервалды тазалау
    if (vizInt) clearInterval(vizInt);
    
    // Бағаналарды "бийлету"
    vizInt = setInterval(() => {
        document.querySelectorAll('.bar').forEach(b => {
            b.style.height = Math.max(5, Math.random() * 100) + '%'; 
        });
    }, 100);
}

// Анализден шыққанда тоқтату керек
function stopVisualizer() { 
    clearInterval(vizInt); 
}