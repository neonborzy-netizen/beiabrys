// --- 4. ПРАКТИКА БЛОГЫ ---

const phrases = {
    'Р': ['Карл у Клары украл кораллы', 'На горе Арарат'],
    'Ш': ['Шла Саша по шоссе', 'Шесть мышат шуршат'],
    'Л': ['Мама мыла Милу мылом', 'Белый лебедь']
};

function initAssistant() {
    const tabs = document.getElementById('sound-tabs');
    // Дыбыс батырмаларын жасау (Р, Ш, Л...)
    tabs.innerHTML = Object.keys(phrases).map(key => `
        <button onclick="loadPhrases('${key}')" class="px-4 py-2 bg-white border border-gray-200 rounded-md text-sm hover:border-blue-500 transition">
            Звук [${key}]
        </button>
    `).join('');
    
    // Алғашқы рет "Р" дыбысын жүктеу
    loadPhrases('Р'); 
}

function loadPhrases(sound) {
    const list = document.getElementById('phrases-container');
    list.innerHTML = phrases[sound].map(p => `
        <div class="p-4 bg-gray-50 rounded-lg flex justify-between items-center cursor-pointer hover:bg-white border border-transparent hover:border-gray-200" onclick="speakPhrase('${p}')">
            <span>"${p}"</span>
            <i data-lucide="play-circle" class="text-gray-400"></i>
        </div>
    `).join('');
    lucide.createIcons();
}

function speakPhrase(text) {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'ru-RU';
    window.speechSynthesis.speak(u);
}