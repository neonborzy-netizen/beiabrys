// --- НЕГІЗГІ БАСҚАРУ ---

let state = {
    score: 0,
    currentIndex: 0,
    errors: [],
    correct: 0
};

// Беттерді ауыстыру логикасы
function navTo(sectionId) {
    // 1. Басты менюді жасыру
    document.getElementById('dashboard').classList.add('hidden');
    // 2. Ішкі беттер контейнерін ашу
    document.getElementById('content-viewer').classList.remove('hidden');
    
    // 3. Барлық секцияларды жасыру
    ['test', 'results', 'gym', 'analysis', 'assistant'].forEach(id => {
        const el = document.getElementById(`sec-${id}`);
        if(el) el.classList.add('hidden');
    });

    // 4. Тек керектісін ашу
    const target = document.getElementById(`sec-${sectionId}`);
    if (target) target.classList.remove('hidden');

    // 5. Сол бетке қатысты функцияны оталдыру
    if (sectionId === 'test') initTest();
    if (sectionId === 'gym') initGym();
    if (sectionId === 'analysis') startVisualizer();
    if (sectionId === 'assistant') initAssistant();
    
    lucide.createIcons();
}

// "Назад" батырмасы
function backToHome() {
    document.getElementById('content-viewer').classList.add('hidden');
    document.getElementById('dashboard').classList.remove('hidden');
    stopVisualizer(); // Егер анализ қосулы тұрса, өшіру
}

// Сайт ашылғанда иконкаларды жүктеу
window.onload = () => lucide.createIcons();