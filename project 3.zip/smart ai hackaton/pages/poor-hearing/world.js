// Қоршаған орта - Сабақтар мен тесттер
const SUBJECT_KEY = 'world';

const LESSONS = {
  1: [
    {
      id: 'nature',
      title: 'Табиғат',
      desc: 'Тірі және өлі табиғат',
      steps: [
        { title: 'Тірі табиғат', content: 'Адамдар, жануарлар, өсімдіктер — тірі табиғат.', keyword: 'Тірі' },
        { title: 'Өлі табиғат', content: 'Тастар, су, ауа, күн — өлі табиғат.', keyword: 'Өлі' },
        { title: 'Байланыс', content: 'Тірі табиғат өлі табиғатсыз өмір сүре алмайды.', keyword: 'Байланыс' }
      ],
      quiz: [
        { q: 'Ағаш қай табиғатқа жатады?', options: ['Тірі', 'Өлі'], answer: 0 },
        { q: 'Тас қай табиғатқа жатады?', options: ['Тірі', 'Өлі'], answer: 1 },
        { q: 'Құс қай табиғатқа жатады?', options: ['Тірі', 'Өлі'], answer: 0 }
      ]
    },
    {
      id: 'seasons',
      title: 'Жыл мезгілдері',
      desc: 'Төрт мезгіл',
      steps: [
        { title: 'Көктем', content: 'Наурыз, сәуір, мамыр — көктем айлары.', keyword: 'Көктем' },
        { title: 'Жаз', content: 'Маусым, шілде, тамыз — жаз айлары.', keyword: 'Жаз' },
        { title: 'Күз', content: 'Қыркүйек, қазан, қараша — күз айлары.', keyword: 'Күз' },
        { title: 'Қыс', content: 'Желтоқсан, қаңтар, ақпан — қыс айлары.', keyword: 'Қыс' }
      ],
      quiz: [
        { q: 'Наурыз қай мезгілге жатады?', options: ['Жаз', 'Күз', 'Қыс', 'Көктем'], answer: 3 },
        { q: 'Шілде қай мезгіл?', options: ['Көктем', 'Жаз', 'Күз', 'Қыс'], answer: 1 },
        { q: 'Қар қай мезгілде жауады?', options: ['Көктем', 'Жаз', 'Күз', 'Қыс'], answer: 3 }
      ]
    },
    {
      id: 'animals',
      title: 'Жануарлар',
      desc: 'Үй және жабайы жануарлар',
      steps: [
        { title: 'Үй жануарлары', content: 'Ит, мысық, сиыр, жылқы — үй жануарлары.', keyword: 'Үй' },
        { title: 'Жабайы жануарлар', content: 'Арыстан, аю, қасқыр, түлкі — жабайы жануарлар.', keyword: 'Жабайы' },
        { title: 'Күтім', content: 'Үй жануарларына күтім керек.', keyword: 'Күтім' }
      ],
      quiz: [
        { q: 'Ит қай топқа жатады?', options: ['Үй жануары', 'Жабайы жануар'], answer: 0 },
        { q: 'Арыстан қай топқа жатады?', options: ['Үй жануары', 'Жабайы жануар'], answer: 1 },
        { q: 'Сиырдан не аламыз?', options: ['Жүн', 'Сүт', 'Жұмыртқа'], answer: 1 }
      ]
    }
  ],
  2: [
    {
      id: 'plants',
      title: 'Өсімдіктер',
      desc: 'Өсімдіктер әлемі',
      steps: [
        { title: 'Өсімдік бөліктері', content: 'Тамыр, сабақ, жапырақ, гүл, жеміс.', keyword: 'Бөліктер' },
        { title: 'Ағаштар', content: 'Қайың, емен, шырша — ағаштар.', keyword: 'Ағаш' },
        { title: 'Гүлдер', content: 'Раушан, қызғалдақ, бәйшешек — гүлдер.', keyword: 'Гүл' }
      ],
      quiz: [
        { q: 'Өсімдік нені сіңіреді?', options: ['Ауа', 'Су және күн сәулесі', 'Тас'], answer: 1 },
        { q: 'Тамыр не үшін керек?', options: ['Су сіңіру', 'Гүлдену', 'Жеміс беру'], answer: 0 },
        { q: 'Қайың не?', options: ['Гүл', 'Ағаш', 'Шөп'], answer: 1 }
      ]
    },
    {
      id: 'water',
      title: 'Су',
      desc: 'Судың маңызы',
      steps: [
        { title: 'Су қайда бар?', content: 'Өзен, көл, теңіз, мұхит — су қоймалары.', keyword: 'Су қоймасы' },
        { title: 'Судың күйлері', content: 'Сұйық (су), қатты (мұз), газ (бу).', keyword: 'Күй' },
        { title: 'Судың маңызы', content: 'Барлық тірі жанға су керек.', keyword: 'Маңыз' }
      ],
      quiz: [
        { q: 'Мұз судың қай күйі?', options: ['Сұйық', 'Қатты', 'Газ'], answer: 1 },
        { q: 'Ең үлкен су қоймасы?', options: ['Көл', 'Өзен', 'Мұхит'], answer: 2 },
        { q: 'Су қайнағанда не болады?', options: ['Мұзға айналады', 'Буға айналады', 'Жоғалады'], answer: 1 }
      ]
    },
    {
      id: 'air',
      title: 'Ауа',
      desc: 'Ауа және оның қасиеттері',
      steps: [
        { title: 'Ауа дегеніміз не?', content: 'Ауа — газдардың қоспасы.', keyword: 'Ауа' },
        { title: 'Ауа құрамы', content: 'Азот, оттегі, көмірқышқыл газы.', keyword: 'Құрам' },
        { title: 'Таза ауа', content: 'Таза ауа денсаулыққа пайдалы.', keyword: 'Таза' }
      ],
      quiz: [
        { q: 'Біз не тыныс аламыз?', options: ['Су', 'Ауа', 'Жер'], answer: 1 },
        { q: 'Ауаны көруге бола ма?', options: ['Иә', 'Жоқ'], answer: 1 },
        { q: 'Ағаштар не шығарады?', options: ['Көмірқышқыл газ', 'Оттегі', 'Азот'], answer: 1 }
      ]
    }
  ],
  3: [
    {
      id: 'body',
      title: 'Адам денесі',
      desc: 'Дене мүшелері',
      steps: [
        { title: 'Сезім мүшелері', content: 'Көз, құлақ, мұрын, тіл, тері — сезім мүшелері.', keyword: 'Сезім' },
        { title: 'Ішкі мүшелер', content: 'Жүрек, өкпе, бауыр, бүйрек — ішкі мүшелер.', keyword: 'Ішкі' },
        { title: 'Сүйектер', content: 'Қаңқа 206 сүйектен тұрады.', keyword: 'Сүйек' }
      ],
      quiz: [
        { q: 'Көзбен не істейміз?', options: ['Естиміз', 'Көреміз', 'Иіс сеземіз'], answer: 1 },
        { q: 'Жүрек не істейді?', options: ['Ауа алады', 'Қан айдайды', 'Ас қорытады'], answer: 1 },
        { q: 'Құлақпен не істейміз?', options: ['Көреміз', 'Естиміз', 'Дәм сеземіз'], answer: 1 }
      ]
    },
    {
      id: 'health',
      title: 'Денсаулық',
      desc: 'Салауатты өмір салты',
      steps: [
        { title: 'Дұрыс тамақтану', content: 'Көкөніс, жеміс, сүт — пайдалы.', keyword: 'Тамақ' },
        { title: 'Спорт', content: 'Күнде жаттығу жасау керек.', keyword: 'Спорт' },
        { title: 'Тазалық', content: 'Қол жуу, тіс тазалау — міндетті.', keyword: 'Тазалық' }
      ],
      quiz: [
        { q: 'Не пайдалы?', options: ['Чипсы', 'Алма', 'Газды су'], answer: 1 },
        { q: 'Тісті күніне неше рет тазалау керек?', options: ['1', '2', '5'], answer: 1 },
        { q: 'Спорт не үшін керек?', options: ['Ұйықтау', 'Денсаулық', 'Ештеңе'], answer: 1 }
      ]
    },
    {
      id: 'ecology',
      title: 'Экология',
      desc: 'Табиғатты қорғау',
      steps: [
        { title: 'Қоқыс', content: 'Қоқысты арнайы жерге тастау керек.', keyword: 'Қоқыс' },
        { title: 'Ормандар', content: 'Ағаш кесуге болмайды, отырғызу керек.', keyword: 'Орман' },
        { title: 'Жануарларды қорғау', content: 'Қызыл кітапқа енген жануарларды қорғау.', keyword: 'Қорғау' }
      ],
      quiz: [
        { q: 'Қоқысты қайда тастау керек?', options: ['Жерге', 'Урнаға', 'Суға'], answer: 1 },
        { q: 'Ағаш не береді?', options: ['Оттегі', 'Көмірқышқыл газ', 'Су'], answer: 0 },
        { q: 'Қызыл кітап не?', options: ['Оқулық', 'Сирек жануарлар тізімі', 'Ертегі'], answer: 1 }
      ]
    }
  ],
  4: [
    {
      id: 'solar',
      title: 'Күн жүйесі',
      desc: 'Ғарыш әлемі',
      steps: [
        { title: 'Күн', content: 'Күн — біздің жұлдызымыз.', keyword: 'Күн' },
        { title: 'Планеталар', content: 'Меркурий, Шолпан, Жер, Марс, Юпитер, Сатурн, Уран, Нептун.', keyword: 'Планета' },
        { title: 'Жер', content: 'Жер — біздің планетамыз, 3-ші орында.', keyword: 'Жер' }
      ],
      quiz: [
        { q: 'Күн жүйесінде неше планета бар?', options: ['6', '8', '9', '12'], answer: 1 },
        { q: 'Жер Күннен нешінші орында?', options: ['1', '2', '3', '4'], answer: 2 },
        { q: 'Ең үлкен планета?', options: ['Жер', 'Марс', 'Юпитер', 'Сатурн'], answer: 2 }
      ]
    },
    {
      id: 'zones',
      title: 'Табиғат зоналары',
      desc: 'Климат белдеулері',
      steps: [
        { title: 'Арктика', content: 'Мұз, аяз, ақ аюлар.', keyword: 'Арктика' },
        { title: 'Орман', content: 'Ағаштар, жануарлар, құстар.', keyword: 'Орман' },
        { title: 'Шөл', content: 'Құм, ыстық, түйелер.', keyword: 'Шөл' },
        { title: 'Дала', content: 'Шөп, жылқылар, қоңыздар.', keyword: 'Дала' }
      ],
      quiz: [
        { q: 'Ақ аю қайда тұрады?', options: ['Орман', 'Шөл', 'Арктика', 'Дала'], answer: 2 },
        { q: 'Шөлде не көп?', options: ['Ағаш', 'Құм', 'Мұз'], answer: 1 },
        { q: 'Түйе қайда тұрады?', options: ['Арктика', 'Орман', 'Шөл'], answer: 2 }
      ]
    },
    {
      id: 'map',
      title: 'Карта',
      desc: 'Географиялық карта',
      steps: [
        { title: 'Карта дегеніміз', content: 'Жер бетінің кішірейтілген суреті.', keyword: 'Карта' },
        { title: 'Континенттер', content: 'Еуразия, Африка, Солтүстік Америка, Оңтүстік Америка, Австралия, Антарктида.', keyword: 'Континент' },
        { title: 'Мұхиттар', content: 'Тынық, Атлант, Үнді, Солтүстік Мұзды.', keyword: 'Мұхит' }
      ],
      quiz: [
        { q: 'Қанша континент бар?', options: ['4', '6', '7', '8'], answer: 1 },
        { q: 'Қазақстан қай континентте?', options: ['Африка', 'Еуразия', 'Америка'], answer: 1 },
        { q: 'Ең үлкен мұхит?', options: ['Атлант', 'Үнді', 'Тынық'], answer: 2 }
      ]
    }
  ]
};

// State
let currentClass = 1;
let currentLesson = null;
let currentQuizIndex = 0;
let quizScore = 0;

// DOM Elements
const lessonsGrid = document.getElementById('lessonsGrid');
const lessonContent = document.getElementById('lessonContent');
const lessonTitle = document.getElementById('lessonTitle');
const lessonBody = document.getElementById('lessonBody');
const quizContainer = document.getElementById('quizContainer');
const quizResult = document.getElementById('quizResult');
const progressFill = document.getElementById('progressFill');
const totalProgress = document.getElementById('totalProgress');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  loadTheme();
  setupClassButtons();
  renderLessons();
  updateProgress();
  
  document.getElementById('backToLessons').addEventListener('click', showLessons);
  document.getElementById('retryQuiz').addEventListener('click', retryQuiz);
});

function loadTheme() {
  const theme = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', theme);
}

function setupClassButtons() {
  document.querySelectorAll('.class-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.class-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentClass = parseInt(btn.dataset.class);
      renderLessons();
      updateProgress();
    });
  });
}

function renderLessons() {
  const lessons = LESSONS[currentClass] || [];
  lessonsGrid.innerHTML = lessons.map((lesson, index) => {
    const completed = isLessonCompleted(currentClass, lesson.id);
    return `
      <div class="lesson-card ${completed ? 'completed' : ''}" data-index="${index}">
        <div class="lesson-icon">${completed ? '✅' : '📚'}</div>
        <div class="lesson-info">
          <h3>${lesson.title}</h3>
          <p>${lesson.desc}</p>
        </div>
        <div class="lesson-arrow">→</div>
      </div>
    `;
  }).join('');

  document.querySelectorAll('.lesson-card').forEach(card => {
    card.addEventListener('click', () => {
      const index = parseInt(card.dataset.index);
      openLesson(index);
    });
  });
}

function openLesson(index) {
  currentLesson = LESSONS[currentClass][index];
  currentQuizIndex = 0;
  quizScore = 0;

  lessonTitle.textContent = currentLesson.title;
  
  lessonBody.innerHTML = currentLesson.steps.map((step, i) => `
    <div class="step-card">
      <div class="step-number">${i + 1}</div>
      <div class="step-content">
        <h4>${step.title}</h4>
        <p>${step.content}</p>
        <span class="step-keyword">${step.keyword}</span>
      </div>
    </div>
  `).join('');

  document.querySelector('.lessons-section').classList.add('hidden');
  document.querySelector('.class-selection').classList.add('hidden');
  document.querySelector('.progress-section').classList.add('hidden');
  lessonContent.classList.remove('hidden');
  
  renderQuiz();
}

function showLessons() {
  lessonContent.classList.add('hidden');
  document.querySelector('.lessons-section').classList.remove('hidden');
  document.querySelector('.class-selection').classList.remove('hidden');
  document.querySelector('.progress-section').classList.remove('hidden');
  quizResult.classList.add('hidden');
  quizContainer.classList.remove('hidden');
}

function renderQuiz() {
  if (!currentLesson || !currentLesson.quiz) return;
  
  const quiz = currentLesson.quiz[currentQuizIndex];
  if (!quiz) {
    showQuizResult();
    return;
  }

  quizContainer.innerHTML = `
    <div class="quiz-question">
      <div class="quiz-progress">Сұрақ ${currentQuizIndex + 1} / ${currentLesson.quiz.length}</div>
      <h4>${quiz.q}</h4>
      <div class="quiz-options">
        ${quiz.options.map((opt, i) => `
          <button class="quiz-option" data-index="${i}">${opt}</button>
        `).join('')}
      </div>
    </div>
  `;

  document.querySelectorAll('.quiz-option').forEach(btn => {
    btn.addEventListener('click', () => selectAnswer(parseInt(btn.dataset.index)));
  });
}

function selectAnswer(index) {
  const quiz = currentLesson.quiz[currentQuizIndex];
  const buttons = document.querySelectorAll('.quiz-option');
  
  buttons.forEach(btn => btn.disabled = true);
  
  if (index === quiz.answer) {
    buttons[index].classList.add('correct');
    quizScore++;
  } else {
    buttons[index].classList.add('wrong');
    buttons[quiz.answer].classList.add('correct');
  }

  setTimeout(() => {
    currentQuizIndex++;
    renderQuiz();
  }, 1000);
}

function showQuizResult() {
  quizContainer.classList.add('hidden');
  quizResult.classList.remove('hidden');
  
  const total = currentLesson.quiz.length;
  const percent = Math.round((quizScore / total) * 100);
  
  const resultIcon = document.getElementById('resultIcon');
  const resultText = document.getElementById('resultText');
  
  if (percent >= 70) {
    resultIcon.textContent = '🎉';
    resultText.textContent = `Жарайсың! ${quizScore}/${total} дұрыс (${percent}%)`;
    markLessonCompleted(currentClass, currentLesson.id);
    updateProgress();
  } else {
    resultIcon.textContent = '😔';
    resultText.textContent = `${quizScore}/${total} дұрыс (${percent}%). Қайта тырыс!`;
  }
}

function retryQuiz() {
  currentQuizIndex = 0;
  quizScore = 0;
  quizResult.classList.add('hidden');
  quizContainer.classList.remove('hidden');
  renderQuiz();
}

function getProgressKey() {
  return `${SUBJECT_KEY}_progress`;
}

function getProgress() {
  const data = localStorage.getItem(getProgressKey());
  return data ? JSON.parse(data) : {};
}

function saveProgress(progress) {
  localStorage.setItem(getProgressKey(), JSON.stringify(progress));
}

function isLessonCompleted(classNum, lessonId) {
  const progress = getProgress();
  return progress[`${classNum}_${lessonId}`] === true;
}

function markLessonCompleted(classNum, lessonId) {
  const progress = getProgress();
  progress[`${classNum}_${lessonId}`] = true;
  saveProgress(progress);
  renderLessons();
}

function updateProgress() {
  const progress = getProgress();
  let total = 0;
  let completed = 0;

  Object.keys(LESSONS).forEach(classNum => {
    LESSONS[classNum].forEach(lesson => {
      total++;
      if (progress[`${classNum}_${lesson.id}`]) {
        completed++;
      }
    });
  });

  const percent = total > 0 ? Math.round((completed / total) * 100) : 0;
  progressFill.style.width = `${percent}%`;
  totalProgress.textContent = `${percent}%`;
}
