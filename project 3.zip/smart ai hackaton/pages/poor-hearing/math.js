// Математика - Сабақтар мен тесттер
const SUBJECT_KEY = 'math';

const LESSONS = {
  1: [
    {
      id: 'numbers',
      title: 'Сандар',
      desc: '1-ден 10-ға дейін',
      steps: [
        { title: 'Сандарды таны', content: '1, 2, 3, 4, 5, 6, 7, 8, 9, 10 — бұлар сандар.', keyword: 'Сан' },
        { title: 'Санау', content: 'Заттарды санауды үйрен: бір алма, екі алма...', keyword: 'Санау' },
        { title: 'Жазу', content: 'Сандарды дәптерге жазып үйрен.', keyword: 'Жазу' }
      ],
      quiz: [
        { q: '5-тен кейін қай сан келеді?', options: ['4', '6', '7', '3'], answer: 1 },
        { q: 'Қанша саусағың бар?', options: ['5', '8', '10', '12'], answer: 2 },
        { q: '3 + 2 = ?', options: ['4', '5', '6', '7'], answer: 1 }
      ]
    },
    {
      id: 'addition',
      title: 'Қосу',
      desc: 'Қарапайым қосу',
      steps: [
        { title: 'Қосу белгісі', content: '+ белгісі қосуды білдіреді.', keyword: 'Плюс' },
        { title: 'Мысал', content: '2 + 3 = 5. Екі алма мен үш алма — бес алма.', keyword: 'Қосу' },
        { title: 'Жаттығу', content: 'Саусақтарыңмен қосуды үйрен.', keyword: 'Жаттығу' }
      ],
      quiz: [
        { q: '1 + 1 = ?', options: ['1', '2', '3', '0'], answer: 1 },
        { q: '2 + 2 = ?', options: ['3', '4', '5', '2'], answer: 1 },
        { q: '3 + 1 = ?', options: ['2', '3', '4', '5'], answer: 2 }
      ]
    },
    {
      id: 'subtraction',
      title: 'Азайту',
      desc: 'Қарапайым азайту',
      steps: [
        { title: 'Азайту белгісі', content: '- белгісі азайтуды білдіреді.', keyword: 'Минус' },
        { title: 'Мысал', content: '5 - 2 = 3. Бес алмадан екеуін алсаң — үш алма қалады.', keyword: 'Азайту' },
        { title: 'Жаттығу', content: 'Заттармен азайтуды үйрен.', keyword: 'Жаттығу' }
      ],
      quiz: [
        { q: '3 - 1 = ?', options: ['1', '2', '3', '4'], answer: 1 },
        { q: '5 - 2 = ?', options: ['2', '3', '4', '5'], answer: 1 },
        { q: '4 - 4 = ?', options: ['0', '1', '2', '4'], answer: 0 }
      ]
    }
  ],
  2: [
    {
      id: 'multiplication',
      title: 'Көбейту',
      desc: 'Көбейту кестесі',
      steps: [
        { title: 'Көбейту белгісі', content: '× белгісі көбейтуді білдіреді.', keyword: 'Көбейту' },
        { title: 'Мысал', content: '2 × 3 = 6. Екіні үш рет қоссаң — алты.', keyword: 'Мысал' },
        { title: 'Көбейту кестесі', content: '2, 3, 4, 5 көбейткіштерін жаттап ал.', keyword: 'Кесте' }
      ],
      quiz: [
        { q: '2 × 2 = ?', options: ['2', '4', '6', '8'], answer: 1 },
        { q: '3 × 3 = ?', options: ['6', '9', '12', '3'], answer: 1 },
        { q: '5 × 2 = ?', options: ['7', '8', '10', '12'], answer: 2 }
      ]
    },
    {
      id: 'division',
      title: 'Бөлу',
      desc: 'Қарапайым бөлу',
      steps: [
        { title: 'Бөлу белгісі', content: '÷ белгісі бөлуді білдіреді.', keyword: 'Бөлу' },
        { title: 'Мысал', content: '6 ÷ 2 = 3. Алты алманы екіге бөлсең — үш-үштен.', keyword: 'Мысал' },
        { title: 'Жаттығу', content: 'Заттарды тең бөлуді үйрен.', keyword: 'Жаттығу' }
      ],
      quiz: [
        { q: '4 ÷ 2 = ?', options: ['1', '2', '3', '4'], answer: 1 },
        { q: '9 ÷ 3 = ?', options: ['2', '3', '4', '6'], answer: 1 },
        { q: '10 ÷ 5 = ?', options: ['1', '2', '3', '5'], answer: 1 }
      ]
    },
    {
      id: 'comparison',
      title: 'Салыстыру',
      desc: 'Сандарды салыстыру',
      steps: [
        { title: 'Белгілер', content: '< кіші, > үлкен, = тең.', keyword: 'Белгі' },
        { title: 'Мысал', content: '5 > 3 (бес үштен үлкен), 2 < 7 (екі жетіден кіші).', keyword: 'Салыстыру' },
        { title: 'Жаттығу', content: 'Сандарды салыстырып жаз.', keyword: 'Жаттығу' }
      ],
      quiz: [
        { q: '7 ? 3 — қай белгі дұрыс?', options: ['<', '>', '='], answer: 1 },
        { q: '5 ? 5 — қай белгі дұрыс?', options: ['<', '>', '='], answer: 2 },
        { q: '2 ? 8 — қай белгі дұрыс?', options: ['<', '>', '='], answer: 0 }
      ]
    }
  ],
  3: [
    {
      id: 'fractions',
      title: 'Бөлшектер',
      desc: 'Қарапайым бөлшектер',
      steps: [
        { title: 'Бөлшек дегеніміз не?', content: 'Бүтінді бөліктерге бөлу. Мысалы: 1/2 — жарты.', keyword: 'Бөлшек' },
        { title: 'Алым мен бөлім', content: 'Алым — үстіңгі сан, бөлім — астыңғы сан.', keyword: 'Алым' },
        { title: 'Мысалдар', content: '1/4 — төрттен бір, 3/4 — төрттен үш.', keyword: 'Мысал' }
      ],
      quiz: [
        { q: '1/2 қалай оқылады?', options: ['Бір бүтін', 'Жарты', 'Екі', 'Төрттен бір'], answer: 1 },
        { q: 'Бөлшектің астыңғы саны қалай аталады?', options: ['Алым', 'Бөлім', 'Сан', 'Қосынды'], answer: 1 },
        { q: '3/4 — бұл қанша?', options: ['Төрттен бір', 'Жарты', 'Төрттен үш', 'Үш'], answer: 2 }
      ]
    },
    {
      id: 'geometry',
      title: 'Геометрия',
      desc: 'Фигуралар',
      steps: [
        { title: 'Негізгі фигуралар', content: 'Шеңбер, үшбұрыш, төртбұрыш, тіктөртбұрыш.', keyword: 'Фигура' },
        { title: 'Периметр', content: 'Периметр — фигураның барлық қабырғаларының қосындысы.', keyword: 'Периметр' },
        { title: 'Аудан', content: 'Аудан — фигураның ішкі бөлігі.', keyword: 'Аудан' }
      ],
      quiz: [
        { q: 'Үшбұрыштың неше қабырғасы бар?', options: ['2', '3', '4', '5'], answer: 1 },
        { q: 'Шеңбердің қабырғасы бар ма?', options: ['Иә', 'Жоқ'], answer: 1 },
        { q: 'Квадраттың барлық қабырғалары...', options: ['Әртүрлі', 'Тең', 'Жоқ'], answer: 1 }
      ]
    },
    {
      id: 'equations',
      title: 'Теңдеулер',
      desc: 'Қарапайым теңдеулер',
      steps: [
        { title: 'Теңдеу дегеніміз не?', content: 'Белгісізі бар теңдік. Мысалы: x + 2 = 5.', keyword: 'Теңдеу' },
        { title: 'Шешу', content: 'x-ті табу керек. x + 2 = 5 болса, x = 3.', keyword: 'Шешу' },
        { title: 'Тексеру', content: 'Жауапты теңдеуге қойып тексер.', keyword: 'Тексеру' }
      ],
      quiz: [
        { q: 'x + 3 = 7, x = ?', options: ['3', '4', '5', '10'], answer: 1 },
        { q: 'x - 2 = 5, x = ?', options: ['3', '5', '7', '10'], answer: 2 },
        { q: '2 × x = 8, x = ?', options: ['2', '4', '6', '8'], answer: 1 }
      ]
    }
  ],
  4: [
    {
      id: 'decimals',
      title: 'Ондық бөлшектер',
      desc: 'Ондық сандар',
      steps: [
        { title: 'Ондық бөлшек', content: '0.5, 1.25, 3.14 — ондық бөлшектер.', keyword: 'Ондық' },
        { title: 'Оқу', content: '0.5 — нөл бүтін оннан бес.', keyword: 'Оқу' },
        { title: 'Амалдар', content: 'Ондық бөлшектермен қосу, азайту.', keyword: 'Амал' }
      ],
      quiz: [
        { q: '0.5 + 0.5 = ?', options: ['0.10', '1', '0.55', '10'], answer: 1 },
        { q: '1.5 - 0.5 = ?', options: ['0.5', '1', '2', '1.0'], answer: 1 },
        { q: '0.25 қалай оқылады?', options: ['Ширек', 'Жарты', 'Нөл бүтін жүзден жиырма бес', 'Екі бес'], answer: 2 }
      ]
    },
    {
      id: 'area',
      title: 'Аудан есептеу',
      desc: 'Фигуралар ауданы',
      steps: [
        { title: 'Тіктөртбұрыш ауданы', content: 'S = a × b (ұзындық × ен).', keyword: 'Формула' },
        { title: 'Квадрат ауданы', content: 'S = a × a (қабырға × қабырға).', keyword: 'Квадрат' },
        { title: 'Өлшем бірліктері', content: 'см², м², км² — аудан өлшемдері.', keyword: 'Өлшем' }
      ],
      quiz: [
        { q: 'Квадраттың қабырғасы 3 см. Ауданы қанша?', options: ['6 см²', '9 см²', '12 см²', '3 см²'], answer: 1 },
        { q: 'Тіктөртбұрыш: 4 см × 5 см. Ауданы?', options: ['9 см²', '18 см²', '20 см²', '25 см²'], answer: 2 },
        { q: 'Аудан қандай өлшеммен өлшенеді?', options: ['см', 'см²', 'см³', 'кг'], answer: 1 }
      ]
    },
    {
      id: 'problems',
      title: 'Есептер',
      desc: 'Мәтінді есептер',
      steps: [
        { title: 'Есепті оқу', content: 'Есепті мұқият оқып, не сұралғанын түсін.', keyword: 'Оқу' },
        { title: 'Шешу жоспары', content: 'Қандай амал керек екенін анықта.', keyword: 'Жоспар' },
        { title: 'Жауап', content: 'Есепті шеш және жауабын жаз.', keyword: 'Жауап' }
      ],
      quiz: [
        { q: 'Әсемде 5 алма, Айгүлде 3 алма. Барлығы қанша?', options: ['2', '8', '15', '35'], answer: 1 },
        { q: '12 кітаптың 4-еуін оқыдым. Қаншасы қалды?', options: ['4', '8', '12', '16'], answer: 1 },
        { q: '3 қорапта 6-дан алма бар. Барлығы қанша?', options: ['9', '18', '12', '36'], answer: 1 }
      ]
    }
  ]
};

// State
let currentClass = 1;
let currentLesson = null;
let currentQuizIndex = 0;
let quizScore = 0;

// DOM Elements
const lessonsGrid = document.getElementById('lessonsGrid');
const lessonContent = document.getElementById('lessonContent');
const lessonTitle = document.getElementById('lessonTitle');
const lessonBody = document.getElementById('lessonBody');
const quizContainer = document.getElementById('quizContainer');
const quizResult = document.getElementById('quizResult');
const progressFill = document.getElementById('progressFill');
const totalProgress = document.getElementById('totalProgress');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  loadTheme();
  setupClassButtons();
  renderLessons();
  updateProgress();
  
  document.getElementById('backToLessons').addEventListener('click', showLessons);
  document.getElementById('retryQuiz').addEventListener('click', retryQuiz);
});

function loadTheme() {
  const theme = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', theme);
}

function setupClassButtons() {
  document.querySelectorAll('.class-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.class-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentClass = parseInt(btn.dataset.class);
      renderLessons();
      updateProgress();
    });
  });
}

function renderLessons() {
  const lessons = LESSONS[currentClass] || [];
  lessonsGrid.innerHTML = lessons.map((lesson, index) => {
    const completed = isLessonCompleted(currentClass, lesson.id);
    return `
      <div class="lesson-card ${completed ? 'completed' : ''}" data-index="${index}">
        <div class="lesson-icon">${completed ? '✅' : '📚'}</div>
        <div class="lesson-info">
          <h3>${lesson.title}</h3>
          <p>${lesson.desc}</p>
        </div>
        <div class="lesson-arrow">→</div>
      </div>
    `;
  }).join('');

  document.querySelectorAll('.lesson-card').forEach(card => {
    card.addEventListener('click', () => {
      const index = parseInt(card.dataset.index);
      openLesson(index);
    });
  });
}

function openLesson(index) {
  currentLesson = LESSONS[currentClass][index];
  currentQuizIndex = 0;
  quizScore = 0;

  lessonTitle.textContent = currentLesson.title;
  
  // Render steps
  lessonBody.innerHTML = currentLesson.steps.map((step, i) => `
    <div class="step-card">
      <div class="step-number">${i + 1}</div>
      <div class="step-content">
        <h4>${step.title}</h4>
        <p>${step.content}</p>
        <span class="step-keyword">${step.keyword}</span>
      </div>
    </div>
  `).join('');

  // Show lesson, hide lessons grid
  document.querySelector('.lessons-section').classList.add('hidden');
  document.querySelector('.class-selection').classList.add('hidden');
  document.querySelector('.progress-section').classList.add('hidden');
  lessonContent.classList.remove('hidden');
  
  // Render first quiz question
  renderQuiz();
}

function showLessons() {
  lessonContent.classList.add('hidden');
  document.querySelector('.lessons-section').classList.remove('hidden');
  document.querySelector('.class-selection').classList.remove('hidden');
  document.querySelector('.progress-section').classList.remove('hidden');
  quizResult.classList.add('hidden');
  quizContainer.classList.remove('hidden');
}

function renderQuiz() {
  if (!currentLesson || !currentLesson.quiz) return;
  
  const quiz = currentLesson.quiz[currentQuizIndex];
  if (!quiz) {
    showQuizResult();
    return;
  }

  quizContainer.innerHTML = `
    <div class="quiz-question">
      <div class="quiz-progress">Сұрақ ${currentQuizIndex + 1} / ${currentLesson.quiz.length}</div>
      <h4>${quiz.q}</h4>
      <div class="quiz-options">
        ${quiz.options.map((opt, i) => `
          <button class="quiz-option" data-index="${i}">${opt}</button>
        `).join('')}
      </div>
    </div>
  `;

  document.querySelectorAll('.quiz-option').forEach(btn => {
    btn.addEventListener('click', () => selectAnswer(parseInt(btn.dataset.index)));
  });
}

function selectAnswer(index) {
  const quiz = currentLesson.quiz[currentQuizIndex];
  const buttons = document.querySelectorAll('.quiz-option');
  
  buttons.forEach(btn => btn.disabled = true);
  
  if (index === quiz.answer) {
    buttons[index].classList.add('correct');
    quizScore++;
  } else {
    buttons[index].classList.add('wrong');
    buttons[quiz.answer].classList.add('correct');
  }

  setTimeout(() => {
    currentQuizIndex++;
    renderQuiz();
  }, 1000);
}

function showQuizResult() {
  quizContainer.classList.add('hidden');
  quizResult.classList.remove('hidden');
  
  const total = currentLesson.quiz.length;
  const percent = Math.round((quizScore / total) * 100);
  
  const resultIcon = document.getElementById('resultIcon');
  const resultText = document.getElementById('resultText');
  
  if (percent >= 70) {
    resultIcon.textContent = '🎉';
    resultText.textContent = `Жарайсың! ${quizScore}/${total} дұрыс (${percent}%)`;
    markLessonCompleted(currentClass, currentLesson.id);
    updateProgress();
  } else {
    resultIcon.textContent = '😔';
    resultText.textContent = `${quizScore}/${total} дұрыс (${percent}%). Қайта тырыс!`;
  }
}

function retryQuiz() {
  currentQuizIndex = 0;
  quizScore = 0;
  quizResult.classList.add('hidden');
  quizContainer.classList.remove('hidden');
  renderQuiz();
}

// Progress functions
function getProgressKey() {
  return `${SUBJECT_KEY}_progress`;
}

function getProgress() {
  const data = localStorage.getItem(getProgressKey());
  return data ? JSON.parse(data) : {};
}

function saveProgress(progress) {
  localStorage.setItem(getProgressKey(), JSON.stringify(progress));
}

function isLessonCompleted(classNum, lessonId) {
  const progress = getProgress();
  return progress[`${classNum}_${lessonId}`] === true;
}

function markLessonCompleted(classNum, lessonId) {
  const progress = getProgress();
  progress[`${classNum}_${lessonId}`] = true;
  saveProgress(progress);
  renderLessons();
}

function updateProgress() {
  const progress = getProgress();
  let total = 0;
  let completed = 0;

  Object.keys(LESSONS).forEach(classNum => {
    LESSONS[classNum].forEach(lesson => {
      total++;
      if (progress[`${classNum}_${lesson.id}`]) {
        completed++;
      }
    });
  });

  const percent = total > 0 ? Math.round((completed / total) * 100) : 0;
  progressFill.style.width = `${percent}%`;
  totalProgress.textContent = `${percent}%`;
}
