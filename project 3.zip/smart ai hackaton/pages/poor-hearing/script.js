// Language system
let currentLanguage = localStorage.getItem('language') || 'ru';

// Статус хабарламаларын сақтайтын объект
let schoolTaskStatus = {
    kk: "Дайынсыз ба?",
    ru: "Готовы?"
};

// Сөйлем құрастыруға арналған массив (алдыңғы сұраныс бойынша)
let currentSentence = [];

// Translations
const translations = {
    ru: {
        backLink: '← Назад на главную',
        mainTitle: 'Я плохо слышу',
        moduleTitle: '← Модуль для Слабослышащих',
        speechRecognitionTitle: 'Распознавание речи (Speech-to-Text)',
        startRecording: 'Начать запись',
        stopRecording: 'Остановить запись',
        demoMode: 'Демо-режим (Mock AI)',
        speechInputPlaceholder: 'Скажите что-нибудь...',
        subtitlesMode: 'Режим Субтитры',
        emojiStatus: 'Эмодзи-статус',
        colorHighlight: 'Цветовое выделение',
        visualRhythm: 'Визуальный ритм',
        gestureTranslationTitle: 'Перевод в Жесты',
        gestureInputPlaceholder: 'Введите слово (напр. Привет, Помощь)',
        gifNotFound: 'GIF не найдено',
        gestureLabel: 'Ишарат',
        loadingGif: 'GIF жүктелуде...',
        gestureSuggestion: 'Попробуйте: Привет, Помощь',
        themeDark: 'Тёмная',
        themeLight: 'Светлая',
        quickPhrasesHeader: 'Быстрые фразы',
        hello: 'привет',
        help: 'помощь',
        thanks: 'спасибо',
        please: 'пожалуйста',
        yes: 'да',
        signLanguageMode: 'Режим Жестовый язык',
        cameraInactive: 'Камера не активна',
        cameraActive: 'Камера активна - Отслеживание рук...',
        enableCamera: 'Включить камеру',
        disableCamera: 'Выключить камеру',
        gestureCorrect: 'Жест выполнен верно',
        gestureNeedsCorrection: 'Требуется корректировка',
        calibrateHand: 'Калибровать руку',
        calibrationInstructions: 'Поместите руку в центр кадра и нажмите "Калибровать"',
        calibrationComplete: 'Калибровка завершена',
        handNotVisible: 'Рука не видна полностью',
        handTooClose: 'Рука слишком близко',
        handTooFar: 'Рука слишком далеко',
        handPositionGood: 'Положение руки хорошее',
        gestureStability: 'Стабильность жеста',
        sensitivity: 'Чувствительность',
        low: 'Низкая',
        medium: 'Средняя',
        high: 'Высокая',
        useButtons: 'Использовать кнопки',
        gestureButtons: 'Кнопки жестов',
        resetCalibration: 'Сбросить калибровку',
        diagnostics: 'Диагностика',
        cameraStatus: 'Статус камеры',
        cameraConnected: 'Камера подключена',
        cameraNotConnected: 'Камера не подключена',
        cameraError: 'Ошибка камеры',
        videoStreamActive: 'Видеопоток активен',
        videoStreamInactive: 'Видеопоток неактивен',
        handDetected: 'Рука обнаружена',
        handNotDetected: 'Рука не обнаружена',
        lightingGood: 'Освещение хорошее',
        lightingPoor: 'Освещение плохое',
        distanceOptimal: 'Расстояние оптимальное (30-70 см)',
        distanceTooClose: 'Слишком близко (< 30 см)',
        distanceTooFar: 'Слишком далеко (> 70 см)',
        angleGood: 'Угол хороший',
        angleBad: 'Отрегулируйте угол камеры',
        coordinates: 'Координаты',
        fps: 'FPS',
        tips: 'Советы',
        tip1: 'Убедитесь, что камера включена и доступна',
        tip2: 'Проверьте освещение - используйте ровный свет',
        tip3: 'Держите руку на расстоянии 30-70 см от камеры',
        tip4: 'Рука должна быть полностью видна в кадре',
        tip5: 'Избегайте резких теней и яркого фона',
        tip6: 'Попробуйте открыть камеру в другом приложении',
        showDiagnostics: 'Показать диагностику',
        hideDiagnostics: 'Скрыть диагностику',
        soundMonitoringTitle: 'Мониторинг Звуков',
        noiseLevel: 'Уровень шума',
        enable: 'Включить',
        disable: 'Выключить',
        test: 'Тест',
        soundMonitoringDescription: 'При обнаружении резкого громкого звука (крик, скрежет) экран станет красным и телефон завибрирует',
        environmentIndicators: 'Индикаторы окружения',
        silence: 'Тишина',
        normal: 'Норма',
        loud: 'Громко',
        loudSoundAlert: '⚠️ Обнаружен громкий звук!',
        loudSoundDescription: 'Экран будет красным до тех пор, пока звук не утихнет',
        subtitlesWelcome: 'Субтитры появятся здесь...',
        gestureRecognized: 'Жест распознан правильно',
        gestureNeedsFix: 'Жест требует корректировки',
        followHints: 'Следуйте подсказкам на экране',
        accuracy: 'Точность',
        confidence: 'Уверенность',
        translation: 'Перевод',
        microphonePermissionDenied: 'Разрешение на использование микрофона не предоставлено',
        cameraPermissionDenied: 'Не удалось получить доступ к камере. Убедитесь, что вы предоставили разрешение на использование камеры.',
        speechNotSupported: 'Распознавание речи не поддерживается в вашем браузере. Используйте демо-режим.',
        recognitionLanguage: 'Язык распознавания:',
        realtimeSubtitlesTitle: 'Субтитры в реальном времени',
        startRealtimeSubtitles: 'Включить субтитры',
        stopRealtimeSubtitles: 'Остановить субтитры',
        realtimeSubtitlesDescription: 'Речь вокруг вас распознаётся и показывается как субтитры с указанием говорящего.',
        speakerUnknown: 'Говорящий',
        speaker1: 'Говорящий 1',
        speaker2: 'Говорящий 2',
        speaker3: 'Говорящий 3',
        speaker4: 'Говорящий 4',
        speaker5: 'Говорящий 5',
        speakerMom: 'Мама',
        speakerDad: 'Папа',
        speakerChef: 'Повар',
        speakerFriend: 'Друг',
        speakerTeacher: 'Учитель',
        speakerDoctor: 'Врач',
        speakerNurse: 'Медсестра',
        speakerColleague: 'Коллега',
        speakerChild: 'Ребенок',
        speakerWoman: 'Женщина',
        speakerMan: 'Мужчина',
        noActiveSpeakers: 'Нажмите «Включить субтитры» — распознанная речь появится здесь.',
        detectingSpeakers: 'Определение говорящих...',
        utterances: 'высказываний',
        activeSpeakers: 'Активные говорящие:',
        multiLangTranslationLabel: 'Умный мультиязычный перевод (AI)',
        multiLangTranslationHint: 'Говорите на казахском, русском или английском — субтитры автоматически покажутся на выбранном языке интерфейса.',
        gamificationTitle: 'Ваш прогресс в жестовом языке',
        currentLevel: 'Уровень',
        dailyStreak: 'Серия дней',
        totalGestures: 'Изучено жестов',
        todayPoints: 'Очки за сегодня',
        gamificationHint: 'Повторяйте жесты точно, чтобы зарабатывать очки и повышать уровень!',
        levelUpMessage: 'Отлично! Вы достигли нового уровня',
        levelLabel: 'Уровень',
        celebrationText: 'Молодец!',
        learningMode: 'Режим обучения',
        showAgainHint: 'Хорошо! Покажи еще один раз!',
        enableSmartMode: 'Включить Smart‑режим (SignAI)',
        disableSmartMode: 'Выключить Smart‑режим',
        // Школьные предметы
        selectSubject: 'Выберите предмет',
        subjectMath: 'Математика',
        subjectRussian: 'Русский язык',
        subjectWorld: 'Окружающий мир',
        lessonComplete: 'Урок окончен! Ты супер!',
        showGesture: 'Покажи',
        repeatOnce: 'Хорошо! Повтори еще раз!',
        startLesson: 'Начинаем урок',
        // lip reading removed
    },
    kk: {
        backLink: '← Басты бетке оралу',
        mainTitle: 'Мен нашар естимін',
        moduleTitle: '← Есту қабілеті нашарларға арналған модуль',
        speechRecognitionTitle: 'Сөйлеуді тану (Speech-to-Text)',
        startRecording: 'Жазбаны бастау',
        stopRecording: 'Жазбаны тоқтату',
        demoMode: 'Демо-режим (Mock AI)',
        speechInputPlaceholder: 'Бірдеңе айтыңыз...',
        subtitlesMode: 'Субтитрлер режимі',
        emojiStatus: 'Эмодзи-статус',
        colorHighlight: 'Түстік ерекшелеу',
        visualRhythm: 'Көрнекі ритм',
        gestureTranslationTitle: 'Ишаратқа аударма',
        gestureInputPlaceholder: 'Сөзді енгізіңіз (мысалы: Сәлем, Көмек)',
        gifNotFound: 'GIF табылмады',
        gestureSuggestion: 'Көріңіз: Сәлем, Көмек',
        themeDark: 'Қараңғы',
        themeLight: 'Жарық',
        quickPhrasesHeader: 'Жылдам тіркестер',
        hello: 'сәлем',
        help: 'көмек',
        thanks: 'рахмет',
        please: 'өтінемін',
        yes: 'иә',
        signLanguageMode: 'Ишарат тілі режимі',
        cameraInactive: 'Камера белсенді емес',
        cameraActive: 'Камера белсенді - Қолдарды бақылау...',
        enableCamera: 'Камераны қосу',
        disableCamera: 'Камераны өшіру',
        gestureCorrect: 'Ишарат дұрыс орындалды',
        gestureNeedsCorrection: 'Түзету қажет',
        calibrateHand: 'Қолды калибрлеу',
        calibrationInstructions: 'Қолды кадрдың ортасына орналастырып, "Калибрлеу" батырмасын басыңыз',
        calibrationComplete: 'Калибрлеу аяқталды',
        handNotVisible: 'Қол толығымен көрінбейді',
        handTooClose: 'Қол тым жақын',
        handTooFar: 'Қол тым алыс',
        handPositionGood: 'Қолдың орналасуы жақсы',
        gestureStability: 'Ишарат тұрақтылығы',
        sensitivity: 'Сезімталдық',
        low: 'Төмен',
        medium: 'Орташа',
        high: 'Жоғары',
        useButtons: 'Батырмаларды пайдалану',
        gestureButtons: 'Ишарат батырмалары',
        resetCalibration: 'Калибрлеуді қалпына келтіру',
        diagnostics: 'Диагностика',
        cameraStatus: 'Камера күйі',
        cameraConnected: 'Камера қосылған',
        cameraNotConnected: 'Камера қосылмаған',
        cameraError: 'Камера қатесі',
        videoStreamActive: 'Бейне ағыны белсенді',
        videoStreamInactive: 'Бейне ағыны белсенді емес',
        handDetected: 'Қол анықталды',
        handNotDetected: 'Қол анықталмады',
        lightingGood: 'Жарықтану жақсы',
        lightingPoor: 'Жарықтану нашар',
        distanceOptimal: 'Қашықтық оңтайлы (30-70 см)',
        distanceTooClose: 'Тым жақын (< 30 см)',
        distanceTooFar: 'Тым алыс (> 70 см)',
        angleGood: 'Бұрыш жақсы',
        angleBad: 'Камера бұрышын реттеңіз',
        coordinates: 'Координаттар',
        fps: 'FPS',
        tips: 'Кеңестер',
        tip1: 'Камера қосылғанын және қолжетімді екенін тексеріңіз',
        tip2: 'Жарықтануды тексеріңіз - тегіс жарық пайдаланыңыз',
        tip3: 'Қолды камерадан 30-70 см қашықтықта ұстаңыз',
        tip4: 'Қол кадрда толығымен көрінуі керек',
        tip5: 'Күрт көлеңкелер мен жарқын фоннан аулақ болыңыз',
        tip6: 'Камераны басқа қолданбада ашуға тырысыңыз',
        showDiagnostics: 'Диагностиканы көрсету',
        hideDiagnostics: 'Диагностиканы жасыру',
        soundMonitoringTitle: 'Дыбыстарды бақылау',
        noiseLevel: 'Шу деңгейі',
        enable: 'Қосу',
        disable: 'Өшіру',
        test: 'Тест',
        soundMonitoringDescription: 'Күрт қатты дыбыс анықталған кезде (айқай, сырғу) экран қызыл болады және телефон дірілдейді',
        environmentIndicators: 'Қоршаған орта көрсеткіштері',
        silence: 'Үнсіздік',
        normal: 'Қалыпты',
        loud: 'Қатты',
        loudSoundAlert: '⚠️ Қатты дыбыс анықталды!',
        loudSoundDescription: 'Дыбыс басылғанша экран қызыл болады',
        subtitlesWelcome: 'Субтитрлер осы жерде пайда болады...',
        gestureRecognized: 'Ишарат дұрыс танылды',
        gestureNeedsFix: 'Ишарат түзетуді қажет етеді',
        followHints: 'Экрандағы кеңестерді орындаңыз',
        accuracy: 'Дәлдік',
        confidence: 'Сенімділік',
        translation: 'Аударма',
        placeHandInFrame: 'Қолды кадрға орналастырыңыз',
        microphonePermissionDenied: 'Микрофонды пайдалануға рұқсат берілмеді',
        cameraPermissionDenied: 'Камераға қол жеткізу мүмкін болмады. Камераны пайдалануға рұқсат бергеніңізді тексеріңіз.',
        speechNotSupported: 'Сөйлеуді тану сіздің браузеріңізде қолдау көрсетілмейді. Демо-режимді пайдаланыңыз.',
        recognitionLanguage: 'Таныту тілі:',
        realtimeSubtitlesTitle: 'Нақты уақытта субтитрлер',
        startRealtimeSubtitles: 'Субтитрлерді қосу',
        stopRealtimeSubtitles: 'Субтитрлерді тоқтату',
        realtimeSubtitlesDescription: 'Айналаңыздағы сөйлеу танылып, сөйлеуші көрсетіліп субтитр ретінде көрсетіледі.',
        speakerUnknown: 'Сөйлеуші',
        speaker1: 'Сөйлеуші 1',
        speaker2: 'Сөйлеуші 2',
        speaker3: 'Сөйлеуші 3',
        speaker4: 'Сөйлеуші 4',
        speaker5: 'Сөйлеуші 5',
        speakerMom: 'Ана',
        speakerDad: 'Әке',
        speakerChef: 'Аспазшы',
        speakerFriend: 'Дос',
        speakerTeacher: 'Мұғалім',
        speakerDoctor: 'Дәрігер',
        speakerNurse: 'Медбике',
        speakerColleague: 'Қызметтес',
        speakerChild: 'Бала',
        speakerWoman: 'Әйел',
        speakerMan: 'Ер',
        noActiveSpeakers: '«Субтитрлерді қосу» батырмасын басыңыз — танылған сөйлеу осы жерде пайда болады.',
        detectingSpeakers: 'Сөйлеушілерді анықтау...',
        utterances: 'айтылымдар',
        activeSpeakers: 'Белсенді сөйлеушілер:',
        multiLangTranslationLabel: 'Ақылды көптілді аударма (AI)',
        multiLangTranslationHint: 'Қазақша, орысша немесе ағылшынша сөйлеңіз — субтитрлер таңдалған интерфейс тілінде көрсетіледі.',
        gamificationTitle: 'Ишарат тіліндегі прогрессіңіз',
        currentLevel: 'Деңгей',
        dailyStreak: 'Күндік серия',
        totalGestures: 'Үйренген ишараттар',
        todayPoints: 'Бүгінгі ұпайлар',
        gamificationHint: 'Ишаратарды дәл қайталап, ұпай жинап, деңгейіңізді көтеріңіз!',
        levelUpMessage: 'Керемет! Сіз жаңа деңгейге жеттіңіз',
        levelLabel: 'Деңгей',
        celebrationText: 'Жарайсың!',
        learningMode: 'Оқу режимі',
        showAgainHint: 'Жақсы! Тағы бір рет көрсет!',
        enableSmartMode: 'Smart режимін қосу (SignAI)',
        disableSmartMode: 'Smart режимін өшіру',
        // Мектеп пәндері
        selectSubject: 'Пәнді таңдаңыз',
        subjectMath: 'Математика',
        subjectRussian: 'Орыс тілі',
        subjectWorld: 'Дүниетану',
        lessonComplete: 'Сабақ аяқталды! Сен кереметсің!',
        showGesture: 'Көрсет',
        repeatOnce: 'Жақсы! Тағы бір рет қайтала!',
        startLesson: 'Сабақты бастаймыз',
        // lip reading removed
    }
};

// Gamification system for sign language learning
const GAMIFICATION_STORAGE_KEY = 'signLanguageGamification';
const GAMIFICATION_XP_PER_GESTURE = 10;
const GAMIFICATION_XP_PER_LEVEL = 50;

let gamificationState = null;
let lastGestureWasSuccess = false;

// Lip Reading Assistant removed

function getTodayDateKey() {
    const now = new Date();
    return now.toISOString().slice(0, 10);
}

function loadGamificationState() {
    try {
        const raw = localStorage.getItem(GAMIFICATION_STORAGE_KEY);
        if (!raw) {
            return {
                totalXp: 0,
                level: 1,
                streak: 0,
                bestStreak: 0,
                totalGestures: 0,
                todayXp: 0,
                dateKey: null,
                lastAwardTimestamp: 0
            };
        }
        const parsed = JSON.parse(raw);
        return {
            totalXp: parsed.totalXp || 0,
            level: parsed.level || 1,
            streak: parsed.streak || 0,
            bestStreak: parsed.bestStreak || 0,
            totalGestures: parsed.totalGestures || 0,
            todayXp: parsed.todayXp || 0,
            dateKey: parsed.dateKey || null,
            lastAwardTimestamp: parsed.lastAwardTimestamp || 0
        };
    } catch (e) {
        console.warn('Failed to load gamification state, resetting.', e);
        return {
            totalXp: 0,
            level: 1,
            streak: 0,
            bestStreak: 0,
            totalGestures: 0,
            todayXp: 0,
            dateKey: null,
            lastAwardTimestamp: 0
        };
    }
}

function saveGamificationState() {
    try {
        if (!gamificationState) return;
        localStorage.setItem(GAMIFICATION_STORAGE_KEY, JSON.stringify(gamificationState));
    } catch (e) {
        console.warn('Failed to save gamification state.', e);
    }
}

function calculateLevelFromXp(xp) {
    if (xp < 0) xp = 0;
    return Math.floor(xp / GAMIFICATION_XP_PER_LEVEL) + 1;
}

function getLevelProgress(xp) {
    const level = calculateLevelFromXp(xp);
    const currentLevelBaseXp = (level - 1) * GAMIFICATION_XP_PER_LEVEL;
    const currentXpInLevel = xp - currentLevelBaseXp;
    return {
        level,
        currentXpInLevel,
        xpForLevel: GAMIFICATION_XP_PER_LEVEL
    };
}

function updateGamificationUI() {
    try {
        if (!gamificationState) return;

        const card = document.getElementById('gamificationCard');
        if (!card) return;

        const progress = getLevelProgress(gamificationState.totalXp);
        const levelBadge = document.getElementById('gamificationLevelBadge');
        const xpText = document.getElementById('gamificationXpText');
        const xpFill = document.getElementById('gamificationXpFill');
        const streakEl = document.getElementById('gamificationStreak');
        const totalGesturesEl = document.getElementById('gamificationTotalGestures');
        const todayXpEl = document.getElementById('gamificationTodayXp');

        const levelLabel = translations[currentLanguage]?.levelLabel || 'Уровень';

        if (levelBadge) {
            levelBadge.textContent = `${levelLabel} ${progress.level}`;
        }

        if (xpText) {
            xpText.textContent = `${progress.currentXpInLevel} / ${progress.xpForLevel} XP`;
        }

        if (xpFill) {
            const percent = Math.max(0, Math.min(100, (progress.currentXpInLevel / progress.xpForLevel) * 100));
            xpFill.style.width = `${percent}%`;
        }

        if (streakEl) {
            const flame = '🔥';
            streakEl.textContent = `${gamificationState.streak}${flame}`;
        }

        if (totalGesturesEl) {
            totalGesturesEl.textContent = gamificationState.totalGestures.toString();
        }

        if (todayXpEl) {
            todayXpEl.textContent = gamificationState.todayXp.toString();
        }
    } catch (e) {
        console.warn('Failed to update gamification UI.', e);
    }
}

function handleGestureSuccessForGamification() {
    try {
        if (!gamificationState) {
            gamificationState = loadGamificationState();
        }

        const now = Date.now();
        // Simple cooldown to avoid multiple rewards from a single long gesture
        if (gamificationState.lastAwardTimestamp && (now - gamificationState.lastAwardTimestamp) < 3000) {
            return;
        }

        const todayKey = getTodayDateKey();

        // Day / streak handling
        if (gamificationState.dateKey === todayKey) {
            // Same day – keep streak
        } else {
            if (gamificationState.dateKey) {
                const prev = new Date(gamificationState.dateKey);
                const today = new Date(todayKey);
                const diffMs = today.getTime() - prev.getTime();
                const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));

                if (diffDays === 1) {
                    gamificationState.streak += 1;
                } else {
                    gamificationState.streak = 1;
                }
            } else {
                gamificationState.streak = 1;
            }
            gamificationState.dateKey = todayKey;
            gamificationState.todayXp = 0;
        }

        if (gamificationState.streak > gamificationState.bestStreak) {
            gamificationState.bestStreak = gamificationState.streak;
        }

        const previousLevel = gamificationState.level;

        gamificationState.totalXp += GAMIFICATION_XP_PER_GESTURE;
        gamificationState.todayXp += GAMIFICATION_XP_PER_GESTURE;
        gamificationState.totalGestures += 1;
        gamificationState.level = calculateLevelFromXp(gamificationState.totalXp);
        gamificationState.lastAwardTimestamp = now;

        saveGamificationState();
        updateGamificationUI();

        if (gamificationState.level > previousLevel) {
            const hintEl = document.getElementById('gamificationHint');
            if (hintEl) {
                const msg = translations[currentLanguage]?.levelUpMessage || 'Вы достигли нового уровня!';
                hintEl.textContent = `${msg} ${gamificationState.level}`;
            }
        }
    } catch (e) {
        console.error('Error in gesture gamification handler:', e);
    }
}

/** Candy salute effect on successful gesture — confetti-style emojis and celebration text. */
function spawnCandyExplosion() {
    const candyContainer = document.createElement('div');
    candyContainer.style.cssText = 'position:fixed; inset:0; pointer-events:none; z-index:9999;';
    document.body.appendChild(candyContainer);

    const types = ['\uD83C\uDF6C', '\uD83C\uDF6D', '\uD83C\uDF6B', '\u2728'];
    for (let i = 0; i < 20; i++) {
        const el = document.createElement('div');
        el.textContent = types[Math.floor(Math.random() * types.length)];
        el.style.cssText = 'position:absolute; left:50%; top:50%; font-size:30px; transition:all 1s ease-out;';
        candyContainer.appendChild(el);
        setTimeout(() => {
            const tx = (Math.random() - 0.5) * 600;
            const ty = (Math.random() - 0.5) * 600;
            el.style.transform = `translate(${tx}px, ${ty}px) rotate(${tx}deg)`;
            el.style.opacity = '0';
        }, 10);
    }

    const txt = document.createElement('h1');
    txt.textContent = translations[currentLanguage]?.celebrationText || 'Молодец!';
    txt.style.cssText = 'position:fixed; top:40%; left:50%; transform:translate(-50%,-50%); font-size:clamp(48px, 10vw, 100px); color:#FF4500; font-family:Arial,sans-serif; text-shadow:4px 4px #FFD700; margin:0;';
    candyContainer.appendChild(txt);

    setTimeout(() => candyContainer.remove(), 2000);
}

// Speech Recognition and Subtitles
let recognition = null;
let isRecording = false;
let subtitlesHistory = [];
let lastSubtitleText = '';
let interimSubtitleElement = null;
let recognitionTimeout = null;

// Создать новый экземпляр распознавания (для повторного запуска после stop)
function createRecognitionInstance() {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) return null;
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const rec = new SpeechRecognition();
    rec.continuous = true;
    rec.interimResults = true;
    const lang = (currentLanguage === 'kk') ? 'kk-KZ' : 'ru-RU';
    rec.lang = lang;
    return rec;
}

// Initialize Web Speech API
if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
    recognition = createRecognitionInstance();
    if (recognition) {
        console.log('Speech recognition initialized with language:', recognition.lang);
    }
}

// Emoji status mapping
const emojiMap = {
    happy: '😊',
    sad: '😔',
    angry: '😠',
    neutral: '😐',
    surprised: '😲',
    thinking: '🤔'
};

// Important words for highlighting
const importantWords = {
    ru: ['помощь', 'помоги', 'спасибо', 'пожалуйста', 'привет', 'здравствуй', 'пока', 'дом', 'работа', 'врач', 'больница'],
    kk: ['көмек', 'көмектес', 'рахмет', 'өтінемін', 'сәлем', 'сау бол', 'қош', 'үй', 'жұмыс', 'дәрігер', 'аурухана']
};

// Auto-detect emotion from text (supports Russian and Kazakh)
function detectEmotion(text) {
    if (!text) return 'neutral';
    
    // Normalize text - remove extra spaces and convert to lowercase
    const normalizedText = text.trim().toLowerCase().replace(/\s+/g, ' ');
    const lowerText = normalizedText;
    
    // Happy emotions (Russian and Kazakh)
    const happyWords = [
        // Russian
        'спасибо', 'благодарю', 'отлично', 'хорошо', 'рад', 'приятно',
        'замечательно', 'прекрасно', 'супер', 'класс',
        // Kazakh
        'рахмет', 'керемет', 'жақсы', 'қуанышты', 'тамаша', 'керемет',
        'жағымды', 'кереметті', 'тамаша', 'әдемі'
    ];
    
    if (happyWords.some(word => lowerText.includes(word))) {
        return 'happy';
    }
    
    // Sad emotions
    const sadWords = [
        // Russian
        'не понимаю', 'не знаю', 'плохо', 'грустно', 'печально',
        'плохой', 'грустный', 'печальный', 'жалко',
        // Kazakh
        'түсінбеймін', 'білмеймін', 'жаман', 'қайғылы', 'мұңды',
        'жамандық', 'қайғы', 'мұң'
    ];
    
    if (sadWords.some(word => lowerText.includes(word))) {
        return 'sad';
    }
    
    // Thinking/Help emotions
    const thinkingWords = [
        // Russian
        'помощь', 'нужно', 'помоги', 'помогите', 'нужен', 'нужна',
        'помощь нужна', 'требуется помощь',
        // Kazakh
        'көмек', 'керек', 'көмектес', 'көмектесіңіз', 'көмек керек',
        'көмектесіңдер', 'көмекте', 'көмек қажет'
    ];
    
    if (thinkingWords.some(word => lowerText.includes(word))) {
        return 'thinking';
    }
    
    // Surprised emotions
    const surprisedWords = [
        // Russian
        'ура', 'вау', 'невероятно', 'удивительно', 'о',
        // Kazakh
        'уай', 'таңқаларлық', 'таң', 'таңқалдым', 'әй'
    ];
    
    if (lowerText.includes('!') || surprisedWords.some(word => lowerText.includes(word))) {
        return 'surprised';
    }
    
    // Angry emotions
    const angryWords = [
        // Russian
        'злой', 'зло', 'разозлился', 'злюсь', 'сердит',
        // Kazakh
        'ашулы', 'қаһарлы', 'ашу', 'қаһар', 'ашуландым'
    ];
    
    if (angryWords.some(word => lowerText.includes(word))) {
        return 'angry';
    }
    
    return 'neutral';
}

// Add subtitle with visual enhancements
function addSubtitle(text, emotion = 'neutral', isInterim = false) {
    if (!text || text.trim() === '') return;
    
    // Normalize text
    text = text.trim().replace(/\s+/g, ' ');
    
    // Remove interim subtitle if exists
    if (interimSubtitleElement && !isInterim) {
        interimSubtitleElement.remove();
        interimSubtitleElement = null;
    }
    
    // Skip if same as last subtitle (avoid duplicates)
    if (!isInterim && text === lastSubtitleText) {
        return;
    }
    
    const subtitlesDisplay = document.getElementById('subtitlesDisplay');
    if (!subtitlesDisplay) return;
    
    const emojiStatusCheckbox = document.getElementById('emojiStatus');
    const colorHighlightCheckbox = document.getElementById('colorHighlight');
    const visualRhythmCheckbox = document.getElementById('visualRhythm');
    
    const emojiStatusEnabled = emojiStatusCheckbox ? emojiStatusCheckbox.checked : true;
    const colorHighlightEnabled = colorHighlightCheckbox ? colorHighlightCheckbox.checked : true;
    const visualRhythmEnabled = visualRhythmCheckbox ? visualRhythmCheckbox.checked : true;

    const subtitleItem = document.createElement('div');
    subtitleItem.className = isInterim ? 'subtitle-item interim' : 'subtitle-item';
    
    if (isInterim) {
        interimSubtitleElement = subtitleItem;
    } else {
        lastSubtitleText = text;
    }

    // Add emoji status
    if (emojiStatusEnabled) {
        const emoji = document.createElement('span');
        emoji.className = 'emoji-status';
        emoji.textContent = emojiMap[emotion] || emojiMap.neutral;
        subtitleItem.appendChild(emoji);
    }

    // Add text with color highlighting
    const textSpan = document.createElement('span');
    textSpan.className = 'subtitle-text';

    if (colorHighlightEnabled) {
        let highlightedText = text;
        const words = importantWords[currentLanguage] || importantWords.ru;
        words.forEach(word => {
            const regex = new RegExp(`\\b${word}\\b`, 'gi');
            highlightedText = highlightedText.replace(regex, (match) => {
                return `<span class="highlighted-word">${match}</span>`;
            });
        });
        textSpan.innerHTML = highlightedText;
    } else {
        textSpan.textContent = text;
    }

    subtitleItem.appendChild(textSpan);

    // Visual rhythm - delay appearance
    if (visualRhythmEnabled) {
        subtitleItem.style.opacity = '0';
        const delay = Math.random() * 300 + 100;
        setTimeout(() => {
            subtitleItem.style.transition = 'opacity 0.5s ease-in';
            subtitleItem.style.opacity = '1';
        }, delay);
    } else {
        subtitleItem.style.opacity = '1';
    }

    if (isInterim) {
        // Remove old interim subtitle if exists
        const oldInterim = subtitlesDisplay.querySelector('.subtitle-item.interim');
        if (oldInterim) {
            oldInterim.remove();
        }
    }
    
    subtitlesDisplay.appendChild(subtitleItem);
    subtitlesDisplay.scrollTop = subtitlesDisplay.scrollHeight;

    // Keep only last 20 final subtitles (not interim)
    const finalSubtitles = Array.from(subtitlesDisplay.children).filter(el => !el.classList.contains('interim'));
    while (finalSubtitles.length > 20) {
        const firstFinal = subtitlesDisplay.querySelector('.subtitle-item:not(.interim)');
        if (firstFinal) {
            firstFinal.remove();
        } else {
            break;
        }
    }
}

// Start/Stop Recording — привязка после готовности DOM
function setupSpeechRecognitionButton() {
    const startRecordingBtn = document.getElementById('startRecording');
    if (!startRecordingBtn || startRecordingBtn.dataset.speechBound === '1') return;
    startRecordingBtn.dataset.speechBound = '1';

    startRecordingBtn.addEventListener('click', function () {
        const btn = document.getElementById('startRecording');
        if (!btn) return;

        if (!recognition) {
            alert(translations[currentLanguage].speechNotSupported);
            return;
        }

        if (!isRecording) {
            try {
                if (interimSubtitleElement) {
                    interimSubtitleElement.remove();
                    interimSubtitleElement = null;
                }
                lastSubtitleText = '';

                let recognitionLang = currentLanguage === 'kk' ? 'kk-KZ' : 'ru-RU';
                recognition.lang = recognitionLang;

                function doStart() {
                    recognition.start();
                }
                try {
                    doStart();
                } catch (err) {
                    recognition = createRecognitionInstance();
                    if (recognition) {
                        recognition.lang = recognitionLang;
                        attachRecognitionHandlers(recognition);
                        try {
                            recognition.start();
                        } catch (e2) {
                            if (currentLanguage === 'kk' && recognitionLang === 'kk-KZ') {
                                recognition.lang = 'kk';
                                recognition.start();
                            } else {
                                recognition.lang = 'ru-RU';
                                recognition.start();
                            }
                        }
                    } else {
                        throw err;
                    }
                }
                isRecording = true;
                btn.textContent = translations[currentLanguage].stopRecording;
                btn.classList.add('active');

                let timeElapsed = 0;
                const timeInterval = setInterval(function () {
                    if (!isRecording) {
                        clearInterval(timeInterval);
                        return;
                    }
                    timeElapsed++;
                    const m = Math.floor(timeElapsed / 60);
                    const s = timeElapsed % 60;
                    const audioTimeEl = document.getElementById('audioTime');
                    if (audioTimeEl) audioTimeEl.textContent = m + ':' + String(s).padStart(2, '0') + ' / 0:09';
                }, 1000);
            } catch (error) {
                console.error('Error starting recognition:', error);
                isRecording = false;
                btn.textContent = translations[currentLanguage].startRecording;
                btn.classList.remove('active');
                alert(translations[currentLanguage].speechNotSupported);
            }
        } else {
            isRecording = false;
            try {
                recognition.stop();
            } catch (e) {
                console.warn('recognition.stop:', e);
            }
            btn.textContent = translations[currentLanguage].startRecording;
            btn.classList.remove('active');
            if (interimSubtitleElement) {
                interimSubtitleElement.remove();
                interimSubtitleElement = null;
            }
            if (recognitionTimeout) {
                clearTimeout(recognitionTimeout);
                recognitionTimeout = null;
            }
            const audioTimeEl = document.getElementById('audioTime');
            if (audioTimeEl) audioTimeEl.textContent = '0:00 / 0:09';
        }
    });
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupSpeechRecognitionButton);
} else {
    setupSpeechRecognitionButton();
}

// Remove old onend handler - now handled in onresult section

// Demo Mode
const demoModeBtn = document.getElementById('demoMode');
if (demoModeBtn) {
    demoModeBtn.addEventListener('click', () => {
        const demoTexts = [
            { text: 'Привет, как дела?', emotion: 'happy' },
            { text: 'Мне нужна помощь', emotion: 'thinking' },
            { text: 'Спасибо большое!', emotion: 'happy' },
            { text: 'Я не понимаю', emotion: 'sad' },
            { text: 'Пожалуйста, повторите', emotion: 'neutral' },
            { text: 'Отлично, спасибо!', emotion: 'happy' },
            { text: 'Мне плохо', emotion: 'sad' }
        ];

        const randomText = demoTexts[Math.floor(Math.random() * demoTexts.length)];
        addSubtitle(randomText.text, randomText.emotion);
    });
}

// Initialize gamification UI on load
document.addEventListener('DOMContentLoaded', () => {
    try {
        gamificationState = loadGamificationState();
        updateGamificationUI();
    } catch (e) {
        console.warn('Failed to initialize gamification.', e);
    }
});

// ——— Размер текста (увеличение/уменьшение) и светлая/тёмная тема ———
const TEXT_SIZE_LEVELS = ['small', 'normal', 'large', 'xlarge'];

function setTextSize(level) {
    if (!TEXT_SIZE_LEVELS.includes(level)) return;
    document.documentElement.setAttribute('data-text-size', level);
    try { localStorage.setItem('textSize', level); } catch (e) {}
    const idx = TEXT_SIZE_LEVELS.indexOf(level);
    const down = document.getElementById('textSizeDown');
    const up = document.getElementById('textSizeUp');
    if (down) down.disabled = idx <= 0;
    if (up) up.disabled = idx >= TEXT_SIZE_LEVELS.length - 1;
}

function setTheme(theme) {
    const v = theme === 'dark' ? 'dark' : 'light';
    if (v === 'dark') document.documentElement.setAttribute('data-theme', 'dark');
    else document.documentElement.removeAttribute('data-theme');
    try { localStorage.setItem('theme', v); } catch (e) {}
    updateThemeButtonLabel();
}

function updateThemeButtonLabel() {
    const btn = document.getElementById('themeToggle');
    if (!btn) return;
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    const label = isDark
        ? (translations[currentLanguage]?.themeLight || 'Светлая')
        : (translations[currentLanguage]?.themeDark || 'Тёмная');
    btn.textContent = (isDark ? '☀️ ' : '🌙 ') + label;
    btn.setAttribute('aria-label', label);
}

function initTextSizeAndTheme() {
    const root = document.documentElement;
    const savedSize = localStorage.getItem('textSize') || 'normal';
    if (TEXT_SIZE_LEVELS.includes(savedSize)) {
        root.setAttribute('data-text-size', savedSize);
        const idx = TEXT_SIZE_LEVELS.indexOf(savedSize);
        const down = document.getElementById('textSizeDown');
        const up = document.getElementById('textSizeUp');
        if (down) down.disabled = idx <= 0;
        if (up) up.disabled = idx >= TEXT_SIZE_LEVELS.length - 1;
    }
    const savedTheme = localStorage.getItem('theme') || 'light';
    if (savedTheme === 'dark') {
        root.setAttribute('data-theme', 'dark');
    } else {
        root.removeAttribute('data-theme');
    }
    updateThemeButtonLabel();

    const down = document.getElementById('textSizeDown');
    const up = document.getElementById('textSizeUp');
    const reset = document.getElementById('textSizeReset');
    const themeBtn = document.getElementById('themeToggle');
    if (down && !down.dataset.bound) {
        down.dataset.bound = '1';
        down.addEventListener('click', function () {
            const idx = TEXT_SIZE_LEVELS.indexOf(root.getAttribute('data-text-size') || 'normal');
            if (idx > 0) setTextSize(TEXT_SIZE_LEVELS[idx - 1]);
        });
    }
    if (up && !up.dataset.bound) {
        up.dataset.bound = '1';
        up.addEventListener('click', function () {
            const idx = TEXT_SIZE_LEVELS.indexOf(root.getAttribute('data-text-size') || 'normal');
            if (idx >= 0 && idx < TEXT_SIZE_LEVELS.length - 1) setTextSize(TEXT_SIZE_LEVELS[idx + 1]);
        });
    }
    if (reset && !reset.dataset.bound) {
        reset.dataset.bound = '1';
        reset.addEventListener('click', function () { setTextSize('normal'); });
    }
    if (themeBtn && !themeBtn.dataset.bound) {
        themeBtn.dataset.bound = '1';
        themeBtn.addEventListener('click', function () {
            const isDark = root.getAttribute('data-theme') === 'dark';
            setTheme(isDark ? 'light' : 'dark');
        });
    }
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initTextSizeAndTheme);
} else {
    initTextSizeAndTheme();
}

// Lip Reading Assistant removed

// Smart-режим теперь интегрирован напрямую через MediaPipe Hands выше

// Gesture Translation
// Gesture data with gifer.com GIF IDs
// Based on https://gifer.com/en/8u7X and sign language collection
// Using API to fetch related GIFs from the collection
const gestureData = {
    // Russian
    'привет': {
        emoji: '👋',
        giferId: '9XAY', // Hello/Wave - https://i.gifer.com/9XAY.gif
        searchTerms: ['hello', 'wave', 'hi'],
        name: 'Привет'
    },
    'помощь': {
        emoji: '🆘',
        giferId: '8U0t', // Help gesture - https://i.gifer.com/8U0t.gif
        searchTerms: ['help', 'assist'],
        name: 'Помощь'
    },
    'спасибо': {
        emoji: '🙏',
        giferId: '8u7X', // Thank you - using collection base
        searchTerms: ['thank you', 'thanks'],
        name: 'Спасибо'
    },
    'пожалуйста': {
        emoji: '🙏',
        giferId: '8u7X', // Please - using collection base
        searchTerms: ['please'],
        name: 'Пожалуйста'
    },
    'да': {
        emoji: '👍',
        giferId: '8u7X', // Yes - using collection base
        searchTerms: ['yes', 'thumbs up'],
        name: 'Да'
    },
    'нет': {
        emoji: '👎',
        giferId: '8u7X', // No - using collection base
        searchTerms: ['no', 'thumbs down'],
        name: 'Нет'
    },
    'дом': {
        emoji: '🏠',
        giferId: '8u7X', // Home - using collection base
        searchTerms: ['home', 'house'],
        name: 'Дом'
    },
    // Kazakh
    'сәлем': {
        emoji: '👋',
        giferId: '9XAY', // Hello/Wave - https://i.gifer.com/9XAY.gif
        searchTerms: ['hello', 'wave', 'hi'],
        name: 'Сәлем'
    },
    'көмек': {
        emoji: '🆘',
        giferId: '8U0t', // Help gesture - https://i.gifer.com/8U0t.gif
        searchTerms: ['help', 'assist'],
        name: 'Көмек'
    },
    'рахмет': {
        emoji: '🙏',
        giferId: '8u7X', // Thank you
        searchTerms: ['thank you', 'thanks'],
        name: 'Рахмет'
    },
    'өтінемін': {
        emoji: '🙏',
        giferId: '8u7X', // Please
        searchTerms: ['please'],
        name: 'Өтінемін'
    },
    'иә': {
        emoji: '👍',
        giferId: '8u7X', // Yes
        searchTerms: ['yes', 'thumbs up'],
        name: 'Иә'
    },
    'жоқ': {
        emoji: '👎',
        giferId: '8u7X', // No
        searchTerms: ['no', 'thumbs down'],
        name: 'Жоқ'
    },
    'үй': {
        emoji: '🏠',
        giferId: '8u7X', // Home
        searchTerms: ['home', 'house'],
        name: 'Үй'
    }
};

// Function to search for GIF on gifer.com API
async function searchGiferGif(searchTerms) {
    try {
        for (const term of searchTerms) {
            const response = await fetch(`https://gifer.com/api/search/media?q=${encodeURIComponent(term + ' sign language')}&limit=5&include=creator,tags.tag`);
            const data = await response.json();
            
            if (data && data.data && data.data.length > 0) {
                // Find the first GIF that matches
                const gif = data.data[0];
                if (gif && gif.id) {
                    return gif.id;
                }
            }
        }
    } catch (error) {
        console.error('Error searching GIF on gifer.com:', error);
    }
    return null;
}

// Function to get GIF URL from gifer.com
// Based on https://gifer.com/en/8u7X
// Gifer.com URLs format: https://i.gifer.com/XXXX.gif
function getGiferGifUrl(giferId) {
    // Direct image URL from gifer.com
    return `https://i.gifer.com/${giferId}.gif`;
}

// Legacy support
const gestureWords = {};
Object.keys(gestureData).forEach(key => {
    gestureWords[key] = gestureData[key].emoji;
});

// Create gesture GIF from gifer.com
async function createGestureGif(giferId, word, gestureName, searchTerms = null) {
    const container = document.createElement('div');
    container.className = 'gesture-gif-container';
    
    // Create loading indicator
    const loadingDiv = document.createElement('div');
    loadingDiv.className = 'gesture-loading';
    loadingDiv.innerHTML = `<div class="spinner"></div><p>${translations[currentLanguage]?.loadingGif || 'Загрузка GIF...'}</p>`;
    container.appendChild(loadingDiv);
    
    // Try to find better GIF if search terms provided
    let finalGifId = giferId;
    if (searchTerms && searchTerms.length > 0) {
        const foundGifId = await searchGiferGif(searchTerms);
        if (foundGifId) {
            finalGifId = foundGifId;
        }
    }
    
    // Get GIF URL from gifer.com
    const gifUrl = getGiferGifUrl(finalGifId);
    
    // Create image element for GIF
    const img = document.createElement('img');
    img.className = 'gesture-gif-image';
    img.alt = gestureName || word;
    img.style.display = 'none';
    img.crossOrigin = 'anonymous'; // For CORS
    
    // Handle image load
    img.onload = () => {
        loadingDiv.style.display = 'none';
        img.style.display = 'block';
    };
    
    // Handle image error - try alternative URL formats
    img.onerror = () => {
        console.warn('Failed to load GIF from i.gifer.com, trying alternative URLs');
        
        // Try alternative URL formats from gifer.com
        const altUrls = [
            `https://gifer.com/embed/${finalGifId}`,
            `https://gifer.com/en/${finalGifId}`,
            `https://i.gifer.com/origin/${finalGifId}.gif`
        ];
        
        let currentAltIndex = 0;
        
        const tryNextUrl = () => {
            if (currentAltIndex >= altUrls.length) {
                // All URLs failed, show emoji fallback
                console.warn('All GIF URLs failed, using emoji fallback');
                loadingDiv.style.display = 'none';
                const emoji = gestureData[word]?.emoji || '👋';
                const emojiDiv = document.createElement('div');
                emojiDiv.className = 'gesture-emoji-fallback';
                emojiDiv.style.fontSize = '64px';
                emojiDiv.style.textAlign = 'center';
                emojiDiv.textContent = emoji;
                container.appendChild(emojiDiv);
                return;
            }
            
            // Try iframe embed
            const iframe = document.createElement('iframe');
            iframe.src = altUrls[currentAltIndex];
            iframe.className = 'gesture-gif-iframe';
            iframe.style.width = '100%';
            iframe.style.height = '300px';
            iframe.style.border = 'none';
            iframe.style.borderRadius = '8px';
            iframe.style.display = 'none';
            
            iframe.onload = () => {
                loadingDiv.style.display = 'none';
                iframe.style.display = 'block';
            };
            
            iframe.onerror = () => {
                currentAltIndex++;
                tryNextUrl();
            };
            
            // Timeout for iframe
            setTimeout(() => {
                if (iframe.style.display === 'none') {
                    currentAltIndex++;
                    tryNextUrl();
                }
            }, 3000);
            
            container.appendChild(iframe);
        };
        
        tryNextUrl();
    };
    
    img.src = gifUrl;
    container.appendChild(img);
    
    // Create label
    const label = document.createElement('p');
    label.className = 'gesture-label';
    label.textContent = `${translations[currentLanguage]?.gestureLabel || 'Жест'}: ${gestureName || word}`;
    label.style.textAlign = 'center';
    label.style.marginTop = '10px';
    label.style.fontWeight = '600';
    container.appendChild(label);
    
    return container;
}

// Removed canvas animation functions - now using real GIFs from internet

const gestureInput = document.getElementById('gestureInput');
if (gestureInput) {
    let currentGifTimeout = null;
    
    gestureInput.addEventListener('input', async (e) => {
        const word = e.target.value.toLowerCase().trim();
        const gestureGif = document.getElementById('gestureGif');
        
        if (!gestureGif) return;
        
        // Clear previous timeout
        if (currentGifTimeout) {
            clearTimeout(currentGifTimeout);
        }
        
        // Debounce - wait 300ms before loading GIF
        currentGifTimeout = setTimeout(async () => {
            if (gestureData[word]) {
                const gesture = gestureData[word];
                const gestureName = currentLanguage === 'kk' 
                    ? (translations.kk[word] || gesture.name)
                    : (translations.ru[word] || gesture.name);
                
                // Create GIF from gifer.com
                const gifContainer = await createGestureGif(gesture.giferId, word, gestureName, gesture.searchTerms);
                gestureGif.innerHTML = '';
                gestureGif.appendChild(gifContainer);
            } else if (word) {
                // Try to find in BASIC_GESTURES database
                const foundGesture = findGesture(word);
                if (foundGesture) {
                    gestureGif.innerHTML = `
                        <div style="text-align: center; padding: 20px;">
                            <div style="font-size: 48px; margin-bottom: 12px;">🤟</div>
                            <div style="font-size: 24px; font-weight: 700; color: var(--color-text); margin-bottom: 8px;">${foundGesture.name}</div>
                            <div style="font-size: 14px; color: var(--color-text-muted);">Жест табылды</div>
                        </div>
                    `;
                } else {
                    gestureGif.innerHTML = `<p style="text-align: center; color: #999;">${translations[currentLanguage]?.gifNotFound || 'GIF не найдено'}</p>`;
                }
            } else {
                gestureGif.innerHTML = `<p style="text-align: center; color: #999;">${translations[currentLanguage]?.gifNotFound || 'GIF не найдено'}</p>`;
            }
        }, 300);
    });
}

// Word tags
document.querySelectorAll('.tag').forEach(tag => {
    tag.addEventListener('click', () => {
        const word = tag.getAttribute('data-word');
        const gestureInput = document.getElementById('gestureInput');
        if (gestureInput) {
            gestureInput.value = word;
            gestureInput.dispatchEvent(new Event('input'));
        }
    });
});

// Hand Tracking with MediaPipe Hands (from Sign-AI)
let handTrackingActive = false;
let videoStream = null;
let mediaPipeHands = null;
let mediaPipeCamera = null;
let isProcessing = false;
let lastGesture = "—";
let lastTime = 0;
let COOLDOWN = 900;
/** Guard so candy does not spawn every frame while the child holds the gesture (3s cooldown). */
let canCelebrate = true;
let gestureHistory = [];

/** Режим обучения: показываем задание и подсказку, проверяем только текущее слово. */
let learningMode = false;

// =====================================================
// ЕКІНШІ ТІЛДІ ОҚЫТУ МОДУЛІ / ДВУЯЗЫЧНЫЙ МОДУЛЬ ОБУЧЕНИЯ
// =====================================================

const schoolData = {
    kk: {
        subjects: { 
            math: "Математика", 
            lang: "Қазақ тілі", 
            world: "Дүниетану" 
        },
        status: { 
            repeat: "Тағы бір рет! 👍", 
            great: "ЖАРАЙСЫҢ! 🎉",
            complete: "Сабақ аяқталды! 🏆",
            showCamera: "Камераны қосыңыз 📷",
            showGesture: "Ишаратты көрсетіңіз 👀"
        },
        modules: {
            math: [
                { name: "Қосу", hint: "➕ Саусақты айқастыр", fingers: "01000", hands: 2 },
                { name: "Алу", hint: "➖ Сұқ саусақ көлденең", fingers: "01000", hands: 1 },
                { name: "Көп", hint: "👐 Екі қолды жай", fingers: "11111", hands: 2 },
                { name: "Аз", hint: "🤏 Саусақты жақындат", fingers: "01000", hands: 1 },
                { name: "Жауап", hint: "☝️ Еріннен алға соз", fingers: "01000", hands: 1 },
                { name: "Шаршы", hint: "⬜ Шаршы сыз", fingers: "01000", hands: 2 },
                { name: "Дөңгелек", hint: "⭕ Шеңбер сыз", fingers: "01000", hands: 1 },
                { name: "Үшбұрыш", hint: "🔺 Үшбұрыш жаса", fingers: "11111", hands: 2 },
                { name: "Төрт", hint: "4️⃣ Төрт саусақ", fingers: "01111", hands: 1 },
                { name: "Нөл", hint: "0️⃣ О пішіні", fingers: "00000", hands: 1 }
            ],
            lang: [
                { name: "Мен", hint: "👈 Өзіңді көрсет", fingers: "01000", hands: 1 },
                { name: "Қалам", hint: "✍️ Жазғандай істе", fingers: "11000", hands: 1 },
                { name: "Дәптер", hint: "📖 Алақанды аш", fingers: "11111", hands: 2 },
                { name: "Сөз", hint: "💬 Екі саусақты соз", fingers: "01100", hands: 1 },
                { name: "Жазу", hint: "✍️ Жазғандай істе", fingers: "11000", hands: 1 },
                { name: "Отыр", hint: "🪑 Алақанды төмен бас", fingers: "11111", hands: 1 },
                { name: "Тұр", hint: "⬆️ Жоғары көрсет", fingers: "01100", hands: 1 },
                { name: "Үзіліс", hint: "🔔 Қолды айқастыр", fingers: "11111", hands: 2 },
                { name: "Сөмке", hint: "🎒 Иықты ұста", fingers: "00000", hands: 2 },
                { name: "Қоңырау", hint: "🔔 Шайқа", fingers: "00000", hands: 1 }
            ],
            world: [
                { name: "Күн", hint: "☀️ Қолды жоғары аш", fingers: "11111", hands: 1 },
                { name: "Тау", hint: "🏔️ Үшбұрыш жаса", fingers: "11111", hands: 2 },
                { name: "Ағаш", hint: "🌳 Саусақты жай", fingers: "11111", hands: 1 },
                { name: "Жер", hint: "🌍 Шарды айналдыр", fingers: "11111", hands: 2 },
                { name: "Қар", hint: "❄️ Баяу түсір", fingers: "11111", hands: 2 },
                { name: "Жел", hint: "💨 Қолды тербелт", fingers: "11111", hands: 2 },
                { name: "Жұлдыз", hint: "⭐ Жоғарыда аш-жұм", fingers: "11111", hands: 1 },
                { name: "Түн", hint: "🌙 Көзді жап", fingers: "11111", hands: 2 },
                { name: "Қыс", hint: "❄️ Тоңғандай істе", fingers: "00000", hands: 2 }
            ]
        }
    },
    ru: {
        subjects: { 
            math: "Математика", 
            lang: "Русский язык", 
            world: "Окруж. мир" 
        },
        status: { 
            repeat: "Покажи еще раз! 👍", 
            great: "МОЛОДЕЦ! 🎉",
            complete: "Урок окончен! 🏆",
            showCamera: "Включите камеру 📷",
            showGesture: "Покажите жест 👀"
        },
        modules: {
            math: [
                { name: "Плюс", hint: "➕ Скрести пальцы", fingers: "01000", hands: 2 },
                { name: "Минус", hint: "➖ Указательный горизонтально", fingers: "01000", hands: 1 },
                { name: "Много", hint: "👐 Разведи руки", fingers: "11111", hands: 2 },
                { name: "Мало", hint: "🤏 Сблизь пальцы", fingers: "01000", hands: 1 },
                { name: "Ответ", hint: "☝️ От губ вперед", fingers: "01000", hands: 1 },
                { name: "Квадрат", hint: "⬜ Рисуй квадрат", fingers: "01000", hands: 2 },
                { name: "Круг", hint: "⭕ Рисуй круг", fingers: "01000", hands: 1 },
                { name: "Треугольник", hint: "🔺 Сложи треугольник", fingers: "11111", hands: 2 },
                { name: "Четыре", hint: "4️⃣ Четыре пальца", fingers: "01111", hands: 1 },
                { name: "Ноль", hint: "0️⃣ Буква О", fingers: "00000", hands: 1 }
            ],
            lang: [
                { name: "Я", hint: "👈 Покажи на себя", fingers: "01000", hands: 1 },
                { name: "Ручка", hint: "✍️ Имитируй письмо", fingers: "11000", hands: 1 },
                { name: "Тетрадь", hint: "📖 Раскрой ладони", fingers: "11111", hands: 2 },
                { name: "Слово", hint: "💬 Два пальца вперед", fingers: "01100", hands: 1 },
                { name: "Писать", hint: "✍️ Имитируй письмо", fingers: "11000", hands: 1 },
                { name: "Садись", hint: "🪑 Ладонь вниз", fingers: "11111", hands: 1 },
                { name: "Встань", hint: "⬆️ Покажи вверх", fingers: "01100", hands: 1 },
                { name: "Перемена", hint: "🔔 Скрести и разведи", fingers: "11111", hands: 2 },
                { name: "Рюкзак", hint: "🎒 За лямки", fingers: "00000", hands: 2 },
                { name: "Звонок", hint: "🔔 Тряси колокольчик", fingers: "00000", hands: 1 }
            ],
            world: [
                { name: "Солнце", hint: "☀️ Руку вверх", fingers: "11111", hands: 1 },
                { name: "Гора", hint: "🏔️ Сложи треугольник", fingers: "11111", hands: 2 },
                { name: "Дерево", hint: "🌳 Растопырь пальцы", fingers: "11111", hands: 1 },
                { name: "Земля", hint: "🌍 Вращай шар", fingers: "11111", hands: 2 },
                { name: "Снег", hint: "❄️ Плавно кружи", fingers: "11111", hands: 2 },
                { name: "Ветер", hint: "💨 Качай руками", fingers: "11111", hands: 2 },
                { name: "Звезда", hint: "⭐ Сжимай-разжимай", fingers: "11111", hands: 1 },
                { name: "Ночь", hint: "🌙 Закрой лицо", fingers: "11111", hands: 2 },
                { name: "Зима", hint: "❄️ Обхвати плечи", fingers: "00000", hands: 2 }
            ]
        }
    }
};

/** Саусақ кодын алу / Получить код пальцев (түзетілген дәлірек нұсқа) */
function getFingerCode(landmarks) {
    if (!landmarks || landmarks.length < 21) return null;
    
    let res = "";
    const fingerTips = [8, 12, 16, 20]; // Сұқ, Орта, Аты жоқ, Шынашақ
    const fingerPips = [6, 10, 14, 18];

    // 1. Бас бармақты тексеру (Thumb)
    // Оң қол мен сол қол үшін x-координатасы әртүрлі болады
    if (landmarks[4].x < landmarks[3].x) {
        res += "1"; 
    } else {
        res += "0";
    }

    // 2. Қалған 4 саусақ
    for (let i = 0; i < 4; i++) {
        if (landmarks[fingerTips[i]].y < landmarks[fingerPips[i]].y) {
            res += "1"; // Саусақ көтеріліп тұр
        } else {
            res += "0"; // Саусақ бүгілулі
        }
    }
    return res;
}

// Получить данные для текущего языка
function getSchoolData() {
    return schoolData[currentLanguage] || schoolData.ru;
}

// Получить модули для текущего языка
function getSchoolModules() {
    return getSchoolData().modules;
}

// Получить статусы для текущего языка
function getSchoolStatus() {
    return getSchoolData().status;
}

// Получить названия предметов для текущего языка
function getSchoolSubjects() {
    return getSchoolData().subjects;
}

// Для обратной совместимости
const schoolModules = schoolData.ru.modules;

/** Текущий выбранный предмет */
let currentSubject = "Математика";

/** Словарь подсказок для ребёнка (режим обучения). */
const gestureDictionary = {
    "УЧИТЕЛЬ": { hint: "Подними указательный палец вверх ☝️", hands: 1 },
    "ТИХО": { hint: "Приложи указательный палец к губам 🤫", hands: 1 },
    "Я ГОТОВ": { hint: "Подними открытую ладонь 🖐️", hands: 1 },
    "ЛЮБОВЬ": { hint: "Покажи пальцами сердечко 🤟", hands: 1 },
    "ШКОЛА": { hint: "Сложи ладони домиком (крышей) 🏠", hands: 2 },
    "Я ЗАКОНЧИЛ": { hint: "Скрести руки буквой Х 🙅‍♂️", hands: 2 },
    "ПОЖАЛУЙСТА": { hint: "Сложи ладони вместе, как книжку 📖", hands: 2 }
};

// ✅ БАЗАЛЫҚ 50 ЖЕСТ БАЗАСЫ
const BASIC_GESTURES = [
  // Қарым қатынас
  { name: "Сәлем", keywords: ["привет", "hello", "сәлем"] },
  { name: "Сау бол", keywords: ["пока", "bye", "сау бол"] },
  { name: "Рахмет", keywords: ["спасибо", "рахмет"] },
  { name: "Өтінемін", keywords: ["пожалуйста", "өтінемін"] },
  { name: "Кешіріңіз", keywords: ["извини", "кешіріңіз"] },

  // Жауаптар
  { name: "Иә", keywords: ["да", "иә"] },
  { name: "Жоқ", keywords: ["нет", "жоқ"] },
  { name: "Білмеймін", keywords: ["не знаю", "білмеймін"] },
  { name: "Мүмкін", keywords: ["может", "мүмкін"] },
  { name: "Түсіндім", keywords: ["понял", "түсіндім"] },

  // Көмек
  { name: "Көмектес", keywords: ["помоги", "көмектес"] },
  { name: "Маған керек", keywords: ["мне нужно", "маған керек"] },
  { name: "Тоқта", keywords: ["стоп", "тоқта"] },
  { name: "Күт", keywords: ["подожди", "күт"] },
  { name: "Тағы", keywords: ["еще", "тағы"] },

  // Адамдар
  { name: "Мен", keywords: ["я", "мен"] },
  { name: "Сен", keywords: ["ты", "сен"] },
  { name: "Біз", keywords: ["мы", "біз"] },
  { name: "Мұғалім", keywords: ["учитель", "мұғалім"] },
  { name: "Дос", keywords: ["друг", "дос"] },

  // Мектеп
  { name: "Мектеп", keywords: ["школа", "мектеп"] },
  { name: "Сабақ", keywords: ["урок", "сабақ"] },
  { name: "Үй жұмысы", keywords: ["домашка", "үй жұмысы"] },
  { name: "Кітап", keywords: ["книга", "кітап"] },
  { name: "Жазу", keywords: ["писать", "жазу"] },

  // Оқу пәндері
  { name: "Математика", keywords: ["математика"] },
  { name: "Оқу", keywords: ["читать", "оқу"] },
  { name: "Жазу пәні", keywords: ["русский", "орыс тілі"] },
  { name: "Тарих", keywords: ["история", "тарих"] },
  { name: "Табиғат", keywords: ["окружающий мир", "табиғат"] },

  // Сандар
  { name: "0", keywords: ["ноль", "нөл"] },
  { name: "1", keywords: ["один", "бір"] },
  { name: "2", keywords: ["два", "екі"] },
  { name: "3", keywords: ["три", "үш"] },
  { name: "4", keywords: ["четыре", "төрт"] },
  { name: "5", keywords: ["пять", "бес"] },

  // Математика амалдары
  { name: "Қосу", keywords: ["плюс", "қосу"] },
  { name: "Азайту", keywords: ["минус", "азайту"] },
  { name: "Көбейту", keywords: ["умножить", "көбейту"] },
  { name: "Бөлу", keywords: ["делить", "бөлу"] },
  { name: "Тең", keywords: ["равно", "тең"] },

  // Күнделікті өмір
  { name: "Тамақ", keywords: ["еда", "тамақ"] },
  { name: "Су", keywords: ["вода", "су"] },
  { name: "Ұйықтау", keywords: ["спать", "ұйықтау"] },
  { name: "Ойнау", keywords: ["играть", "ойнау"] },
  { name: "Бар", keywords: ["идти", "бар"] },

  // Эмоциялар
  { name: "Жақсы", keywords: ["хорошо", "жақсы"] },
  { name: "Жаман", keywords: ["плохо", "жаман"] },
  { name: "Қуаныш", keywords: ["радость", "қуаныш"] },
  { name: "Қорқу", keywords: ["страх", "қорқу"] },
  { name: "Ашу", keywords: ["злость", "ашу"] }
];

// Жестті мәтін бойынша табу
function findGesture(text) {
  if (!text) return null;
  const lowerText = text.toLowerCase();
  return BASIC_GESTURES.find(g =>
    g.keywords.some(k => lowerText.includes(k.toLowerCase()))
  );
}

/** Получить текущий словарь обучения (из выбранного предмета или базовый) */
function getCurrentLearningDictionary() {
    if (currentSubject && schoolModules[currentSubject]) {
        return schoolModules[currentSubject];
    }
    return learningDictionary;
}

/** Словарь с паттернами пальцев (Б,У,С,Бз,М): 1 — поднят, 0 — согнут. Для processHands. */
const learningDictionary = [
    { name: "ИЗВИНИ", hint: "Рука к сердцу ❤️", fingers: "11111", hands: 1 },
    { name: "ПОЖАЛУЙСТА", hint: "Ладони вместе 🙏", fingers: "11111", hands: 2 },
    { name: "УЧИТЕЛЬ", hint: "Три пальца вверх (указательный, средний, безымянный) ✌️➕", fingers: "01110", hands: 1 },
    { name: "ШКОЛА", hint: "Крыша домика 🏠", fingers: "11111", hands: 2 },
    { name: "ЛЮБОВЬ", hint: "Сердечко 🤟", fingers: "11001", hands: 1 }
];
let wordIndex = 0;
let currentTarget = "УЧИТЕЛЬ";
/** Счётчик успешных показов текущего жеста (нужно 2 раза подряд). */
let successCount = 0;
/** Пауза проверки, чтобы не срабатывало 100 раз в секунду. */
let isChecking = true;
/** Пауза для словаря с паттернами (processHands). */
let canCheck = true;

function updateHint() {
    const hintElement = document.getElementById('hint-box');
    if (!hintElement) return;
    const data = gestureDictionary[currentTarget];
    if (!data) return;
    hintElement.innerHTML = `
        <div style="font-size: 18px; color: #333; margin-bottom: 8px;"><strong>Задание:</strong> Покажи слово <b>${currentTarget}</b></div>
        <div style="font-size: 22px; color: #007bff;">${data.hint}</div>
    `;
}

/** Обновить плашку задания из текущего словаря предмета (для processHands). */
function updateLearningUI() {
    const hintElement = document.getElementById('hint-box');
    const dictionary = getCurrentLearningDictionary();
    if (!hintElement || !dictionary.length) return;
    
    // Безопасный индекс
    if (wordIndex >= dictionary.length) wordIndex = 0;
    
    const current = dictionary[wordIndex];
    currentTarget = current.name;
    
    // Показываем название предмета если используем школьные модули
    const subjectLabel = currentSubject && schoolModules[currentSubject] 
        ? `<div style="font-size: 14px; color: #666; margin-bottom: 6px;">📚 Предмет: <b>${currentSubject}</b></div>` 
        : '';
    
    hintElement.innerHTML = `
        ${subjectLabel}
        <div style="font-size: 18px; color: #333; margin-bottom: 8px;"><strong>Задание:</strong> Покажи <b>${current.name}</b></div>
        <div style="font-size: 22px; color: #007bff;">${current.hint}</div>
    `;
    const statusEl = document.getElementById('status-text');
    if (statusEl) statusEl.textContent = '';
    
    // Озвучить инструкцию
    const showText = translations[currentLanguage]?.showGesture || 'Покажи';
    speakInstruction(`${showText}: ${current.name}`);
}

/** Функция озвучки инструкций (Голос учителя) */
function speakInstruction(text) {
    // Егер қазақ тілі болса, функция жұмысын тоқтатады
    if (currentLanguage === 'kk') return;
    
    if (!text || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const msg = new SpeechSynthesisUtterance(text);
    msg.lang = 'ru-RU';
    msg.pitch = 1.1; 
    msg.rate = 0.9;
    msg.volume = 1;
    
    const voices = window.speechSynthesis.getVoices();
    const preferred = voices.find(v => v.lang === msg.lang) || voices.find(v => v.lang.startsWith(msg.lang.split('-')[0]));
    if (preferred) msg.voice = preferred;
    
    window.speechSynthesis.speak(msg);
}

/** Переключить предмет обучения */
function switchSubject(subjectName) {
    if (schoolModules[subjectName]) {
        currentSubject = subjectName;
        wordIndex = 0;
        successCount = 0;
        canCheck = true;
        isChecking = true;
        updateLearningUI();
        const startText = translations[currentLanguage]?.startLesson || 'Начинаем урок';
        speakInstruction(`${startText}: ${subjectName}`);
    }
}

/** Выбрать предмет школьного модуля (math, lang, world) */
function selectSchoolSubject(subjectKey, buttonElement) {
    changeSchoolSubject(subjectKey, buttonElement);
}

/** Изменить предмет (для нового UI) */
function changeSchoolSubject(subjectKey, buttonElement) {
    // Убрать active со всех кнопок
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    
    // Добавить active на нажатую кнопку
    if (buttonElement) {
        buttonElement.classList.add('active');
    } else {
        const btn = document.getElementById(`btn-${subjectKey}`);
        if (btn) btn.classList.add('active');
    }
    
    const modules = getSchoolModules();
    
    if (!modules[subjectKey]) {
        console.warn('Subject not found:', subjectKey);
        return;
    }
    
    // Обновить состояние
    schoolSubjectKey = subjectKey;
    schoolWordIndex = 0;
    schoolSuccessCount = 0;
    schoolCompletedWords = 0;
    schoolCanCheck = true;
    
    // Обновить UI
    updateSchoolUI();
    
    // Озвучить
    const subjects = getSchoolSubjects();
    const subjectName = subjects[subjectKey];
    speakSchool(subjectName);
}

/** Озвучка для школьного модуля */
function speakSchool(text) {
    // Егер қазақ тілі болса, функция жұмысын тоқтатады
    if (currentLanguage === 'kk') return;
    
    if (!text || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const msg = new SpeechSynthesisUtterance(text);
    msg.lang = 'ru-RU';
    msg.pitch = 1.1;
    msg.rate = 0.9;
    window.speechSynthesis.speak(msg);
}

// Глобальные переменные для школьного модуля
var schoolSubjectKey = "math";
var schoolWordIndex = 0;
var schoolSuccessCount = 0;
var schoolCompletedWords = 0;
var schoolCanCheck = true;
var schoolCameraActive = false;


/** Озвучить слово (режим обучения): русский или казахский по языку интерфейса, приятный тон и темп. */
function speakWord(text) {
    // Егер қазақ тілі болса, функция жұмысын тоқтатады
    if (currentLanguage === 'kk') return;
    
    if (!text || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const locale = 'ru-RU';
    const doSpeak = () => {
        const speech = new SpeechSynthesisUtterance(text);
        speech.lang = locale;
        speech.pitch = 1.2;
        speech.rate = 0.9;
        speech.volume = 1;
        const voices = window.speechSynthesis.getVoices();
        const preferred = voices.find((v) => v.lang === locale) || voices.find((v) => v.lang.startsWith(locale.split('-')[0]));
        if (preferred) speech.voice = preferred;
        window.speechSynthesis.speak(speech);
    };
    const voices = window.speechSynthesis.getVoices();
    if (voices.length === 0) {
        window.speechSynthesis.onvoiceschanged = () => {
            window.speechSynthesis.onvoiceschanged = null;
            doSpeak();
        };
    } else {
        doSpeak();
    }
}

/** Проверка по паттерну пальцев и количеству рук (вызывать в onResults при включённом режиме обучения). */
function processHands(multiLandmarks) {
    const dictionary = getCurrentLearningDictionary();
    if (!multiLandmarks || multiLandmarks.length === 0 || !canCheck || !dictionary.length) return;
    if (!hasValidLandmarks(multiLandmarks[0])) return;
    
    // Безопасный индекс
    if (wordIndex >= dictionary.length) wordIndex = 0;
    
    const current = dictionary[wordIndex];
    const detectedHands = multiLandmarks.length;
    const landmarks = multiLandmarks[0];
    const tips = [8, 12, 16, 20];
    const pips = [6, 10, 14, 18];
    const fingers = tips.map((t, i) => (landmarks[t].y < landmarks[pips[i]].y ? "1" : "0"));
    fingers.unshift(landmarks[4].y < landmarks[2].y ? "1" : "0");
    const fingerStr = fingers.join("");
    if (fingerStr !== current.fingers || detectedHands < current.hands) return;
    successCount++;
    canCheck = false;
    isChecking = false;
    if (successCount === 1) {
        // Подбадривание
        const repeatText = translations[currentLanguage]?.repeatOnce || 'Хорошо! Повтори еще раз!';
        speakInstruction(repeatText);
        showSimpleFeedback(translations[currentLanguage]?.showAgainHint || 'Хорошо! Еще один раз!');
        setTimeout(() => { canCheck = true; isChecking = true; }, 1500);
    } else if (successCount >= 2) {
        // ПОБЕДА: Озвучка + Эффекты
        const audioText = current.audio || current.name;
        speakWord(audioText);
        showStarExplosion(current.name);
        successCount = 0;
        wordIndex = (wordIndex + 1) % dictionary.length;
        
        // Если закончили все слова в предмете
        if (wordIndex === 0) {
            setTimeout(() => {
                const completeText = translations[currentLanguage]?.lessonComplete || 'Урок окончен! Ты супер!';
                speakInstruction(completeText);
            }, 2000);
        }
        
        setTimeout(() => { canCheck = true; isChecking = true; updateLearningUI(); }, 4000);
    }
}

/** Эффект "КОНФЕТЫ + ЖАРАЙСЫҢ" с названием выученного слова */
function showStarExplosion(word) {
    const overlay = document.createElement('div');
    overlay.className = 'learning-celebration';
    overlay.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 10000;
        text-align: center;
        font-family: 'Comic Sans MS', 'Arial Black', sans-serif;
        pointer-events: none;
    `;
    
    const textRu = translations[currentLanguage]?.celebrationText || 'Молодец!';
    const textKk = currentLanguage === 'kk' ? 'Жарайсың!' : 'ЖАРАЙСЫҢ!';
    
    overlay.innerHTML = `
        <h1 class="winner-pulse" style="font-size: clamp(50px, 14vw, 70px); color: #FFD700; text-shadow: 3px 3px 10px #000; margin: 0;">${word}!</h1>
        <h2 style="font-size: clamp(36px, 10vw, 50px); color: #FF4500; text-shadow: 2px 2px 8px rgba(0,0,0,0.5); margin-top: 10px;">
            ${textKk} 🍬
        </h2>
        <p style="font-size: 24px; color: #fff; text-shadow: 1px 1px 5px #000; margin-top: 5px;">${textRu}</p>
    `;
    document.body.appendChild(overlay);

    // Салют из звезд и конфет
    createCelebrationParticles();

    setTimeout(() => overlay.remove(), 3500);
}

/** Создание частиц для празднования (конфеты, звезды) */
function createCelebrationParticles() {
    const items = ['🍬', '🍭', '🍫', '⭐', '🌟', '✨', '🎉', '🎊', '💫', '🏆'];
    for (let i = 0; i < 40; i++) {
        const item = document.createElement('div');
        item.textContent = items[Math.floor(Math.random() * items.length)];
        item.style.cssText = `
            position: fixed;
            left: 50%;
            top: 50%;
            font-size: ${Math.random() * 35 + 25}px;
            z-index: 9999;
            transition: all 2s cubic-bezier(0.25, 1, 0.5, 1);
            pointer-events: none;
        `;
        document.body.appendChild(item);
        
        setTimeout(() => {
            const angle = Math.random() * Math.PI * 2;
            const radius = Math.random() * 600 + 150;
            const x = Math.cos(angle) * radius;
            const y = Math.sin(angle) * radius;
            item.style.transform = `translate(calc(-50% + ${x}px), calc(-50% + ${y}px)) rotate(${Math.random() * 1080}deg) scale(${Math.random() * 0.5 + 0.5})`;
            item.style.opacity = '0';
        }, 50);
        
        setTimeout(() => item.remove(), 2100);
    }
}

/** Победа в режиме словаря: надпись Молодец/Жарайсың + конфеты, затем следующее слово. */
function showWinnerEffects() {
    // Используем новую функцию с текущим словом
    const dictionary = getCurrentLearningDictionary();
    const current = dictionary[wordIndex] || { name: '' };
    showStarExplosion(current.name || translations[currentLanguage]?.celebrationText || 'Молодец!');
}

function chooseNextWord() {
    const keys = Object.keys(gestureDictionary);
    const idx = keys.indexOf(currentTarget);
    currentTarget = keys[(idx + 1) % keys.length];
}

/** Проверяет только текущее задание (режим обучения). Возвращает текущее слово при успехе, иначе null. */
function detectAllGesturesForLearning(multiLandmarks) {
    try {
        if (!multiLandmarks || multiLandmarks.length === 0) return null;
        if (!hasValidLandmarks(multiLandmarks[0])) return null;
        const h1 = getFingerStatus(multiLandmarks[0]);
        if (!h1) return null;
        const isTwoHands = multiLandmarks.length === 2;
        const h2 = isTwoHands && hasValidLandmarks(multiLandmarks[1]) ? getFingerStatus(multiLandmarks[1]) : null;

        if (currentTarget === "УЧИТЕЛЬ" && !isTwoHands && h1.join('') === '01000') return "УЧИТЕЛЬ";
        if (currentTarget === "ТИХО" && !isTwoHands && h1.join('') === '01000') return "ТИХО";
        if (currentTarget === "Я ГОТОВ" && !isTwoHands && h1.every(f => f === 1)) return "Я ГОТОВ";
        if (currentTarget === "ЛЮБОВЬ" && isTwoHands && h2) {
            const distHeart = Math.hypot(multiLandmarks[0][4].x - multiLandmarks[1][4].x, multiLandmarks[0][4].y - multiLandmarks[1][4].y);
            if (distHeart < 0.1 && h1[1] === 1 && h2[1] === 1) return "ЛЮБОВЬ";
        }
        if (isTwoHands && h2) {
            if (currentTarget === "ШКОЛА") {
                const dist = Math.hypot(multiLandmarks[0][8].x - multiLandmarks[1][8].x, multiLandmarks[0][8].y - multiLandmarks[1][8].y);
                if (dist < 0.1 && h1[1] === 1 && h2[1] === 1) return "ШКОЛА";
            }
            if (currentTarget === "Я ЗАКОНЧИЛ") {
                const wristDist = Math.hypot(multiLandmarks[0][0].x - multiLandmarks[1][0].x, multiLandmarks[0][0].y - multiLandmarks[1][0].y);
                if (wristDist < 0.1 && h1.every(f => f === 1) && h2.every(f => f === 1)) return "Я ЗАКОНЧИЛ";
            }
            if (currentTarget === "ПОЖАЛУЙСТА") {
                const distPalms = Math.hypot(multiLandmarks[0][0].x - multiLandmarks[1][0].x, multiLandmarks[0][0].y - multiLandmarks[1][0].y);
                if (distPalms < 0.1 && h1.every(f => f === 1) && h2.every(f => f === 1)) return "ПОЖАЛУЙСТА";
            }
        }
    } catch (e) {
        console.warn('detectAllGesturesForLearning:', e);
    }
    return null;
}

/** Короткая подсказка между попытками (1 раз / 2 раза). */
function showSimpleFeedback(text) {
    const feedback = document.createElement('div');
    feedback.className = 'learning-feedback';
    feedback.textContent = text;
    feedback.style.cssText = 'position:fixed; bottom:20%; left:50%; transform:translateX(-50%); font-size:clamp(24px, 5vw, 40px); color:#007bff; background:white; padding:12px 20px; border-radius:10px; z-index:10000; box-shadow:0 4px 12px rgba(0,0,0,0.15); pointer-events:none;';
    document.body.appendChild(feedback);
    setTimeout(() => feedback.remove(), 1400);
}

/** Показать надпись «Молодец»/«Жарайсың» и эффект конфет при правильном жесте (без смены слова). */
function showGestureCelebration() {
    const text = translations[currentLanguage]?.celebrationText || 'Молодец!';
    const winNote = document.createElement('div');
    winNote.className = 'gesture-celebration';
    winNote.innerHTML = text + ' 🍬';
    winNote.style.cssText = 'position:fixed; top:50%; left:50%; transform:translate(-50%,-50%); font-size:clamp(48px, 12vw, 80px); color:#ff8c00; z-index:10001; font-family:Arial,sans-serif; text-shadow:3px 3px #ffd700; pointer-events:none;';
    document.body.appendChild(winNote);
    spawnCandyExplosion();
    setTimeout(() => {
        winNote.remove();
        canCelebrate = true;
    }, 3000);
}

/** Эффект победы в режиме обучения: надпись МОЛОДЕЦ, конфеты, через 3 с — следующее слово и обновление подсказки. */
function celebrate() {
    const winNote = document.createElement('div');
    winNote.className = 'learning-celebration';
    winNote.innerHTML = (translations[currentLanguage]?.celebrationText || 'Молодец!') + ' 🍬';
    winNote.style.cssText = 'position:fixed; top:50%; left:50%; transform:translate(-50%,-50%); font-size:clamp(48px, 12vw, 80px); color:#ff8c00; z-index:10001; font-family:Arial,sans-serif; text-shadow:3px 3px #ffd700; pointer-events:none;';
    document.body.appendChild(winNote);
    spawnCandyExplosion();
    setTimeout(() => {
        winNote.remove();
        chooseNextWord();
        updateHint();
        canCelebrate = true;
    }, 3000);
}

// Gesture templates for sentence building
const gestureTemplates = [
    { pattern: ["Hello", "You"], sentence: "Hello, how are you?" },
    { pattern: ["Help", "You"], sentence: "Do you need help?" },
    { pattern: ["Yes", "Help"], sentence: "Yes, I need help." },
    { pattern: ["No", "Help"], sentence: "I don't need help." },
    { pattern: ["Thank you", "You"], sentence: "Thank you very much!" },
    { pattern: ["Good", "You"], sentence: "You are good." },
    { pattern: ["Stop", "You"], sentence: "Please stop!" },
];

// Gesture translations dictionary (English gesture name -> RU/KK)
const gestureTranslations = {
    ru: {
        "Hello": "Привет",
        "How are you": "Как дела?",
        "Goodbye": "До свидания",
        "Help": "Помощь",
        "Yes": "Да",
        "No": "Нет",
        "Thank you": "Спасибо",
        "Water": "Вода",
        "Stop": "Стоп",
        "OK": "ОК",
        "Good": "Хорошо",
        "You": "Ты",
        "Hello, how are you?": "Привет, как дела?",
        "Do you need help?": "Вам нужна помощь?",
        "Yes, I need help.": "Да, мне нужна помощь.",
        "I don't need help.": "Мне не нужна помощь.",
        "Thank you very much!": "Большое спасибо!",
        "You are good.": "Ты хороший.",
        "Please stop!": "Пожалуйста, остановитесь!",
        "Teacher": "Учитель",
        "I'm ready": "Я готов",
        "Super": "Молодец",
        "School": "Школа",
        "Friendship": "Дружба",
        "Please": "Пожалуйста",
        "Silence": "Тишина",
        "Quiet": "Тихо",
        "I want to answer": "Хочу ответить",
        "I'm done": "Я закончил"
    },
    kk: {
        "Hello": "Сәлем",
        "How are you": "Қалайсың?",
        "Goodbye": "Сау бол",
        "Help": "Көмектесіңіз",
        "Yes": "Иә",
        "No": "Жоқ",
        "Thank you": "Рақмет",
        "Water": "Су",
        "Stop": "Тоқта",
        "OK": "Жақсы",
        "Good": "Жақсы",
        "You": "Сен",
        "Hello, how are you?": "Сәлем, қалың қалай?",
        "Do you need help?": "Сізге көмек керек пе?",
        "Yes, I need help.": "Иә, маған көмек керек.",
        "I don't need help.": "Маған көмек қажет емес.",
        "Thank you very much!": "Үлкен рахмет!",
        "You are good.": "Сен жақсысың.",
        "Please stop!": "Өтінемін, тоқтаңыз!",
        "Teacher": "Мұғалім",
        "I'm ready": "Мен дайынмын",
        "Super": "Жарайсың",
        "School": "Мектеп",
        "Friendship": "Достық",
        "Please": "Өтінемін",
        "Silence": "Тыныштық",
        "Quiet": "Тыныш",
        "I want to answer": "Жауап бергім келеді",
        "I'm done": "Мен біттім"
    }
};

// Daily phrases dictionary for Quick Phrases (RU/KK)
const phraseTranslations = {
    hello:      { ru: 'Привет',       kk: 'Сәлем' },
    how_are_you: { ru: 'Как дела?',   kk: 'Қалайсың?' },
    thank_you:  { ru: 'Спасибо',      kk: 'Рақмет' },
    help:       { ru: 'Помогите',     kk: 'Көмектесіңіз' },
    yes:        { ru: 'Да',           kk: 'Иә' },
    no:         { ru: 'Нет',          kk: 'Жоқ' },
    water:      { ru: 'Вода',         kk: 'Су' },
    goodbye:    { ru: 'До свидания',   kk: 'Сау бол' }
};

// Function to translate gesture to current language
function translateGesture(gestureText) {
    if (!gestureText || gestureText === "—") {
        return "—";
    }
    
    const lang = currentLanguage || 'ru';
    const translations = gestureTranslations[lang] || gestureTranslations.ru;
    
    // Try to translate the gesture or sentence
    return translations[gestureText] || gestureText;
}

/** Озвучить текст: русский (ru-RU) или казахский (kk-KZ) по текущему языку интерфейса. */
function speakWithVoice(text, lang) {
    if (!text || !window.speechSynthesis) return;
    const langCode = lang || currentLanguage || 'ru';
    const doSpeak = () => {
        const msg = new SpeechSynthesisUtterance(text);
        const locale = langCode === 'kk' ? 'kk-KZ' : (langCode === 'ru' ? 'ru-RU' : 'en-US');
        msg.lang = locale;
        msg.volume = 1.0;
        if (langCode === 'kk') {
            msg.rate = 0.85;
            msg.pitch = 1.0;
        }
        const voices = window.speechSynthesis.getVoices();
        let preferred = voices.find((v) => v.lang === locale);
        if (!preferred) preferred = voices.find((v) => v.lang.startsWith(locale.split('-')[0]));
        if (preferred) msg.voice = preferred;
        window.speechSynthesis.speak(msg);
    };
    const voices = window.speechSynthesis.getVoices();
    if (voices.length === 0) {
        window.speechSynthesis.onvoiceschanged = () => {
            window.speechSynthesis.onvoiceschanged = null;
            doSpeak();
        };
    } else {
        doSpeak();
    }
}

/** History entries for gesture mode: { englishSentence, timestamp } — used to re-render in current language */
let historyEntries = [];

/** Re-render history list in current language (call after language switch or when adding). */
function renderHistory() {
    const historyContainer = document.getElementById('historyContainer');
    const historyEmpty = document.getElementById('historyEmpty');
    if (!historyContainer) return;
    historyContainer.innerHTML = '';
    if (historyEntries.length === 0) {
        if (historyEmpty) historyContainer.appendChild(historyEmpty);
        return;
    }
    historyEntries.forEach(({ englishSentence, timestamp }) => {
        const translatedForHistory = englishSentence.includes(" · ")
            ? englishSentence.split(" · ").map((g) => translateGesture(g.trim())).join(" · ")
            : translateGesture(englishSentence);
        const historyItem = document.createElement('div');
        historyItem.className = 'history-item';
        historyItem.style.cssText = 'padding: 8px; margin: 4px 0; background: var(--bg-secondary, #f5f5f5); border-radius: 4px;';
        historyItem.innerHTML = `
            <div style="font-size: 11px; color: #999; margin-bottom: 4px;">${timestamp}</div>
            <div style="font-size: 14px;">${translatedForHistory}</div>
            <div style="font-size: 11px; color: #888; margin-top: 2px;">${englishSentence}</div>
        `;
        historyContainer.appendChild(historyItem);
    });
    historyContainer.scrollTop = historyContainer.scrollHeight;
}

// Gesture Stabilization
const GESTURE_BUFFER_SIZE = 12;
const gestureBuffer = [];

function getStabilizedGesture(newGesture) {
    gestureBuffer.push(newGesture);
    if (gestureBuffer.length > GESTURE_BUFFER_SIZE) {
        gestureBuffer.shift();
    }

    const counts = {};
    gestureBuffer.forEach((g) => {
        counts[g] = (counts[g] || 0) + 1;
    });

    let maxCount = 0;
    let stabilized = "—";
    for (const g in counts) {
        if (counts[g] > maxCount) {
            maxCount = counts[g];
            stabilized = g;
        }
    }

    return maxCount > GESTURE_BUFFER_SIZE * 0.6 ? stabilized : lastGesture;
}

/** Check that landmarks array has enough points (MediaPipe Hands = 21). Prevents camera freeze on bad data. */
function hasValidLandmarks(landmarks) {
    if (!landmarks || !Array.isArray(landmarks) || landmarks.length < 21) return false;
    const required = [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20];
    return required.every((i) => landmarks[i] && typeof landmarks[i].x === 'number' && typeof landmarks[i].y === 'number');
}

/** Finger status: [thumb, index, middle, ring, pinky], 1 = up, 0 = bent (MediaPipe indices). Returns null if landmarks invalid. */
function getFingerStatus(landmarks) {
    if (!hasValidLandmarks(landmarks)) return null;
    const tips = [8, 12, 16, 20];
    const pips = [6, 10, 14, 18];
    const thumbTip = landmarks[4];
    const thumbBase = landmarks[2];
    const fingers = tips.map((tip, i) => (landmarks[tip].y < landmarks[pips[i]].y ? 1 : 0));
    const isThumbUp = thumbTip.y < thumbBase.y ? 1 : 0;
    fingers.unshift(isThumbUp);
    return fingers;
}

/** Final/classroom gestures — one hand: Quiet, I want to answer; two hands: I'm done, Friendship. Returns English key or null. */
function detectFinalGestures(multiLandmarks) {
    try {
        if (!multiLandmarks || multiLandmarks.length === 0) return null;
        if (!hasValidLandmarks(multiLandmarks[0])) return null;
        const h1 = getFingerStatus(multiLandmarks[0]);
        if (!h1) return null;
        const isTwoHands = multiLandmarks.length === 2;
        const h2 = isTwoHands && hasValidLandmarks(multiLandmarks[1]) ? getFingerStatus(multiLandmarks[1]) : null;

        if (!isTwoHands && h1.join('') === '01000') return "Quiet";
        if (!isTwoHands && h1.every(f => f === 1)) return "I want to answer";
        if (isTwoHands && h2 && hasValidLandmarks(multiLandmarks[1])) {
            const wristDist = Math.hypot(
                multiLandmarks[0][0].x - multiLandmarks[1][0].x,
                multiLandmarks[0][0].y - multiLandmarks[1][0].y
            );
            if (wristDist < 0.08 && h1.every(f => f === 1) && h2.every(f => f === 1)) return "I'm done";
            const fingerDist = Math.hypot(
                multiLandmarks[0][12].x - multiLandmarks[1][12].x,
                multiLandmarks[0][12].y - multiLandmarks[1][12].y
            );
            if (fingerDist < 0.05) return "Friendship";
        }
    } catch (e) {
        console.warn('detectFinalGestures:', e);
    }
    return null;
}

/** School/classroom gestures (two hands supported). Returns English key or null. Fallback when detectFinalGestures is null. */
function detectSchoolGestures(multiLandmarks) {
    try {
        if (!multiLandmarks || multiLandmarks.length === 0) return null;
        if (!hasValidLandmarks(multiLandmarks[0])) return null;
        const h1 = getFingerStatus(multiLandmarks[0]);
        if (!h1) return null;
        const isTwoHands = multiLandmarks.length === 2;
        const h2 = isTwoHands && hasValidLandmarks(multiLandmarks[1]) ? getFingerStatus(multiLandmarks[1]) : null;

        if (!isTwoHands && h1.join('') === '10000') return "Super";
        if (isTwoHands && h2 && hasValidLandmarks(multiLandmarks[1])) {
            const distTips = Math.hypot(multiLandmarks[0][8].x - multiLandmarks[1][8].x, multiLandmarks[0][8].y - multiLandmarks[1][8].y);
            if (distTips < 0.1 && h1[1] === 1 && h2[1] === 1) return "School";
            const distHeart = Math.hypot(multiLandmarks[0][4].x - multiLandmarks[1][4].x, multiLandmarks[0][4].y - multiLandmarks[1][4].y);
            if (distHeart < 0.1 && h1[1] === 1 && h2[1] === 1) return "Friendship";
            const distPalms = Math.hypot(multiLandmarks[0][0].x - multiLandmarks[1][0].x, multiLandmarks[0][0].y - multiLandmarks[1][0].y);
            if (distPalms < 0.1 && h1.every(f => f === 1) && h2.every(f => f === 1)) return "Please";
            if (Math.abs(multiLandmarks[0][0].x - multiLandmarks[1][0].x) < 0.05) return "Silence";
        }
    } catch (e) {
        console.warn('detectSchoolGestures:', e);
    }
    return null;
}

// Gesture Classification (from Sign-AI)
function classifyGesture(landmarks, handedness = "Unknown") {
    function getDist(p1, p2) {
        return Math.hypot(
            landmarks[p1].x - landmarks[p2].x,
            landmarks[p1].y - landmarks[p2].y
        );
    }

    function isFingerOpen(tipIdx, pipIdx) {
        return getDist(tipIdx, 0) > getDist(pipIdx, 0) * 1.2;
    }

    const thumbOpen = getDist(4, 0) > getDist(3, 0) * 1.1;
    const indexOpen = isFingerOpen(8, 6);
    const middleOpen = isFingerOpen(12, 10);
    const ringOpen = isFingerOpen(16, 14);
    const pinkyOpen = isFingerOpen(20, 18);

    // Gesture Classification
    const thumbIndexDist = getDist(4, 8);
    if (thumbIndexDist < 0.05 && middleOpen && ringOpen && pinkyOpen) {
        return { gesture: "OK", confidence: 95 };
    }

    if (thumbOpen && indexOpen && middleOpen && ringOpen && pinkyOpen) {
        const thumbIndexSpread = Math.abs(landmarks[4].x - landmarks[8].x);
        const indexMiddleSpread = Math.abs(landmarks[8].x - landmarks[12].x);
        const middleRingSpread = Math.abs(landmarks[12].x - landmarks[16].x);
        const ringPinkySpread = Math.abs(landmarks[16].x - landmarks[20].x);

        const avgSpread =
            (thumbIndexSpread +
                indexMiddleSpread +
                middleRingSpread +
                ringPinkySpread) /
            4;

        if (avgSpread > 0.05) {
            return { gesture: "Hello", confidence: 95 };
        }
        if (avgSpread > 0.03) {
            return { gesture: "Goodbye", confidence: 88 };
        }
        return { gesture: "How are you", confidence: 90 };
    }

    if (!thumbOpen && !indexOpen && !middleOpen && !ringOpen && !pinkyOpen) {
        if (handedness === "Left") {
            return { gesture: "Help", confidence: 90 };
        }
        return { gesture: "Stop", confidence: 90 };
    }

    if (indexOpen && middleOpen && !ringOpen && !pinkyOpen && !thumbOpen) {
        return { gesture: "Good", confidence: 92 };
    }

    if (indexOpen && !middleOpen && !ringOpen && !pinkyOpen && !thumbOpen) {
        const indexTipY = landmarks[8].y;
        const wristY = landmarks[0].y;
        if (indexTipY < wristY + 0.15) {
            return { gesture: "Water", confidence: 88 };
        }
        return { gesture: "You", confidence: 90 };
    }

    if (thumbOpen && pinkyOpen && !indexOpen && !middleOpen && !ringOpen) {
        return { gesture: "Thank you", confidence: 88 };
    }

    if (thumbOpen && !indexOpen && !middleOpen && !ringOpen && !pinkyOpen) {
        if (landmarks[4].y < landmarks[3].y) {
            return { gesture: "Yes", confidence: 95 };
        }
    }

    if (thumbOpen && !indexOpen && !middleOpen && !ringOpen && !pinkyOpen) {
        if (landmarks[4].y > landmarks[3].y) {
            return { gesture: "No", confidence: 95 };
        }
    }

    return { gesture: "—", confidence: 0 };
}

// Initialize MediaPipe Hands (from Sign-AI)
function initializeMediaPipeHands(canvas, video, status, gestureResult, confidenceBar, confidenceValue) {
    // Set canvas dimensions to match video
    if (video && canvas) {
        video.addEventListener('loadedmetadata', () => {
            canvas.width = video.videoWidth || 640;
            canvas.height = video.videoHeight || 480;
        });
    }
    if (typeof Hands === 'undefined') {
        console.error('MediaPipe Hands library not loaded');
        return null;
    }

    const canvasCtx = canvas.getContext('2d', {
        alpha: false,
        desynchronized: true,
        willReadFrequently: false,
    });

    // MediaPipe Hands Setup (exact from Sign-AI)
    const hands = new Hands({
        locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`,
    });

    hands.setOptions({
        selfieMode: true,
        maxNumHands: 2,
        modelComplexity: 1,
        minDetectionConfidence: 0.6,
        minTrackingConfidence: 0.6,
    });

    // MediaPipe Hands onResults Handler (exact from Sign-AI)
    hands.onResults((results) => {
        if (isProcessing) return;
        isProcessing = true;

        requestAnimationFrame(() => {
            let schoolGesture = null;
            try {
            canvasCtx.clearRect(0, 0, canvas.width, canvas.height);

            if (results.image) {
                canvasCtx.drawImage(
                    results.image,
                    0,
                    0,
                    canvas.width,
                    canvas.height
                );
            }

            let gestureOutput = "—";
            let confidence = 0;
            const handColors = [
                { connector: "#00FF00", landmark: "#FF0000" }, // first hand: green/red
                { connector: "#0088FF", landmark: "#FF8800" }, // second hand: blue/orange
            ];

            if (results.multiHandLandmarks?.length > 0) {
                const handResults = []; // { gesture, confidence, handedness }
                const statusParts = [];

                // Final/classroom gestures first, then school gestures fallback (safe: no throw)
                schoolGesture = detectFinalGestures(results.multiHandLandmarks) || detectSchoolGestures(results.multiHandLandmarks);
                if (schoolGesture) {
                    gestureOutput = schoolGesture;
                    confidence = 92;
                    if (status) {
                        const lang = currentLanguage === 'kk' ? 'Қол' : 'Рука';
                        const gestureLabel = translateGesture(schoolGesture);
                        status.textContent = `${lang}: ${gestureLabel} | ${translations[currentLanguage]?.gestureRecognized || 'Распознано'}`;
                    }
                }

                results.multiHandLandmarks.forEach((landmarks, i) => {
                    if (!hasValidLandmarks(landmarks)) return;
                    const handedness = results.multiHandedness?.[i]?.label || "Unknown";

                    // Draw hand landmarks and connections (different color per hand)
                    if (typeof drawConnectors !== 'undefined' && typeof drawLandmarks !== 'undefined') {
                        const colors = handColors[i] || handColors[0];
                        drawConnectors(canvasCtx, landmarks, HAND_CONNECTIONS, {
                            color: colors.connector,
                            lineWidth: 2,
                        });
                        drawLandmarks(canvasCtx, landmarks, {
                            color: colors.landmark,
                            lineWidth: 1,
                            radius: 3,
                        });
                    }

                    if (!schoolGesture) {
                        const rawResult = classifyGesture(landmarks, handedness);
                        const stableGesture = getStabilizedGesture(rawResult.gesture);
                        if (stableGesture !== "—") {
                            handResults.push({ gesture: stableGesture, confidence: rawResult.confidence, handedness });
                            statusParts.push(`${handedness}: ${translateGesture(stableGesture)}`);
                        }
                    }
                });

                // Show one word only: pick the gesture with highest confidence (if no school gesture)
                if (!schoolGesture && handResults.length > 0) {
                    const best = handResults.reduce((a, b) => (b.confidence > a.confidence ? b : a));
                    gestureOutput = best.gesture;
                    confidence = best.confidence;
                    if (status) {
                        const lang = currentLanguage === 'kk' ? 'Қол' : 'Рука';
                        status.textContent = `${lang}: ${statusParts.join(" | ")} | ${translations[currentLanguage]?.gestureRecognized || 'Распознано'}`;
                    }
                } else if (!schoolGesture && status) {
                    status.textContent = translations[currentLanguage]?.handNotDetected || 'Рука не обнаружена';
                }
            } else {
                if (status) {
                    status.textContent = translations[currentLanguage]?.handNotDetected || 'Рука не обнаружена';
                }
                confidence = 0;
            }

            // Переведённый текст для отображения (русский/казахский по текущему языку)
            const translatedGesture = gestureOutput !== "—"
                ? (gestureOutput.includes(" · ")
                    ? gestureOutput.split(" · ").map((g) => translateGesture(g.trim())).join(" · ")
                    : translateGesture(gestureOutput))
                : "—";
            // Update gesture display — показываем на русском/казахском, не на английском
            if (gestureResult) {
                gestureResult.textContent = translatedGesture;
                if (gestureOutput !== "—") {
                    gestureResult.classList.add('active');
                } else {
                    gestureResult.classList.remove('active');
                }
            }

            // Update translation output (#output) — то же значение на текущем языке
            const outputElement = document.getElementById('output');
            if (outputElement) {
                outputElement.textContent = translatedGesture;
            }

            // Update confidence bar (from Sign-AI)
            if (confidenceBar) {
                confidenceBar.style.width = confidence + "%";
            }
            if (confidenceValue) {
                confidenceValue.textContent = Math.round(confidence) + "%";

                if (confidence >= 80) {
                    confidenceValue.style.color = "#00ff88";
                } else if (confidence >= 50) {
                    confidenceValue.style.color = "#ffaa00";
                } else {
                    confidenceValue.style.color = "#ff4444";
                }
            }

            // Handle gesture recognition with cooldown (from Sign-AI)
            const now = Date.now();
            if (
                gestureOutput !== "—" &&
                gestureOutput !== lastGesture &&
                now - lastTime > COOLDOWN
            ) {
                gestureHistory.push(gestureOutput);

                let englishSentence = gestureOutput;

                if (gestureHistory.length >= 2) {
                    const lastTwo = gestureHistory.slice(-2);
                    const template = gestureTemplates.find(
                        (t) => t.pattern[0] === lastTwo[0] && t.pattern[1] === lastTwo[1]
                    );
                    if (template) englishSentence = template.sentence;
                }

                // Update sentence text element
                const sentenceText = document.getElementById('sentenceText');
                if (sentenceText) {
                    sentenceText.textContent = englishSentence;
                }

                // Update translation output with full sentence if available (support combined gestures)
                const outputElement = document.getElementById('output');
                if (outputElement) {
                    const translatedSentence = englishSentence.includes(" · ")
                        ? englishSentence.split(" · ").map((g) => translateGesture(g.trim())).join(" · ")
                        : translateGesture(englishSentence);
                    outputElement.textContent = translatedSentence;
                }
                // Озвучить распознанную фразу на текущем языке: русский или казахский
                speakWithVoice(translatedSentence, currentLanguage);

                // Add to history (store English, show translated in current language)
                const timestamp = new Date().toLocaleTimeString();
                historyEntries.push({ englishSentence, timestamp });
                renderHistory();

                // При правильном жесте: надпись «Молодец»/«Жарайсың» и конфеты (рус/каз по языку интерфейса)
                const showCelebration = (schoolGesture || (confidence >= 80 && !lastGestureWasSuccess)) && canCelebrate;
                if (showCelebration) {
                    canCelebrate = false;
                    showGestureCelebration();
                }
                if (confidence >= 80 && !lastGestureWasSuccess) {
                    lastGestureWasSuccess = true;
                    handleGestureSuccessForGamification();
                }

                lastGesture = gestureOutput;
                lastTime = now;
            }

            // Режим обучения: проверка по паттерну пальцев (словарь learningDictionary) или по геометрии (gestureDictionary)
            if (learningMode && results.multiHandLandmarks?.length > 0) {
                processHands(results.multiHandLandmarks);
                if (canCheck && isChecking) {
                    const learned = detectAllGesturesForLearning(results.multiHandLandmarks);
                    if (learned === currentTarget) {
                        successCount++;
                        isChecking = false;
                        if (successCount < 2) {
                            showSimpleFeedback(translations[currentLanguage]?.showAgainHint || 'Хорошо! Покажи еще один раз!');
                            setTimeout(() => { isChecking = true; }, 1500);
                        } else {
                            celebrate();
                            successCount = 0;
                            setTimeout(() => { isChecking = true; }, 4000);
                        }
                    }
                }
            }

            } catch (err) {
                console.warn('Hands onResults error:', err);
            } finally {
                isProcessing = false;
            }
        });
    });

    return hands;
}

// Start/Stop Camera with MediaPipe Hands
const startCameraBtn = document.getElementById('startCamera');
if (startCameraBtn) {
    startCameraBtn.addEventListener('click', async () => {
        const video = document.getElementById('webcam');
        const canvas = document.getElementById('output_canvas');
        const status = document.getElementById('handTrackingStatus');
        const gestureResult = document.getElementById('gesture_result');
        const confidenceBar = document.getElementById('confidenceBar');
        const confidenceValue = document.getElementById('confidenceValue');
        const btn = document.getElementById('startCamera');

        // Set canvas dimensions
        if (canvas) {
            canvas.width = 640;
            canvas.height = 480;
        }

        if (!handTrackingActive) {
            try {
                // Check if MediaPipe libraries are loaded
                if (typeof Hands === 'undefined' || typeof Camera === 'undefined') {
                    alert('MediaPipe библиотеки не загружены. Убедитесь, что скрипты подключены.');
                    return;
                }

                // Initialize MediaPipe Hands with onResults handler (from Sign-AI)
                mediaPipeHands = initializeMediaPipeHands(canvas, video, status, gestureResult, confidenceBar, confidenceValue);
                if (!mediaPipeHands) {
                    alert('Не удалось инициализировать MediaPipe Hands');
                    return;
                }

                // Camera Setup (exact from Sign-AI)
                mediaPipeCamera = new Camera(video, {
                    onFrame: async () => {
                        if (handTrackingActive && mediaPipeHands) {
                            await mediaPipeHands.send({ image: video });
                        }
                    },
                    width: 640,
                    height: 480,
                });

                await mediaPipeCamera.start();
                
                handTrackingActive = true;
                btn.textContent = translations[currentLanguage]?.disableCamera || 'Выключить камеру';
                if (status) {
                    status.textContent = translations[currentLanguage]?.cameraActive || 'Камера активна';
                }

            } catch (error) {
                console.error('Error starting camera:', error);
                alert(translations[currentLanguage]?.cameraPermissionDenied || 'Не удалось получить доступ к камере');
                handTrackingActive = false;
            }
        } else {
            // Stop MediaPipe Camera
            if (mediaPipeCamera) {
                mediaPipeCamera.stop();
                mediaPipeCamera = null;
            }

            // Stop video stream
            if (video && video.srcObject) {
                video.srcObject.getTracks().forEach(track => track.stop());
                video.srcObject = null;
            }

            // Clear canvas
            if (canvas) {
                const ctx = canvas.getContext('2d');
                if (ctx) {
                    ctx.clearRect(0, 0, canvas.width || 640, canvas.height || 480);
                }
            }

            handTrackingActive = false;
            mediaPipeHands = null;
            
            if (btn) btn.textContent = translations[currentLanguage]?.enableCamera || 'Включить камеру';
            if (status) {
                status.textContent = translations[currentLanguage]?.cameraInactive || 'Камера не активна';
            }
            if (gestureResult) {
                gestureResult.textContent = "Здесь будет текст";
                gestureResult.classList.remove('active');
            }
            if (confidenceBar) confidenceBar.style.width = "0%";
            if (confidenceValue) confidenceValue.textContent = "0%";
            
            // Clear translation output
            const outputElement = document.getElementById('output');
            if (outputElement) {
                outputElement.textContent = "—";
            }

            // Reset gesture tracking
            lastGesture = "—";
            gestureHistory = [];
            gestureBuffer.length = 0;
        }
    });
}

// Diagnostics functions
function updateDiagnostics(video, canvas) {
    try {
        if (!video || !canvas) return;
        
        // Check camera connection
        diagnosticsData.cameraConnected = video.srcObject !== null && video.srcObject !== undefined;
        
        // Check video stream
        diagnosticsData.videoStreamActive = video.readyState >= 2 && !video.paused && !video.ended;
        
        // Check hand detection
        diagnosticsData.handDetected = handTrackingData && handTrackingData.handQuality === 'good';
    
        // Analyze lighting (simplified - based on image brightness)
        if (canvas && video.readyState >= 2) {
            try {
                const ctx = canvas.getContext('2d');
                if (!ctx) return;
                
                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                const data = imageData.data;
                
                let totalBrightness = 0;
                let pixelCount = 0;
                
                // Sample brightness (every 10th pixel for performance)
                for (let i = 0; i < data.length; i += 40) {
                    const r = data[i];
                    const g = data[i + 1];
                    const b = data[i + 2];
                    const brightness = (r + g + b) / 3;
                    totalBrightness += brightness;
                    pixelCount++;
                }
                
                if (pixelCount > 0) {
                    const avgBrightness = totalBrightness / pixelCount;
                    
                    // Good lighting: brightness between 80 and 200
                    if (avgBrightness >= 80 && avgBrightness <= 200) {
                        diagnosticsData.lighting = 'good';
                    } else {
                        diagnosticsData.lighting = 'poor';
                    }
                }
            } catch (error) {
                console.error('Error analyzing lighting:', error);
            }
        }
        
        // Update distance based on hand quality
        if (handTrackingData && handTrackingData.handQuality) {
            if (handTrackingData.handQuality === 'too_close') {
                diagnosticsData.distance = 'too_close';
            } else if (handTrackingData.handQuality === 'too_far') {
                diagnosticsData.distance = 'too_far';
            } else if (handTrackingData.handQuality === 'good') {
                diagnosticsData.distance = 'optimal';
            } else {
                diagnosticsData.distance = 'unknown';
            }
        }
        
        // Check angle (simplified - based on hand position in frame)
        if (handTrackingData && handTrackingData.handBounds && 
            typeof handTrackingData.handBounds.minX === 'number') {
            const centerX = canvas.width / 2;
            const centerY = canvas.height / 2;
            const handCenterX = (handTrackingData.handBounds.minX + handTrackingData.handBounds.maxX) / 2;
            const handCenterY = (handTrackingData.handBounds.minY + handTrackingData.handBounds.maxY) / 2;
            
            const offsetX = Math.abs(handCenterX - centerX);
            const offsetY = Math.abs(handCenterY - centerY);
            const maxOffset = Math.max(canvas.width, canvas.height) * 0.3;
            
            if (offsetX < maxOffset && offsetY < maxOffset) {
                diagnosticsData.angle = 'good';
            } else {
                diagnosticsData.angle = 'bad';
            }
        }
        
        // Update diagnostics display
        updateDiagnosticsDisplay();
    } catch (error) {
        console.error('Error updating diagnostics:', error);
    }
}

function updateDiagnosticsDisplay() {
    try {
        // Camera status
        const cameraStatusText = document.getElementById('cameraStatusText');
        if (cameraStatusText) {
            if (diagnosticsData.cameraConnected) {
                cameraStatusText.textContent = translations[currentLanguage]?.cameraConnected || 'Камера подключена';
                cameraStatusText.className = 'diagnostic-value success';
            } else {
                cameraStatusText.textContent = translations[currentLanguage]?.cameraNotConnected || 'Камера не подключена';
                cameraStatusText.className = 'diagnostic-value error';
            }
        }
    
        // Video stream
        const videoStreamText = document.getElementById('videoStreamText');
        if (videoStreamText) {
            if (diagnosticsData.videoStreamActive) {
                videoStreamText.textContent = translations[currentLanguage]?.videoStreamActive || 'Видеопоток активен';
                videoStreamText.className = 'diagnostic-value success';
            } else {
                videoStreamText.textContent = translations[currentLanguage]?.videoStreamInactive || 'Видеопоток неактивен';
                videoStreamText.className = 'diagnostic-value error';
            }
        }
        
        // Hand detection
        const handDetectionText = document.getElementById('handDetectionText');
        if (handDetectionText) {
            if (diagnosticsData.handDetected) {
                handDetectionText.textContent = translations[currentLanguage]?.handDetected || 'Рука обнаружена';
                handDetectionText.className = 'diagnostic-value success';
            } else {
                handDetectionText.textContent = translations[currentLanguage]?.handNotDetected || 'Рука не обнаружена';
                handDetectionText.className = 'diagnostic-value error';
            }
        }
        
        // Lighting
        const lightingText = document.getElementById('lightingText');
        if (lightingText) {
            if (diagnosticsData.lighting === 'good') {
                lightingText.textContent = translations[currentLanguage]?.lightingGood || 'Освещение хорошее';
                lightingText.className = 'diagnostic-value success';
            } else if (diagnosticsData.lighting === 'poor') {
                lightingText.textContent = translations[currentLanguage]?.lightingPoor || 'Освещение плохое';
                lightingText.className = 'diagnostic-value warning';
            } else {
                lightingText.textContent = '-';
                lightingText.className = 'diagnostic-value';
            }
        }
        
        // Distance
        const distanceText = document.getElementById('distanceText');
        if (distanceText) {
            if (diagnosticsData.distance === 'optimal') {
                distanceText.textContent = translations[currentLanguage]?.distanceOptimal || 'Расстояние оптимальное (30-70 см)';
                distanceText.className = 'diagnostic-value success';
            } else if (diagnosticsData.distance === 'too_close') {
                distanceText.textContent = translations[currentLanguage]?.distanceTooClose || 'Слишком близко (< 30 см)';
                distanceText.className = 'diagnostic-value warning';
            } else if (diagnosticsData.distance === 'too_far') {
                distanceText.textContent = translations[currentLanguage]?.distanceTooFar || 'Слишком далеко (> 70 см)';
                distanceText.className = 'diagnostic-value warning';
            } else {
                distanceText.textContent = '-';
                distanceText.className = 'diagnostic-value';
            }
        }
        
        // Angle
        const angleText = document.getElementById('angleText');
        if (angleText) {
            if (diagnosticsData.angle === 'good') {
                angleText.textContent = translations[currentLanguage]?.angleGood || 'Угол хороший';
                angleText.className = 'diagnostic-value success';
            } else if (diagnosticsData.angle === 'bad') {
                angleText.textContent = translations[currentLanguage]?.angleBad || 'Отрегулируйте угол камеры';
                angleText.className = 'diagnostic-value warning';
            } else {
                angleText.textContent = '-';
                angleText.className = 'diagnostic-value';
            }
        }
        
        // Coordinates
        const coordinatesText = document.getElementById('coordinatesText');
        if (coordinatesText) {
            if (diagnosticsData.coordinates && 
                diagnosticsData.coordinates.x !== null && 
                diagnosticsData.coordinates.y !== null) {
                coordinatesText.textContent = `X: ${diagnosticsData.coordinates.x}, Y: ${diagnosticsData.coordinates.y}`;
                coordinatesText.className = 'diagnostic-value';
            } else {
                coordinatesText.textContent = '-';
                coordinatesText.className = 'diagnostic-value';
            }
        }
        
        // FPS
        const fpsText = document.getElementById('fpsText');
        if (fpsText) {
            fpsText.textContent = `${diagnosticsData.fps || 0} fps`;
            fpsText.className = 'diagnostic-value';
        }
    } catch (error) {
        console.error('Error updating diagnostics display:', error);
    }
}

// Diagnostics UI removed from index.html

// Calibration functions
document.addEventListener('DOMContentLoaded', () => {
    const calibrateHandBtn = document.getElementById('calibrateHand');
    if (calibrateHandBtn) {
        calibrateHandBtn.addEventListener('click', () => {
            try {
                const video = document.getElementById('cameraVideo');
                const canvas = document.getElementById('handCanvas');
                
                if (!video || !canvas || !handTrackingActive) {
                    alert(translations[currentLanguage]?.cameraInactive || 'Сначала включите камеру');
                    return;
                }
                
                // Get current hand points
                const points = generateMockHandPoints(canvas.width, canvas.height);
                
                if (!points || points.length < 5) {
                    alert(translations[currentLanguage]?.handNotVisible || 'Рука не видна полностью');
                    return;
                }
                
                // Check quality
                if (!handTrackingData || handTrackingData.handQuality !== 'good') {
                    alert(translations[currentLanguage]?.handNotVisible || 'Рука не видна полностью');
                    return;
                }
                
                // Set calibration origin (wrist point - index 0)
                if (points[0] && typeof points[0].x === 'number' && typeof points[0].y === 'number') {
                    handTrackingData.calibrationOrigin = {
                        x: points[0].x,
                        y: points[0].y
                    };
                    
                    // Calculate hand size (average distance from wrist to fingertips)
                    const wrist = points[0];
                    let totalDistance = 0;
                    let count = 0;
                    
                    // Fingertip indices: 4, 8, 12, 16, 20
                    const fingertips = [4, 8, 12, 16, 20];
                    fingertips.forEach(idx => {
                        if (points[idx] && typeof points[idx].x === 'number' && typeof points[idx].y === 'number') {
                            const dist = getDistance(wrist, points[idx]);
                            if (dist > 0) {
                                totalDistance += dist;
                                count++;
                            }
                        }
                    });
                    
                    handTrackingData.handSize = count > 0 ? totalDistance / count : 80;
                    handTrackingData.calibrated = true;
                    
                    // Show success message
                    const status = document.getElementById('handTrackingStatus');
                    if (status) {
                        status.textContent = translations[currentLanguage]?.calibrationComplete || 'Калибровка завершена';
                        setTimeout(() => {
                            if (handTrackingActive) {
                                status.textContent = translations[currentLanguage]?.cameraActive || 'Камера активна';
                            }
                        }, 2000);
                    }
                    
                    // Clear history to start fresh
                    handTrackingData.pointHistory = [];
                }
            } catch (error) {
                console.error('Error calibrating hand:', error);
                alert('Ошибка при калибровке');
            }
        });
    }
});

// Reset calibration
document.addEventListener('DOMContentLoaded', () => {
    const resetCalibrationBtn = document.getElementById('resetCalibration');
    if (resetCalibrationBtn) {
        resetCalibrationBtn.addEventListener('click', () => {
            try {
                if (handTrackingData) {
                    handTrackingData.calibrated = false;
                    handTrackingData.calibrationOrigin = { x: null, y: null };
                    handTrackingData.handSize = null;
                    handTrackingData.pointHistory = [];
                }
            } catch (error) {
                console.error('Error resetting calibration:', error);
            }
        });
    }

    // Sensitivity selector
    const sensitivitySelect = document.getElementById('sensitivitySelect');
    if (sensitivitySelect) {
        sensitivitySelect.addEventListener('change', (e) => {
            try {
                if (handTrackingData) {
                    handTrackingData.sensitivity = e.target.value;
                    
                    // Adjust stability threshold based on sensitivity
                    switch(e.target.value) {
                        case 'low':
                            handTrackingData.stabilityThreshold = 5;
                            break;
                        case 'medium':
                            handTrackingData.stabilityThreshold = 3;
                            break;
                        case 'high':
                            handTrackingData.stabilityThreshold = 2;
                            break;
                    }
                }
            } catch (error) {
                console.error('Error changing sensitivity:', error);
            }
        });
    }
});

// Gesture stability check with threshold
function checkGestureStability(detectedGesture) {
    try {
        // Initialize if needed
        if (!handTrackingData.gestureFrames) {
            handTrackingData.gestureFrames = [];
        }
        
        // Add to history
        handTrackingData.gestureFrames.push(detectedGesture);
        
        // Keep only last N frames
        if (handTrackingData.gestureFrames.length > handTrackingData.stabilityThreshold * 2) {
            handTrackingData.gestureFrames.shift();
        }
        
        // Check if gesture is stable
        if (handTrackingData.gestureFrames.length >= handTrackingData.stabilityThreshold) {
            const recentFrames = handTrackingData.gestureFrames.slice(-handTrackingData.stabilityThreshold);
            const allSame = recentFrames.every(g => g === recentFrames[0] && g !== null);
            
            if (allSame) {
                handTrackingData.currentStableGesture = recentFrames[0];
                return recentFrames[0];
            }
        }
        
        return null;
    } catch (error) {
        console.error('Error checking gesture stability:', error);
        return null;
    }
}

// Gesture buttons (fallback input method)
document.addEventListener('DOMContentLoaded', () => {
    const gestureButtons = document.querySelectorAll('.gesture-btn');
    gestureButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            try {
                const gesture = btn.getAttribute('data-gesture');
                const skeletonDisplay = document.getElementById('handSkeleton');
                
                if (skeletonDisplay) {
                    skeletonDisplay.innerHTML = `
                        <div style="color: #28a745; font-weight: 600; text-align: center; padding: 10px;">
                            ✓ ${translations[currentLanguage]?.gestureRecognized || 'Жест распознан правильно'}<br>
                            Жест: ${gesture || 'неизвестно'}
                        </div>
                    `;
                }
                
                // Update accuracy
                gestureAccuracy = {
                    overall: 1.0,
                    thumb: 1.0,
                    index: 1.0,
                    middle: 1.0,
                    ring: 1.0,
                    pinky: 1.0
                };
                
                updateHandTrackingStatus(gestureAccuracy);
                // Ensure gamification UI is in sync after manual gesture
                updateGamificationUI();
            } catch (error) {
                console.error('Error handling gesture button click:', error);
            }
        });
    });
});

// Toggle gesture buttons visibility
function toggleGestureButtons(show) {
    try {
        const gestureButtonsContainer = document.getElementById('gestureButtons');
        if (gestureButtonsContainer) {
            if (show) {
                gestureButtonsContainer.classList.remove('hidden');
            } else {
                gestureButtonsContainer.classList.add('hidden');
            }
        }
    } catch (error) {
        console.warn('Error toggling gesture buttons:', error);
    }
}

// Hand tracking state
let currentGesture = null;
let gestureAccuracy = {};

// Improved hand tracking system
let handTrackingData = {
    // Calibration
    calibrated: false,
    calibrationOrigin: { x: null, y: null },
    handSize: null,
    
    // Smoothing
    pointHistory: [], // History of last N frames for each point
    smoothedPoints: [],
    smoothingWindow: 5, // Number of frames to average
    
    // Stability threshold
    gestureFrames: [], // History of detected gestures
    stabilityThreshold: 3, // Frames needed for stable gesture
    currentStableGesture: null,
    
    // Quality check
    handQuality: 'unknown', // 'good', 'too_close', 'too_far', 'not_visible'
    handBounds: null,
    
    // Sensitivity
    sensitivity: 'medium', // 'low', 'medium', 'high'
    
    // Hand position tracking
    handPosition: { x: null, y: null, detected: false },
    handVelocity: { x: 0, y: 0 }
};

// Diagnostics system
let diagnosticsData = {
    cameraConnected: false,
    videoStreamActive: false,
    handDetected: false,
    lighting: 'unknown', // 'good', 'poor'
    distance: 'unknown', // 'optimal', 'too_close', 'too_far'
    angle: 'unknown', // 'good', 'bad'
    coordinates: { x: null, y: null },
    fps: 0,
    frameCount: 0,
    lastFpsUpdate: Date.now()
};

// Draw hand skeleton overlay with color indication
let animationFrameId = null;

function drawHandSkeleton(canvas, video) {
    if (!canvas || !video) {
        console.error('Canvas or video not available');
        return;
    }
    
    const ctx = canvas.getContext('2d');
    if (!ctx) {
        console.error('Could not get canvas context');
        return;
    }
    
    function updateCanvas() {
        if (!handTrackingActive || !canvas || !video) {
            if (animationFrameId) {
                cancelAnimationFrame(animationFrameId);
                animationFrameId = null;
            }
            return;
        }
        
        // Wait for video to be ready
        if (video.readyState < 2) {
            animationFrameId = requestAnimationFrame(updateCanvas);
            return;
        }
        
        const videoWidth = video.videoWidth || 640;
        const videoHeight = video.videoHeight || 480;
        
        if (canvas.width !== videoWidth || canvas.height !== videoHeight) {
            canvas.width = videoWidth;
            canvas.height = videoHeight;
        }
        
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Generate hand tracking points with improved system
        const handPoints = generateMockHandPoints(canvas.width, canvas.height);
        
        // Update hand quality indicator
        updateHandQualityIndicator();
        
        // Show calibration controls if camera is active
        const calibrationControls = document.getElementById('calibrationControls');
        if (calibrationControls && handTrackingActive) {
            calibrationControls.classList.remove('hidden');
        }
        
        // Show quality indicator
        const qualityIndicator = document.getElementById('handQualityIndicator');
        if (qualityIndicator && handTrackingActive) {
            qualityIndicator.classList.remove('hidden');
        }
        
        // Check gesture stability (only if hand quality is good)
        let detectedGesture = null;
        if (handTrackingData && handTrackingData.handQuality === 'good') {
            detectedGesture = detectGestureFromPoints(handPoints);
            const stableGesture = checkGestureStability(detectedGesture);
            
            if (stableGesture) {
                currentGesture = stableGesture;
                // Hide gesture buttons if gesture is detected
                toggleGestureButtons(false);
            } else {
                // Show gesture buttons if gesture is not stable
                toggleGestureButtons(true);
            }
        } else {
            // Show gesture buttons if hand quality is poor
            toggleGestureButtons(true);
        }
        
        // Evaluate gesture accuracy
        const accuracy = evaluateGestureAccuracy(handPoints);
        gestureAccuracy = accuracy || { overall: 0.5, thumb: 0.5, index: 0.5, middle: 0.5, ring: 0.5, pinky: 0.5 };
        
        // Log coordinates for debugging
        if (handPoints && handPoints.length > 0 && handPoints[0] && 
            typeof handPoints[0].x === 'number' && typeof handPoints[0].y === 'number') {
            if (diagnosticsData) {
                diagnosticsData.coordinates = {
                    x: Math.round(handPoints[0].x),
                    y: Math.round(handPoints[0].y)
                };
            }
        }
        
        // Update FPS
        if (diagnosticsData) {
            diagnosticsData.frameCount = (diagnosticsData.frameCount || 0) + 1;
            const now = Date.now();
            if (now - (diagnosticsData.lastFpsUpdate || now) >= 1000) {
                diagnosticsData.fps = diagnosticsData.frameCount || 0;
                diagnosticsData.frameCount = 0;
                diagnosticsData.lastFpsUpdate = now;
            }
        }
        
        // Draw skeleton lines with color indication
        const connections = [
            [0, 1], [1, 2], [2, 3], [3, 4], // Thumb
            [0, 5], [5, 6], [6, 7], [7, 8], // Index
            [0, 9], [9, 10], [10, 11], [11, 12], // Middle
            [0, 13], [13, 14], [14, 15], [15, 16], // Ring
            [0, 17], [17, 18], [18, 19], [19, 20] // Pinky
        ];
        
        connections.forEach(([start, end], index) => {
            if (handPoints[start] && handPoints[end] &&
                typeof handPoints[start].x === 'number' && typeof handPoints[start].y === 'number' &&
                typeof handPoints[end].x === 'number' && typeof handPoints[end].y === 'number') {
                // Color based on accuracy: green for correct, red for incorrect
                const isCorrect = accuracy && accuracy.overall > 0.7;
                ctx.strokeStyle = isCorrect ? '#28a745' : '#dc3545';
                ctx.lineWidth = isCorrect ? 3 : 2;
                
                ctx.beginPath();
                ctx.moveTo(handPoints[start].x, handPoints[start].y);
                ctx.lineTo(handPoints[end].x, handPoints[end].y);
                ctx.stroke();
                
                // Draw correction arrows for incorrect positions
                if (!isCorrect && index % 3 === 0) {
                    try {
                        drawCorrectionArrow(ctx, handPoints[start], handPoints[end]);
                    } catch (error) {
                        // Ignore arrow drawing errors
                    }
                }
            }
        });
        
        // Draw points with color indication
        handPoints.forEach((point, index) => {
            if (point && typeof point.x === 'number' && typeof point.y === 'number') {
                const isCorrect = accuracy && accuracy.overall > 0.7;
                ctx.fillStyle = isCorrect ? '#28a745' : '#dc3545';
                
                ctx.beginPath();
                ctx.arc(point.x, point.y, 5, 0, 2 * Math.PI);
                ctx.fill();
                
                // Draw point number for debugging
                if (index % 4 === 0) {
                    try {
                        ctx.fillStyle = 'white';
                        ctx.font = '10px Arial';
                        ctx.fillText(index.toString(), point.x + 8, point.y);
                    } catch (error) {
                        // Ignore text drawing errors
                    }
                }
            }
        });
        
        // Draw hand contour (digital grid)
        drawHandContour(ctx, handPoints);
        
        // Update hand skeleton status
        if (accuracy) {
            updateHandTrackingStatus(accuracy);
        }
        
        // Hand tracking overlay is drawn in drawHandTrackingOverlay function
        
        animationFrameId = requestAnimationFrame(updateCanvas);
    }
    
    // Start animation loop
    if (video.readyState >= 2) {
        updateCanvas();
    } else {
        video.addEventListener('loadedmetadata', () => {
            updateCanvas();
        }, { once: true });
    }
}

// Draw correction arrow
function drawCorrectionArrow(ctx, start, end) {
    const midX = (start.x + end.x) / 2;
    const midY = (start.y + end.y) / 2;
    const angle = Math.atan2(end.y - start.y, end.x - start.x);
    
    ctx.strokeStyle = '#ff6b6b';
    ctx.fillStyle = '#ff6b6b';
    ctx.lineWidth = 2;
    
    // Draw arrow
    ctx.beginPath();
    ctx.moveTo(midX, midY);
    const arrowLength = 20;
    const arrowAngle = angle + Math.PI / 2;
    ctx.lineTo(
        midX + Math.cos(arrowAngle) * arrowLength,
        midY + Math.sin(arrowAngle) * arrowLength
    );
    ctx.stroke();
    
    // Arrowhead
    ctx.beginPath();
    ctx.moveTo(
        midX + Math.cos(arrowAngle) * arrowLength,
        midY + Math.sin(arrowAngle) * arrowLength
    );
    ctx.lineTo(
        midX + Math.cos(arrowAngle) * arrowLength - Math.cos(angle) * 8,
        midY + Math.sin(arrowAngle) * arrowLength - Math.sin(angle) * 8
    );
    ctx.lineTo(
        midX + Math.cos(arrowAngle) * arrowLength + Math.cos(angle) * 8,
        midY + Math.sin(arrowAngle) * arrowLength + Math.sin(angle) * 8
    );
    ctx.closePath();
    ctx.fill();
}

// Draw hand contour (digital grid)
function drawHandContour(ctx, points) {
    try {
        if (!ctx || !points || points.length < 5) return;
        
        ctx.strokeStyle = 'rgba(0, 255, 255, 0.3)';
        ctx.lineWidth = 1;
        ctx.setLineDash([5, 5]);
        
        // Draw grid around hand
        const bounds = getHandBounds(points);
        if (!bounds || typeof bounds.minX !== 'number') return;
        
        const gridSize = 30;
        
        for (let x = bounds.minX; x <= bounds.maxX; x += gridSize) {
            ctx.beginPath();
            ctx.moveTo(x, bounds.minY);
            ctx.lineTo(x, bounds.maxY);
            ctx.stroke();
        }
        
        for (let y = bounds.minY; y <= bounds.maxY; y += gridSize) {
            ctx.beginPath();
            ctx.moveTo(bounds.minX, y);
            ctx.lineTo(bounds.maxX, y);
            ctx.stroke();
        }
        
        ctx.setLineDash([]);
    } catch (error) {
        console.error('Error drawing hand contour:', error);
    }
}

// Get hand bounds
function getHandBounds(points) {
    try {
        if (!points || points.length === 0) {
            return { minX: 0, minY: 0, maxX: 0, maxY: 0 };
        }
        
        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        points.forEach(point => {
            if (point && typeof point.x === 'number' && typeof point.y === 'number') {
                minX = Math.min(minX, point.x);
                minY = Math.min(minY, point.y);
                maxX = Math.max(maxX, point.x);
                maxY = Math.max(maxY, point.y);
            }
        });
        
        // Если не нашли валидных точек, возвращаем дефолтные значения
        if (minX === Infinity) {
            return { minX: 0, minY: 0, maxX: 0, maxY: 0 };
        }
        
        return { minX, minY, maxX, maxY };
    } catch (error) {
        console.error('Error getting hand bounds:', error);
        return { minX: 0, minY: 0, maxX: 0, maxY: 0 };
    }
}

// Improved hand point generation with quality check and smoothing
function generateMockHandPoints(width, height) {
    try {
        if (!width || !height || width <= 0 || height <= 0) {
            width = 640;
            height = 480;
        }
        
        if (!handTrackingData) {
            handTrackingData = {
                calibrated: false,
                calibrationOrigin: { x: null, y: null },
                handSize: null,
                pointHistory: [],
                smoothedPoints: [],
                smoothingWindow: 5,
                gestureFrames: [],
                stabilityThreshold: 3,
                currentStableGesture: null,
                handQuality: 'unknown',
                handBounds: null,
                sensitivity: 'medium',
                handPosition: { x: null, y: null, detected: false },
                handVelocity: { x: 0, y: 0 }
            };
        }
        
        const centerX = width / 2;
        const centerY = height / 2;
        const points = [];
        
        // Use calibration origin if available
        const originX = (handTrackingData.calibrationOrigin && 
                        handTrackingData.calibrationOrigin.x !== null) 
            ? handTrackingData.calibrationOrigin.x 
            : centerX;
        const originY = (handTrackingData.calibrationOrigin && 
                        handTrackingData.calibrationOrigin.y !== null) 
            ? handTrackingData.calibrationOrigin.y 
            : centerY;
        
        // Generate 21 hand keypoints (MediaPipe format)
        for (let i = 0; i < 21; i++) {
            const angle = (i / 21) * Math.PI * 2;
            const baseRadius = handTrackingData.handSize || 80;
            const radius = baseRadius + Math.sin(Date.now() / 500 + i) * 20;
            points.push({
                x: originX + Math.cos(angle) * radius,
                y: originY + Math.sin(angle) * radius
            });
        }
        
        // Apply smoothing
        const smoothed = applySmoothing(points);
        
        // Check hand quality
        checkHandQuality(smoothed, width, height);
        
        return smoothed;
    } catch (error) {
        console.error('Error generating mock hand points:', error);
        // Return default points
        const defaultPoints = [];
        for (let i = 0; i < 21; i++) {
            defaultPoints.push({ x: 320, y: 240 });
        }
        return defaultPoints;
    }
}

// Apply moving average smoothing to hand points
function applySmoothing(points) {
    try {
        if (!points || points.length === 0 || !handTrackingData) {
            return points || [];
        }
        
        // Initialize history if needed
        if (!handTrackingData.pointHistory) {
            handTrackingData.pointHistory = [];
        }
        
        if (handTrackingData.pointHistory.length === 0) {
            for (let i = 0; i < handTrackingData.smoothingWindow; i++) {
                handTrackingData.pointHistory.push(points.map(p => p ? { ...p } : null));
            }
        }
        
        // Add current frame to history
        handTrackingData.pointHistory.push(points.map(p => p ? { ...p } : null));
        if (handTrackingData.pointHistory.length > handTrackingData.smoothingWindow) {
            handTrackingData.pointHistory.shift();
        }
        
        // Calculate smoothed points using moving average
        const smoothed = [];
        for (let i = 0; i < Math.min(21, points.length); i++) {
            let sumX = 0, sumY = 0;
            let count = 0;
            
            for (const frame of handTrackingData.pointHistory) {
                if (frame && frame[i] && typeof frame[i].x === 'number' && typeof frame[i].y === 'number') {
                    sumX += frame[i].x;
                    sumY += frame[i].y;
                    count++;
                }
            }
            
            if (count > 0 && points[i]) {
                smoothed.push({
                    x: sumX / count,
                    y: sumY / count
                });
            } else if (points[i]) {
                smoothed.push({ ...points[i] });
            } else {
                smoothed.push({ x: 0, y: 0 });
            }
        }
        
        handTrackingData.smoothedPoints = smoothed;
        return smoothed;
    } catch (error) {
        console.error('Error applying smoothing:', error);
        return points || [];
    }
}

// Check hand quality (visibility, distance, etc.)
function checkHandQuality(points, width, height) {
    try {
        if (!points || points.length < 5 || !width || !height) {
            if (handTrackingData) {
                handTrackingData.handQuality = 'not_visible';
            }
            return;
        }
        
        // Calculate hand bounds
        const bounds = getHandBounds(points);
        if (handTrackingData) {
            handTrackingData.handBounds = bounds;
        }
        
        if (!bounds || typeof bounds.maxX !== 'number' || typeof bounds.minX !== 'number') {
            if (handTrackingData) {
                handTrackingData.handQuality = 'not_visible';
            }
            return;
        }
        
        const handWidth = bounds.maxX - bounds.minX;
        const handHeight = bounds.maxY - bounds.minY;
        const handArea = handWidth * handHeight;
        const frameArea = width * height;
        
        if (frameArea === 0) {
            if (handTrackingData) {
                handTrackingData.handQuality = 'unknown';
            }
            return;
        }
        
        const handRatio = handArea / frameArea;
        
        // Check if hand is fully visible
        const margin = 20;
        if (bounds.minX < margin || bounds.minY < margin || 
            bounds.maxX > width - margin || bounds.maxY > height - margin) {
            if (handTrackingData) {
                handTrackingData.handQuality = 'not_visible';
            }
            return;
        }
        
        // Check distance (based on hand size relative to frame)
        if (handTrackingData) {
            if (handRatio > 0.4) {
                handTrackingData.handQuality = 'too_close';
            } else if (handRatio < 0.05) {
                handTrackingData.handQuality = 'too_far';
            } else {
                handTrackingData.handQuality = 'good';
            }
        }
    } catch (error) {
        console.error('Error checking hand quality:', error);
        if (handTrackingData) {
            handTrackingData.handQuality = 'unknown';
        }
    }
}

// Update hand quality indicator
function updateHandQualityIndicator() {
    try {
        const indicator = document.getElementById('handQualityIndicator');
        const text = document.getElementById('handQualityText');
        
        if (!indicator || !text) return;
        
        const quality = handTrackingData.handQuality || 'unknown';
        
        if (quality === 'good') {
            indicator.classList.remove('hidden', 'warning', 'error');
            indicator.classList.add('success');
            text.textContent = translations[currentLanguage]?.handPositionGood || 'Положение руки хорошее';
        } else if (quality === 'too_close' || quality === 'too_far') {
            indicator.classList.remove('hidden', 'success', 'error');
            indicator.classList.add('warning');
            text.textContent = quality === 'too_close' 
                ? (translations[currentLanguage]?.handTooClose || 'Рука слишком близко')
                : (translations[currentLanguage]?.handTooFar || 'Рука слишком далеко');
        } else {
            indicator.classList.remove('hidden', 'success', 'warning');
            indicator.classList.add('error');
            text.textContent = translations[currentLanguage]?.handNotVisible || 'Рука не видна полностью';
        }
    } catch (error) {
        console.error('Error updating hand quality indicator:', error);
    }
}

// Detect gesture from hand points
function detectGestureFromPoints(points) {
    try {
        if (!points || points.length < 21) return null;
        
        if (!handTrackingData) return null;
        
        // Simple gesture detection based on finger positions
        const wrist = points[0];
        const thumbTip = points[4];
        const indexTip = points[8];
        const middleTip = points[12];
        const ringTip = points[16];
        const pinkyTip = points[20];
        
        if (!wrist || !thumbTip || !indexTip || !middleTip || !ringTip || !pinkyTip) {
            return null;
        }
        
        // Calculate finger extensions (distance from wrist to tip)
        const handSize = handTrackingData.handSize || 80;
        const thumbExtended = getDistance(wrist, thumbTip) > handSize * 0.6;
        const indexExtended = getDistance(wrist, indexTip) > handSize * 0.8;
        const middleExtended = getDistance(wrist, middleTip) > handSize * 0.8;
        const ringExtended = getDistance(wrist, ringTip) > handSize * 0.7;
        const pinkyExtended = getDistance(wrist, pinkyTip) > handSize * 0.6;
        
        // Detect common gestures
        if (indexExtended && !middleExtended && !ringExtended && !pinkyExtended) {
            return 'point'; // Pointing
        } else if (indexExtended && middleExtended && !ringExtended && !pinkyExtended) {
            return 'peace'; // Peace sign
        } else if (thumbExtended && indexExtended && middleExtended && ringExtended && pinkyExtended) {
            return 'open'; // Open hand
        } else if (!thumbExtended && !indexExtended && !middleExtended && !ringExtended && !pinkyExtended) {
            return 'fist'; // Fist
        } else if (thumbExtended && indexExtended && !middleExtended && !ringExtended && !pinkyExtended) {
            return 'ok'; // OK sign
        }
        
        return null;
    } catch (error) {
        console.error('Error detecting gesture from points:', error);
        return null;
    }
}

// Helper function to calculate distance
function getDistance(p1, p2) {
    try {
        if (!p1 || !p2 || 
            typeof p1.x !== 'number' || typeof p1.y !== 'number' ||
            typeof p2.x !== 'number' || typeof p2.y !== 'number') {
            return 0;
        }
        return Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2));
    } catch (error) {
        console.error('Error calculating distance:', error);
        return 0;
    }
}

// Evaluate gesture accuracy (improved)
function evaluateGestureAccuracy(points) {
    try {
        if (!points || points.length < 21) {
            return {
                overall: 0,
                thumb: 0,
                index: 0,
                middle: 0,
                ring: 0,
                pinky: 0
            };
        }
        
        // Check if hand quality is good
        if (!handTrackingData || handTrackingData.handQuality !== 'good') {
            return {
                overall: 0.3,
                thumb: 0.3,
                index: 0.3,
                middle: 0.3,
                ring: 0.3,
                pinky: 0.3
            };
        }
        
        // Check if calibrated
        if (!handTrackingData.calibrated) {
            return {
                overall: 0.5,
                thumb: 0.5,
                index: 0.5,
                middle: 0.5,
                ring: 0.5,
                pinky: 0.5
            };
        }
        
        // Calculate accuracy based on point stability (variance)
        if (!handTrackingData.pointHistory || handTrackingData.pointHistory.length < 2) {
            return {
                overall: 0.5,
                thumb: 0.5,
                index: 0.5,
                middle: 0.5,
                ring: 0.5,
                pinky: 0.5
            };
        }
        
        const wrist = points[0];
        if (!wrist) {
            return {
                overall: 0.5,
                thumb: 0.5,
                index: 0.5,
                middle: 0.5,
                ring: 0.5,
                pinky: 0.5
            };
        }
        
        let totalVariance = 0;
        const fingerTips = [4, 8, 12, 16, 20];
        let validFingers = 0;
        
        fingerTips.forEach((tipIdx) => {
            if (handTrackingData.pointHistory.length > 1 && tipIdx < points.length) {
                const variances = [];
                for (let i = 1; i < handTrackingData.pointHistory.length; i++) {
                    const prevFrame = handTrackingData.pointHistory[i - 1];
                    const currFrame = handTrackingData.pointHistory[i];
                    if (prevFrame && currFrame && 
                        prevFrame[tipIdx] && currFrame[tipIdx]) {
                        const dist = getDistance(prevFrame[tipIdx], currFrame[tipIdx]);
                        variances.push(dist);
                    }
                }
                
                if (variances.length > 0) {
                    const avgVariance = variances.reduce((a, b) => a + b, 0) / variances.length;
                    totalVariance += avgVariance;
                    validFingers++;
                }
            }
        });
        
        // Lower variance = higher accuracy
        const avgVariance = validFingers > 0 ? totalVariance / validFingers : 0;
        const baseAccuracy = Math.max(0, Math.min(1, 1 - (avgVariance / 50)));
        
        // Boost accuracy if gesture is stable
        const stabilityBoost = handTrackingData.currentStableGesture ? 0.2 : 0;
        
        const overallAccuracy = Math.min(1, baseAccuracy + stabilityBoost);
        
        return {
            overall: overallAccuracy,
            thumb: Math.max(0, Math.min(1, overallAccuracy + (Math.random() - 0.5) * 0.1)),
            index: Math.max(0, Math.min(1, overallAccuracy + (Math.random() - 0.5) * 0.1)),
            middle: Math.max(0, Math.min(1, overallAccuracy + (Math.random() - 0.5) * 0.1)),
            ring: Math.max(0, Math.min(1, overallAccuracy + (Math.random() - 0.5) * 0.1)),
            pinky: Math.max(0, Math.min(1, overallAccuracy + (Math.random() - 0.5) * 0.1))
        };
    } catch (error) {
        console.error('Error evaluating gesture accuracy:', error);
        return {
            overall: 0.5,
            thumb: 0.5,
            index: 0.5,
            middle: 0.5,
            ring: 0.5,
            pinky: 0.5
        };
    }
}

// Update hand tracking status
function updateHandTrackingStatus(accuracy) {
    try {
        if (!accuracy || typeof accuracy.overall !== 'number') {
            return;
        }
        
        const status = document.getElementById('handTrackingStatus');
        const skeletonDisplay = document.getElementById('handSkeleton');
        
        if (!status) return;
        
        const accuracyPercent = Math.round(accuracy.overall * 100);
        
        if (accuracy.overall > 0.7) {
            status.textContent = `✓ ${translations[currentLanguage]?.gestureCorrect || 'Жест выполнен верно'} (${accuracyPercent}%)`;
            status.style.backgroundColor = 'rgba(40, 167, 69, 0.8)';
            
            // Gamification hook: count a successful gesture once per stable success
            if (!lastGestureWasSuccess) {
                lastGestureWasSuccess = true;
                handleGestureSuccessForGamification();
            }
            
            if (skeletonDisplay) {
                skeletonDisplay.innerHTML = `
                    <div style="color: #28a745; font-weight: 600; text-align: center; padding: 10px;">
                        ✓ ${translations[currentLanguage]?.gestureRecognized || 'Жест распознан правильно'}<br>
                        ${translations[currentLanguage]?.accuracy || 'Точность'}: ${accuracyPercent}%
                    </div>
                `;
            }
        } else {
            status.textContent = `⚠ ${translations[currentLanguage]?.gestureNeedsCorrection || 'Требуется корректировка'} (${accuracyPercent}%)`;
            status.style.backgroundColor = 'rgba(220, 53, 69, 0.8)';
            lastGestureWasSuccess = false;
            if (skeletonDisplay) {
                skeletonDisplay.innerHTML = `
                    <div style="color: #dc3545; font-weight: 600; text-align: center; padding: 10px;">
                        ⚠ ${translations[currentLanguage]?.gestureNeedsFix || 'Жест требует корректировки'}<br>
                        ${translations[currentLanguage]?.followHints || 'Следуйте подсказкам на экране'}
                    </div>
                `;
            }
        }
    } catch (error) {
        console.error('Error updating hand tracking status:', error);
    }
}

// Fallback hand detection (simplified version)
function detectHandFromVideoFallback(ctx, width, height) {
    // Get image data from canvas
    const imageData = ctx.getImageData(0, 0, width, height);
    const data = imageData.data;
    const handPoints = [];
    const skinPixels = [];
    
    // Simple skin color detection
    for (let y = 0; y < height; y += 12) {
        for (let x = 0; x < width; x += 12) {
            const index = (y * width + x) * 4;
            const r = data[index];
            const g = data[index + 1];
            const b = data[index + 2];
            
            if (isSkinColor(r, g, b)) {
                skinPixels.push({ x, y });
            }
        }
    }
    
    // Find hand center
    if (skinPixels.length > 10) {
        const centerX = skinPixels.reduce((sum, p) => sum + p.x, 0) / skinPixels.length;
        const centerY = skinPixels.reduce((sum, p) => sum + p.y, 0) / skinPixels.length;
        
        // Update position with smoothing
        if (handPosition.x === null) {
            handPosition.x = centerX;
            handPosition.y = centerY;
            handPosition.detected = true;
        } else {
            const smoothing = 0.7;
            handPosition.x = centerX * smoothing + handPosition.x * (1 - smoothing);
            handPosition.y = centerY * smoothing + handPosition.y * (1 - smoothing);
        }
        
        // Generate simple hand structure
        const baseX = handPosition.x;
        const baseY = handPosition.y;
        
        // Wrist (0)
        handPoints.push({ x: baseX, y: baseY });
        
        // Generate 20 more points in a simple hand shape
        for (let i = 1; i <= 20; i++) {
            const angle = (i / 20) * Math.PI * 1.5;
            const radius = 30 + (i % 4) * 15;
            handPoints.push({
                x: baseX + Math.cos(angle) * radius,
                y: baseY + Math.sin(angle) * radius
            });
        }
    } else {
        handPosition.detected = false;
    }
    
    return handPoints;
}

// Old detectHandFromVideo function (kept for reference, not used)
function detectHandFromVideo(ctx, width, height, currentFrame, previousFrame) {
    if (!currentFrame) return [];
    
    const data = currentFrame.data;
    const handPoints = [];
    const skinPixels = [];
    const motionPixels = [];
    
    // Step 1: Detect motion between frames
    if (previousFrame) {
        const prevData = previousFrame.data;
        for (let y = 0; y < height; y += 5) {
            for (let x = 0; x < width; x += 5) {
                const index = (y * width + x) * 4;
                const r = data[index];
                const g = data[index + 1];
                const b = data[index + 2];
                
                const prevR = prevData[index];
                const prevG = prevData[index + 1];
                const prevB = prevData[index + 2];
                
                // Calculate motion
                const motion = Math.abs(r - prevR) + Math.abs(g - prevG) + Math.abs(b - prevB);
                
                if (motion > 30) { // Threshold for motion detection
                    motionPixels.push({ x, y, motion });
                }
            }
        }
    }
    
    // Step 2: Detect skin color (more aggressive detection)
    for (let y = 0; y < height; y += 6) {
        for (let x = 0; x < width; x += 6) {
            const index = (y * width + x) * 4;
            const r = data[index];
            const g = data[index + 1];
            const b = data[index + 2];
            
            if (isSkinColor(r, g, b)) {
                skinPixels.push({ x, y });
            }
        }
    }
    
    // Step 3: Find hand center using both skin color and motion
    let centerX = width / 2;
    let centerY = height / 2;
    let detected = false;
    
    // Lower threshold for better detection
    if (skinPixels.length > 20) {
        // Use skin color detection
        centerX = skinPixels.reduce((sum, p) => sum + p.x, 0) / skinPixels.length;
        centerY = skinPixels.reduce((sum, p) => sum + p.y, 0) / skinPixels.length;
        detected = true;
    } else if (motionPixels.length > 15) {
        // Use motion detection as fallback
        const sortedMotion = motionPixels.sort((a, b) => b.motion - a.motion);
        const topMotion = sortedMotion.slice(0, Math.min(10, sortedMotion.length));
        centerX = topMotion.reduce((sum, p) => sum + p.x, 0) / topMotion.length;
        centerY = topMotion.reduce((sum, p) => sum + p.y, 0) / topMotion.length;
        detected = true;
    } else if (handPosition.detected && handPosition.x !== null) {
        // If we had detection before, keep tracking even if current detection is weak
        detected = true;
        centerX = handPosition.x;
        centerY = handPosition.y;
    }
    
    // Step 4: Track hand position with smoothing
    if (detected) {
        if (handPosition.x === null || !handPosition.detected) {
            // First detection - set position immediately
            handPosition.x = centerX;
            handPosition.y = centerY;
            handPosition.detected = true;
            handVelocity.x = 0;
            handVelocity.y = 0;
        } else {
            // Smooth tracking - follow hand movement
            const smoothing = 0.8; // More responsive
            const dx = centerX - handPosition.x;
            const dy = centerY - handPosition.y;
            
            // Only update if movement is significant (reduce jitter)
            if (Math.abs(dx) > 2 || Math.abs(dy) > 2) {
                // Update velocity
                handVelocity.x = dx * 0.4 + handVelocity.x * 0.6;
                handVelocity.y = dy * 0.4 + handVelocity.y * 0.6;
                
                // Update position with smoothing
                handPosition.x += dx * smoothing;
                handPosition.y += dy * smoothing;
            }
        }
    } else {
        // If not detected, use predicted position based on velocity (for short time)
        if (handPosition.detected && handPosition.x !== null) {
            // Continue tracking for a few frames even without detection
            handPosition.x += handVelocity.x;
            handPosition.y += handVelocity.y;
            // Gradually reduce velocity
            handVelocity.x *= 0.85;
            handVelocity.y *= 0.85;
            
            // If velocity is very low, mark as not detected
            if (Math.abs(handVelocity.x) < 1 && Math.abs(handVelocity.y) < 1) {
                // Keep position but reduce confidence
            }
        }
    }
    
    // Step 5: Generate hand keypoints following the tracked position
    if (handPosition.detected && handPosition.x !== null && handPosition.y !== null) {
        const baseX = handPosition.x;
        const baseY = handPosition.y;
        const time = Date.now() / 1000;
        
        // Add small natural movement based on detected motion
        const motionOffsetX = motionPixels.length > 0 ? 
            (motionPixels.reduce((sum, p) => sum + (p.x - baseX), 0) / motionPixels.length) * 0.1 : 0;
        const motionOffsetY = motionPixels.length > 0 ? 
            (motionPixels.reduce((sum, p) => sum + (p.y - baseY), 0) / motionPixels.length) * 0.1 : 0;
        
        const finalX = baseX + motionOffsetX;
        const finalY = baseY + motionOffsetY;
        
        // Generate MediaPipe-style 21 keypoints following hand position
        // Wrist (0)
        handPoints.push({ x: finalX, y: finalY });
        
        // Thumb (1-4) - follows hand movement
        for (let i = 1; i <= 4; i++) {
            handPoints.push({
                x: finalX - 40 + i * 15 + handVelocity.x * 0.5,
                y: finalY - 20 + i * 10 + handVelocity.y * 0.5
            });
        }
        
        // Index finger (5-8)
        for (let i = 0; i < 4; i++) {
            handPoints.push({
                x: finalX - 20 + i * 8 + handVelocity.x * 0.3,
                y: finalY - 50 - i * 15 + handVelocity.y * 0.3
            });
        }
        
        // Middle finger (9-12)
        for (let i = 0; i < 4; i++) {
            handPoints.push({
                x: finalX + i * 8 + handVelocity.x * 0.3,
                y: finalY - 55 - i * 18 + handVelocity.y * 0.3
            });
        }
        
        // Ring finger (13-16)
        for (let i = 0; i < 4; i++) {
            handPoints.push({
                x: finalX + 20 + i * 8 + handVelocity.x * 0.3,
                y: finalY - 50 - i * 15 + handVelocity.y * 0.3
            });
        }
        
        // Pinky (17-20)
        for (let i = 0; i < 4; i++) {
            handPoints.push({
                x: finalX + 40 + i * 8 + handVelocity.x * 0.3,
                y: finalY - 40 - i * 12 + handVelocity.y * 0.3
            });
        }
    }
    
    return handPoints;
}

// Simple and reliable skin color detection
function isSkinColor(r, g, b) {
    // Simple RGB-based skin detection
    // Skin typically has: R > G > B and R is high
    
    // Basic checks
    if (r < 95 || g < 40 || b < 20) return false; // Too dark
    if (r > 250 && g > 250 && b > 250) return false; // Too bright (white)
    
    // Check if red is dominant
    if (r <= g || g <= b) return false;
    
    // Check RGB ratios typical of skin
    const rgDiff = r - g;
    const gbDiff = g - b;
    
    // Skin usually has significant difference between R and G, and G and B
    if (rgDiff < 15 || gbDiff < 15) return false;
    
    // Check if it's not too blue (skin is warm-toned)
    if (b > r * 0.8) return false;
    
    // Overall brightness check (not too dark, not too light)
    const brightness = (r + g + b) / 3;
    if (brightness < 60 || brightness > 240) return false;
    
    return true;
}

// Draw hand tracking overlay
function drawHandTrackingOverlay(ctx, handPoints, accuracy) {
    if (!handPoints || handPoints.length < 21) return;
    
    // Draw skeleton lines with color indication
    const connections = [
        [0, 1], [1, 2], [2, 3], [3, 4], // Thumb
        [0, 5], [5, 6], [6, 7], [7, 8], // Index
        [0, 9], [9, 10], [10, 11], [11, 12], // Middle
        [0, 13], [13, 14], [14, 15], [15, 16], // Ring
        [0, 17], [17, 18], [18, 19], [19, 20] // Pinky
    ];
    
    const isCorrect = accuracy && accuracy.overall > 0.7;
    
    connections.forEach(([start, end]) => {
        if (handPoints[start] && handPoints[end]) {
            ctx.strokeStyle = isCorrect ? '#28a745' : '#dc3545';
            ctx.lineWidth = isCorrect ? 3 : 2;
            
            ctx.beginPath();
            ctx.moveTo(handPoints[start].x, handPoints[start].y);
            ctx.lineTo(handPoints[end].x, handPoints[end].y);
            ctx.stroke();
        }
    });
    
    // Draw points with color indication
    handPoints.forEach((point, index) => {
        if (point) {
            ctx.fillStyle = isCorrect ? '#28a745' : '#dc3545';
            ctx.beginPath();
            ctx.arc(point.x, point.y, 5, 0, 2 * Math.PI);
            ctx.fill();
        }
    });
    
    // Draw hand contour
    drawHandContour(ctx, handPoints);
    
    // Update status
    if (accuracy) {
        updateHandTrackingStatus(accuracy);
    }
}

// Sound Monitoring
let audioContext = null;
let analyser = null;
let microphone = null;
let monitoringActive = false;
let alertScreenVisible = false;

const enableMonitoringBtn = document.getElementById('enableMonitoring');
if (enableMonitoringBtn) {
    enableMonitoringBtn.addEventListener('click', async () => {
    const btn = document.getElementById('enableMonitoring');
    
    if (!monitoringActive) {
        try {
            // Resume audio context if suspended
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
            if (audioContext.state === 'suspended') {
                await audioContext.resume();
            }
            
            analyser = audioContext.createAnalyser();
            analyser.fftSize = 256;
            analyser.smoothingTimeConstant = 0.8;
            
            const stream = await navigator.mediaDevices.getUserMedia({ 
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true
                } 
            });
            
            microphone = audioContext.createMediaStreamSource(stream);
            microphone.connect(analyser);
            
            monitoringActive = true;
            btn.textContent = translations[currentLanguage].disable;
            btn.classList.add('active');
            
            // Store stream for cleanup
            microphone._stream = stream;
            
            updateVolumeVisualization();
        } catch (error) {
            console.error('Error accessing microphone:', error);
            alert(translations[currentLanguage].microphonePermissionDenied);
            monitoringActive = false;
        }
    } else {
        // Stop all tracks
        if (microphone && microphone._stream) {
            microphone._stream.getTracks().forEach(track => track.stop());
        }
        
        // Disconnect and close audio context
        if (microphone) {
            microphone.disconnect();
            microphone = null;
        }
        
        if (audioContext && audioContext.state !== 'closed') {
            audioContext.close().catch(err => console.error('Error closing audio context:', err));
            audioContext = null;
        }
        
            analyser = null;
        monitoringActive = false;
        btn.textContent = translations[currentLanguage].enable;
        btn.classList.remove('active');
        
        const noiseLevelEl = document.getElementById('noiseLevel');
        const noiseProgressFillEl = document.getElementById('noiseProgressFill');
        const volumeFillEl = document.getElementById('volumeFill');
        const volumeCircle = document.getElementById('volumeCircle');
        
        if (noiseLevelEl) noiseLevelEl.textContent = '0%';
        if (noiseProgressFillEl) noiseProgressFillEl.style.width = '0%';
        if (volumeFillEl) volumeFillEl.style.width = '0%';
        if (volumeCircle) volumeCircle.className = 'volume-circle';

        const envBlock = document.getElementById('environmentIndicators');
        if (envBlock) {
            envBlock.setAttribute('data-current-level', 'silence');
            const labels = envBlock.querySelectorAll('.volume-label span[data-level]');
            labels.forEach((span) => {
                span.classList.toggle('volume-label-active', span.getAttribute('data-level') === 'silence');
            });
        }
        
        // Hide alert if visible
        if (alertScreenVisible) {
            document.getElementById('alertScreen').classList.add('hidden');
            alertScreenVisible = false;
        }
    }
    });
}

// Update volume visualization
let volumeAnimationFrame = null;

function updateVolumeVisualization() {
    if (!monitoringActive || !analyser) {
        if (volumeAnimationFrame) {
            cancelAnimationFrame(volumeAnimationFrame);
            volumeAnimationFrame = null;
        }
        return;
    }
    
    try {
        const dataArray = new Uint8Array(analyser.frequencyBinCount);
        analyser.getByteFrequencyData(dataArray);
        
        const average = dataArray.reduce((a, b) => a + b) / dataArray.length;
        const volume = Math.min(Math.round((average / 255) * 100), 100);
        
        const noiseLevelEl = document.getElementById('noiseLevel');
        const noiseProgressFillEl = document.getElementById('noiseProgressFill');
        const volumeFillEl = document.getElementById('volumeFill');
        const volumeCircle = document.getElementById('volumeCircle');
        
        if (noiseLevelEl) noiseLevelEl.textContent = `${volume}%`;
        if (noiseProgressFillEl) noiseProgressFillEl.style.width = `${volume}%`;
        if (volumeFillEl) volumeFillEl.style.width = `${volume}%`;
        
        if (volumeCircle) {
            volumeCircle.classList.remove('low', 'medium', 'high', 'pulsing');
            
            if (volume < 20) {
                volumeCircle.classList.add('low');
            } else if (volume < 60) {
                volumeCircle.classList.add('medium');
                volumeCircle.classList.add('pulsing');
            } else {
                volumeCircle.classList.add('high');
                volumeCircle.classList.add('pulsing');
                
                // Show alert for loud sounds
                if (volume > 80 && !alertScreenVisible) {
                    showAlertScreen();
                }
            }
            
            if (volume > 20) {
                volumeCircle.classList.add('pulsing');
            }
        }

        // Mark current level on environment indicators (Тишина / Норма / Громко) for "бірге түсетін" on click
        const envBlock = document.getElementById('environmentIndicators');
        if (envBlock) {
            const currentLevel = volume < 20 ? 'silence' : volume < 60 ? 'normal' : 'loud';
            envBlock.setAttribute('data-current-level', currentLevel);
            const labels = envBlock.querySelectorAll('.volume-label span[data-level]');
            labels.forEach((span) => {
                span.classList.toggle('volume-label-active', span.getAttribute('data-level') === currentLevel);
            });
        }
        
        volumeAnimationFrame = requestAnimationFrame(updateVolumeVisualization);
    } catch (error) {
        console.error('Error updating volume visualization:', error);
        if (volumeAnimationFrame) {
            cancelAnimationFrame(volumeAnimationFrame);
            volumeAnimationFrame = null;
        }
    }
}

// Environment indicators: on click, highlight current level + visual together (бірге түсетін)
const environmentIndicatorsEl = document.getElementById('environmentIndicators');
if (environmentIndicatorsEl) {
    function toggleEnvironmentIndicatorsActive() {
        environmentIndicatorsEl.classList.toggle('environment-indicators--active');
    }
    environmentIndicatorsEl.addEventListener('click', toggleEnvironmentIndicatorsActive);
    environmentIndicatorsEl.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            toggleEnvironmentIndicatorsActive();
        }
    });
}

// Show alert screen for loud sounds
let volumeCheckInterval = null;

function showAlertScreen() {
    if (alertScreenVisible) return; // Already showing
    
    alertScreenVisible = true;
    const alertScreen = document.getElementById('alertScreen');
    if (alertScreen) {
        alertScreen.classList.remove('hidden');
    }
    
    // Vibrate if supported
    if (navigator.vibrate) {
        try {
            navigator.vibrate([200, 100, 200, 100, 200]);
        } catch (e) {
            console.error('Vibration error:', e);
        }
    }
    
    // Clear any existing interval
    if (volumeCheckInterval) {
        clearInterval(volumeCheckInterval);
    }
    
    // Hide after sound decreases
    volumeCheckInterval = setInterval(() => {
        if (!monitoringActive || !analyser) {
            if (alertScreen) alertScreen.classList.add('hidden');
            alertScreenVisible = false;
            clearInterval(volumeCheckInterval);
            volumeCheckInterval = null;
            return;
        }
        
        try {
            const dataArray = new Uint8Array(analyser.frequencyBinCount);
            analyser.getByteFrequencyData(dataArray);
            const average = dataArray.reduce((a, b) => a + b) / dataArray.length;
            const volume = Math.round((average / 255) * 100);
            
            if (volume < 60) {
                if (alertScreen) alertScreen.classList.add('hidden');
                alertScreenVisible = false;
                clearInterval(volumeCheckInterval);
                volumeCheckInterval = null;
            }
        } catch (error) {
            console.error('Error checking volume:', error);
            clearInterval(volumeCheckInterval);
            volumeCheckInterval = null;
        }
    }, 100);
}

// Test sound button
const testSoundBtn = document.getElementById('testSound');
if (testSoundBtn) {
    testSoundBtn.addEventListener('click', () => {
        showAlertScreen();
        setTimeout(() => {
            const alertScreen = document.getElementById('alertScreen');
            if (alertScreen) {
                alertScreen.classList.add('hidden');
            }
            alertScreenVisible = false;
        }, 2000);
    });
}

// Sound Monitoring Functions for Corner Panel
function toggleSoundMonitoring() {
    if (!monitoring) {
        startSoundMonitoring();
    } else {
        stopSoundMonitoring();
    }
    monitoring = !monitoring;
}

async function startSoundMonitoring() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
        if (audioContext.state === 'suspended') {
            await audioContext.resume();
        }
        
        analyser = audioContext.createAnalyser();
        analyser.fftSize = 256;
        analyser.smoothingTimeConstant = 0.8;
        
        microphone = audioContext.createMediaStreamSource(stream);
        microphone.connect(analyser);
        
        // Store stream for cleanup
        microphone._stream = stream;
        
        // Update button text
        const soundBtn = document.querySelector('.sound-btn');
        if (soundBtn) {
            soundBtn.textContent = 'Выключить';
        }
        
        updateSoundLevel();
    } catch (error) {
        console.error('Error accessing microphone:', error);
        alert('Разрешение на использование микрофона не предоставлено');
        monitoring = false;
    }
}

function updateSoundLevel() {
    if (!monitoring || !analyser) return;
    
    try {
        const dataArray = new Uint8Array(analyser.frequencyBinCount);
        analyser.getByteFrequencyData(dataArray);
        
        const average = dataArray.reduce((a, b) => a + b) / dataArray.length;
        const volume = Math.min(Math.round((average / 255) * 100), 100);
        const percent = Math.min(volume / 2, 100);
        
        const bar = document.getElementById("soundLevel");
        if (bar) {
            bar.style.width = percent + "%";
        }
        
        if (monitoring) {
            requestAnimationFrame(updateSoundLevel);
        }
    } catch (error) {
        console.error('Error updating sound level:', error);
    }
}

function stopSoundMonitoring() {
    // Stop all tracks
    if (microphone && microphone._stream) {
        microphone._stream.getTracks().forEach(track => track.stop());
    }
    
    // Disconnect and close audio context
    if (microphone) {
        microphone.disconnect();
        microphone = null;
    }
    
    if (audioContext && audioContext.state !== 'closed') {
        audioContext.close().catch(err => console.error('Error closing audio context:', err));
        audioContext = null;
    }
    
    analyser = null;
    monitoring = false;
    
    // Reset button text
    const soundBtn = document.querySelector('.sound-btn');
    if (soundBtn) {
        soundBtn.textContent = 'Включить';
    }
    
    // Reset progress bar
    const bar = document.getElementById("soundLevel");
    if (bar) {
        bar.style.width = "0%";
    }
}

// Real-time Subtitles with Speaker Diarization
let realtimeSubtitlesActive = false;
let realtimeRecognition = null;
let realtimeAudioContext = null;
let realtimeAnalyser = null;
let realtimeMicrophone = null;
let speakers = new Map(); // Map to store speaker profiles
let currentSpeakerId = null;
let speakerCounter = 0;
let lastSpeechTime = 0;
let speechGapThreshold = 1500; // 1.5 seconds gap to consider new speaker

// Speaker profile structure
class SpeakerProfile {
    constructor(id, name) {
        this.id = id;
        this.name = name;
        this.pitchHistory = [];
        this.energyHistory = [];
        this.spectralCentroidHistory = [];
        this.lastSeen = Date.now();
        this.utteranceCount = 0;
    }
    
    updateFeatures(pitch, energy, spectralCentroid) {
        this.pitchHistory.push(pitch);
        this.energyHistory.push(energy);
        this.spectralCentroidHistory.push(spectralCentroid);
        
        // Keep only last 20 measurements
        if (this.pitchHistory.length > 20) {
            this.pitchHistory.shift();
            this.energyHistory.shift();
            this.spectralCentroidHistory.shift();
        }
        
        this.lastSeen = Date.now();
        this.utteranceCount++;
    }
    
    getAveragePitch() {
        if (this.pitchHistory.length === 0) return 0;
        return this.pitchHistory.reduce((a, b) => a + b, 0) / this.pitchHistory.length;
    }
    
    getAverageEnergy() {
        if (this.energyHistory.length === 0) return 0;
        return this.energyHistory.reduce((a, b) => a + b, 0) / this.energyHistory.length;
    }
    
    getAverageSpectralCentroid() {
        if (this.spectralCentroidHistory.length === 0) return 0;
        return this.spectralCentroidHistory.reduce((a, b) => a + b, 0) / this.spectralCentroidHistory.length;
    }
    
    getSimilarity(pitch, energy, spectralCentroid) {
        const avgPitch = this.getAveragePitch();
        const avgEnergy = this.getAverageEnergy();
        const avgSpectral = this.getAverageSpectralCentroid();
        
        if (avgPitch === 0 && avgEnergy === 0 && avgSpectral === 0) return 0;
        
        // Improved similarity calculation with weighted features
        // Pitch is most important for speaker identification (weight: 0.5)
        const pitchDiff = Math.abs(pitch - avgPitch);
        const pitchSimilarity = pitchDiff < 30 ? 1 : Math.max(0, 1 - (pitchDiff - 30) / 100);
        
        // Energy variation is less important but still significant (weight: 0.3)
        const energyDiff = Math.abs(energy - avgEnergy);
        const maxEnergy = Math.max(avgEnergy, energy, 0.1);
        const energySimilarity = energyDiff / maxEnergy < 0.3 ? 1 : Math.max(0, 1 - (energyDiff / maxEnergy - 0.3) / 0.4);
        
        // Spectral centroid for timbre (weight: 0.2)
        const spectralDiff = Math.abs(spectralCentroid - avgSpectral);
        const maxSpectral = Math.max(avgSpectral, spectralCentroid, 100);
        const spectralSimilarity = spectralDiff / maxSpectral < 0.2 ? 1 : Math.max(0, 1 - (spectralDiff / maxSpectral - 0.2) / 0.3);
        
        // Weighted combination
        const similarity = pitchSimilarity * 0.5 + energySimilarity * 0.3 + spectralSimilarity * 0.2;
        
        // Boost similarity if we have enough history (more confident)
        const confidenceBoost = Math.min(1, this.pitchHistory.length / 10);
        return Math.min(1, similarity * (0.7 + 0.3 * confidenceBoost));
    }
}

// Analyze audio features for speaker identification
function analyzeAudioFeatures(audioContext, analyser) {
    if (!analyser) return null;
    
    try {
        const bufferLength = analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);
        const floatDataArray = new Float32Array(bufferLength);
        
        analyser.getByteFrequencyData(dataArray);
        analyser.getByteTimeDomainData(floatDataArray);
        
        // Calculate energy (RMS)
        let sumSquares = 0;
        for (let i = 0; i < floatDataArray.length; i++) {
            sumSquares += floatDataArray[i] * floatDataArray[i];
        }
        const energy = Math.sqrt(sumSquares / floatDataArray.length);
        
        // Calculate spectral centroid (brightness of sound)
        let weightedSum = 0;
        let magnitudeSum = 0;
        for (let i = 0; i < dataArray.length; i++) {
            const magnitude = dataArray[i];
            weightedSum += i * magnitude;
            magnitudeSum += magnitude;
        }
        const spectralCentroid = magnitudeSum > 0 ? weightedSum / magnitudeSum : 0;
        
        // Estimate pitch using autocorrelation (simplified)
        let pitch = 0;
        if (energy > 0.01) {
            // Simple pitch estimation using zero-crossing rate
            let zeroCrossings = 0;
            for (let i = 1; i < floatDataArray.length; i++) {
                if ((floatDataArray[i] >= 0 && floatDataArray[i - 1] < 0) ||
                    (floatDataArray[i] < 0 && floatDataArray[i - 1] >= 0)) {
                    zeroCrossings++;
                }
            }
            const sampleRate = audioContext.sampleRate;
            pitch = (zeroCrossings / 2) * (sampleRate / floatDataArray.length);
        }
        
        return {
            pitch: pitch,
            energy: energy,
            spectralCentroid: spectralCentroid
        };
    } catch (error) {
        console.error('Error analyzing audio features:', error);
        return null;
    }
}

// Identify or create speaker based on audio features (improved algorithm)
function identifySpeaker(pitch, energy, spectralCentroid) {
    const now = Date.now();
    const timeSinceLastSpeech = now - lastSpeechTime;
    
    // Improved gap detection - only reset if gap is significant AND energy is low
    if (timeSinceLastSpeech > speechGapThreshold && currentSpeakerId && energy < 0.05) {
        currentSpeakerId = null;
    }
    
    // Filter out noise - only process if energy is above threshold
    if (energy < 0.02) {
        return currentSpeakerId || null;
    }
    
    // If we have a current speaker, check if features match (with hysteresis)
    if (currentSpeakerId && speakers.has(currentSpeakerId)) {
        const speaker = speakers.get(currentSpeakerId);
        const similarity = speaker.getSimilarity(pitch, energy, spectralCentroid);
        
        // Use hysteresis: higher threshold to switch away, lower to stay
        const stayThreshold = speaker.utteranceCount > 5 ? 0.65 : 0.55; // More confident with more data
        
        if (similarity > stayThreshold) {
            speaker.updateFeatures(pitch, energy, spectralCentroid);
            return currentSpeakerId;
        }
    }
    
    // Try to match with existing speakers (improved matching)
    let bestMatch = null;
    let bestSimilarity = 0.6; // Higher threshold for matching
    
    // Sort speakers by recency and utterance count (prefer recent, active speakers)
    const sortedSpeakers = Array.from(speakers.entries())
        .sort((a, b) => {
            const recencyDiff = b[1].lastSeen - a[1].lastSeen;
            const utteranceDiff = b[1].utteranceCount - a[1].utteranceCount;
            // Prefer speakers seen recently and with more utterances
            return recencyDiff + utteranceDiff * 1000;
        });
    
    for (const [id, speaker] of sortedSpeakers) {
        // Skip speakers that haven't been seen for a while (unless very similar)
        const timeSinceSeen = now - speaker.lastSeen;
        if (timeSinceSeen > 10000 && speaker.utteranceCount < 3) {
            continue; // Skip old, inactive speakers
        }
        
        const similarity = speaker.getSimilarity(pitch, energy, spectralCentroid);
        
        // Boost similarity for recently active speakers
        const recencyBoost = timeSinceSeen < 3000 ? 0.1 : 0;
        const adjustedSimilarity = Math.min(1, similarity + recencyBoost);
        
        if (adjustedSimilarity > bestSimilarity) {
            bestSimilarity = adjustedSimilarity;
            bestMatch = id;
        }
    }
    
    // If we found a good match, use it
    if (bestMatch && bestSimilarity > 0.65) {
        currentSpeakerId = bestMatch;
        speakers.get(bestMatch).updateFeatures(pitch, energy, spectralCentroid);
        return bestMatch;
    }
    
    // Only create new speaker if we're confident it's different
    // Check if features are significantly different from all existing speakers
    let isSignificantlyDifferent = true;
    for (const [id, speaker] of speakers.entries()) {
        const similarity = speaker.getSimilarity(pitch, energy, spectralCentroid);
        if (similarity > 0.5) {
            isSignificantlyDifferent = false;
            break;
        }
    }
    
    // Create new speaker only if significantly different
    if (isSignificantlyDifferent || speakers.size === 0) {
        speakerCounter++;
        let speakerName;
        
        // Improved name assignment based on pitch and characteristics
        const isHighPitch = pitch > 200;
        const isLowPitch = pitch < 150;
        
        if (speakerCounter === 1) {
            speakerName = isHighPitch ? translations[currentLanguage].speakerWoman : translations[currentLanguage].speakerMan;
        } else if (speakerCounter === 2) {
            speakerName = isHighPitch ? translations[currentLanguage].speakerMom : translations[currentLanguage].speakerDad;
        } else if (speakerCounter === 3) {
            speakerName = translations[currentLanguage].speakerChef;
        } else if (speakerCounter === 4) {
            speakerName = translations[currentLanguage].speakerFriend;
        } else if (speakerCounter === 5) {
            speakerName = translations[currentLanguage].speakerTeacher;
        } else {
            speakerName = `${translations[currentLanguage].speaker1.replace('1', speakerCounter)}`;
        }
        
        const newSpeaker = new SpeakerProfile(speakerCounter, speakerName);
        newSpeaker.updateFeatures(pitch, energy, spectralCentroid);
        speakers.set(speakerCounter, newSpeaker);
        currentSpeakerId = speakerCounter;
        
        updateSpeakersList();
        
        return speakerCounter;
    }
    
    // If not significantly different but no good match, use current speaker or most similar
    if (currentSpeakerId && speakers.has(currentSpeakerId)) {
        speakers.get(currentSpeakerId).updateFeatures(pitch, energy, spectralCentroid);
        return currentSpeakerId;
    }
    
    // Fallback: use best match even if below threshold
    if (bestMatch) {
        currentSpeakerId = bestMatch;
        speakers.get(bestMatch).updateFeatures(pitch, energy, spectralCentroid);
        return bestMatch;
    }
    
    return null;
}

// Update speakers list display
function updateSpeakersList() {
    const speakersList = document.getElementById('speakersList');
    if (!speakersList) return;
    
    if (speakers.size === 0) {
        speakersList.innerHTML = '';
        return;
    }
    
    // Update speaker names based on current language and ID
    speakers.forEach((speaker, id) => {
        // Update names based on speaker ID and characteristics
        if (id === 1) {
            speaker.name = speaker.pitchHistory.length > 0 && speaker.getAveragePitch() > 200 
                ? translations[currentLanguage].speakerWoman 
                : translations[currentLanguage].speakerMan;
        } else if (id === 2) {
            speaker.name = speaker.pitchHistory.length > 0 && speaker.getAveragePitch() > 200 
                ? translations[currentLanguage].speakerMom 
                : translations[currentLanguage].speakerDad;
        } else if (id === 3) {
            speaker.name = translations[currentLanguage].speakerChef;
        } else if (id === 4) {
            speaker.name = translations[currentLanguage].speakerFriend;
        } else if (id === 5) {
            speaker.name = translations[currentLanguage].speakerTeacher;
        } else {
            speaker.name = `${translations[currentLanguage].speaker1.replace('1', id)}`;
        }
    });
    
    speakersList.innerHTML = `<div class="speakers-header">${translations[currentLanguage].activeSpeakers}</div>`;
    const speakersArray = Array.from(speakers.values()).sort((a, b) => b.lastSeen - a.lastSeen);
    
    speakersArray.forEach(speaker => {
        const speakerItem = document.createElement('div');
        speakerItem.className = 'speaker-item';
        speakerItem.innerHTML = `
            <span class="speaker-name">${speaker.name}</span>
            <span class="speaker-stats">(${speaker.utteranceCount} ${translations[currentLanguage].utterances})</span>
        `;
        speakersList.appendChild(speakerItem);
    });
}

// Add real-time subtitle with speaker identification
function addRealtimeSubtitle(text, speakerId) {
    if (!text || text.trim() === '') return;
    
    const display = document.getElementById('realtimeSubtitlesDisplay');
    if (!display) return;
    
    // Remove placeholder
    const placeholder = display.querySelector('.subtitles-placeholder');
    if (placeholder) {
        placeholder.remove();
    }
    
    const speaker = speakers.get(speakerId);
    const speakerName = speaker ? speaker.name : translations[currentLanguage].speakerUnknown;
    
    // Emotion recognition removed
    let emotionEmoji = '';
    
    const subtitleItem = document.createElement('div');
    subtitleItem.className = 'realtime-subtitle-item';
    
    const speakerLabel = document.createElement('span');
    speakerLabel.className = 'speaker-label';
    speakerLabel.textContent = `${speakerName}:`;
    
    const textSpan = document.createElement('span');
    textSpan.className = 'realtime-subtitle-text';
    
    // Add emotion emoji before text if available
    if (emotionEmoji) {
        const emotionSpan = document.createElement('span');
        emotionSpan.className = 'emotion-emoji-inline';
        emotionSpan.textContent = emotionEmoji;
        emotionSpan.style.marginRight = '5px';
        textSpan.appendChild(emotionSpan);
    }
    
    textSpan.appendChild(document.createTextNode(text.trim()));
    
    subtitleItem.appendChild(speakerLabel);
    subtitleItem.appendChild(textSpan);
    
    display.appendChild(subtitleItem);
    
    // Auto-scroll to bottom
    display.scrollTop = display.scrollHeight;
    
    // Keep only last 30 subtitles
    const items = display.querySelectorAll('.realtime-subtitle-item');
    while (items.length > 30) {
        items[0].remove();
    }
    
    lastSpeechTime = Date.now();
}

// Создать экземпляр распознавания для субтитров в реальном времени
function createRealtimeRecognition() {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) return null;
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const rec = new SpeechRecognition();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = currentLanguage === 'kk' ? 'kk-KZ' : 'ru-RU';
    return rec;
}

// Привязать обработчики к экземпляру realtime-распознавания
function attachRealtimeRecognitionHandlers(rec) {
    if (!rec) return;
    rec.onresult = function (event) {
        var finalTranscript = '';
        for (var i = event.resultIndex; i < event.results.length; i++) {
            var transcript = event.results[i][0].transcript;
            if (event.results[i].isFinal) finalTranscript += transcript.trim() + ' ';
        }
        if (finalTranscript.trim()) {
            var features = realtimeAudioContext && realtimeAnalyser ? analyzeAudioFeatures(realtimeAudioContext, realtimeAnalyser) : null;
            var speakerId = (features && features.energy > 0.01) ? identifySpeaker(features.pitch, features.energy, features.spectralCentroid) : (currentSpeakerId || 0);
            addRealtimeSubtitle(finalTranscript.trim(), speakerId);
        }
    };
    rec.onerror = function (event) {
        if (event.error === 'not-allowed') alert(translations[currentLanguage].microphonePermissionDenied);
    };
    rec.onend = function () {
        if (!realtimeSubtitlesActive || !realtimeRecognition) return;
        setTimeout(function () {
            if (!realtimeSubtitlesActive || !realtimeRecognition) return;
            try {
                realtimeRecognition.lang = currentLanguage === 'kk' ? 'kk-KZ' : 'ru-RU';
                realtimeRecognition.start();
            } catch (e) {
                realtimeRecognition = createRealtimeRecognition();
                if (realtimeRecognition) {
                    attachRealtimeRecognitionHandlers(realtimeRecognition);
                    realtimeRecognition.start();
                }
            }
        }, 100);
    };
}

// Кнопка субтитров в реальном времени — привязка после готовности DOM
function setupRealtimeSubtitlesButton() {
    var btn = document.getElementById('startRealtimeSubtitles');
    if (!btn || btn.dataset.realtimeBound === '1') return;
    btn.dataset.realtimeBound = '1';

    btn.addEventListener('click', function () {
        var b = document.getElementById('startRealtimeSubtitles');
        if (!b) return;

        if (!realtimeSubtitlesActive) {
            if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
                alert(translations[currentLanguage].speechNotSupported);
                return;
            }
            realtimeRecognition = createRealtimeRecognition();
            if (!realtimeRecognition) {
                alert(translations[currentLanguage].speechNotSupported);
                return;
            }
            attachRealtimeRecognitionHandlers(realtimeRecognition);

            (function tryAudio() {
                if (!window.AudioContext && !window.webkitAudioContext) return Promise.resolve();
                return Promise.resolve().then(function () {
                    realtimeAudioContext = new (window.AudioContext || window.webkitAudioContext)();
                    if (realtimeAudioContext.state === 'suspended') return realtimeAudioContext.resume();
                }).then(function () {
                    realtimeAnalyser = realtimeAudioContext.createAnalyser();
                    realtimeAnalyser.fftSize = 2048;
                    realtimeAnalyser.smoothingTimeConstant = 0.8;
                    return navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
                }).then(function (stream) {
                    realtimeMicrophone = realtimeAudioContext.createMediaStreamSource(stream);
                    realtimeMicrophone.connect(realtimeAnalyser);
                    realtimeMicrophone._stream = stream;
                    analyzeAudioForDiarization();
                }).catch(function (err) {
                    console.warn('Microphone/diarization optional:', err);
                });
            })();

            function doStart() {
                realtimeRecognition.start();
            }
            try {
                doStart();
            } catch (err) {
                realtimeRecognition = createRealtimeRecognition();
                if (realtimeRecognition) {
                    attachRealtimeRecognitionHandlers(realtimeRecognition);
                    try {
                        realtimeRecognition.start();
                    } catch (e2) {
                        if (currentLanguage === 'kk') {
                            realtimeRecognition.lang = 'kk';
                            realtimeRecognition.start();
                        } else {
                            realtimeRecognition.lang = 'ru-RU';
                            realtimeRecognition.start();
                        }
                    }
                } else {
                    alert(translations[currentLanguage].speechNotSupported);
                    return;
                }
            }
            realtimeSubtitlesActive = true;
            b.textContent = translations[currentLanguage].stopRealtimeSubtitles;
            b.classList.add('active');
            var display = document.getElementById('realtimeSubtitlesDisplay');
            if (display) {
                var ph = display.querySelector('.subtitles-placeholder');
                if (ph) ph.textContent = translations[currentLanguage].detectingSpeakers;
                else {
                    var np = document.createElement('p');
                    np.className = 'subtitles-placeholder';
                    np.textContent = translations[currentLanguage].detectingSpeakers;
                    display.appendChild(np);
                }
            }
        } else {
            realtimeSubtitlesActive = false;
            if (realtimeRecognition) {
                try { realtimeRecognition.stop(); } catch (e) {}
                realtimeRecognition = null;
            }
            if (realtimeMicrophone && realtimeMicrophone._stream) {
                realtimeMicrophone._stream.getTracks().forEach(function (t) { t.stop(); });
            }
            if (realtimeMicrophone) {
                realtimeMicrophone.disconnect();
                realtimeMicrophone = null;
            }
            if (realtimeAudioContext && realtimeAudioContext.state !== 'closed') {
                realtimeAudioContext.close().catch(function () {});
                realtimeAudioContext = null;
            }
            realtimeAnalyser = null;
            b.textContent = translations[currentLanguage].startRealtimeSubtitles;
            b.classList.remove('active');
            var display = document.getElementById('realtimeSubtitlesDisplay');
            if (display) display.innerHTML = '<p class="subtitles-placeholder">' + (translations[currentLanguage].noActiveSpeakers || 'Нажмите «Включить субтитры».') + '</p>';
            var speakersList = document.getElementById('speakersList');
            if (speakersList) speakersList.innerHTML = '';
            speakers.clear();
            currentSpeakerId = null;
            speakerCounter = 0;
        }
    });
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupRealtimeSubtitlesButton);
} else {
    setupRealtimeSubtitlesButton();
}

// Analyze audio periodically for diarization
function analyzeAudioForDiarization() {
    if (!realtimeSubtitlesActive || !realtimeAnalyser) {
        return;
    }
    
    // This runs periodically to analyze audio even when no speech is detected
    // Helps identify speakers during pauses
    setTimeout(() => {
        if (realtimeSubtitlesActive && realtimeAnalyser) {
            const features = analyzeAudioFeatures(realtimeAudioContext, realtimeAnalyser);
            if (features && features.energy > 0.01) {
                // Update current speaker if active
                if (currentSpeakerId && speakers.has(currentSpeakerId)) {
                    speakers.get(currentSpeakerId).updateFeatures(
                        features.pitch,
                        features.energy,
                        features.spectralCentroid
                    );
                }
            }
            analyzeAudioForDiarization();
        }
    }, 500); // Analyze every 500ms
}

// Emotion Recognition System removed


// Привязать обработчики к экземпляру распознавания (для init и пересоздания после stop)
function attachRecognitionHandlers(rec) {
    if (!rec) return;
    rec.onresult = function (event) {
        let interimTranscript = '';
        let finalTranscript = '';
        let hasFinal = false;
        if (recognitionTimeout) {
            clearTimeout(recognitionTimeout);
            recognitionTimeout = null;
        }
        for (let i = event.resultIndex; i < event.results.length; i++) {
            const transcript = event.results[i][0].transcript;
            const confidence = event.results[i][0].confidence || 0.5;
            const normalizedTranscript = transcript.trim();
            if (event.results[i].isFinal) {
                if (normalizedTranscript.length > 0) finalTranscript += normalizedTranscript + ' ';
                hasFinal = true;
            } else {
                if (confidence > 0.2 && normalizedTranscript.length > 0) interimTranscript += normalizedTranscript + ' ';
            }
        }
        if (interimTranscript && !hasFinal) {
            const interimText = interimTranscript.trim();
            if (interimText.length > 0) {
                const emotion = detectEmotion(interimText);
                addSubtitle(interimText, emotion, true);
            }
        }
        if (finalTranscript && hasFinal) {
            const finalText = finalTranscript.trim();
            if (finalText.length > 0) {
                const emotion = detectEmotion(finalText);
                addSubtitle(finalText, emotion, false);
            }
        }
    };
    rec.onerror = function (event) {
        console.warn('Speech recognition error:', event.error);
        if (event.error === 'no-speech' && isRecording) {
            try {
                rec.start();
            } catch (e) {
                console.warn('Restart recognition:', e);
            }
        } else if (event.error === 'audio-capture' || event.error === 'not-allowed') {
            isRecording = false;
            var btn = document.getElementById('startRecording');
            if (btn) {
                btn.textContent = translations[currentLanguage].startRecording;
                btn.classList.remove('active');
            }
            alert(translations[currentLanguage].microphonePermissionDenied);
        }
    };
    rec.onend = function () {
        if (!isRecording) return;
        try {
            rec.start();
        } catch (e) {
            console.warn('Recognition onend restart:', e);
            isRecording = false;
            var btn = document.getElementById('startRecording');
            if (btn) {
                btn.textContent = translations[currentLanguage].startRecording;
                btn.classList.remove('active');
            }
        }
    };
}

if (recognition) {
    attachRecognitionHandlers(recognition);
}

// Language switching function
function switchLanguage(lang) {
    const wasRecording = isRecording;
    const previousLanguage = currentLanguage;
    
    currentLanguage = lang;
    localStorage.setItem('language', lang);
    
    // Update HTML lang attribute
    const htmlLang = document.getElementById('htmlLang');
    if (htmlLang) {
        htmlLang.setAttribute('lang', lang);
    }
    
    // Update recognition language
    if (recognition) {
        let newLang;
        if (lang === 'kk') {
            // Try kk-KZ first, fallback to kk
            newLang = 'kk-KZ';
        } else {
            newLang = 'ru-RU';
        }
        
        recognition.lang = newLang;
        console.log(`Recognition language updated to: ${newLang}`);
        
        // If recording is active, restart recognition with new language
        if (wasRecording) {
            try {
                // Stop current recognition
                recognition.stop();
                
                // Wait a bit and restart with new language
                setTimeout(() => {
                    if (isRecording && recognition) {
                        try {
                            recognition.start();
                            console.log(`Speech recognition restarted with language: ${newLang}`);
                        } catch (error) {
                            console.error('Error restarting recognition with new language:', error);
                            // If kk-KZ fails, try kk
                            if (lang === 'kk' && newLang === 'kk-KZ') {
                                console.warn('kk-KZ not supported, trying kk');
                                recognition.lang = 'kk';
                                try {
                                    recognition.start();
                                    console.log('Speech recognition restarted with language: kk');
                                } catch (e2) {
                                    console.error('Both kk-KZ and kk failed');
                                    isRecording = false;
                                    const btn = document.getElementById('startRecording');
                                    if (btn) {
                                        btn.textContent = translations[currentLanguage].startRecording;
                                        btn.classList.remove('active');
                                    }
                                }
                            } else {
                                // If restart fails, reset recording state
                                isRecording = false;
                                const btn = document.getElementById('startRecording');
                                if (btn) {
                                    btn.textContent = translations[currentLanguage].startRecording;
                                    btn.classList.remove('active');
                                }
                            }
                        }
                    }
                }, 300);
            } catch (error) {
                console.error('Error stopping recognition for language switch:', error);
            }
        }
    }
    
    // Update real-time recognition language
    if (realtimeRecognition) {
        let newLang;
        if (lang === 'kk') {
            newLang = 'kk-KZ';
        } else {
            newLang = 'ru-RU';
        }
        
        realtimeRecognition.lang = newLang;
        console.log(`Real-time recognition language updated to: ${newLang}`);
        
        // If real-time subtitles are active, restart recognition with new language
        if (realtimeSubtitlesActive) {
            try {
                realtimeRecognition.stop();
                setTimeout(() => {
                    if (realtimeSubtitlesActive && realtimeRecognition) {
                        try {
                            realtimeRecognition.start();
                            console.log(`Real-time recognition restarted with language: ${newLang}`);
                        } catch (error) {
                            console.error('Error restarting real-time recognition with new language:', error);
                            if (lang === 'kk' && newLang === 'kk-KZ') {
                                console.warn('kk-KZ not supported, trying kk');
                                realtimeRecognition.lang = 'kk';
                                try {
                                    realtimeRecognition.start();
                                } catch (e2) {
                                    console.error('Both kk-KZ and kk failed for real-time recognition');
                                }
                            }
                        }
                    }
                }, 300);
            } catch (error) {
                console.error('Error stopping real-time recognition for language switch:', error);
            }
        }
    }
    
    // Update all elements with data-i18n
    document.querySelectorAll('[data-i18n]').forEach(element => {
        const key = element.getAttribute('data-i18n');
        if (translations[lang] && translations[lang][key]) {
            element.textContent = translations[lang][key];
        }
    });
    
    // Update placeholders
    document.querySelectorAll('[data-i18n-placeholder]').forEach(element => {
        const key = element.getAttribute('data-i18n-placeholder');
        if (translations[lang] && translations[lang][key]) {
            element.placeholder = translations[lang][key];
        }
    });
    
    // Update language buttons
    document.querySelectorAll('.lang-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.getAttribute('data-lang') === lang) {
            btn.classList.add('active');
        }
    });
    
    // Update recognition language display
    const recognitionLangDisplay = document.getElementById('recognitionLangDisplay');
    if (recognitionLangDisplay) {
        recognitionLangDisplay.textContent = lang === 'kk' ? 'Қазақша' : 'Русский';
    }
    
    // Update dynamic texts
    updateDynamicTexts();
    updateQuickPhrasesButtons();

    // Update gesture translation output if gesture is currently displayed (use English key lastGesture)
    const outputElement = document.getElementById('output');
    const gestureResultEl = document.getElementById('gesture_result');
    if (outputElement && gestureResultEl && lastGesture && lastGesture !== "—") {
        const translatedGesture = lastGesture.includes(" · ")
            ? lastGesture.split(" · ").map((g) => translateGesture(g.trim())).join(" · ")
            : translateGesture(lastGesture);
        outputElement.textContent = translatedGesture;
        gestureResultEl.textContent = translatedGesture;
    }
    // Re-render history in new language so all entries show translated
    renderHistory();

    // Update speakers list if real-time subtitles are active
    if (realtimeSubtitlesActive) {
        updateSpeakersList();
    }
    if (typeof updateThemeButtonLabel === 'function') updateThemeButtonLabel();
    
    // Update school module UI for new language
    if (typeof schoolBaseSubject !== 'undefined' && schoolBaseSubject) {
        // Переключаем предмет на новый язык
        const newSubjectName = getSubjectName(schoolBaseSubject);
        if (newSubjectName) {
            schoolCurrentSubject = newSubjectName;
        }
    }
    
    // Обновить видимость языковых элементов
    document.querySelectorAll('.lang-kk').forEach(el => {
        el.style.display = lang === 'kk' ? 'inline' : 'none';
    });
    document.querySelectorAll('.lang-ru').forEach(el => {
        el.style.display = lang === 'ru' ? 'inline' : 'none';
    });
    
    // Обновить UI школьного модуля при смене языка
    if (typeof updateSchoolUI === 'function') {
        // Сбросить индекс слова при смене языка
        if (typeof schoolWordIndex !== 'undefined') {
            schoolWordIndex = 0;
            schoolSuccessCount = 0;
        }
        updateSchoolUI();
    }
    
    // Озвучить смену языка (тек орыс тілінде)
    if (lang === 'ru') {
        const greet = "Выбран русский язык";
        if (typeof speakSchool === 'function') {
            speakSchool(greet);
        }
    }
    // Егер lang === 'kk' болса, ештеңе айтпайды (үнсіз ауысады)
}

/** Update Quick Phrases button labels by current language (RU/KK). */
function updateQuickPhrasesButtons() {
    const container = document.getElementById('quickPhrases');
    if (!container || typeof phraseTranslations === 'undefined') return;
    const lang = currentLanguage === 'kk' ? 'kk' : 'ru';
    container.querySelectorAll('.btn-quick-phrase[data-phrase]').forEach((btn) => {
        const key = btn.getAttribute('data-phrase');
        if (phraseTranslations[key]) {
            btn.textContent = phraseTranslations[key][lang];
        }
    });
}

    // Update dynamic texts that are set in JavaScript
function updateDynamicTexts() {
    const handTrackingStatus = document.getElementById('handTrackingStatus');
    if (handTrackingStatus) {
        if (handTrackingActive) {
            handTrackingStatus.textContent = translations[currentLanguage].cameraActive;
            handTrackingStatus.classList.add('active');
            // Update status with current accuracy if available
            if (gestureAccuracy && gestureAccuracy.overall) {
                updateHandTrackingStatus(gestureAccuracy);
            }
        } else {
            handTrackingStatus.textContent = translations[currentLanguage].cameraInactive;
            handTrackingStatus.classList.remove('active');
        }
    }
    
    const subtitlesDisplay = document.getElementById('subtitlesDisplay');
    if (subtitlesDisplay && subtitlesDisplay.children.length === 0) {
        const welcomeMsg = document.createElement('div');
        welcomeMsg.className = 'subtitle-item';
        welcomeMsg.innerHTML = `<span class="subtitle-text">${translations[currentLanguage].subtitlesWelcome}</span>`;
        welcomeMsg.style.opacity = '0.5';
        subtitlesDisplay.appendChild(welcomeMsg);
    }
    
    // Update button texts
    const startRecordingBtn = document.getElementById('startRecording');
    if (startRecordingBtn && !isRecording) {
        startRecordingBtn.textContent = translations[currentLanguage].startRecording;
    } else if (startRecordingBtn && isRecording) {
        startRecordingBtn.textContent = translations[currentLanguage].stopRecording;
    }
    
    const startCameraBtn = document.getElementById('startCamera');
    if (startCameraBtn) {
        if (handTrackingActive) {
            startCameraBtn.textContent = translations[currentLanguage].disableCamera;
        } else {
            startCameraBtn.textContent = translations[currentLanguage].enableCamera;
        }
    }
    
    const enableMonitoringBtn = document.getElementById('enableMonitoring');
    if (enableMonitoringBtn) {
        if (monitoringActive) {
            enableMonitoringBtn.textContent = translations[currentLanguage].disable;
        } else {
            enableMonitoringBtn.textContent = translations[currentLanguage].enable;
        }
    }
    
    const startRealtimeSubtitlesBtn = document.getElementById('startRealtimeSubtitles');
    if (startRealtimeSubtitlesBtn) {
        if (realtimeSubtitlesActive) {
            startRealtimeSubtitlesBtn.textContent = translations[currentLanguage].stopRealtimeSubtitles;
        } else {
            startRealtimeSubtitlesBtn.textContent = translations[currentLanguage].startRealtimeSubtitles;
        }
    }
    
    
    // Update hand quality indicator text
    if (handTrackingActive) {
        updateHandQualityIndicator();
    }
    
    // Update word tags
    const wordTags = document.querySelectorAll('.tag');
    wordTags.forEach(tag => {
        const wordKey = tag.getAttribute('data-word');
        if (wordKey) {
            // Map Russian words to keys
            const wordMap = {
                'привет': 'hello',
                'помощь': 'help',
                'спасибо': 'thanks',
                'пожалуйста': 'please',
                'да': 'yes'
            };
            
            // Map Kazakh words to keys
            const kzWordMap = {
                'сәлем': 'hello',
                'көмек': 'help',
                'рахмет': 'thanks',
                'өтінемін': 'please',
                'иә': 'yes'
            };
            
            let key = wordMap[wordKey] || kzWordMap[wordKey];
            if (key && translations[currentLanguage][key]) {
                tag.textContent = translations[currentLanguage][key];
                // Update data-word attribute for current language
                if (currentLanguage === 'kk') {
                    const reverseMap = {
                        'hello': 'сәлем',
                        'help': 'көмек',
                        'thanks': 'рахмет',
                        'please': 'өтінемін',
                        'yes': 'иә'
                    };
                    tag.setAttribute('data-word', reverseMap[key] || wordKey);
                } else {
                    const reverseMap = {
                        'hello': 'привет',
                        'help': 'помощь',
                        'thanks': 'спасибо',
                        'please': 'пожалуйста',
                        'yes': 'да'
                    };
                    tag.setAttribute('data-word', reverseMap[key] || wordKey);
                }
            }
        }
    });
}

// Language switcher event listeners
document.addEventListener('DOMContentLoaded', () => {
    const langRuBtn = document.getElementById('langRu');
    const langKkBtn = document.getElementById('langKk');
    
    if (langRuBtn) {
        langRuBtn.addEventListener('click', () => switchLanguage('ru'));
    }
    
    if (langKkBtn) {
        langKkBtn.addEventListener('click', () => switchLanguage('kk'));
    }
    
    // Initialize with saved language
    switchLanguage(currentLanguage);
    
    // Initialize recognition language display
    const recognitionLangDisplay = document.getElementById('recognitionLangDisplay');
    if (recognitionLangDisplay) {
        recognitionLangDisplay.textContent = currentLanguage === 'kk' ? 'Қазақша' : 'Русский';
    }
    
    // Initialize new sentence/history features (if elements exist)
    const clearSentenceBtn = document.getElementById('clearSentence');
    if (clearSentenceBtn) {
        clearSentenceBtn.addEventListener('click', () => {
            const sentenceText = document.getElementById('sentenceText');
            if (sentenceText) {
                sentenceText.textContent = 'Ожидание жеста...';
            }
            lastGesture = "—";
            gestureHistory = [];
        });
    }
    
    const speakSentenceBtn = document.getElementById('speakSentence');
    if (speakSentenceBtn) {
        speakSentenceBtn.addEventListener('click', () => {
            const sentenceText = document.getElementById('sentenceText');
            if (!sentenceText || !sentenceText.textContent || sentenceText.textContent === 'Ожидание жеста...') {
                alert('Нет предложения для озвучивания!');
                return;
            }
            speakWithVoice(sentenceText.textContent, currentLanguage);
        });
    }

    document.querySelectorAll('.btn-quick-phrase[data-phrase]').forEach((btn) => {
        btn.addEventListener('click', () => {
            const key = btn.getAttribute('data-phrase');
            if (!phraseTranslations || !phraseTranslations[key]) return;
            const lang = currentLanguage === 'kk' ? 'kk' : 'ru';
            const text = phraseTranslations[key][lang];
            speakWithVoice(text, currentLanguage);
        });
    });
    
    const translateBtn = document.getElementById('translateBtn');
    if (translateBtn) {
        translateBtn.addEventListener('click', async () => {
            const sentenceText = document.getElementById('sentenceText');
            const gestureResult = document.getElementById('gesture_result');
            const outputEl = document.getElementById('output');
            const languageSelect = document.getElementById('languageSelect');
            const translatedText = document.getElementById('translatedText');
            // English source for API: sentenceText or gesture_result (so API gets English)
            let text = (sentenceText && sentenceText.textContent) ? sentenceText.textContent.trim() : '';
            if (!text && gestureResult && gestureResult.textContent && gestureResult.textContent !== '—' && gestureResult.textContent !== 'Здесь будет текст') {
                text = gestureResult.textContent.trim();
            }
            if (!text && outputEl && outputEl.textContent && outputEl.textContent !== '—') {
                // Output is already translated; use local dictionary or show as-is for selected language
                const out = outputEl.textContent.trim();
                const target = languageSelect ? languageSelect.value : 'ru';
                if (target === (currentLanguage || 'ru')) {
                    if (translatedText) translatedText.textContent = out;
                    return;
                }
                text = out;
            }
            if (!text) {
                alert('Нет предложения для перевода!');
                return;
            }
            const target = languageSelect ? languageSelect.value : 'ru';
            // If text is from our dictionary (RU/KK), find English for API
            if (typeof gestureTranslations !== 'undefined') {
                for (const dict of Object.values(gestureTranslations)) {
                    const enKey = Object.entries(dict).find(([, v]) => v === text);
                    if (enKey) {
                        text = enKey[0];
                        break;
                    }
                }
            }
            if (translatedText) {
                translatedText.textContent = 'Переводится...';
            }
            try {
                const res = await fetch(
                    `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=en|${target}`
                );
                const data = await res.json();
                if (data.responseStatus === 200 && data.responseData.translatedText) {
                    const translated = data.responseData.translatedText;
                    if (translatedText) {
                        translatedText.textContent = translated;
                    }
                } else {
                    if (translatedText) {
                        translatedText.textContent = 'Ошибка перевода';
                    }
                }
            } catch (err) {
                console.error('Translation error:', err);
                if (translatedText) {
                    translatedText.textContent = 'Ошибка перевода. Проверьте интернет.';
                }
            }
        });
    }
    
    const clearHistoryBtn = document.getElementById('clearHistory');
    if (clearHistoryBtn) {
        clearHistoryBtn.addEventListener('click', () => {
            historyEntries = [];
            renderHistory();
        });
    }

    // Режим обучения: чекбокс и блок подсказок
    const learningModeCheckbox = document.getElementById('learningModeCheckbox');
    const hintBox = document.getElementById('hint-box');
    
    if (learningModeCheckbox && hintBox) {
        learningModeCheckbox.addEventListener('change', () => {
            learningMode = learningModeCheckbox.checked;
            hintBox.style.display = learningMode ? 'block' : 'none';
            if (learningMode) {
                successCount = 0;
                isChecking = true;
                canCheck = true;
                wordIndex = 0;
                updateLearningUI();
            }
        });
        const labelLearning = document.querySelector('.learning-mode-toggle [data-i18n="learningMode"]');
        if (labelLearning && translations[currentLanguage]?.learningMode) {
            labelLearning.textContent = translations[currentLanguage].learningMode;
        }
        if (learningModeCheckbox.checked) {
            learningMode = true;
            hintBox.style.display = 'block';
            wordIndex = 0;
            updateLearningUI();
        }
    }
    
    // Обработчики кнопок выбора предмета (для старого режима обучения)
    const subjectButtons = document.querySelectorAll('.btn-subject[data-subject]');
    subjectButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            subjectButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            const subject = btn.getAttribute('data-subject');
            if (subject) {
                switchSubject(subject);
            }
        });
    });

    // =====================================================
    // ШКОЛЬНОЕ ОБУЧЕНИЕ ЖЕСТАМ (БӨЛЕК БЛОК)
    // =====================================================
    
    // Дополнительные переменные для камеры
    let schoolHands = null;
    let schoolCamera = null;
    
    // DOM элементы школьного модуля
    const schoolWebcam = document.getElementById('schoolWebcam');
    const schoolCanvas = document.getElementById('schoolCanvas');
    const schoolVideoPlaceholder = document.getElementById('school-video-placeholder');
    const startSchoolCameraBtn = document.getElementById('startSchoolCamera');
    const skipSchoolWordBtn = document.getElementById('skipSchoolWord');
    
    // Обновить UI школьного модуля (жаңа көк дизайн)
    function updateSchoolUI() {
        const modules = getSchoolModules();
        const subjects = getSchoolSubjects();
        const status = getSchoolStatus();
        
        const dictionary = modules[schoolSubjectKey];
        if (!dictionary || !dictionary.length) return;
        
        if (schoolWordIndex >= dictionary.length) schoolWordIndex = 0;
        
        const current = dictionary[schoolWordIndex];
        const total = dictionary.length;
        const currentNum = schoolWordIndex + 1;
        
        // Обновить задание
        const taskNameEl = document.getElementById('school-task-name');
        const taskHintEl = document.getElementById('school-task-hint');
        const statusTextEl = document.getElementById('school-status-text');
        const progressTextEl = document.getElementById('school-progress-text');
        
        if (taskNameEl) taskNameEl.textContent = current.name;
        if (taskHintEl) taskHintEl.textContent = current.hint;
        if (progressTextEl) progressTextEl.textContent = `${currentNum} / ${total}`;
        
        // Обновить статус
        if (statusTextEl) {
            if (schoolCameraActive) {
                statusTextEl.innerHTML = `<span class="lang-kk">${status.showGesture}</span><span class="lang-ru">${status.showGesture}</span>`;
            } else {
                statusTextEl.innerHTML = `<span class="lang-kk">${status.showCamera}</span><span class="lang-ru">${status.showCamera}</span>`;
            }
        }
        
        // Обновить прогресс-бар
        updateSchoolProgress();
        
        // Обновить видимость языковых элементов
        updateLanguageVisibility();
    }
    
    // Обновить видимость элементов по языку
    function updateLanguageVisibility() {
        document.querySelectorAll('.lang-kk').forEach(el => {
            el.style.display = currentLanguage === 'kk' ? 'inline' : 'none';
        });
        document.querySelectorAll('.lang-ru').forEach(el => {
            el.style.display = currentLanguage === 'ru' ? 'inline' : 'none';
        });
    }
    
    // Обновить прогресс-бар
    function updateSchoolProgress() {
        const modules = getSchoolModules();
        const dictionary = modules[schoolSubjectKey];
        if (!dictionary) return;
        
        const total = dictionary.length;
        const percent = Math.round((schoolWordIndex / total) * 100);
        
        const progressBar = document.getElementById('school-progress-bar');
        const percentText = document.getElementById('school-percent-text');
        
        if (progressBar) progressBar.style.width = `${percent}%`;
        if (percentText) percentText.textContent = `${percent}%`;
    }
    
    // Обработка успешного выполнения слова
    function handleWordSuccess() {
        const modules = getSchoolModules();
        const dictionary = modules[schoolSubjectKey];
        const status = getSchoolStatus();
        const total = dictionary.length;
        
        // Сәттілік эффектілері
        showStarExplosion(dictionary[schoolWordIndex].name);
        
        // Егер сабақ аяқталса
        if (schoolWordIndex + 1 === total) {
            const progressBar = document.getElementById('school-progress-bar');
            const percentText = document.getElementById('school-percent-text');
            if (progressBar) progressBar.style.width = `100%`;
            if (percentText) percentText.textContent = `100%`;
            speakSchool(status.complete.replace(/[🎯👍🎉🏆📷👀]/g, ''));
        }
    }
    
    
    // Обработка жестов для школьного модуля
    function processSchoolHands(multiLandmarks) {
        // Егер нүктелер табылмаса, функциядан шығу
        if (!multiLandmarks || multiLandmarks.length === 0 || !schoolCanCheck) return;
        if (!hasValidLandmarks(multiLandmarks[0])) return;
        
        // Қате болмас үшін нысанның бар-жоғын тексеру
        if (typeof schoolTaskStatus === 'undefined') {
            window.schoolTaskStatus = { kk: "Дайынсыз ба?", ru: "Готовы?" };
        }
        
        const modules = getSchoolModules();
        const dictionary = modules[schoolSubjectKey];
        if (!dictionary || !dictionary.length) return;
        if (schoolWordIndex >= dictionary.length) schoolWordIndex = 0;
        
        const current = dictionary[schoolWordIndex];
        
        // Камерадағы қолдар саны тапсырмаға сай ма?
        // Проверяем, хватает ли рук
        if (multiLandmarks.length < current.hands) return;
        
        // Бірінші қолдың коды / Код первой руки
        const hand1 = getFingerCode(multiLandmarks[0]);
        if (!hand1) return;
        
        let isCorrect = (hand1 === current.fingers);
        
        // Егер 2 қол керек болса, екіншісін де тексереміз
        // Если нужно 2 руки - проверяем вторую
        if (current.hands === 2 && multiLandmarks[1]) {
            if (hasValidLandmarks(multiLandmarks[1])) {
                const hand2 = getFingerCode(multiLandmarks[1]);
                if (hand2) {
                    isCorrect = isCorrect && (hand2 === current.fingers);
                } else {
                    isCorrect = false;
                }
            } else {
                isCorrect = false;
            }
        }
        
        // Егер жест дұрыс емес болса - шығамыз
        // Если жест неправильный - выходим
        if (!isCorrect) return;
        
        schoolSuccessCount++;
        schoolCanCheck = false;
        
        const status = getSchoolStatus();
        
        // DOM элементін табу
        const schoolTaskStatusEl = document.getElementById('school-status-text') || document.querySelector('.school-task-status');
        
        if (schoolSuccessCount === 1) {
            // Первый успех - попросить повторить
            if (schoolTaskStatusEl) {
                schoolTaskStatusEl.innerHTML = `<span class="status-try-again">${status.repeat}</span>`;
            }
            speakSchool(status.repeat.replace(/[🎯👍🎉🏆📷👀]/g, ''));
            setTimeout(() => { schoolCanCheck = true; }, 1500);
        } else if (schoolSuccessCount >= 2) {
            // Победа!
            schoolCompletedWords++;
            
            if (schoolTaskStatusEl) {
                schoolTaskStatusEl.innerHTML = `<span class="status-success">${status.great}</span>`;
            }
            
            // Озвучить слово и поздравление
            speakSchool(`${current.name}. ${status.great.replace(/[🎯👍🎉🏆📷👀]/g, '')}`);
            showStarExplosion(current.name);
            
            schoolSuccessCount = 0;
            schoolWordIndex++;
            schoolCompletedWords = schoolWordIndex;
            
            // Обновить прогресс сразу
            updateSchoolProgress();
            
            // Проверить завершение урока
            if (schoolWordIndex >= dictionary.length) {
                schoolWordIndex = 0;
                schoolCompletedWords = dictionary.length;
                handleWordSuccess();
                setTimeout(() => {
                    speakSchool(status.complete.replace(/[🎯👍🎉🏆📷👀]/g, ''));
                    const statusTextEl = document.getElementById('school-status-text');
                    if (statusTextEl) {
                        statusTextEl.innerHTML = `<span class="lang-kk">${status.complete}</span><span class="lang-ru">${status.complete}</span>`;
                    }
                }, 2500);
            }
            
            setTimeout(() => {
                schoolCanCheck = true;
                updateSchoolUI();
            }, 4000);
        }
    }
    
    // Инициализация камеры школьного модуля (жақсартылған)
    async function initSchoolCamera() {
        // 1. Егер бұрынғы камера қосулы болса, оны толық өшіреміз
        if (schoolCamera) {
            try {
                await schoolCamera.stop();
            } catch (e) {
                console.warn('Error stopping previous camera:', e);
            }
            schoolCamera = null;
        }
        
        if (!schoolWebcam || !schoolCanvas) return;
        
        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                video: { width: 480, height: 360, facingMode: 'user' } // Төмендетілген ажыратымдылық
            });
            
            schoolWebcam.srcObject = stream;
            await schoolWebcam.play();
            
            // Настройка canvas (ажыратымдылықты төмендету)
            const ctx = schoolCanvas.getContext('2d');
            schoolCanvas.width = 480;
            schoolCanvas.height = 360;
            
            // Скрыть placeholder
            if (schoolVideoPlaceholder) schoolVideoPlaceholder.style.display = 'none';
            if (schoolWebcam) schoolWebcam.style.display = 'block';
            
            // Инициализация MediaPipe Hands (баяулатылған конфигурация)
            schoolHands = new Hands({
                locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
            });
            
            schoolHands.setOptions({
                maxNumHands: 2,
                modelComplexity: 0, // 0 - ең жеңіл (процессорды шаршатпайды)
                minDetectionConfidence: 0.5, // Төмендетілді (дәлірек тану)
                minTrackingConfidence: 0.5
            });
            
            schoolHands.onResults((results) => {
                // Отрисовка
                ctx.save();
                ctx.clearRect(0, 0, schoolCanvas.width, schoolCanvas.height);
                ctx.drawImage(results.image, 0, 0, schoolCanvas.width, schoolCanvas.height);
                
                if (results.multiHandLandmarks) {
                    for (const landmarks of results.multiHandLandmarks) {
                        drawConnectors(ctx, landmarks, HAND_CONNECTIONS, {color: '#00FF00', lineWidth: 3});
                        drawLandmarks(ctx, landmarks, {color: '#FF0000', lineWidth: 1, radius: 4});
                    }
                    
                    // Обработка жестов
                    if (schoolCameraActive) {
                        processSchoolHands(results.multiHandLandmarks);
                    }
                }
                
                ctx.restore();
            });
            
            // Запуск камеры (төмендетілген ажыратымдылық - процессорды шаршатпау үшін)
            schoolCamera = new Camera(schoolWebcam, {
                onFrame: async () => {
                    try {
                        // Егер hands объектісі дайын болса ғана жіберу
                        if (schoolHands && schoolCameraActive) {
                            await schoolHands.send({ image: schoolWebcam });
                        }
                    } catch (e) {
                        console.error("MediaPipe өңдеу қатесі:", e);
                        // Қате шықса, камераны тоқтатып, қайта іске қосу керек болуы мүмкін
                        if (e.name === 'AbortError' || e.message?.includes('Aborted')) {
                            console.warn("MediaPipe операциясы тоқтатылды, камераны қайта бастау...");
                            // Камераны қайта бастау логикасын осында қосуға болады
                        }
                    }
                },
                width: 480,
                height: 360
            });
            
            await schoolCamera.start();
            schoolCameraActive = true;
            
            console.log("Мектеп камерасы және MediaPipe сәтті қосылды");
            
            // Обновить кнопку
            if (startSchoolCameraBtn) {
                const stopText = currentLanguage === 'kk' ? 'Камераны өшіру' : 'Выключить камеру';
                startSchoolCameraBtn.innerHTML = `⏹️ <span class="lang-kk">${stopText}</span><span class="lang-ru">${stopText}</span>`;
                startSchoolCameraBtn.classList.add('active');
            }
            
            updateSchoolUI();
            
        } catch (error) {
            console.error('School camera error:', error);
            alert('Камераға қол жеткізу мүмкін емес / Не удалось получить доступ к камере');
        }
    }
    
    // Остановить камеру школьного модуля (жақсартылған)
    async function stopSchoolCamera() {
        if (schoolCamera) {
            try {
                await schoolCamera.stop();
            } catch (e) {
                console.warn('Error stopping camera:', e);
            }
            schoolCamera = null;
        }
        
        if (schoolWebcam && schoolWebcam.srcObject) {
            schoolWebcam.srcObject.getTracks().forEach(track => track.stop());
            schoolWebcam.srcObject = null;
        }
        
        schoolCameraActive = false;
        
        // Показать placeholder
        if (schoolVideoPlaceholder) schoolVideoPlaceholder.style.display = 'flex';
        if (schoolWebcam) schoolWebcam.style.display = 'none';
        
        // Канвасты тазалау (нүктелер қалып қоймауы үшін)
        if (schoolCanvas) {
            const ctx = schoolCanvas.getContext('2d');
            ctx.clearRect(0, 0, schoolCanvas.width, schoolCanvas.height);
        }
        
        // Обновить кнопку
        if (startSchoolCameraBtn) {
            const startText = currentLanguage === 'kk' ? 'Камераны қосу' : 'Включить камеру';
            startSchoolCameraBtn.innerHTML = `📷 <span class="lang-kk">${startText}</span><span class="lang-ru">${startText}</span>`;
            startSchoolCameraBtn.classList.remove('active');
        }
        
        updateSchoolUI();
    }
    
    // Обработчики событий школьного модуля
    if (startSchoolCameraBtn) {
        startSchoolCameraBtn.addEventListener('click', async () => {
            if (schoolCameraActive) {
                await stopSchoolCamera();
            } else {
                await initSchoolCamera();
            }
        });
    }
    
    if (skipSchoolWordBtn) {
        skipSchoolWordBtn.addEventListener('click', () => {
            const modules = getSchoolModules();
            const dictionary = modules[schoolSubjectKey];
            if (dictionary) {
                schoolWordIndex = (schoolWordIndex + 1) % dictionary.length;
                schoolSuccessCount = 0;
                schoolCanCheck = true;
                updateSchoolUI();
            }
        });
    }
    
    // Өшіру функциясы / Функция сброса
    function resetSchoolWord() {
        schoolWordIndex = 0;
        schoolSuccessCount = 0;
        schoolCompletedWords = 0;
        schoolCanCheck = true;
        updateSchoolUI();
        updateSchoolProgress();
        
        // Озвучить
        const status = getSchoolStatus();
        const resetText = currentLanguage === 'kk' ? 'Басынан басталды' : 'Начато заново';
        speakSchool(resetText);
    }
    
    // Глобальды функция ретінде қолжетімді ету
    window.resetSchoolWord = resetSchoolWord;
    
    // Инициализация UI школьного модуля
    updateSchoolUI();
});

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    console.log('Accessibility app initialized');
    
    // Check for browser support
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        console.warn('getUserMedia is not supported in this browser');
    }
    
    if (!recognition) {
        console.warn('Speech Recognition is not supported in this browser');
        const startBtn = document.getElementById('startRecording');
        if (startBtn) {
            startBtn.disabled = true;
            startBtn.title = translations[currentLanguage].speechNotSupported;
        }
    } else {
        // Log current recognition language
        console.log(`Speech recognition ready with language: ${recognition.lang}`);
    }
    
    // Initialize empty displays
    const subtitlesDisplay = document.getElementById('subtitlesDisplay');
    if (subtitlesDisplay && subtitlesDisplay.children.length === 0) {
        const welcomeMsg = document.createElement('div');
        welcomeMsg.className = 'subtitle-item';
        welcomeMsg.innerHTML = `<span class="subtitle-text">${translations[currentLanguage].subtitlesWelcome}</span>`;
        welcomeMsg.style.opacity = '0.5';
        subtitlesDisplay.appendChild(welcomeMsg);
    }
    
    // Initialize recognition language display
    const recognitionLangDisplay = document.getElementById('recognitionLangDisplay');
    if (recognitionLangDisplay) {
        recognitionLangDisplay.textContent = currentLanguage === 'kk' ? 'Қазақша' : 'Русский';
    }
});

// Sound Widget Implementation
(() => {
  let audioCtx = null;
  let analyser = null;
  let micSource = null;
  let micStream = null;
  let rafId = null;
  let isOn = false;

  const btn = document.getElementById("soundToggleBtn");
  const bar = document.getElementById("soundLevelBar");
  const badge = document.getElementById("soundBadge");
  const statusText = document.getElementById("soundStatusText");

  if (!btn || !bar || !badge || !statusText) {
    console.warn("Sound widget elements not found.");
    return;
  }

  btn.addEventListener("click", async () => {
    if (!isOn) await start();
    else stop();
  });

  async function start() {
    try {
      btn.disabled = true;
      statusText.textContent = "Запрашиваю микрофон…";

      micStream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true },
      });

      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      analyser = audioCtx.createAnalyser();
      analyser.fftSize = 1024;
      analyser.smoothingTimeConstant = 0.85; // 0.7–0.9

      micSource = audioCtx.createMediaStreamSource(micStream);
      micSource.connect(analyser);

      isOn = true;
      badge.textContent = "вкл";
      badge.style.background = "#dcfce7";
      badge.style.color = "#166534";

      btn.textContent = "Выключить";
      btn.classList.add("off");
      statusText.textContent = "Слушаю звук…";

      btn.disabled = false;
      loop();
    } catch (e) {
      console.error(e);
      statusText.textContent = "Нет доступа к микрофону (разреши в браузере).";
      btn.disabled = false;
      stop(true);
    }
  }

  function loop() {
    if (!isOn || !analyser) return;

    const data = new Uint8Array(analyser.fftSize);
    analyser.getByteTimeDomainData(data);

    // RMS loudness (0..1 шамасында)
    let sum = 0;
    for (let i = 0; i < data.length; i++) {
      const v = (data[i] - 128) / 128; // -1..1
      sum += v * v;
    }
    const rms = Math.sqrt(sum / data.length);

    const SENS = 1.6;      // 1.2–2.0 (аз болса — тыныш көрсетеді)
    const percent = Math.min(100, Math.round(rms * 100 * SENS));

    bar.style.width = percent + "%";

    if (percent >= 70) bar.style.background = "#ef4444";
    else if (percent >= 40) bar.style.background = "#f59e0b";
    else bar.style.background = "#22c55e";

    rafId = requestAnimationFrame(loop);
  }

  function stop(silent = false) {
    isOn = false;

    if (rafId) cancelAnimationFrame(rafId);
    rafId = null;

    if (micStream) {
      micStream.getTracks().forEach(t => t.stop());
      micStream = null;
    }

    if (audioCtx) {
      audioCtx.close().catch(() => {});
      audioCtx = null;
    }

    analyser = null;
    micSource = null;

    bar.style.width = "0%";
    bar.style.background = "#22c55e";

    badge.textContent = "выкл";
    badge.style.background = "#f2f4f7";
    badge.style.color = "#667085";

    btn.textContent = "Включить";
    btn.classList.remove("off");

    if (!silent) statusText.textContent = "Выключено.";
  }
})();

// Sound Widget Drag + Restore Position
(() => {
  const widget = document.getElementById("soundWidget");
  const handle = document.getElementById("soundDragHandle");
  if (!widget || !handle) return;

  const saved = localStorage.getItem("soundWidgetPos");
  if (saved) {
    try {
      const { left, top } = JSON.parse(saved);
      widget.style.left = left + "px";
      widget.style.top = top + "px";
      widget.style.right = "auto";
      widget.style.bottom = "auto";
    } catch {}
  }

  let isDragging = false;
  let startX = 0;
  let startY = 0;
  let startLeft = 0;
  let startTop = 0;

  handle.addEventListener("mousedown", (e) => {
    if (e.target.closest("button, input, textarea, select, a")) return;

    isDragging = true;
    const rect = widget.getBoundingClientRect();
    startX = e.clientX;
    startY = e.clientY;
    startLeft = rect.left;
    startTop = rect.top;

    widget.style.left = rect.left + "px";
    widget.style.top = rect.top + "px";
    widget.style.right = "auto";
    widget.style.bottom = "auto";

    e.preventDefault();
  });

  window.addEventListener("mousemove", (e) => {
    if (!isDragging) return;

    const dx = e.clientX - startX;
    const dy = e.clientY - startY;

    let newLeft = startLeft + dx;
    let newTop = startTop + dy;

    const w = widget.offsetWidth;
    const h = widget.offsetHeight;
    const maxLeft = window.innerWidth - w - 10;
    const maxTop = window.innerHeight - h - 10;

    newLeft = Math.max(10, Math.min(maxLeft, newLeft));
    newTop = Math.max(10, Math.min(maxTop, newTop));

    widget.style.left = newLeft + "px";
    widget.style.top = newTop + "px";
  });

  window.addEventListener("mouseup", () => {
    if (!isDragging) return;
    isDragging = false;

    const rect = widget.getBoundingClientRect();
    localStorage.setItem(
      "soundWidgetPos",
      JSON.stringify({
        left: Math.round(rect.left),
        top: Math.round(rect.top),
      })
    );
  });
})();

function resetSoundWidgetPos() {
  localStorage.removeItem("soundWidgetPos");
  const w = document.getElementById("soundWidget");
  if (!w) return;
  w.style.top = "120px";
  w.style.right = "20px";
  w.style.left = "auto";
}

// =======================
// QUIZ BANK (1–4 класс)
// пән -> класс -> lessonKey -> сұрақтар
// correct: дұрыс жауап индексі (0,1,2,3)
// =======================
const QUIZ_BANK = {
  math: {
    1: {
      numbers: [
        { q: "1-ден кейін қандай сан?", a: ["2", "3", "0"], correct: 0 },
        { q: "5-тен бұрын қандай сан?", a: ["3", "4", "6"], correct: 1 },
        { q: "Қайсысы ең үлкен?", a: ["2", "7", "5"], correct: 1 },
      ],
      plusminus: [
        { q: "➕ белгісі нені білдіреді?", a: ["Қосу", "Азайту", "Бөлу"], correct: 0 },
        { q: "➖ белгісі нені білдіреді?", a: ["Көбейту", "Азайту", "Қосу"], correct: 1 },
        { q: "3 + 2 = ?", a: ["4", "5", "6"], correct: 1 },
      ],
      minus: [
        { q: "7 - 3 = ?", a: ["3", "4", "5"], correct: 1 },
        { q: "10 - 5 = ?", a: ["4", "5", "6"], correct: 1 },
        { q: "Азайту нені білдіреді?", a: ["Кеміту", "Көбейту", "Қосу"], correct: 0 },
      ],
      compare: [
        { q: "8 _ 5 қай белгі?", a: [">", "<", "="], correct: 0 },
        { q: "3 _ 3 қай белгі?", a: [">", "<", "="], correct: 2 },
        { q: "2 _ 9 қай белгі?", a: [">", "<", "="], correct: 1 },
      ],
    },
    2: {
      multiply: [
        { q: "Көбейту белгісі қандай?", a: ["×", "÷", "−"], correct: 0 },
        { q: "2 × 3 = ?", a: ["5", "6", "7"], correct: 1 },
        { q: "5 × 4 = ?", a: ["15", "20", "25"], correct: 1 },
      ],
      divide: [
        { q: "Бөлу белгісі қандай?", a: ["+", "÷", "="], correct: 1 },
        { q: "8 ÷ 2 = ?", a: ["3", "4", "5"], correct: 1 },
        { q: "15 ÷ 3 = ?", a: ["4", "5", "6"], correct: 1 },
      ],
      time: [
        { q: "Уақытты немен өлшейміз?", a: ["Сағат", "Сызғыш", "Кітап"], correct: 0 },
        { q: "1 сағатта неше минут бар?", a: ["30", "60", "100"], correct: 1 },
        { q: "Жарты сағат неше минут?", a: ["15", "30", "45"], correct: 1 },
      ],
      measure: [
        { q: "1 метрде неше см?", a: ["10", "100", "1000"], correct: 1 },
        { q: "Ұзындықты немен өлшейміз?", a: ["Сызғыш", "Сағат", "Термометр"], correct: 0 },
        { q: "Салмақты немен өлшейміз?", a: ["Таразы", "Сызғыш", "Сағат"], correct: 0 },
      ],
    },
    3: {
      bigNumbers: [
        { q: "100 саны қалай оқылады?", a: ["Жүз", "Он", "Мың"], correct: 0 },
        { q: "345 санында неше жүздік?", a: ["3", "4", "5"], correct: 0 },
        { q: "200 + 150 = ?", a: ["300", "350", "400"], correct: 1 },
      ],
      fractions: [
        { q: "1/2 деген не?", a: ["Жарты", "Үштен бір", "Бүтін"], correct: 0 },
        { q: "Пиццаны 4-ке бөлдік. 1 бөлік — бұл?", a: ["1/2", "1/3", "1/4"], correct: 2 },
        { q: "Қайсысы бөлшек?", a: ["3", "1/4", "10"], correct: 1 },
      ],
      problems: [
        { q: "5 алма + 3 алма = ?", a: ["7", "8", "9"], correct: 1 },
        { q: "Есепте не маңызды?", a: ["Амал таңдау", "Түс", "Ән"], correct: 0 },
        { q: "10 - 4 = ?", a: ["5", "6", "7"], correct: 1 },
      ],
      shapes: [
        { q: "Шаршының неше қабырғасы бар?", a: ["3", "4", "5"], correct: 1 },
        { q: "Үшбұрыштың неше бұрышы бар?", a: ["2", "3", "4"], correct: 1 },
        { q: "Шеңбер деген не?", a: ["Дөңгелек сызық", "Түзу сызық", "Бұрыш"], correct: 0 },
      ],
    },
    4: {
      equations: [
        { q: "Теңдеу деген не?", a: ["Белгісізі бар мысал", "Сурет", "Ән"], correct: 0 },
        { q: "x + 4 = 10 болса, x = ?", a: ["4", "6", "14"], correct: 1 },
        { q: "x × 2 = 8 болса, x = ?", a: ["4", "6", "16"], correct: 0 },
      ],
      perimeter: [
        { q: "Периметр деген не?", a: ["Қабырғалар қосындысы", "Түс", "Көлем"], correct: 0 },
        { q: "Қабырғасы 5 см шаршының периметрі?", a: ["15", "20", "25"], correct: 1 },
        { q: "Қабырғасы 3 см шаршының ауданы?", a: ["6", "9", "12"], correct: 1 },
      ],
      fracOps: [
        { q: "1/3 + 1/3 = ?", a: ["1/3", "2/3", "3/3"], correct: 1 },
        { q: "3/4 - 1/4 = ?", a: ["1/4", "2/4", "4/4"], correct: 1 },
        { q: "Бөлшек қосу қалай?", a: ["Алымдарды қосамыз", "Бөлімдерді қосамыз", "Көбейтеміз"], correct: 0 },
      ],
      thousands: [
        { q: "5000 + 2000 = ?", a: ["6000", "7000", "8000"], correct: 1 },
        { q: "1000 қалай оқылады?", a: ["Мың", "Жүз", "Он"], correct: 0 },
        { q: "3456 ≈ ?", a: ["3000", "3500", "4000"], correct: 1 },
      ],
    },
  },

  ru: {
    1: {
      letters: [
        { q: "А — қандай дыбыс?", a: ["Дауысты", "Дауыссыз"], correct: 0 },
        { q: "'Мама' сөзінде неше дыбыс?", a: ["3", "4", "5"], correct: 1 },
        { q: "Әріп не үшін керек?", a: ["Сөз құрау үшін", "Су ішу үшін", "Ойын үшін"], correct: 0 },
      ],
      syllables: [
        { q: "'Папа' сөзінде неше буын?", a: ["1", "2", "3"], correct: 1 },
        { q: "Буын деген не?", a: ["Сөздің бөлігі", "Кітап", "Сан"], correct: 0 },
        { q: "'Мо-ло-ко' неше буын?", a: ["2", "3", "4"], correct: 1 },
      ],
      words: [
        { q: "'Кот' — бұл не?", a: ["Ит", "Мысық", "Құс"], correct: 1 },
        { q: "Сөз неден тұрады?", a: ["Әріптерден", "Сандардан", "Түстерден"], correct: 0 },
        { q: "Қайсысы сөз?", a: ["ма-ма", "2+2", "10"], correct: 0 },
      ],
      sentence: [
        { q: "Сөйлем неден басталады?", a: ["Кіші әріп", "Бас әріп", "Сан"], correct: 1 },
        { q: "Сөйлем соңында не?", a: ["Нүкте", "Үтір", "Ештеңе"], correct: 0 },
        { q: "Сөйлем деген не?", a: ["Аяқталған ой", "Бір әріп", "Сан"], correct: 0 },
      ],
    },
    2: {
      parts: [
        { q: "'Собака' — қай сөз табы?", a: ["Зат есім", "Сын есім", "Етістік"], correct: 0 },
        { q: "Зат есім нені білдіреді?", a: ["Затты/адамды", "Қимылды", "Түсті"], correct: 0 },
        { q: "Етістік нені білдіреді?", a: ["Қимылды", "Затты", "Санды"], correct: 0 },
      ],
      synonyms: [
        { q: "'Большой' антонимі?", a: ["Красный", "Маленький", "Быстрый"], correct: 1 },
        { q: "Синоним деген не?", a: ["Ұқсас мағына", "Қарама-қарсы", "Сан"], correct: 0 },
        { q: "Антоним деген не?", a: ["Қарама-қарсы мағына", "Ұқсас мағына", "Түс"], correct: 0 },
      ],
      sentBuild: [
        { q: "'Мама читает' — бастауыш қайсы?", a: ["Мама", "Читает"], correct: 0 },
        { q: "Бастауыш деген не?", a: ["Сөйлем иесі", "Қимыл", "Түс"], correct: 0 },
        { q: "Баяндауыш деген не?", a: ["Қимыл", "Зат", "Сан"], correct: 0 },
      ],
      plural: [
        { q: "'Столы' — қай түр?", a: ["Жекеше", "Көпше"], correct: 1 },
        { q: "Көпше түр деген не?", a: ["Көп зат", "Бір зат", "Жоқ зат"], correct: 0 },
        { q: "'Кот' — қай түр?", a: ["Жекеше", "Көпше"], correct: 0 },
      ],
    },
    3: {
      members: [
        { q: "'Мальчик читает книгу' — толықтауыш?", a: ["Мальчик", "Читает", "Книгу"], correct: 2 },
        { q: "Толықтауыш қай сұраққа жауап?", a: ["Кімге? Нені?", "Кім?", "Қандай?"], correct: 0 },
        { q: "Анықтауыш қай сұраққа жауап?", a: ["Қандай?", "Кім?", "Не істеді?"], correct: 0 },
      ],
      punctuation: [
        { q: "'Как тебя зовут' соңына не қоямыз?", a: [".", "?", "!"], correct: 1 },
        { q: "Лепті сөйлем соңында не?", a: ["!", "?", "."], correct: 0 },
        { q: "Үтір қашан қойылады?", a: ["Тізімде", "Сөйлем соңында", "Сөз басында"], correct: 0 },
      ],
      roots: [
        { q: "'Домик' сөзінің түбірі?", a: ["Дом", "Домик", "Ик"], correct: 0 },
        { q: "Түбір деген не?", a: ["Сөздің негізі", "Сөз соңы", "Сөз басы"], correct: 0 },
        { q: "Жұрнақ қайда тұрады?", a: ["Түбірден кейін", "Түбірден бұрын", "Сөз басында"], correct: 0 },
      ],
      reading: [
        { q: "Мәтіннің негізгі ойын қалай табамыз?", a: ["Тақырыпқа қарап", "Оқып түсініп", "Суретке қарап"], correct: 1 },
        { q: "Тақырып деген не?", a: ["Мәтін не туралы", "Сурет", "Сан"], correct: 0 },
        { q: "Негізгі ой деген не?", a: ["Ең басты мағына", "Кездейсоқ сөз", "Түс"], correct: 0 },
      ],
    },
    4: {
      writing: [
        { q: "Мәтін неше бөлімнен тұрады?", a: ["2", "3", "4"], correct: 1 },
        { q: "Кіріспе деген не?", a: ["Мәтін басы", "Мәтін соңы", "Мәтін ортасы"], correct: 0 },
        { q: "Қорытынды деген не?", a: ["Мәтін соңы", "Мәтін басы", "Мәтін ортасы"], correct: 0 },
      ],
      summary: [
        { q: "Мазмұндама дегеніміз не?", a: ["Жаңа мәтін", "Мәтінді қайта айту", "Сурет салу"], correct: 1 },
        { q: "Жоспар не үшін керек?", a: ["Ретімен айту үшін", "Ұйықтау үшін", "Ойын үшін"], correct: 0 },
        { q: "Мазмұндамада не маңызды?", a: ["Оқиға реті", "Тек смайлик", "Тек сан"], correct: 0 },
      ],
      vocabulary: [
        { q: "Сөздің мағынасын қайдан табамыз?", a: ["Кітаптан", "Сөздіктен", "Суреттен"], correct: 1 },
        { q: "Сөздік не үшін керек?", a: ["Мағынаны білу үшін", "Ойын үшін", "Ұйықтау үшін"], correct: 0 },
        { q: "Жаңа сөзді қалай үйренеміз?", a: ["Сөйлемде қолданып", "Ұмытып", "Елемей"], correct: 0 },
      ],
      essay: [
        { q: "Шығарма жазудың бірінші қадамы?", a: ["Жазу", "Тақырып таңдау", "Тексеру"], correct: 1 },
        { q: "Шығарма деген не?", a: ["Өз ойыңды жазу", "Көшіру", "Сурет салу"], correct: 0 },
        { q: "Шығармада не маңызды?", a: ["Ойды байланыстыру", "Тек сурет", "Тек сан"], correct: 0 },
      ],
    },
  },

  world: {
    1: {
      animals: [
        { q: "Ит — қандай жануар?", a: ["Үй", "Жабайы"], correct: 0 },
        { q: "Арыстан қайда тұрады?", a: ["Үйде", "Табиғатта"], correct: 1 },
        { q: "Үй жануары қайсы?", a: ["Мысық", "Арыстан", "Қасқыр"], correct: 0 },
      ],
      plants: [
        { q: "Алма — бұл не?", a: ["Көкөніс", "Жеміс", "Гүл"], correct: 1 },
        { q: "Өсімдікке не керек?", a: ["Су", "Телефон", "Шоколад"], correct: 0 },
        { q: "Гүл деген не?", a: ["Өсімдік", "Жануар", "Тас"], correct: 0 },
      ],
      seasons: [
        { q: "Қар қай мезгілде жауады?", a: ["Көктем", "Жаз", "Қыс"], correct: 2 },
        { q: "Жапырақ қашан түседі?", a: ["Көктем", "Күз", "Қыс"], correct: 1 },
        { q: "Жазда күн қандай?", a: ["Ыстық", "Өте суық", "Қараңғы"], correct: 0 },
      ],
      family: [
        { q: "Әкенің әкесі — бұл кім?", a: ["Аға", "Ата", "Іні"], correct: 1 },
        { q: "Отбасы мүшесін таңда:", a: ["Әке", "Бұлт", "Қалам"], correct: 0 },
        { q: "Ана деген кім?", a: ["Туған ана", "Мұғалім", "Дәрігер"], correct: 0 },
      ],
    },
    2: {
      weather: [
        { q: "Жаңбыр неден жауады?", a: ["Күннен", "Бұлттан", "Жерден"], correct: 1 },
        { q: "Жел деген не?", a: ["Ауаның қозғалысы", "Судың қозғалысы", "Тастың қозғалысы"], correct: 0 },
        { q: "Ауа райын немен білеміз?", a: ["Болжау", "Кітап", "Сағат"], correct: 0 },
      ],
      water: [
        { q: "Теңіз суы қандай?", a: ["Тәтті", "Тұзды"], correct: 1 },
        { q: "Өзен деген не?", a: ["Ағын су", "Тұрақты су", "Құрғақ жер"], correct: 0 },
        { q: "Көл деген не?", a: ["Тұрақты су", "Ағын су", "Тау"], correct: 0 },
      ],
      safety: [
        { q: "Қызыл шам — не істейміз?", a: ["Жүреміз", "Тоқтаймыз", "Жүгіреміз"], correct: 1 },
        { q: "Жолдан өтуге не керек?", a: ["Бағдаршам", "Доп", "Қалам"], correct: 0 },
        { q: "Үйде электрге жақындау дұрыс па?", a: ["Жоқ", "Иә", "Білмеймін"], correct: 0 },
      ],
      nature: [
        { q: "Табиғатты қалай қорғаймыз?", a: ["Қоқыс тастаймыз", "Ағаш отырғызамыз"], correct: 1 },
        { q: "Табиғат байлығы деген не?", a: ["Су, ауа, жер", "Телефон", "Ойын"], correct: 0 },
        { q: "Үнемдеу деген не?", a: ["Аз жұмсау", "Көп жұмсау", "Тастау"], correct: 0 },
      ],
    },
    3: {
      body: [
        { q: "Жүрек не істейді?", a: ["Ойлайды", "Қан айдайды", "Тыныс алады"], correct: 1 },
        { q: "Өкпе не істейді?", a: ["Тыныс алады", "Ас қорытады"], correct: 0 },
        { q: "Ми не үшін керек?", a: ["Ойлау үшін", "Ұшу үшін", "Жүзу үшін"], correct: 0 },
      ],
      health: [
        { q: "Күніне неше сағат ұйықтау керек?", a: ["4-5", "8-10", "12-14"], correct: 1 },
        { q: "Денсаулыққа пайдалы не?", a: ["Ұйқы", "Көп тәтті", "Көп газировка"], correct: 0 },
        { q: "Су ішу неге керек?", a: ["Дене үшін", "Телефон үшін", "Кітап үшін"], correct: 0 },
      ],
      senses: [
        { q: "Немен көреміз?", a: ["Құлақпен", "Көзбен", "Мұрынмен"], correct: 1 },
        { q: "Немен естиміз?", a: ["Көзбен", "Құлақпен", "Тілмен"], correct: 1 },
        { q: "Немен иіс сеземіз?", a: ["Мұрынмен", "Көзбен", "Құлақпен"], correct: 0 },
      ],
      society: [
        { q: "Кім емдейді?", a: ["Мұғалім", "Дәрігер", "Полиция"], correct: 1 },
        { q: "Мектепте кім оқытады?", a: ["Дәрігер", "Мұғалім", "Аспаз"], correct: 1 },
        { q: "Өрт сөндіруші не істейді?", a: ["Өрт сөндіреді", "Емдейді", "Оқытады"], correct: 0 },
      ],
    },
    4: {
      ecology: [
        { q: "Пластик бөтелкені қайда тастаймыз?", a: ["Қағаз контейнеріне", "Пластик контейнеріне"], correct: 1 },
        { q: "Қоқысты бөлу не үшін?", a: ["Қайта өңдеу үшін", "Ойын үшін", "Жасыру үшін"], correct: 0 },
        { q: "Экология деген не?", a: ["Табиғатты қорғау", "Ойын", "Ән"], correct: 0 },
      ],
      protect: [
        { q: "Қызыл кітапта не жазылған?", a: ["Барлық жануарлар", "Сирек жануарлар"], correct: 1 },
        { q: "Қорық деген не?", a: ["Қорғалатын аумақ", "Дүкен", "Мектеп"], correct: 0 },
        { q: "Ағаш не үшін керек?", a: ["Оттегі үшін", "Ойын үшін", "Ән үшін"], correct: 0 },
      ],
      kzNature: [
        { q: "Қазақстанның ең үлкен көлі?", a: ["Балқаш", "Каспий", "Арал"], correct: 1 },
        { q: "Қазақстанда қандай тау бар?", a: ["Алатау", "Эверест", "Альпі"], correct: 0 },
        { q: "Сайғақ қайда тұрады?", a: ["Қазақстанда", "Африкада", "Австралияда"], correct: 0 },
      ],
      space: [
        { q: "Күн — бұл не?", a: ["Планета", "Жұлдыз", "Серік"], correct: 1 },
        { q: "Ай — Жердің несі?", a: ["Жұлдызы", "Серігі", "Күні"], correct: 1 },
        { q: "Жер — бұл не?", a: ["Планета", "Жұлдыз", "Серік"], correct: 0 },
      ],
    },
  },

  history: {
    1: {
      family: [
        { q: "Отбасының ең үлкен мүшесі?", a: ["Іні", "Ата", "Аға"], correct: 1 },
        { q: "Отбасы мүшесін таңда:", a: ["Әке", "Бұлт", "Қалам"], correct: 0 },
        { q: "Ана деген кім?", a: ["Туған ана", "Мұғалім", "Дәрігер"], correct: 0 },
      ],
      time: [
        { q: "Бүгіннен кейінгі күн?", a: ["Кеше", "Ертең", "Апта"], correct: 1 },
        { q: "Кеше деген қай уақыт?", a: ["Өткен күн", "Келесі күн", "Қазір"], correct: 0 },
        { q: "Апта күндері нешеу?", a: ["5", "7", "10"], correct: 1 },
      ],
      homeland: [
        { q: "Туған жер дегеніміз не?", a: ["Барлық елдер", "Сен туған жер", "Мектеп"], correct: 1 },
        { q: "Қалада не бар?", a: ["Үйлер", "Тек теңіз", "Тек орман"], correct: 0 },
        { q: "Ауылда не болуы мүмкін?", a: ["Ферма", "Метро ғана", "Тек биік үйлер"], correct: 0 },
      ],
      holidays: [
        { q: "Наурыз қашан?", a: ["1 қаңтар", "22 наурыз", "9 мамыр"], correct: 1 },
        { q: "Жаңа жыл қашан?", a: ["1 қаңтар", "22 наурыз", "16 желтоқсан"], correct: 0 },
        { q: "Туған күн деген не?", a: ["Сенің мерекең", "Ел мерекесі", "Апта күні"], correct: 0 },
      ],
    },
    2: {
      kzMap: [
        { q: "Қазақстанның астанасы?", a: ["Алматы", "Астана", "Шымкент"], correct: 1 },
        { q: "Қазақстанда неше облыс?", a: ["10", "17", "25"], correct: 1 },
        { q: "Ең үлкен қала?", a: ["Астана", "Алматы", "Қарағанды"], correct: 1 },
      ],
      symbols: [
        { q: "Қазақстан туының түсі?", a: ["Қызыл", "Көк", "Жасыл"], correct: 1 },
        { q: "Елтаңбада не бейнеленген?", a: ["Арыстан", "Шаңырақ", "Жұлдыз"], correct: 1 },
        { q: "Әнұран деген не?", a: ["Мемлекеттік ән", "Мультфильм", "Жарнама"], correct: 0 },
      ],
      traditions: [
        { q: "Тұсау кесу қашан өткізіледі?", a: ["Бала туғанда", "Бала жүргенде", "Мектепке барғанда"], correct: 1 },
        { q: "Қонаққа не істейміз?", a: ["Құрмет көрсетеміз", "Елемейміз", "Ұрысамыз"], correct: 0 },
        { q: "Дәстүр деген не?", a: ["Әдет-ғұрып", "Компьютер", "Карта"], correct: 0 },
      ],
      clothes: [
        { q: "Шапан — кімнің киімі?", a: ["Әйелдің", "Ер адамның", "Баланың"], correct: 1 },
        { q: "Камзол — кімнің киімі?", a: ["Әйелдің", "Ер адамның", "Баланың"], correct: 0 },
        { q: "Тақия деген не?", a: ["Бас киім", "Аяқ киім", "Қол киім"], correct: 0 },
      ],
    },
    3: {
      ancient: [
        { q: "Сақтар қалай өмір сүрген?", a: ["Қалада", "Көшіп жүрген"], correct: 1 },
        { q: "Көшпенді деген кім?", a: ["Көшіп жүрген адам", "Қалада тұрған", "Теңізші"], correct: 0 },
        { q: "Түркілер кім?", a: ["Ежелгі халық", "Қазіргі ел", "Ойын"], correct: 0 },
      ],
      khanate: [
        { q: "Қазақ хандығы қашан құрылды?", a: ["1465", "1991", "1861"], correct: 0 },
        { q: "Алғашқы хандар кім?", a: ["Керей мен Жәнібек", "Абай мен Шоқан", "Ыбырай мен Алтынсарин"], correct: 0 },
        { q: "Жүз деген не?", a: ["Халық бөлігі", "Сан", "Қала"], correct: 0 },
      ],
      people: [
        { q: "Абай кім болған?", a: ["Хан", "Ақын", "Ғалым"], correct: 1 },
        { q: "Абылай хан кім?", a: ["Қолбасшы", "Ақын", "Суретші"], correct: 0 },
        { q: "Ыбырай Алтынсарин кім?", a: ["Ағартушы", "Хан", "Батыр"], correct: 0 },
      ],
      independence: [
        { q: "Тәуелсіздік күні қашан?", a: ["1 қаңтар", "16 желтоқсан", "22 наурыз"], correct: 1 },
        { q: "Қазақстан қашан тәуелсіз болды?", a: ["1991", "1465", "2000"], correct: 0 },
        { q: "Тәуелсіздік деген не?", a: ["Өз алдына ел болу", "Ойын", "Мереке"], correct: 0 },
      ],
    },
    4: {
      civilizations: [
        { q: "Пирамидалар қай елде?", a: ["Грекия", "Египет", "Рим"], correct: 1 },
        { q: "Ұлы қорған қай елде?", a: ["Египет", "Рим", "Қытай"], correct: 2 },
        { q: "Өркениет деген не?", a: ["Ежелгі қоғам мәдениеті", "Бір ойын", "Бір түс"], correct: 0 },
      ],
      silkroad: [
        { q: "Жібек жолы нені байланыстырды?", a: ["Солтүстік-Оңтүстік", "Шығыс-Батыс"], correct: 1 },
        { q: "Жібек жолы арқылы не тасылды?", a: ["Жібек, дәрі", "Тек тас", "Тек су"], correct: 0 },
        { q: "Жібек жолы қай елден өтті?", a: ["Қазақстан", "Австралия", "Антарктида"], correct: 0 },
      ],
      timeline: [
        { q: "1 ғасырда неше жыл?", a: ["10", "100", "1000"], correct: 1 },
        { q: "Уақыт сызығы не үшін?", a: ["Оқиғаларды реттеу үшін", "Сурет салу үшін", "Ойнау үшін"], correct: 0 },
        { q: "Хронология деген не?", a: ["Уақыт реті", "Түс", "Дәм"], correct: 0 },
      ],
      worldHolidays: [
        { q: "Балалар күні қашан?", a: ["1 қаңтар", "1 маусым", "1 қыркүйек"], correct: 1 },
        { q: "Бейбітшілік күні қашан?", a: ["21 қыркүйек", "1 қаңтар", "22 наурыз"], correct: 0 },
        { q: "Адам құқықтары күні қашан?", a: ["10 желтоқсан", "1 қаңтар", "9 мамыр"], correct: 0 },
      ],
    },
  },
};

// ===== School Materials (1–4 класс) =====
const SCHOOL = {
  math: {
    name: "Математика",
    classes: {
      1: [
        lesson("Сандар 1–20", [
          step("1–5 санау", "Саусақпен 1-ден 5-ке дейін көрсет.", "Сан 1"),
          step("6–10 санау", "Екі қолмен 6-дан 10-ға дейін көрсет.", "Сан 6"),
          step("11–15 санау", "Он бір, он екі... деп сана.", "Сан 10"),
          step("16–20 санау", "Он алты, он жеті... деп сана.", "Сан 10"),
        ], QUIZ_BANK.math[1].numbers),
        lesson("Қосу (+)", [
          step("Қосу белгісі", "+ белгісі екі санды біріктіреді.", "Плюс"),
          step("1+1, 2+1", "Қарапайым қосу мысалдары.", "Плюс"),
          step("5+5=10", "Он шығару мысалы.", "Плюс"),
          step("Есеп шығару", "Алма + алма = неше алма?", "Плюс"),
        ], QUIZ_BANK.math[1].plusminus),
        lesson("Азайту (−)", [
          step("Азайту белгісі", "− белгісі санды кемітеді.", "Минус"),
          step("5−2=3", "Бестен екіні алсақ — үш.", "Минус"),
          step("10−5=5", "Оннан бесті алсақ — бес.", "Минус"),
        ], QUIZ_BANK.math[1].minus),
        lesson("Салыстыру (>, <, =)", [
          step("Үлкен белгісі >", "5 > 3 — бес үштен үлкен.", "Үлкен"),
          step("Кіші белгісі <", "2 < 7 — екі жетіден кіші.", "Кіші"),
          step("Тең белгісі =", "4 = 4 — төрт төртке тең.", "Тең"),
        ], QUIZ_BANK.math[1].compare),
      ],
      2: [
        lesson("Көбейту негіздері", [
          step("Көбейту белгісі ×", "× белгісі қайталап қосуды білдіреді.", "Көбейту"),
          step("2×3=6", "Екіні үш рет қоссақ — алты.", "Көбейту"),
          step("Кесте 2", "2×1=2, 2×2=4, 2×3=6...", "Сан 2"),
          step("Кесте 5", "5×1=5, 5×2=10, 5×3=15...", "Сан 5"),
        ], QUIZ_BANK.math[2].multiply),
        lesson("Бөлу негіздері", [
          step("Бөлу белгісі ÷", "÷ белгісі бөлуді білдіреді.", "Бөлу"),
          step("6÷2=3", "Алтыны екіге бөлсек — үш.", "Бөлу"),
          step("10÷5=2", "Онды беске бөлсек — екі.", "Бөлу"),
        ], QUIZ_BANK.math[2].divide),
        lesson("Уақыт және сағат", [
          step("Сағат циферблаты", "12 сан, 2 тілше.", "Сағат"),
          step("Сағат оқу", "Үлкен тілше — минут, кіші — сағат.", "Сағат"),
          step("Жарты сағат", "30 минут = жарты сағат.", "Уақыт"),
        ], QUIZ_BANK.math[2].time),
        lesson("Өлшем бірліктері", [
          step("Сантиметр (см)", "Сызғышпен өлшейміз.", "Өлшем"),
          step("Метр (м)", "1 м = 100 см.", "Өлшем"),
          step("Килограмм (кг)", "Салмақ өлшемі.", "Салмақ"),
        ], QUIZ_BANK.math[2].measure),
      ],
      3: [
        lesson("Көптаңбалы сандар", [
          step("Жүздік", "100, 200, 300... — жүздіктер.", "Сан 100"),
          step("Үш таңбалы сан", "245 = 2 жүз + 4 он + 5 бірлік.", "Сан"),
          step("Баған қосу", "Бірлік, ондық, жүздік бағанмен.", "Плюс"),
          step("Баған азайту", "Қарыз алу әдісі.", "Минус"),
        ], QUIZ_BANK.math[3].bigNumbers),
        lesson("Бөлшектер", [
          step("Бөлшек дегеніміз", "Бүтінді бөліктерге бөлу.", "Бөлшек"),
          step("1/2 — жартысы", "Екіге бөлгенде бір бөлік.", "Бөлшек"),
          step("1/4 — ширегі", "Төртке бөлгенде бір бөлік.", "Бөлшек"),
          step("Бөлшек салыстыру", "1/2 > 1/4.", "Үлкен"),
        ], QUIZ_BANK.math[3].fractions),
        lesson("Есептер шығару", [
          step("Есеп оқу", "Не берілген? Не табу керек?", "Есеп"),
          step("Амал таңдау", "Қосу, азайту, көбейту, бөлу.", "Амал"),
          step("Шешу және тексеру", "Жауапты тексер.", "Тексеру"),
        ], QUIZ_BANK.math[3].problems),
        lesson("Геометриялық фигуралар", [
          step("Шаршы", "4 қабырғасы тең.", "Шаршы"),
          step("Тіктөртбұрыш", "Қарама-қарсы қабырғалар тең.", "Тіктөртбұрыш"),
          step("Үшбұрыш", "3 қабырғасы бар.", "Үшбұрыш"),
          step("Шеңбер", "Дөңгелек сызық.", "Шеңбер"),
        ], QUIZ_BANK.math[3].shapes),
      ],
      4: [
        lesson("Теңдеулер", [
          step("Белгісіз x", "x — табу керек сан.", "Теңдеу"),
          step("x + 5 = 12", "x = 12 - 5 = 7.", "Теңдеу"),
          step("x × 3 = 15", "x = 15 ÷ 3 = 5.", "Теңдеу"),
          step("Тексеру", "x-ті орнына қойып тексер.", "Тексеру"),
        ], QUIZ_BANK.math[4].equations),
        lesson("Периметр және аудан", [
          step("Периметр", "Барлық қабырғаларды қос.", "Периметр"),
          step("Шаршы периметрі", "P = 4 × a.", "Периметр"),
          step("Аудан", "Ішкі бетінің өлшемі.", "Аудан"),
          step("Шаршы ауданы", "S = a × a.", "Аудан"),
        ], QUIZ_BANK.math[4].perimeter),
        lesson("Бөлшектермен амалдар", [
          step("Бөлшек қосу", "1/4 + 1/4 = 2/4 = 1/2.", "Бөлшек"),
          step("Бөлшек азайту", "3/4 - 1/4 = 2/4.", "Бөлшек"),
          step("Аралас сан", "1 бүтін 1/2 = 3/2.", "Бөлшек"),
        ], QUIZ_BANK.math[4].fracOps),
        lesson("Көпорынды сандар", [
          step("Мың", "1000 — мың.", "Сан 1000"),
          step("Мыңдық оқу", "3456 = 3 мың 4 жүз 5 он 6.", "Сан"),
          step("Үлкен сандар қосу", "Баған әдісі.", "Плюс"),
          step("Дөңгелектеу", "3456 ≈ 3500.", "Дөңгелектеу"),
        ], QUIZ_BANK.math[4].thousands),
      ],
    }
  },

  ru: {
    name: "Орыс тілі",
    classes: {
      1: [
        lesson("Әріптер мен дыбыстар", [
          step("Дауысты дыбыстар", "А, О, У, Ы, И, Э — дауысты.", "Дауысты"),
          step("Дауыссыз дыбыстар", "Б, В, Г, Д... — дауыссыз.", "Дауыссыз"),
          step("Әріп жазу", "Үлкен және кіші әріптер.", "Әріп"),
          step("Дыбыс санау", "Сөздегі дыбыстарды сана.", "Дыбыс"),
        ], QUIZ_BANK.ru[1].letters),
        lesson("Буындар", [
          step("Буын дегеніміз", "Бір дауыстыға бір буын.", "Буын"),
          step("Ма-ма", "2 буын: ма + ма.", "Буын"),
          step("Мо-ло-ко", "3 буын: мо + ло + ко.", "Буын"),
        ], QUIZ_BANK.ru[1].syllables),
        lesson("Алғашқы сөздер", [
          step("Зат атаулары", "Мама, папа, дом, кот.", "Сөз"),
          step("Сөз оқу", "Әріптерді біріктіріп оқы.", "Оқу"),
          step("Сөз жазу", "Естігенді жаз.", "Жазу"),
        ], QUIZ_BANK.ru[1].words),
        lesson("Сөйлем бастамасы", [
          step("Сөйлем дегеніміз", "Аяқталған ой.", "Сөйлем"),
          step("Бас әріп", "Сөйлем бас әріптен басталады.", "Бас әріп"),
          step("Нүкте", "Сөйлем соңында нүкте қойылады.", "Нүкте"),
        ], QUIZ_BANK.ru[1].sentence),
      ],
      2: [
        lesson("Сөз таптары", [
          step("Зат есім", "Кім? Не? — мама, стол.", "Зат есім"),
          step("Сын есім", "Қандай? — красный, большой.", "Сын есім"),
          step("Етістік", "Не істейді? — бегает, читает.", "Етістік"),
        ], QUIZ_BANK.ru[2].parts),
        lesson("Синоним және антоним", [
          step("Синоним", "Мағынасы ұқсас сөздер.", "Синоним"),
          step("Антоним", "Қарама-қарсы мағыналы сөздер.", "Антоним"),
          step("Мысалдар", "Большой-маленький, хороший-плохой.", "Сөз"),
        ], QUIZ_BANK.ru[2].synonyms),
        lesson("Сөйлем құрау", [
          step("Бастауыш", "Кім? Не? — сөйлемнің иесі.", "Бастауыш"),
          step("Баяндауыш", "Не істейді? — іс-әрекет.", "Баяндауыш"),
          step("Сөйлем жазу", "Бастауыш + баяндауыш.", "Сөйлем"),
        ], QUIZ_BANK.ru[2].sentBuild),
        lesson("Көпше түр", [
          step("Жекеше", "Бір зат: кот, дом.", "Жекеше"),
          step("Көпше", "Көп зат: коты, дома.", "Көпше"),
          step("Ережелер", "-ы, -и, -а жалғаулары.", "Ереже"),
        ], QUIZ_BANK.ru[2].plural),
      ],
      3: [
        lesson("Сөйлем мүшелері", [
          step("Бастауыш", "Сөйлемнің басты мүшесі.", "Бастауыш"),
          step("Баяндауыш", "Не істейді?", "Баяндауыш"),
          step("Толықтауыш", "Кімге? Нені?", "Толықтауыш"),
          step("Анықтауыш", "Қандай?", "Анықтауыш"),
        ], QUIZ_BANK.ru[3].members),
        lesson("Тыныс белгілері", [
          step("Нүкте", "Хабарлы сөйлем соңында.", "Нүкте"),
          step("Сұрақ белгісі", "Сұраулы сөйлем соңында.", "Сұрақ"),
          step("Леп белгісі", "Лепті сөйлем соңында.", "Леп"),
          step("Үтір", "Тізім, қаратпа сөз.", "Үтір"),
        ], QUIZ_BANK.ru[3].punctuation),
        lesson("Түбір және жұрнақ", [
          step("Түбір", "Сөздің негізгі бөлігі.", "Түбір"),
          step("Жұрнақ", "Түбірден кейін жалғанады.", "Жұрнақ"),
          step("Жалғау", "Сөз соңындағы бөлік.", "Жалғау"),
        ], QUIZ_BANK.ru[3].roots),
        lesson("Мәтін оқу", [
          step("Тақырып", "Мәтін не туралы?", "Тақырып"),
          step("Негізгі ой", "Автор не айтқысы келеді?", "Негізгі ой"),
          step("Сұрақтарға жауап", "Мәтін бойынша жауап бер.", "Жауап"),
        ], QUIZ_BANK.ru[3].reading),
      ],
      4: [
        lesson("Мәтін жазу", [
          step("Жоспар құру", "Кіріспе, негізгі, қорытынды.", "Жоспар"),
          step("Кіріспе", "Тақырыпты таныстыру.", "Кіріспе"),
          step("Негізгі бөлім", "Ойды ашу.", "Негізгі"),
          step("Қорытынды", "Ойды аяқтау.", "Қорытынды"),
        ], QUIZ_BANK.ru[4].writing),
        lesson("Мазмұндама", [
          step("Мәтінді оқу", "Мұқият оқып түсін.", "Оқу"),
          step("Жоспар жасау", "Негізгі оқиғаларды жаз.", "Жоспар"),
          step("Өз сөзіңмен жазу", "Мағынасын сақтап жаз.", "Жазу"),
        ], QUIZ_BANK.ru[4].summary),
        lesson("Сөздік жұмыс", [
          step("Жаңа сөздер", "Түсініксіз сөздерді үйрен.", "Сөздік"),
          step("Сөздікпен жұмыс", "Мағынасын тап.", "Сөздік"),
          step("Сөйлемде қолдану", "Жаңа сөзбен сөйлем құра.", "Сөйлем"),
        ], QUIZ_BANK.ru[4].vocabulary),
        lesson("Шығарма жазу", [
          step("Тақырып таңдау", "Не туралы жазасың?", "Тақырып"),
          step("Ойларды жинау", "Не айтқың келеді?", "Ой"),
          step("Жазу", "Сөйлемдерді байланыстыр.", "Жазу"),
          step("Тексеру", "Қателерді түзет.", "Тексеру"),
        ], QUIZ_BANK.ru[4].essay),
      ],
    }
  },

  world: {
    name: "Қоршаған орта",
    classes: {
      1: [
        lesson("Жануарлар әлемі", [
          step("Үй жануарлары", "Ит, мысық, сиыр, жылқы.", "Жануар"),
          step("Жабайы жануарлар", "Арыстан, аю, қасқыр.", "Жануар"),
          step("Құстар", "Торғай, қарға, бүркіт.", "Құс"),
          step("Жәндіктер", "Көбелек, ара, құмырсқа.", "Жәндік"),
        ], QUIZ_BANK.world[1].animals),
        lesson("Өсімдіктер", [
          step("Ағаштар", "Алма ағашы, қайың, емен.", "Ағаш"),
          step("Гүлдер", "Раушан, қызғалдақ, бәйшешек.", "Гүл"),
          step("Көкөністер", "Сәбіз, қияр, қызанақ.", "Көкөніс"),
          step("Жемістер", "Алма, алмұрт, жүзім.", "Жеміс"),
        ], QUIZ_BANK.world[1].plants),
        lesson("Жыл мезгілдері", [
          step("Көктем", "Қар ериді, гүлдер ашылады.", "Көктем"),
          step("Жаз", "Жылы, күн ұзақ.", "Жаз"),
          step("Күз", "Жапырақ түседі, салқын.", "Күз"),
          step("Қыс", "Қар жауады, суық.", "Қыс"),
        ], QUIZ_BANK.world[1].seasons),
        lesson("Менің отбасым", [
          step("Ата-ана", "Әке, ана — ең жақындар.", "Отбасы"),
          step("Аға-апа, іні-қарындас", "Бауырлар.", "Отбасы"),
          step("Ата-әже", "Үлкендер, тәжірибелі.", "Отбасы"),
        ], QUIZ_BANK.world[1].family),
      ],
      2: [
        lesson("Ауа райы", [
          step("Күн", "Жарық, жылы.", "Күн"),
          step("Жаңбыр", "Бұлттан су тамады.", "Жаңбыр"),
          step("Қар", "Суық, ақ.", "Қар"),
          step("Жел", "Ауа қозғалысы.", "Жел"),
        ], QUIZ_BANK.world[2].weather),
        lesson("Су және жер", [
          step("Өзен", "Ағын су.", "Өзен"),
          step("Көл", "Тұрақты су.", "Көл"),
          step("Теңіз", "Үлкен, тұзды су.", "Теңіз"),
          step("Тау", "Биік жер бедері.", "Тау"),
        ], QUIZ_BANK.world[2].water),
        lesson("Қауіпсіздік ережелері", [
          step("Жол қауіпсіздігі", "Бағдаршам, жаяу жүргінші.", "Жол"),
          step("Өрт қауіпсіздігі", "Оттан сақтан.", "Өрт"),
          step("Үйдегі қауіпсіздік", "Ток, газ, су.", "Үй"),
        ], QUIZ_BANK.world[2].safety),
        lesson("Адам және табиғат", [
          step("Табиғат байлығы", "Су, ауа, жер.", "Табиғат"),
          step("Табиғатты қорғау", "Қоқыс тастама, ағаш отырғыз.", "Қорғау"),
          step("Үнемдеу", "Су, электр үнемде.", "Үнемдеу"),
        ], QUIZ_BANK.world[2].nature),
      ],
      3: [
        lesson("Адам денесі", [
          step("Бас", "Ми, көз, құлақ, мұрын, ауыз.", "Бас"),
          step("Дене", "Жүрек, өкпе, асқазан.", "Дене"),
          step("Қол-аяқ", "Қимыл мүшелері.", "Қол"),
          step("Сүйек", "Дене қаңқасы.", "Сүйек"),
        ], QUIZ_BANK.world[3].body),
        lesson("Денсаулық", [
          step("Дұрыс тамақтану", "Көкөніс, жеміс, сүт.", "Тамақ"),
          step("Ұйқы", "8-10 сағат ұйықта.", "Ұйқы"),
          step("Спорт", "Қозғал, жүгір, ойна.", "Спорт"),
          step("Тазалық", "Қол жу, тіс тазала.", "Тазалық"),
        ], QUIZ_BANK.world[3].health),
        lesson("Сезім мүшелері", [
          step("Көз — көру", "Түстерді, заттарды көреміз.", "Көз"),
          step("Құлақ — есту", "Дыбыстарды естиміз.", "Құлақ"),
          step("Мұрын — иіс", "Иістерді сеземіз.", "Мұрын"),
          step("Тіл — дәм", "Тәтті, ащы, тұзды.", "Тіл"),
        ], QUIZ_BANK.world[3].senses),
        lesson("Қоғам", [
          step("Мектеп", "Оқу орны.", "Мектеп"),
          step("Дәрігер", "Емдейді.", "Дәрігер"),
          step("Полиция", "Қорғайды.", "Полиция"),
          step("Өртсөндіруші", "Өрт сөндіреді.", "Өртсөндіруші"),
        ], QUIZ_BANK.world[3].society),
      ],
      4: [
        lesson("Экология", [
          step("Экология дегеніміз", "Табиғат туралы ғылым.", "Экология"),
          step("Ластану", "Ауа, су, жер ластануы.", "Ластану"),
          step("Қоқыс сұрыптау", "Пластик, қағаз, шыны.", "Сұрыптау"),
          step("Қайта өңдеу", "Қоқыстан жаңа зат.", "Өңдеу"),
        ], QUIZ_BANK.world[4].ecology),
        lesson("Табиғатты қорғау", [
          step("Қызыл кітап", "Сирек жануарлар тізімі.", "Қызыл кітап"),
          step("Қорық", "Қорғалатын аумақ.", "Қорық"),
          step("Ағаш отырғызу", "Оттегі көзі.", "Ағаш"),
          step("Су үнемдеу", "Суды бекер ағызба.", "Су"),
        ], QUIZ_BANK.world[4].protect),
        lesson("Қазақстан табиғаты", [
          step("Дала", "Кең жазық жер.", "Дала"),
          step("Тау", "Алатау, Алтай.", "Тау"),
          step("Өзен-көл", "Ертіс, Балқаш, Каспий.", "Өзен"),
          step("Жануарлар", "Арқар, сайғақ, бүркіт.", "Жануар"),
        ], QUIZ_BANK.world[4].kzNature),
        lesson("Ғарыш", [
          step("Күн", "Жұлдыз, жылу көзі.", "Күн"),
          step("Жер", "Біздің планета.", "Жер"),
          step("Ай", "Жердің серігі.", "Ай"),
          step("Жұлдыздар", "Алыстағы күндер.", "Жұлдыз"),
        ], QUIZ_BANK.world[4].space),
      ],
    }
  },

  history: {
    name: "Тарих",
    classes: {
      1: [
        lesson("Менің отбасым", [
          step("Отбасы мүшелері", "Әке, ана, аға, апа.", "Отбасы"),
          step("Отбасы тарихы", "Ата-әже қайдан келген?", "Тарих"),
          step("Отбасы дәстүрі", "Мерекелер, тамақтар.", "Дәстүр"),
        ], QUIZ_BANK.history[1].family),
        lesson("Уақыт түсінігі", [
          step("Кеше", "Өткен күн.", "Кеше"),
          step("Бүгін", "Қазіргі күн.", "Бүгін"),
          step("Ертең", "Келесі күн.", "Ертең"),
          step("Апта күндері", "Дүйсенбі, сейсенбі...", "Апта"),
        ], QUIZ_BANK.history[1].time),
        lesson("Туған жер", [
          step("Менің қалам/ауылым", "Қайда тұрасың?", "Қала"),
          step("Көше, үй", "Мекенжай.", "Мекенжай"),
          step("Туған жер тарихы", "Қашан пайда болған?", "Тарих"),
        ], QUIZ_BANK.history[1].homeland),
        lesson("Мерекелер", [
          step("Жаңа жыл", "1 қаңтар.", "Мереке"),
          step("Наурыз", "22 наурыз — көктем мерекесі.", "Наурыз"),
          step("Туған күн", "Сенің мерекең.", "Туған күн"),
        ], QUIZ_BANK.history[1].holidays),
      ],
      2: [
        lesson("Қазақстан — менің елім", [
          step("Қазақстан картасы", "Үлкен ел, көп облыс.", "Карта"),
          step("Астана", "Елордамыз.", "Астана"),
          step("Алматы", "Ең үлкен қала.", "Алматы"),
          step("Облыстар", "17 облыс бар.", "Облыс"),
        ], QUIZ_BANK.history[2].kzMap),
        lesson("Мемлекеттік рәміздер", [
          step("Ту", "Көк түс, күн, бүркіт.", "Ту"),
          step("Елтаңба", "Шаңырақ, тұлпарлар.", "Елтаңба"),
          step("Әнұран", "Мемлекеттік ән.", "Әнұран"),
        ], QUIZ_BANK.history[2].symbols),
        lesson("Қазақ дәстүрлері", [
          step("Қонақжайлық", "Қонақты құрметтеу.", "Дәстүр"),
          step("Бесік той", "Нәрестені бесікке салу.", "Той"),
          step("Тұсау кесу", "Бала жүргенде.", "Той"),
          step("Наурыз дастарханы", "Наурыз көже, бауырсақ.", "Тамақ"),
        ], QUIZ_BANK.history[2].traditions),
        lesson("Ұлттық киім", [
          step("Шапан", "Ер адам киімі.", "Киім"),
          step("Камзол", "Әйел киімі.", "Киім"),
          step("Тақия, бөрік", "Бас киім.", "Бас киім"),
          step("Саптама етік", "Аяқ киім.", "Аяқ киім"),
        ], QUIZ_BANK.history[2].clothes),
      ],
      3: [
        lesson("Ежелгі Қазақстан", [
          step("Көшпенділер", "Мал өсірген, көшіп жүрген.", "Көшпенді"),
          step("Сақтар", "Ежелгі тайпа.", "Сақ"),
          step("Ғұндар", "Атты әскер.", "Ғұн"),
          step("Түркілер", "Түркі қағанаты.", "Түрік"),
        ], QUIZ_BANK.history[3].ancient),
        lesson("Қазақ хандығы", [
          step("Құрылуы", "1465 жыл.", "Хандық"),
          step("Керей мен Жәнібек", "Алғашқы хандар.", "Хан"),
          step("Жүздер", "Үлкен, Орта, Кіші жүз.", "Жүз"),
        ], QUIZ_BANK.history[3].khanate),
        lesson("Тарихи тұлғалар", [
          step("Абылай хан", "Ұлы қолбасшы.", "Абылай"),
          step("Абай Құнанбаев", "Ұлы ақын.", "Абай"),
          step("Ыбырай Алтынсарин", "Ағартушы.", "Ыбырай"),
          step("Шоқан Уәлиханов", "Ғалым, саяхатшы.", "Шоқан"),
        ], QUIZ_BANK.history[3].people),
        lesson("Тәуелсіздік", [
          step("1991 жыл", "Қазақстан тәуелсіз болды.", "Тәуелсіздік"),
          step("16 желтоқсан", "Тәуелсіздік күні.", "Мереке"),
          step("Тұңғыш Президент", "Н.Ә. Назарбаев.", "Президент"),
        ], QUIZ_BANK.history[3].independence),
      ],
      4: [
        lesson("Ежелгі өркениеттер", [
          step("Ежелгі Египет", "Пирамидалар, фараондар.", "Египет"),
          step("Ежелгі Грекия", "Демократия, философия.", "Грекия"),
          step("Ежелгі Рим", "Империя, заңдар.", "Рим"),
          step("Ежелгі Қытай", "Ұлы қорған, жібек жолы.", "Қытай"),
        ], QUIZ_BANK.history[4].civilizations),
        lesson("Ұлы Жібек жолы", [
          step("Сауда жолы", "Шығыс пен Батысты байланыстырған.", "Жібек жолы"),
          step("Қазақстан арқылы", "Маңызды бөлігі.", "Қазақстан"),
          step("Тауарлар", "Жібек, дәрі-дәрмек, асыл тастар.", "Сауда"),
          step("Қалалар", "Отырар, Тараз, Түркістан.", "Қала"),
        ], QUIZ_BANK.history[4].silkroad),
        lesson("Уақыт сызығы", [
          step("Ғасыр", "100 жыл.", "Ғасыр"),
          step("Мыңжылдық", "1000 жыл.", "Мыңжылдық"),
          step("Б.з.д. және б.з.", "Біздің заманға дейін/кейін.", "Заман"),
          step("Хронология", "Оқиғалар реті.", "Хронология"),
        ], QUIZ_BANK.history[4].timeline),
        lesson("Әлемдік мерекелер", [
          step("Жаңа жыл", "1 қаңтар — бүкіл әлемде.", "Жаңа жыл"),
          step("Балалар күні", "1 маусым.", "Балалар"),
          step("Бейбітшілік күні", "21 қыркүйек.", "Бейбітшілік"),
          step("Адам құқықтары күні", "10 желтоқсан.", "Құқық"),
        ], QUIZ_BANK.history[4].worldHolidays),
      ],
    }
  }
};

// helpers
function lesson(title, steps, quiz = []) {
  return { title, steps, quiz };
}
function step(name, desc, gesture, examples = []) {
  return { name, desc, gesture, examples };
}
function quizQ(question, options, correctIndex) {
  return { question, options, correctIndex };
}

// Gesture targeting integration
function setSchoolTargetGesture(gesture) {
  if (typeof window.setTargetGesture === "function") {
    window.setTargetGesture(gesture);
  } else {
    window.targetGesture = gesture;
  }
}

// ===== School UI State =====
let schoolCurrentSubject = null;
let schoolCurrentClass = null;
let schoolCurrentLessonIndex = null;
let schoolCurrentStepIndex = 0;

const schoolEls = {
  crumb: document.getElementById("schoolCrumb"),
  subjectGrid: document.getElementById("subjectGrid"),
  classPanel: document.getElementById("classPanel"),
  classGrid: document.getElementById("classGrid"),
  classTitle: document.getElementById("classTitle"),
  lessonPanel: document.getElementById("lessonPanel"),
  lessonList: document.getElementById("lessonList"),
  lessonTitle: document.getElementById("lessonTitle"),
  learnPanel: document.getElementById("learnPanel"),
  learnTitle: document.getElementById("learnTitle"),

  stepCounter: document.getElementById("stepCounter"),
  stepName: document.getElementById("stepName"),
  stepDesc: document.getElementById("stepDesc"),
  gesturePill: document.getElementById("gesturePill"),
  progressText: document.getElementById("progressText"),
  progressFill: document.getElementById("progressFill"),

  backToSubjects: document.getElementById("backToSubjects"),
  backToClasses: document.getElementById("backToClasses"),
  backToLessons: document.getElementById("backToLessons"),

  prevStep: document.getElementById("prevStep"),
  nextStep: document.getElementById("nextStep"),
  resetLesson: document.getElementById("resetLesson"),
};

function showSchoolPanel(panel) {
  schoolEls.classPanel.classList.add("hidden");
  schoolEls.lessonPanel.classList.add("hidden");
  schoolEls.learnPanel.classList.add("hidden");
  if (panel) panel.classList.remove("hidden");
}

function setSchoolCrumb(text) {
  if (schoolEls.crumb) schoolEls.crumb.textContent = text;
}

function schoolKeyProgress(subj, cls, lessonIdx) {
  return `school_progress_${subj}_${cls}_${lessonIdx}`;
}

function loadSchoolProgress(subj, cls, lessonIdx) {
  const raw = localStorage.getItem(schoolKeyProgress(subj, cls, lessonIdx));
  if (!raw) return 0;
  const n = Number(raw);
  return Number.isFinite(n) ? Math.max(0, Math.min(100, n)) : 0;
}

function saveSchoolProgress(subj, cls, lessonIdx, value) {
  localStorage.setItem(schoolKeyProgress(subj, cls, lessonIdx), String(value));
}

function loadSchoolQuizResult(subj, cls, lessonIdx) {
  const key = `school_quiz_${subj}_${cls}_${lessonIdx}`;
  const data = localStorage.getItem(key);
  if (!data) return null;
  try {
    return JSON.parse(data);
  } catch {
    return null;
  }
}

function renderSchoolClasses() {
  schoolEls.classGrid.innerHTML = "";
  for (let c = 1; c <= 4; c++) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.textContent = `${c} класс`;
    btn.addEventListener("click", () => openSchoolClass(c));
    schoolEls.classGrid.appendChild(btn);
  }
  schoolEls.classTitle.textContent = `${SCHOOL[schoolCurrentSubject].name} — класс таңдаңыз`;
}

function renderSchoolLessons() {
  const lessons = SCHOOL[schoolCurrentSubject].classes[schoolCurrentClass] || [];
  schoolEls.lessonList.innerHTML = "";

  lessons.forEach((L, idx) => {
    const div = document.createElement("div");
    div.className = "lesson-item";
    const p = loadSchoolProgress(schoolCurrentSubject, schoolCurrentClass, idx);
    const quizResult = loadSchoolQuizResult(schoolCurrentSubject, schoolCurrentClass, idx);
    
    let quizHtml = "";
    if (quizResult && quizResult.bestPercent !== undefined) {
      const passed = quizResult.bestPercent >= 50;
      quizHtml = `<div class="l-quiz ${passed ? 'passed' : ''}">Тест: ${quizResult.bestPercent}%</div>`;
    } else if (L.quiz && L.quiz.length > 0) {
      quizHtml = `<div class="l-quiz">Тест: өтілмеген</div>`;
    }
    
    div.innerHTML = `
      <div class="l-title">${L.title}</div>
      <div class="l-sub">Қадам: ${L.steps.length} • Прогресс: ${p}%</div>
      ${quizHtml}
    `;
    div.addEventListener("click", () => openSchoolLesson(idx));
    schoolEls.lessonList.appendChild(div);
  });

  schoolEls.lessonTitle.textContent = `${SCHOOL[schoolCurrentSubject].name} • ${schoolCurrentClass} класс — сабақтар`;
}

function renderSchoolStep() {
  const lesson = SCHOOL[schoolCurrentSubject].classes[schoolCurrentClass][schoolCurrentLessonIndex];
  const steps = lesson.steps;
  const s = steps[schoolCurrentStepIndex];

  schoolEls.learnTitle.textContent = `${lesson.title} (${SCHOOL[schoolCurrentSubject].name} • ${schoolCurrentClass} класс)`;
  schoolEls.stepCounter.textContent = `${schoolCurrentStepIndex + 1} / ${steps.length}`;
  schoolEls.stepName.textContent = s.name;
  schoolEls.stepDesc.textContent = s.desc;
  schoolEls.gesturePill.textContent = `Жест: ${s.gesture || "—"}`;

  // Set target gesture for hand-tracking integration
  if (s.gesture) {
    setSchoolTargetGesture(s.gesture);
  }

  const percent = Math.round(((schoolCurrentStepIndex) / Math.max(1, steps.length - 1)) * 100);
  schoolEls.progressText.textContent = `${percent}%`;
  schoolEls.progressFill.style.width = `${percent}%`;
  saveSchoolProgress(schoolCurrentSubject, schoolCurrentClass, schoolCurrentLessonIndex, percent);

  schoolEls.prevStep.disabled = schoolCurrentStepIndex === 0;
  schoolEls.nextStep.textContent = (schoolCurrentStepIndex === steps.length - 1) ? "Дайын ✅" : "Келесі →";
}

function openSchoolSubject(subj) {
  schoolCurrentSubject = subj;
  schoolCurrentClass = null;
  schoolCurrentLessonIndex = null;
  schoolCurrentStepIndex = 0;

  setSchoolCrumb(`${SCHOOL[subj].name} → класс`);
  renderSchoolClasses();
  showSchoolPanel(schoolEls.classPanel);
}

function openSchoolClass(cls) {
  schoolCurrentClass = cls;
  schoolCurrentLessonIndex = null;
  schoolCurrentStepIndex = 0;

  setSchoolCrumb(`${SCHOOL[schoolCurrentSubject].name} → ${cls} класс → сабақ`);
  renderSchoolLessons();
  showSchoolPanel(schoolEls.lessonPanel);
}

function openSchoolLesson(lessonIdx) {
  schoolCurrentLessonIndex = lessonIdx;
  schoolCurrentStepIndex = 0;

  setSchoolCrumb(`${SCHOOL[schoolCurrentSubject].name} → ${schoolCurrentClass} класс → ${SCHOOL[schoolCurrentSubject].classes[schoolCurrentClass][lessonIdx].title}`);
  showSchoolPanel(schoolEls.learnPanel);
  renderSchoolStep();
}

function resetSchoolLesson() {
  saveSchoolProgress(schoolCurrentSubject, schoolCurrentClass, schoolCurrentLessonIndex, 0);
  schoolCurrentStepIndex = 0;
  renderSchoolStep();
}

// ===== Wire School UI =====
if (schoolEls.subjectGrid) {
  schoolEls.subjectGrid.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-subject]");
    if (!btn) return;
    openSchoolSubject(btn.dataset.subject);
  });
}

schoolEls.backToSubjects?.addEventListener("click", () => {
  setSchoolCrumb("Пән таңдаңыз");
  showSchoolPanel(null);
  schoolEls.classPanel.classList.add("hidden");
  schoolEls.lessonPanel.classList.add("hidden");
  schoolEls.learnPanel.classList.add("hidden");
});

schoolEls.backToClasses?.addEventListener("click", () => {
  setSchoolCrumb(`${SCHOOL[schoolCurrentSubject].name} → класс`);
  showSchoolPanel(schoolEls.classPanel);
});

schoolEls.backToLessons?.addEventListener("click", () => {
  setSchoolCrumb(`${SCHOOL[schoolCurrentSubject].name} → ${schoolCurrentClass} класс → сабақ`);
  showSchoolPanel(schoolEls.lessonPanel);
  renderSchoolLessons();
});

schoolEls.prevStep?.addEventListener("click", () => {
  if (schoolCurrentStepIndex > 0) {
    schoolCurrentStepIndex--;
    renderSchoolStep();
  }
});

schoolEls.nextStep?.addEventListener("click", () => {
  const lesson = SCHOOL[schoolCurrentSubject].classes[schoolCurrentClass][schoolCurrentLessonIndex];
  if (schoolCurrentStepIndex < lesson.steps.length - 1) {
    schoolCurrentStepIndex++;
    renderSchoolStep();
  } else {
    // дайын
    schoolEls.progressText.textContent = "100%";
    schoolEls.progressFill.style.width = "100%";
    saveSchoolProgress(schoolCurrentSubject, schoolCurrentClass, schoolCurrentLessonIndex, 100);
    alert("Сабақ аяқталды ✅");
  }
});

schoolEls.resetLesson?.addEventListener("click", resetSchoolLesson);

// ===== Quiz Mode with Tabs =====
let schoolQuizIndex = 0;
let schoolQuizScore = 0;
let schoolQuizAnswers = [];
let schoolQuizSelectedAnswer = null;
let schoolQuizAnswered = false;

// Tab elements
const tabLearn = document.getElementById("tabLearn");
const tabQuiz = document.getElementById("tabQuiz");
const learnContent = document.getElementById("schoolLearnContent");
const quizContent = document.getElementById("schoolQuizContent");

// Quiz elements
const quizQuestionBox = document.getElementById("quizQuestionBox");
const quizResultBox = document.getElementById("quizResultBox");
const quizCounter = document.getElementById("quizCounter");
const quizScoreEl = document.getElementById("quizScore");
const quizQuestion = document.getElementById("quizQuestion");
const quizOptions = document.getElementById("quizOptions");
const quizFeedback = document.getElementById("quizFeedback");
const feedbackIcon = document.getElementById("feedbackIcon");
const feedbackText = document.getElementById("feedbackText");
const quizNextBtn = document.getElementById("quizNextBtn");

// Tab switching
function switchSchoolTab(tab) {
  if (tab === "learn") {
    tabLearn?.classList.add("active");
    tabQuiz?.classList.remove("active");
    learnContent?.classList.remove("hidden");
    quizContent?.classList.add("hidden");
  } else {
    tabLearn?.classList.remove("active");
    tabQuiz?.classList.add("active");
    learnContent?.classList.add("hidden");
    quizContent?.classList.remove("hidden");
    startSchoolQuiz();
  }
}

tabLearn?.addEventListener("click", () => switchSchoolTab("learn"));
tabQuiz?.addEventListener("click", () => switchSchoolTab("quiz"));

function startSchoolQuiz() {
  const lesson = SCHOOL[schoolCurrentSubject]?.classes[schoolCurrentClass]?.[schoolCurrentLessonIndex];
  if (!lesson?.quiz || lesson.quiz.length === 0) {
    quizQuestionBox?.classList.add("hidden");
    quizResultBox?.classList.remove("hidden");
    document.getElementById("resultEmoji").textContent = "📭";
    document.getElementById("resultTitle").textContent = "Тест жоқ";
    document.getElementById("resultTitle").className = "result-title";
    document.getElementById("resultScore").textContent = "Бұл сабақта тест әлі қосылмаған.";
    return;
  }
  
  schoolQuizIndex = 0;
  schoolQuizScore = 0;
  schoolQuizAnswers = [];
  schoolQuizSelectedAnswer = null;
  schoolQuizAnswered = false;
  
  quizQuestionBox?.classList.remove("hidden");
  quizResultBox?.classList.add("hidden");
  
  renderSchoolQuizQuestion();
}

function renderSchoolQuizQuestion() {
  const lesson = SCHOOL[schoolCurrentSubject].classes[schoolCurrentClass][schoolCurrentLessonIndex];
  const quiz = lesson.quiz;
  
  if (schoolQuizIndex >= quiz.length) {
    showSchoolQuizResult();
    return;
  }
  
  const qData = quiz[schoolQuizIndex];
  // Support both formats: {q, a, correct} and {question, options, correctIndex}
  const questionText = qData.q || qData.question;
  const options = qData.a || qData.options;
  
  schoolQuizSelectedAnswer = null;
  schoolQuizAnswered = false;
  
  // Update header
  if (quizCounter) quizCounter.textContent = `${schoolQuizIndex + 1} / ${quiz.length}`;
  if (quizScoreEl) quizScoreEl.textContent = `Ұпай: ${schoolQuizScore}`;
  
  // Update question
  if (quizQuestion) quizQuestion.textContent = questionText;
  
  // Render options
  if (quizOptions) {
    quizOptions.innerHTML = options.map((opt, i) => 
      `<button class="quiz-option" data-idx="${i}">${opt}</button>`
    ).join("");
    
    quizOptions.querySelectorAll(".quiz-option").forEach(btn => {
      btn.addEventListener("click", () => selectSchoolQuizAnswer(parseInt(btn.dataset.idx)));
    });
  }
  
  // Hide feedback
  quizFeedback?.classList.add("hidden");
  quizFeedback?.classList.remove("correct", "wrong");
  
  // Disable next button
  if (quizNextBtn) {
    quizNextBtn.disabled = true;
    quizNextBtn.textContent = "Келесі сұрақ →";
  }
}

function selectSchoolQuizAnswer(idx) {
  if (schoolQuizAnswered) return;
  
  const lesson = SCHOOL[schoolCurrentSubject].classes[schoolCurrentClass][schoolCurrentLessonIndex];
  const qData = lesson.quiz[schoolQuizIndex];
  // Support both formats: {q, a, correct} and {question, options, correctIndex}
  const correctIdx = qData.correct !== undefined ? qData.correct : qData.correctIndex;
  const options = qData.a || qData.options;
  const questionText = qData.q || qData.question;
  const isCorrect = idx === correctIdx;
  
  schoolQuizSelectedAnswer = idx;
  schoolQuizAnswered = true;
  
  if (isCorrect) schoolQuizScore++;
  schoolQuizAnswers.push({ question: questionText, selected: idx, correct: correctIdx, isCorrect });
  
  // Update options styling
  quizOptions?.querySelectorAll(".quiz-option").forEach((btn, i) => {
    btn.disabled = true;
    if (i === correctIdx) {
      btn.classList.add("correct");
    } else if (i === idx && !isCorrect) {
      btn.classList.add("wrong");
    }
    if (i === idx) {
      btn.classList.add("selected");
    }
  });
  
  // Show feedback
  if (quizFeedback) {
    quizFeedback.classList.remove("hidden");
    quizFeedback.classList.add(isCorrect ? "correct" : "wrong");
  }
  if (feedbackIcon) feedbackIcon.textContent = isCorrect ? "✅" : "❌";
  if (feedbackText) {
    feedbackText.textContent = isCorrect 
      ? "Дұрыс!" 
      : `Қате! Дұрыс жауап: ${options[correctIdx]}`;
  }
  
  // Enable next button
  if (quizNextBtn) {
    quizNextBtn.disabled = false;
    const isLast = schoolQuizIndex >= lesson.quiz.length - 1;
    quizNextBtn.textContent = isLast ? "Нәтижені көру →" : "Келесі сұрақ →";
  }
  
  // Update score display
  if (quizScoreEl) quizScoreEl.textContent = `Ұпай: ${schoolQuizScore}`;
}

function nextSchoolQuizQuestion() {
  schoolQuizIndex++;
  renderSchoolQuizQuestion();
}

function showSchoolQuizResult() {
  const lesson = SCHOOL[schoolCurrentSubject].classes[schoolCurrentClass][schoolCurrentLessonIndex];
  const total = lesson.quiz.length;
  const percent = Math.round((schoolQuizScore / total) * 100);
  
  quizQuestionBox?.classList.add("hidden");
  quizResultBox?.classList.remove("hidden");
  
  const resultEmoji = document.getElementById("resultEmoji");
  const resultTitle = document.getElementById("resultTitle");
  const resultScore = document.getElementById("resultScore");
  
  if (resultEmoji) resultEmoji.textContent = percent >= 80 ? "🎉" : percent >= 50 ? "👍" : "📚";
  if (resultTitle) {
    resultTitle.textContent = percent >= 80 ? "Керемет!" : percent >= 50 ? "Жақсы!" : "Қайта оқы";
    resultTitle.className = `result-title ${percent >= 80 ? "excellent" : percent >= 50 ? "good" : "retry"}`;
  }
  if (resultScore) resultScore.textContent = `${schoolQuizScore} / ${total} (${percent}%)`;
  
  // Save quiz result
  const key = `school_quiz_${schoolCurrentSubject}_${schoolCurrentClass}_${schoolCurrentLessonIndex}`;
  const existing = JSON.parse(localStorage.getItem(key) || "{}");
  const bestPercent = Math.max(existing.bestPercent || 0, percent);
  localStorage.setItem(key, JSON.stringify({ 
    bestPercent, 
    lastPercent: percent, 
    lastCorrect: schoolQuizScore, 
    total, 
    updatedAt: Date.now() 
  }));
}

// Quiz button listeners
quizNextBtn?.addEventListener("click", nextSchoolQuizQuestion);
document.getElementById("retryQuizBtn")?.addEventListener("click", startSchoolQuiz);
document.getElementById("backToLearnBtn")?.addEventListener("click", () => switchSchoolTab("learn"));

// Accordion mode: only one STT section open at a time
document.querySelectorAll(".stt-acc").forEach(d => {
  d.addEventListener("toggle", () => {
    if (!d.open) return;
    document.querySelectorAll(".stt-acc").forEach(x => { if (x !== d) x.open = false; });
  });
});

(() => {
  const btn = document.getElementById("sttStartBtn");
  const langSel = document.getElementById("sttLang");
  const input = document.getElementById("sttInput");
  const box = document.getElementById("subtitlesBox");

  if (!btn || !langSel || !input || !box) {
    console.warn("STT elements not found:", { btn, langSel, input, box });
    return;
  }

  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) {
    btn.disabled = true;
    btn.textContent = "Speech-to-Text не поддерживается";
    return;
  }

  const rec = new SR();
  rec.continuous = true;
  rec.interimResults = true;

  let isOn = false;

  function setUI(on) {
    isOn = on;
    btn.textContent = on ? "⏹ Остановить запись" : "▶ Начать запись";
    btn.style.opacity = on ? "0.95" : "1";
  }

  // тіл өзгерсе — келесі стартта сол тілмен жүреді
  function applyLang() {
    rec.lang = langSel.value || "ru-RU";
  }
  applyLang();
  langSel.addEventListener("change", applyLang);

  btn.addEventListener("click", () => {
    try {
      if (!isOn) {
        applyLang();
        rec.start();
        setUI(true);
      } else {
        rec.stop();
        setUI(false);
      }
    } catch (e) {
      console.error("STT start/stop error:", e);
      // кейде "already started" болса — stop жасап қайта қосамыз
      try { rec.stop(); } catch {}
      setUI(false);
    }
  });

  rec.onresult = (event) => {
    let interim = "";
    let finalText = "";

    for (let i = event.resultIndex; i < event.results.length; i++) {
      const text = event.results[i][0].transcript;
      if (event.results[i].isFinal) finalText += text + " ";
      else interim += text;
    }

    // input — соңғы сөздер
    if (finalText.trim()) input.value = finalText.trim();
    // subtitles textarea — толық ағын
    box.value = (box.value + " " + finalText).trim() + (interim ? ("\n" + interim) : "");
  };

  rec.onerror = (e) => {
    console.error("STT error:", e);
    setUI(false);
    if (e.error === "not-allowed" || e.error === "service-not-allowed") {
      box.value = "Микрофонға рұқсат беріңіз (браузерде Allow).";
    }
  };

  rec.onend = () => {
    // егер қолданушы өзі тоқтатпаса — кейде браузер өзі тоқтатады
    // сонда UI дұрыс болсын
    setUI(false);
  };
})();
