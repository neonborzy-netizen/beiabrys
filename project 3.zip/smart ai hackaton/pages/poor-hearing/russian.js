// Орыс тілі - Сабақтар мен тесттер
const SUBJECT_KEY = 'russian';

const LESSONS = {
  1: [
    {
      id: 'alphabet',
      title: 'Әліпби',
      desc: 'Орыс әріптері',
      steps: [
        { title: 'Дауысты дыбыстар', content: 'А, Е, Ё, И, О, У, Ы, Э, Ю, Я — дауысты дыбыстар.', keyword: 'Дауысты' },
        { title: 'Дауыссыз дыбыстар', content: 'Б, В, Г, Д, Ж, З, К, Л, М, Н, П, Р, С, Т, Ф, Х, Ц, Ч, Ш, Щ.', keyword: 'Дауыссыз' },
        { title: 'Әріптерді жазу', content: 'Әр әріпті дұрыс жазуды үйрен.', keyword: 'Жазу' }
      ],
      quiz: [
        { q: 'Қай әріп дауысты?', options: ['Б', 'А', 'К', 'М'], answer: 1 },
        { q: 'Орыс әліпбиінде неше әріп бар?', options: ['26', '33', '42', '30'], answer: 1 },
        { q: 'Қай әріп дауыссыз?', options: ['О', 'У', 'П', 'И'], answer: 2 }
      ]
    },
    {
      id: 'syllables',
      title: 'Буындар',
      desc: 'Буынға бөлу',
      steps: [
        { title: 'Буын дегеніміз не?', content: 'Бір дауыстысы бар дыбыс тобы.', keyword: 'Буын' },
        { title: 'Буынға бөлу', content: 'МА-МА, ПА-ПА, КНИ-ГА.', keyword: 'Бөлу' },
        { title: 'Ереже', content: 'Қанша дауысты — сонша буын.', keyword: 'Ереже' }
      ],
      quiz: [
        { q: '"МАМА" сөзінде неше буын?', options: ['1', '2', '3', '4'], answer: 1 },
        { q: '"ШКОЛА" сөзінде неше буын?', options: ['1', '2', '3', '4'], answer: 1 },
        { q: '"Я" сөзінде неше буын?', options: ['0', '1', '2', '3'], answer: 1 }
      ]
    },
    {
      id: 'words',
      title: 'Сөздер',
      desc: 'Қарапайым сөздер',
      steps: [
        { title: 'Зат есім', content: 'Адам, жануар, зат атаулары: мама, кошка, дом.', keyword: 'Зат есім' },
        { title: 'Етістік', content: 'Әрекет атаулары: бегать, читать, писать.', keyword: 'Етістік' },
        { title: 'Сын есім', content: 'Сапа атаулары: красный, большой, добрый.', keyword: 'Сын есім' }
      ],
      quiz: [
        { q: '"Кошка" қай сөз табы?', options: ['Етістік', 'Зат есім', 'Сын есім'], answer: 1 },
        { q: '"Бегать" қай сөз табы?', options: ['Етістік', 'Зат есім', 'Сын есім'], answer: 0 },
        { q: '"Красный" қай сөз табы?', options: ['Етістік', 'Зат есім', 'Сын есім'], answer: 2 }
      ]
    }
  ],
  2: [
    {
      id: 'sentences',
      title: 'Сөйлемдер',
      desc: 'Сөйлем құру',
      steps: [
        { title: 'Сөйлем дегеніміз не?', content: 'Аяқталған ой білдіретін сөздер тобы.', keyword: 'Сөйлем' },
        { title: 'Бас әріп', content: 'Сөйлем бас әріптен басталады.', keyword: 'Бас әріп' },
        { title: 'Тыныс белгілері', content: 'Сөйлем соңында нүкте, сұрақ немесе леп белгісі қойылады.', keyword: 'Тыныс белгі' }
      ],
      quiz: [
        { q: 'Сөйлем неден басталады?', options: ['Кіші әріп', 'Бас әріп', 'Сан', 'Нүкте'], answer: 1 },
        { q: 'Сұраулы сөйлем соңында не қойылады?', options: ['.', '!', '?', ','], answer: 2 },
        { q: '"мама пришла" — бұл дұрыс па?', options: ['Иә', 'Жоқ, бас әріп керек'], answer: 1 }
      ]
    },
    {
      id: 'spelling',
      title: 'Емле',
      desc: 'Дұрыс жазу',
      steps: [
        { title: 'ЖИ-ШИ', content: 'ЖИ, ШИ — И әрпімен жазылады.', keyword: 'ЖИ-ШИ' },
        { title: 'ЧА-ЩА', content: 'ЧА, ЩА — А әрпімен жазылады.', keyword: 'ЧА-ЩА' },
        { title: 'ЧУ-ЩУ', content: 'ЧУ, ЩУ — У әрпімен жазылады.', keyword: 'ЧУ-ЩУ' }
      ],
      quiz: [
        { q: '"Ж_ЗНЬ" — қай әріп жетіспейді?', options: ['Ы', 'И', 'Е', 'А'], answer: 1 },
        { q: '"Ч_ДО" — қай әріп жетіспейді?', options: ['Ю', 'У', 'А', 'Я'], answer: 1 },
        { q: '"Ш_НА" — қай әріп жетіспейді?', options: ['Ы', 'И', 'Е', 'А'], answer: 1 }
      ]
    },
    {
      id: 'reading',
      title: 'Оқу',
      desc: 'Мәтін оқу',
      steps: [
        { title: 'Дауыстап оқу', content: 'Мәтінді дауыстап, анық оқу.', keyword: 'Дауыстап' },
        { title: 'Түсіну', content: 'Оқығанды түсіну, сұрақтарға жауап беру.', keyword: 'Түсіну' },
        { title: 'Қайталау', content: 'Негізгі ойды қайталап айту.', keyword: 'Қайталау' }
      ],
      quiz: [
        { q: 'Оқу кезінде не маңызды?', options: ['Тез оқу', 'Түсіну', 'Көп оқу'], answer: 1 },
        { q: 'Мәтіннен кейін не істеу керек?', options: ['Ұмыту', 'Сұрақтарға жауап беру', 'Ештеңе'], answer: 1 },
        { q: 'Дауыстап оқу не үшін керек?', options: ['Жылдам оқу', 'Анық айту үшін', 'Керек емес'], answer: 1 }
      ]
    }
  ],
  3: [
    {
      id: 'nouns',
      title: 'Зат есім',
      desc: 'Зат есімнің түрлері',
      steps: [
        { title: 'Род', content: 'Мужской (он), женский (она), средний (оно).', keyword: 'Род' },
        { title: 'Число', content: 'Единственное (бір), множественное (көп).', keyword: 'Число' },
        { title: 'Падеж', content: 'Именительный, родительный, дательный...', keyword: 'Падеж' }
      ],
      quiz: [
        { q: '"Книга" қай род?', options: ['Мужской', 'Женский', 'Средний'], answer: 1 },
        { q: '"Окно" қай род?', options: ['Мужской', 'Женский', 'Средний'], answer: 2 },
        { q: '"Столы" қай число?', options: ['Единственное', 'Множественное'], answer: 1 }
      ]
    },
    {
      id: 'verbs',
      title: 'Етістік',
      desc: 'Етістіктің шақтары',
      steps: [
        { title: 'Өткен шақ', content: 'Читал, писал, бегал — өткен шақ.', keyword: 'Өткен шақ' },
        { title: 'Осы шақ', content: 'Читаю, пишу, бегаю — осы шақ.', keyword: 'Осы шақ' },
        { title: 'Келер шақ', content: 'Буду читать, напишу — келер шақ.', keyword: 'Келер шақ' }
      ],
      quiz: [
        { q: '"Читал" қай шақ?', options: ['Өткен', 'Осы', 'Келер'], answer: 0 },
        { q: '"Буду играть" қай шақ?', options: ['Өткен', 'Осы', 'Келер'], answer: 2 },
        { q: '"Пишу" қай шақ?', options: ['Өткен', 'Осы', 'Келер'], answer: 1 }
      ]
    },
    {
      id: 'adjectives',
      title: 'Сын есім',
      desc: 'Сын есімнің түрлері',
      steps: [
        { title: 'Түс', content: 'Красный, синий, зелёный — түс білдіреді.', keyword: 'Түс' },
        { title: 'Өлшем', content: 'Большой, маленький, высокий — өлшем.', keyword: 'Өлшем' },
        { title: 'Сапа', content: 'Добрый, умный, красивый — сапа.', keyword: 'Сапа' }
      ],
      quiz: [
        { q: '"Зелёный" не білдіреді?', options: ['Өлшем', 'Түс', 'Сапа'], answer: 1 },
        { q: '"Большой" не білдіреді?', options: ['Өлшем', 'Түс', 'Сапа'], answer: 0 },
        { q: '"Умный" не білдіреді?', options: ['Өлшем', 'Түс', 'Сапа'], answer: 2 }
      ]
    }
  ],
  4: [
    {
      id: 'composition',
      title: 'Шығарма',
      desc: 'Шығарма жазу',
      steps: [
        { title: 'Кіріспе', content: 'Шығарманың басы — тақырыпты таныстыру.', keyword: 'Кіріспе' },
        { title: 'Негізгі бөлім', content: 'Негізгі ой, оқиғалар, мысалдар.', keyword: 'Негізгі' },
        { title: 'Қорытынды', content: 'Ойды қорытындылау, пікір білдіру.', keyword: 'Қорытынды' }
      ],
      quiz: [
        { q: 'Шығарма неден басталады?', options: ['Қорытынды', 'Кіріспе', 'Негізгі бөлім'], answer: 1 },
        { q: 'Негізгі бөлімде не болады?', options: ['Таныстыру', 'Оқиғалар, мысалдар', 'Пікір'], answer: 1 },
        { q: 'Қорытындыда не істейміз?', options: ['Таныстырамыз', 'Ойды аяқтаймыз', 'Сұрақ қоямыз'], answer: 1 }
      ]
    },
    {
      id: 'punctuation',
      title: 'Тыныс белгілері',
      desc: 'Тыныс белгілерін қою',
      steps: [
        { title: 'Нүкте', content: 'Хабарлы сөйлем соңында нүкте қойылады.', keyword: 'Нүкте' },
        { title: 'Үтір', content: 'Тізім, қаратпа сөз, күрделі сөйлемде үтір қойылады.', keyword: 'Үтір' },
        { title: 'Қос нүкте', content: 'Түсіндіру алдында қос нүкте қойылады.', keyword: 'Қос нүкте' }
      ],
      quiz: [
        { q: 'Хабарлы сөйлем соңында не қойылады?', options: ['?', '!', '.', ','], answer: 2 },
        { q: 'Тізім арасына не қойылады?', options: ['Нүкте', 'Үтір', 'Қос нүкте'], answer: 1 },
        { q: '"Мама сказала: ..." — қай белгі қойылған?', options: ['Нүкте', 'Үтір', 'Қос нүкте'], answer: 2 }
      ]
    },
    {
      id: 'grammar',
      title: 'Грамматика',
      desc: 'Грамматикалық талдау',
      steps: [
        { title: 'Бастауыш', content: 'Сөйлемнің негізгі субъектісі (кім? не?).', keyword: 'Бастауыш' },
        { title: 'Баяндауыш', content: 'Бастауыштың не істегенін білдіреді.', keyword: 'Баяндауыш' },
        { title: 'Анықтауыш', content: 'Зат есімді сипаттайды (қандай?).', keyword: 'Анықтауыш' }
      ],
      quiz: [
        { q: '"Мама читает книгу" — бастауыш қайсы?', options: ['читает', 'мама', 'книгу'], answer: 1 },
        { q: '"Кошка спит" — баяндауыш қайсы?', options: ['кошка', 'спит'], answer: 1 },
        { q: '"Красная роза" — анықтауыш қайсы?', options: ['красная', 'роза'], answer: 0 }
      ]
    }
  ]
};

// State
let currentClass = 1;
let currentLesson = null;
let currentQuizIndex = 0;
let quizScore = 0;

// DOM Elements
const lessonsGrid = document.getElementById('lessonsGrid');
const lessonContent = document.getElementById('lessonContent');
const lessonTitle = document.getElementById('lessonTitle');
const lessonBody = document.getElementById('lessonBody');
const quizContainer = document.getElementById('quizContainer');
const quizResult = document.getElementById('quizResult');
const progressFill = document.getElementById('progressFill');
const totalProgress = document.getElementById('totalProgress');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  loadTheme();
  setupClassButtons();
  renderLessons();
  updateProgress();
  
  document.getElementById('backToLessons').addEventListener('click', showLessons);
  document.getElementById('retryQuiz').addEventListener('click', retryQuiz);
});

function loadTheme() {
  const theme = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', theme);
}

function setupClassButtons() {
  document.querySelectorAll('.class-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.class-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentClass = parseInt(btn.dataset.class);
      renderLessons();
      updateProgress();
    });
  });
}

function renderLessons() {
  const lessons = LESSONS[currentClass] || [];
  lessonsGrid.innerHTML = lessons.map((lesson, index) => {
    const completed = isLessonCompleted(currentClass, lesson.id);
    return `
      <div class="lesson-card ${completed ? 'completed' : ''}" data-index="${index}">
        <div class="lesson-icon">${completed ? '✅' : '📚'}</div>
        <div class="lesson-info">
          <h3>${lesson.title}</h3>
          <p>${lesson.desc}</p>
        </div>
        <div class="lesson-arrow">→</div>
      </div>
    `;
  }).join('');

  document.querySelectorAll('.lesson-card').forEach(card => {
    card.addEventListener('click', () => {
      const index = parseInt(card.dataset.index);
      openLesson(index);
    });
  });
}

function openLesson(index) {
  currentLesson = LESSONS[currentClass][index];
  currentQuizIndex = 0;
  quizScore = 0;

  lessonTitle.textContent = currentLesson.title;
  
  lessonBody.innerHTML = currentLesson.steps.map((step, i) => `
    <div class="step-card">
      <div class="step-number">${i + 1}</div>
      <div class="step-content">
        <h4>${step.title}</h4>
        <p>${step.content}</p>
        <span class="step-keyword">${step.keyword}</span>
      </div>
    </div>
  `).join('');

  document.querySelector('.lessons-section').classList.add('hidden');
  document.querySelector('.class-selection').classList.add('hidden');
  document.querySelector('.progress-section').classList.add('hidden');
  lessonContent.classList.remove('hidden');
  
  renderQuiz();
}

function showLessons() {
  lessonContent.classList.add('hidden');
  document.querySelector('.lessons-section').classList.remove('hidden');
  document.querySelector('.class-selection').classList.remove('hidden');
  document.querySelector('.progress-section').classList.remove('hidden');
  quizResult.classList.add('hidden');
  quizContainer.classList.remove('hidden');
}

function renderQuiz() {
  if (!currentLesson || !currentLesson.quiz) return;
  
  const quiz = currentLesson.quiz[currentQuizIndex];
  if (!quiz) {
    showQuizResult();
    return;
  }

  quizContainer.innerHTML = `
    <div class="quiz-question">
      <div class="quiz-progress">Сұрақ ${currentQuizIndex + 1} / ${currentLesson.quiz.length}</div>
      <h4>${quiz.q}</h4>
      <div class="quiz-options">
        ${quiz.options.map((opt, i) => `
          <button class="quiz-option" data-index="${i}">${opt}</button>
        `).join('')}
      </div>
    </div>
  `;

  document.querySelectorAll('.quiz-option').forEach(btn => {
    btn.addEventListener('click', () => selectAnswer(parseInt(btn.dataset.index)));
  });
}

function selectAnswer(index) {
  const quiz = currentLesson.quiz[currentQuizIndex];
  const buttons = document.querySelectorAll('.quiz-option');
  
  buttons.forEach(btn => btn.disabled = true);
  
  if (index === quiz.answer) {
    buttons[index].classList.add('correct');
    quizScore++;
  } else {
    buttons[index].classList.add('wrong');
    buttons[quiz.answer].classList.add('correct');
  }

  setTimeout(() => {
    currentQuizIndex++;
    renderQuiz();
  }, 1000);
}

function showQuizResult() {
  quizContainer.classList.add('hidden');
  quizResult.classList.remove('hidden');
  
  const total = currentLesson.quiz.length;
  const percent = Math.round((quizScore / total) * 100);
  
  const resultIcon = document.getElementById('resultIcon');
  const resultText = document.getElementById('resultText');
  
  if (percent >= 70) {
    resultIcon.textContent = '🎉';
    resultText.textContent = `Жарайсың! ${quizScore}/${total} дұрыс (${percent}%)`;
    markLessonCompleted(currentClass, currentLesson.id);
    updateProgress();
  } else {
    resultIcon.textContent = '😔';
    resultText.textContent = `${quizScore}/${total} дұрыс (${percent}%). Қайта тырыс!`;
  }
}

function retryQuiz() {
  currentQuizIndex = 0;
  quizScore = 0;
  quizResult.classList.add('hidden');
  quizContainer.classList.remove('hidden');
  renderQuiz();
}

function getProgressKey() {
  return `${SUBJECT_KEY}_progress`;
}

function getProgress() {
  const data = localStorage.getItem(getProgressKey());
  return data ? JSON.parse(data) : {};
}

function saveProgress(progress) {
  localStorage.setItem(getProgressKey(), JSON.stringify(progress));
}

function isLessonCompleted(classNum, lessonId) {
  const progress = getProgress();
  return progress[`${classNum}_${lessonId}`] === true;
}

function markLessonCompleted(classNum, lessonId) {
  const progress = getProgress();
  progress[`${classNum}_${lessonId}`] = true;
  saveProgress(progress);
  renderLessons();
}

function updateProgress() {
  const progress = getProgress();
  let total = 0;
  let completed = 0;

  Object.keys(LESSONS).forEach(classNum => {
    LESSONS[classNum].forEach(lesson => {
      total++;
      if (progress[`${classNum}_${lesson.id}`]) {
        completed++;
      }
    });
  });

  const percent = total > 0 ? Math.round((completed / total) * 100) : 0;
  progressFill.style.width = `${percent}%`;
  totalProgress.textContent = `${percent}%`;
}
