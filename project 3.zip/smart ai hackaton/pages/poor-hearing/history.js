// Тарих - Сабақтар мен тесттер
const HISTORY = {
  1: [
    { title:"Тәуелсіздік", sub:"Тәуелсіз Қазақстан", icon:"🏳️" },
    { title:"Ұлы Жібек жолы", sub:"Сауда жолы", icon:"🛤️" },
    { title:"Ежелгі өркениеттер", sub:"Әлем тарихы", icon:"🏛️" },
  ],
  2: [
    { title:"Қазақ хандығы", sub:"Хандар мен билер", icon:"👑" },
    { title:"Батырлар", sub:"Ерлік тарихы", icon:"🛡️" },
    { title:"Көшпенділер", sub:"Дәстүр және өмір", icon:"🐎" },
  ],
  3: [
    { title:"Қалалар", sub:"Түркістан, Отырар", icon:"🏙️" },
    { title:"Ғалымдар", sub:"Әл-Фараби", icon:"📜" },
    { title:"Мәдениет", sub:"Салт-дәстүр", icon:"🎭" },
  ],
  4: [
    { title:"XX ғасыр", sub:"Маңызды оқиғалар", icon:"🗓️" },
    { title:"Тәуелсіздік жолы", sub:"1991–қазір", icon:"✨" },
    { title:"Қазақстан картасы", sub:"Өңірлер", icon:"🗺️" },
  ]
};

let currentClass = 1;

function renderLessons(cls){
  currentClass = cls;
  const grid = document.getElementById("lessonGrid");
  if(!grid) return;

  grid.innerHTML = "";
  (HISTORY[cls] || []).forEach(item=>{
    const card = document.createElement("div");
    card.className = "edu-card";
    card.innerHTML = `
      <div class="edu-card-left">
        <div class="edu-ic">${item.icon}</div>
        <div>
          <div class="edu-card-title">${item.title}</div>
          <div class="edu-card-sub">${item.sub}</div>
        </div>
      </div>
      <div class="edu-arrow">›</div>
    `;
    card.addEventListener("click", ()=>{
      alert("Сабақ ашу: " + item.title);
    });
    grid.appendChild(card);
  });
}

(function init(){
  const row = document.getElementById("classRow");
  if(row){
    row.addEventListener("click", (e)=>{
      const btn = e.target.closest("[data-class]");
      if(!btn) return;
      row.querySelectorAll(".edu-pill").forEach(b=>b.classList.remove("active"));
      btn.classList.add("active");
      renderLessons(Number(btn.dataset.class));
    });
  }
  renderLessons(1);
})();
