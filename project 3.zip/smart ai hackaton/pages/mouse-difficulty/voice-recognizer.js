/**
 * Voice recognizer for pages WITHOUT their own recognition.
 * Uses Web Speech API and routes transcripts to window.VoiceUI.
 *
 * Pages: motor-exercises.html (and any other standalone page).
 * Index/Lesson/Tutor already have their own recognizers — do NOT include there.
 */
(function () {
  'use strict';

  function safeJsonParse(str, fallback) {
    try { return JSON.parse(str); } catch { return fallback; }
  }

  function getSettings() {
    const saved = localStorage.getItem('appSettings');
    const defaults = { voiceNavigation: false, controlMethod: 'both' };
    return saved ? { ...defaults, ...safeJsonParse(saved, {}) } : defaults;
  }

  function isEnabled() {
    const s = getSettings();
    if (s.controlMethod === 'keyboard') return false;
    return !!s.voiceNavigation;
  }

  function getLang() {
    const htmlLang = document.documentElement.lang || 'ru';
    return htmlLang === 'kk' ? 'kk-KZ' : 'ru-RU';
  }

  if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
    return;
  }

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  let rec = null;
  let active = false;
  let micPromptShown = false;

  function checkMicPermission() {
    return new Promise(function (resolve) {
      if (!navigator.permissions || !navigator.permissions.query) {
        resolve('prompt');
        return;
      }
      try {
        navigator.permissions.query({ name: 'microphone' })
          .then(function (result) { resolve(result.state); })
          .catch(function () { resolve('prompt'); });
      } catch (e) {
        resolve('prompt');
      }
    });
  }

  function showMicPromptButton(onClick) {
    if (micPromptShown) return;
    micPromptShown = true;
    var wrap = document.createElement('div');
    wrap.id = 'voiceMicPromptWrap';
    wrap.innerHTML = '<button type="button" id="voiceMicPromptBtn">🎤 Включить голос (разрешить микрофон один раз)</button>';
    wrap.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);z-index:100002;';
    var btn = wrap.querySelector('button');
    btn.style.cssText = 'padding:14px 24px;background:linear-gradient(135deg,#6366F1,#8B5CF6);color:#fff;border:none;border-radius:16px;font:600 15px Inter,system-ui,sans-serif;cursor:pointer;box-shadow:0 8px 24px rgba(99,102,241,0.4);';
    btn.onclick = function () {
      wrap.remove();
      micPromptShown = false;
      if (onClick) onClick();
    };
    document.body.appendChild(wrap);
  }

  function createRecognition() {
    var r = new SpeechRecognition();
    r.lang = getLang();
    r.continuous = true;
    r.interimResults = true;
    r.maxAlternatives = 3;
    r.onresult = function (event) {
      var last = event.results[event.results.length - 1];
      if (last.isFinal) {
        var transcript = last[0].transcript.toLowerCase().trim();
        if (window.VoiceUI) window.VoiceUI.handleTranscript(transcript, true);
      }
    };
    r.onerror = function (event) {
      if (event.error === 'not-allowed') active = false;
    };
    r.onend = function () {
      if (!active || !isEnabled()) return;
      // При file:// не перезапускаем — иначе браузер бесконечно спрашивает разрешение
      if (window.location.protocol === 'file:') return;
      setTimeout(function () {
        if (!active) return;
        try { rec = createRecognition(); rec.start(); } catch (e) {}
      }, 200);
    };
    return r;
  }

  function start() {
    if (!isEnabled()) return;
    if (active) return;
    function doStart() {
      if (active) return;
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        try { rec = createRecognition(); rec.start(); active = true; window.VoiceUI?.showIndicator?.('🎤 Голосовое управление'); } catch (e) {}
        return;
      }
      navigator.mediaDevices.getUserMedia({ audio: true })
        .then(function (stream) {
          stream.getTracks().forEach(function (t) { t.stop(); });
          rec = createRecognition();
          try {
            rec.start();
            active = true;
            window.VoiceUI?.showIndicator?.('🎤 Голосовое управление');
          } catch (e) {}
        })
        .catch(function () {
          try { rec = createRecognition(); rec.start(); active = true; } catch (e) {}
        });
    }
    checkMicPermission().then(function (state) {
      if (state === 'granted') {
        doStart();
      } else if (state === 'prompt') {
        showMicPromptButton(doStart);
      }
    });
  }

  function stop() {
    active = false;
    try { rec.stop(); } catch {}
    window.VoiceUI?.hideIndicator?.();
  }

  // react to settings changes from other tabs/pages
  window.addEventListener('storage', (e) => {
    if (e.key === 'appSettings') {
      if (isEnabled()) start();
      else stop();
    }
  });

  // Запуск только если в настройках включён микрофон (не запрашиваем при загрузке)
  setTimeout(function () {
    if (isEnabled()) start();
  }, 300);
})();

