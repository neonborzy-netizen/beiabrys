/**
 * Push-to-Talk (Нажми и говори) — надёжный режим, когда непрерывное распознавание не срабатывает.
 * Нажми и держи кнопку → говори → отпусти → команда выполнится.
 */
(function () {
  'use strict';

  if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) return;

  var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  var lang = (document.documentElement.lang || 'ru') === 'kk' ? 'kk-KZ' : 'ru-RU';
  var rec = null;
  var lastTranscript = '';
  var btn = null;
  var statusEl = null;

  function getStatusText() {
    return (document.documentElement.lang || 'ru') === 'kk'
      ? 'Басып, сөйле'
      : 'Нажми и говори';
  }

  function createButton() {
    if (btn) return;
    var wrap = document.createElement('div');
    wrap.id = 'voicePttWrap';
    wrap.innerHTML = '<button type="button" id="voicePttBtn" aria-label="' + getStatusText() + '">' +
      '<span class="voice-ptt-icon">🎤</span>' +
      '<span class="voice-ptt-text">' + getStatusText() + '</span>' +
      '</button>' +
      '<div id="voicePttStatus" class="voice-ptt-status"></div>';
    wrap.className = 'voice-ptt-wrap';
    var s = document.createElement('style');
    s.textContent = [
      '.voice-ptt-wrap{position:fixed;bottom:20px;left:50%;transform:translateX(-50%);z-index:100001;display:flex;flex-direction:column;align-items:center;gap:8px;}',
      '.voice-ptt-wrap button{',
      'min-width:180px;min-height:56px;padding:14px 24px;',
      'background:linear-gradient(135deg,#6366F1,#8B5CF6);color:#fff;border:none;border-radius:16px;',
      'font:600 18px/1.2 Inter,system-ui,sans-serif;cursor:pointer;',
      'box-shadow:0 8px 24px rgba(99,102,241,0.4);transition:transform 0.15s,box-shadow 0.15s;}',
      '.voice-ptt-wrap button:hover{transform:scale(1.03);box-shadow:0 12px 32px rgba(99,102,241,0.5);}',
      '.voice-ptt-wrap button:active,.voice-ptt-wrap button.recording{transform:scale(0.97);background:linear-gradient(135deg,#22C55E,#16A34A);box-shadow:0 4px 16px rgba(34,197,94,0.5);}',
      '.voice-ptt-icon{display:block;font-size:24px;margin-bottom:4px;}',
      '.voice-ptt-text{display:block;font-size:14px;}',
      '.voice-ptt-status{min-height:24px;font-size:14px;color:#6366F1;font-weight:600;text-align:center;}',
      '.voice-ptt-status.listening{color:#22C55E;animation:pulse-ptt 1s infinite;}',
      '@keyframes pulse-ptt{50%{opacity:0.7;}}'
    ].join('');
    document.head.appendChild(s);
    document.body.appendChild(wrap);
    btn = document.getElementById('voicePttBtn');
    statusEl = document.getElementById('voicePttStatus');
  }

  function setStatus(text, isListening) {
    if (statusEl) {
      statusEl.textContent = text || '';
      statusEl.classList.toggle('listening', !!isListening);
    }
  }

  function requestMic() {
    return new Promise(function (resolve) {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        resolve(false);
        return;
      }
      navigator.mediaDevices.getUserMedia({ audio: true })
        .then(function (stream) {
          stream.getTracks().forEach(function (t) { t.stop(); });
          resolve(true);
        })
        .catch(function () { resolve(false); });
    });
  }

  function startListening() {
    if (rec) {
      try { rec.stop(); } catch (e) {}
      rec = null;
    }
    rec = new SpeechRecognition();
    rec.lang = lang;
    rec.continuous = false;
    rec.interimResults = true;
    rec.maxAlternatives = 3;
    lastTranscript = '';

    rec.onresult = function (event) {
      var results = event.results;
      var last = results[results.length - 1];
      for (var i = 0; i < results.length; i++) {
        var r = results[i];
        if (r.isFinal && r[0]) {
          lastTranscript = (lastTranscript ? lastTranscript + ' ' : '') + r[0].transcript;
        }
      }
      if (!last.isFinal && last[0]) {
        setStatus('Слушаю: ' + last[0].transcript, true);
      }
    };

    rec.onend = function () {
      setStatus('', false);
      if (btn) btn.classList.remove('recording');
      if (lastTranscript) {
        var handled = window.VoiceUI && window.VoiceUI.handleTranscript(lastTranscript, true);
        if (!handled) {
          window.dispatchEvent(new CustomEvent('voice-command', { detail: { transcript: lastTranscript } }));
        }
      }
      rec = null;
    };

    rec.onerror = function (e) {
      if (e.error === 'not-allowed') {
        setStatus('Разрешите микрофон в браузере', false);
      } else if (e.error === 'no-speech') {
        setStatus('Не услышал. Попробуй ещё раз.', false);
      }
      if (btn) btn.classList.remove('recording');
      rec = null;
    };

    try {
      rec.start();
      setStatus('Говори…', true);
      if (btn) btn.classList.add('recording');
    } catch (e) {
      setStatus('Ошибка. Попробуй ещё раз.', false);
      if (btn) btn.classList.remove('recording');
    }
  }

  function stopListening() {
    if (rec) {
      try { rec.stop(); } catch (e) {}
    }
  }

  function onPointerDown(e) {
    e.preventDefault();
    lastTranscript = '';
    requestMic().then(function (ok) {
      if (ok) startListening();
      else setStatus('Нет доступа к микрофону', false);
    });
  }

  function onPointerUp(e) {
    e.preventDefault();
    stopListening();
  }

  function init() {
    createButton();
    if (!btn) return;
    btn.addEventListener('pointerdown', onPointerDown);
    btn.addEventListener('pointerup', onPointerUp);
    btn.addEventListener('pointerleave', onPointerUp);
    btn.addEventListener('pointercancel', onPointerUp);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
