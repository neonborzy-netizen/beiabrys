/**
 * Voice UI helpers (NO SpeechRecognition here).
 * Работает поверх любого распознавания речи:
 * - Режим "номера": показать номера → нажми номер N
 * - Нажми/открой/выбери по тексту (aria-label/текст кнопки)
 * - Фокус: следующее/предыдущее
 * - Прокрутка
 *
 * На страницах, где распознавание уже есть (index/lesson/tutor),
 * их обработчик речи вызывает `window.VoiceUI.handleTranscript(...)`.
 */
(function () {
  'use strict';

  function safeJsonParse(str, fallback) {
    try { return JSON.parse(str); } catch { return fallback; }
  }

  function getAppSettings() {
    const saved = localStorage.getItem('appSettings');
    const defaults = {
      voiceNavigation: true,
      controlMethod: 'both',
    };
    return saved ? { ...defaults, ...safeJsonParse(saved, {}) } : defaults;
  }

  function normalize(s) {
    return String(s || '')
      .toLowerCase()
      .replace(/[.,!?;:()[\]{}"“”«»]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function isVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    // хотя бы частично в viewport
    const vw = window.innerWidth || 0, vh = window.innerHeight || 0;
    return r.bottom >= 0 && r.right >= 0 && r.top <= vh && r.left <= vw;
  }

  function isActionable(el) {
    if (!el) return false;
    if (el.hasAttribute('disabled')) return false;
    const tag = (el.tagName || '').toLowerCase();
    if (tag === 'button' || tag === 'a') return true;
    if (tag === 'input' || tag === 'select' || tag === 'textarea') return true;
    const role = el.getAttribute('role');
    if (role === 'button' || role === 'link' || role === 'checkbox' || role === 'radio' || role === 'switch') return true;
    if (el.hasAttribute('tabindex')) return true;
    if (el.hasAttribute('data-voice-cmd')) return true;
    if (el.classList && (el.classList.contains('course-card') || el.classList.contains('motor-card') || el.classList.contains('motor-exercises') || el.classList.contains('stage-close'))) return true;
    return false;
  }

  function getAccessibleName(el) {
    const aria = el.getAttribute('aria-label');
    if (aria) return aria;
    const labelledby = el.getAttribute('aria-labelledby');
    if (labelledby) {
      const ids = labelledby.split(/\s+/).filter(Boolean);
      const parts = ids.map((id) => document.getElementById(id)?.textContent).filter(Boolean);
      if (parts.length) return parts.join(' ');
    }
    const alt = el.getAttribute('alt');
    if (alt) return alt;
    const title = el.getAttribute('title');
    if (title) return title;
    if ((el.tagName || '').toLowerCase() === 'input') {
      const type = (el.getAttribute('type') || '').toLowerCase();
      if (type === 'button' || type === 'submit' || type === 'reset') return el.value || '';
      const id = el.id;
      if (id) {
        const label = document.querySelector(`label[for="${CSS.escape(id)}"]`);
        if (label?.textContent) return label.textContent;
      }
    }
    return (el.textContent || '').trim();
  }

  function getActionables() {
    const candidates = Array.from(document.querySelectorAll(
      'button, a, input, select, textarea, [role="button"], [role="link"], [role="checkbox"], [role="radio"], [role="switch"], [tabindex], [data-voice-cmd], .course-card, .motor-card, .motor-exercises, .stage-close'
    ));
    return candidates.filter((el) => isActionable(el) && isVisible(el));
  }

  function injectStylesOnce() {
    if (document.getElementById('voiceUiStyles')) return;
    const style = document.createElement('style');
    style.id = 'voiceUiStyles';
    style.textContent = `
      .voice-ui-indicator{
        position:fixed; right:16px; bottom:16px;
        z-index:100000;
        background: rgba(99,102,241,0.92);
        color:#fff; padding:10px 12px; border-radius:12px;
        font: 600 13px/1.2 Inter, system-ui, sans-serif;
        box-shadow: 0 12px 30px rgba(0,0,0,.18);
      }
      .voice-ui-overlay{
        position:fixed; inset:0; z-index:99999; pointer-events:none;
      }
      .voice-ui-badge{
        position:absolute;
        min-width: 26px; height: 26px;
        padding: 0 8px;
        border-radius: 999px;
        background: rgba(34,197,94,0.95);
        color:#fff;
        font: 800 13px/26px Inter, system-ui, sans-serif;
        text-align:center;
        box-shadow: 0 8px 18px rgba(0,0,0,.18);
        transform: translate(-20%, -55%);
        white-space: nowrap;
      }
      .voice-ui-focus{
        outline: 4px solid rgba(34,197,94,0.7) !important;
        outline-offset: 3px !important;
      }
    `;
    document.head.appendChild(style);
  }

  const VoiceUI = {
    overlayEl: null,
    overlayMap: new Map(), // number -> element
    overlayVisible: false,
    indicatorEl: null,

    showIndicator(text) {
      injectStylesOnce();
      if (!this.indicatorEl) {
        const el = document.createElement('div');
        el.className = 'voice-ui-indicator';
        el.id = 'voiceUiIndicator';
        document.body.appendChild(el);
        this.indicatorEl = el;
      }
      this.indicatorEl.textContent = text || '🎤 Голосовое управление';
    },

    hideIndicator() {
      if (this.indicatorEl) {
        this.indicatorEl.remove();
        this.indicatorEl = null;
      }
    },

    showNumbers() {
      injectStylesOnce();
      this.hideNumbers();
      const overlay = document.createElement('div');
      overlay.className = 'voice-ui-overlay';
      overlay.id = 'voiceUiOverlay';
      document.body.appendChild(overlay);
      this.overlayEl = overlay;
      this.overlayMap = new Map();

      const actionables = getActionables();
      let n = 1;
      for (const el of actionables) {
        const r = el.getBoundingClientRect();
        const badge = document.createElement('div');
        badge.className = 'voice-ui-badge';
        badge.textContent = String(n);
        badge.style.left = `${Math.max(0, r.left)}px`;
        badge.style.top = `${Math.max(0, r.top)}px`;
        overlay.appendChild(badge);
        this.overlayMap.set(n, el);
        n += 1;
        if (n > 99) break;
      }
      this.overlayVisible = true;
      return this.overlayMap.size;
    },

    hideNumbers() {
      if (this.overlayEl) {
        this.overlayEl.remove();
        this.overlayEl = null;
      }
      this.overlayMap = new Map();
      this.overlayVisible = false;
    },

    toggleNumbers() {
      if (this.overlayVisible) this.hideNumbers();
      else this.showNumbers();
    },

    activateNumber(n) {
      const el = this.overlayMap.get(n);
      if (!el) return false;
      try {
        el.scrollIntoView({ block: 'center', inline: 'center', behavior: 'smooth' });
      } catch {}
      try {
        el.focus?.();
        // имитация клика
        if (typeof el.click === 'function') el.click();
        else el.dispatchEvent(new MouseEvent('click', { bubbles: true }));
      } catch {}
      return true;
    },

    activateByText(transcript) {
      const t = normalize(transcript);
      if (!t) return false;
      const verbs = [
        'нажми', 'нажать', 'открой', 'открыть', 'выбери', 'выбрать', 'запусти', 'запустить',
        'перейди', 'перейти', 'включи', 'включить', 'выключи', 'выключить', 'нажмите', 'откройте', 'выберите'
      ];
      let query = t;
      for (const v of verbs) query = query.replace(new RegExp(`\\b${v}\\b`, 'gi'), ' ');
      query = normalize(query);
      if (!query && t.length >= 2) query = t;
      if (!query) return false;

      const els = getActionables();
      let best = null;
      let bestScore = 0;
      for (const el of els) {
        const name = normalize(getAccessibleName(el));
        const dataCmd = (el.getAttribute('data-voice-cmd') || '').toLowerCase();
        const text = normalize((el.textContent || '').slice(0, 100));
        const combined = [name, dataCmd, text].filter(Boolean).join(' ');
        if (!combined) continue;
        const qWords = query.split(' ').filter((w) => w.length >= 1);
        let score = 0;
        for (const w of qWords) {
          if (w.length < 2) continue;
          if (combined.includes(w)) score += w.length;
        }
        if (combined.includes(query)) score += query.length * 2 + 5;
        if (score > bestScore) {
          bestScore = score;
          best = el;
        }
      }
      if (!best || bestScore < 2) return false;
      try { best.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch {}
      try { best.focus?.(); } catch {}
      try { best.click?.(); } catch {}
      return true;
    },

    focusNext() {
      const els = getActionables();
      if (!els.length) return false;
      const active = document.activeElement;
      let idx = els.indexOf(active);
      idx = idx < 0 ? 0 : Math.min(els.length - 1, idx + 1);
      const el = els[idx];
      try {
        el.focus?.();
        el.classList?.add('voice-ui-focus');
        setTimeout(() => el.classList?.remove('voice-ui-focus'), 600);
      } catch {}
      return true;
    },

    focusPrev() {
      const els = getActionables();
      if (!els.length) return false;
      const active = document.activeElement;
      let idx = els.indexOf(active);
      idx = idx < 0 ? 0 : Math.max(0, idx - 1);
      const el = els[idx];
      try {
        el.focus?.();
        el.classList?.add('voice-ui-focus');
        setTimeout(() => el.classList?.remove('voice-ui-focus'), 600);
      } catch {}
      return true;
    },

    scrollBy(dir) {
      const dy = dir === 'up' ? -0.7 : 0.7;
      window.scrollBy({ top: (window.innerHeight || 600) * dy, behavior: 'smooth' });
      return true;
    },

    goBack() {
      const backSelectors = [
        '[aria-label*="Назад"]',
        '.back-btn',
        '.back-to-modules-btn',
        '.motor-back',
        '#backBtn',
        '#backToModulesBtn',
        '#backToProfileBtn',
        '#backToCoursesBtn'
      ];
      const seen = new Set();
      for (const sel of backSelectors) {
        const nodes = document.querySelectorAll(sel);
        for (const el of nodes) {
          if (seen.has(el)) continue;
          seen.add(el);
          if (isVisible(el) && isActionable(el)) {
            try { el.click(); return true; } catch {}
          }
        }
      }
      window.history.back();
      return true;
    },

    goClose() {
      const closeSelectors = [
        '.stage-close', '#stageClose', '#stageClose',
        '[aria-label*="Закрыть"]', '[aria-label*="жабу"]', '[aria-label*="Close"]',
        '[data-voice-cmd="close"]', 'button[data-dismiss="modal"]'
      ];
      for (const sel of closeSelectors) {
        const el = document.querySelector(sel);
        if (el && isVisible(el) && isActionable(el)) {
          try { el.click(); return true; } catch {}
        }
      }
      const actionables = getActionables();
      const closeLike = actionables.find((el) => {
        const name = normalize(getAccessibleName(el));
        return name && (name.includes('закрыть') || name.includes('жабу') || name.includes('close') || name === '✕' || name === '×');
      });
      if (closeLike) {
        try { closeLike.click(); return true; } catch {}
      }
      return false;
    },

    extractNumber(transcript) {
      const t = normalize(transcript);
      const digit = t.match(/\b([1-9][0-9]?)\b/);
      if (digit) return parseInt(digit[1], 10);
      const map = {
        'десятый': 10, 'девятый': 9, 'восьмой': 8, 'седьмой': 7, 'шестой': 6, 'пятый': 5,
        'четвёртый': 4, 'четвертый': 4, 'третий': 3, 'второй': 2, 'первый': 1,
        'десять': 10, 'девять': 9, 'восемь': 8, 'семь': 7, 'шесть': 6, 'пять': 5,
        'четыре': 4, 'три': 3, 'два': 2, 'один': 1, 'одна': 1, 'одно': 1, 'раз': 1,
        'оныншы': 10, 'тоғызыншы': 9, 'сегізинші': 8, 'жетінші': 7, 'алтыншы': 6, 'бесінші': 5,
        'төртінші': 4, 'үшінші': 3, 'екінші': 2, 'бірінші': 1,
        'он': 10, 'тоғыз': 9, 'сегіз': 8, 'жеті': 7, 'алты': 6, 'бес': 5,
        'төрт': 4, 'үш': 3, 'екі': 2, 'бір': 1
      };
      for (const k of Object.keys(map)) {
        if (t.includes(k)) return map[k];
      }
      return null;
    },

    handleTranscript(transcript, force) {
      if (!force) {
        const settings = getAppSettings();
        if (settings.controlMethod === 'keyboard') return false;
        if (!settings.voiceNavigation) return false;
      }

      const t = normalize(transcript);
      if (!t) return false;

      // Закрыть окно / модалку
      if (t.includes('закрой') || t.includes('закрыть') || t.includes('жабық') || t.includes('жабу') || t.includes('закрой окно') || t.includes('закрой окно упражнения')) {
        if (this.goClose()) return true;
      }

      // Режим номеров
      if (t.includes('покажи номера') || t.includes('покажи цифры') || t.includes('нумерация') || t.includes('номерлер') || t.includes('номера')) {
        this.showNumbers();
        return true;
      }
      if (t.includes('скрой номера') || t.includes('убери номера') || t.includes('жасыр')) {
        this.hideNumbers();
        return true;
      }
      if (t.includes('нажми номер') || t.includes('номер ') || t.includes('вариант один') || t.includes('вариант два') || t.includes('вариант три') || t.includes('вариант четыре') || t.includes('вариант пять') ||
          (t.includes('номер') && (t.includes('нажми') || t.includes('открой') || t.includes('бас') || t.includes('выбери'))) ||
          (t.includes('вариант') && this.extractNumber(t) != null) ||
          (t.includes('первый вариант') || t.includes('второй вариант') || t.includes('третий вариант') || t.includes('четвёртый вариант') || t.includes('пятый вариант')) {
        const n = this.extractNumber(t);
        if (n != null) return this.activateNumber(n);
      }

      // Навигация / фокус / скролл
      if (t === 'назад' || t.includes('вернись') || t.includes('артқа') || t.includes('к списку') || t.includes('к курсам') || t.includes('курстарға')) return this.goBack();
      if (t.includes('вниз') || t.includes('төмен') || t.includes('прокрути вниз')) return this.scrollBy('down');
      if (t.includes('вверх') || t.includes('жоғары') || t.includes('прокрути вверх')) return this.scrollBy('up');
      if (t.includes('следующее') || t.includes('дальше') || t.includes('келесі') || t.includes('следующий') || t.includes('вперёд')) return this.focusNext();
      if (t.includes('предыдущее') || t.includes('назад элемент') || t.includes('алдыңғы') || t.includes('предыдущий')) return this.focusPrev();

      // Любая фраза с действием — попытка кликнуть по тексту (каждая мелочь)
      if (t.length >= 2) {
        if (this.activateByText(t)) return true;
      }
      if (t.includes('нажми') || t.includes('открой') || t.includes('выбери') || t.includes('бас') || t.includes('ашу')) {
        return this.activateByText(t);
      }

      return false;
    }
  };

  window.VoiceUI = VoiceUI;
})();

