// ИИ-Тьютор для ребёнка с моторными нарушениями
// Голосовое управление без использования рук

class VoiceTutor {
    constructor() {
        this.recognition = null;
        this.synthesis = window.speechSynthesis;
        this.isListening = false;
        this.isSpeaking = false;
        this.currentTask = null;
        this.taskIndex = 0;
        this.currentLang = 'ru';
        this.lessonStep = 0; // Шаг урока (0 - объяснение, 1 - вопрос)
        this.attemptsCount = 0; // Счётчик попыток для адаптации
        this.difficultyLevel = 1; // Уровень сложности (1-3, можно упрощать)
        this.waitingForConfirmation = false; // Ожидаем подтверждение (да/нет)
        this.suggestedAnswer = null; // Предложенный ответ для подтверждения
        
        // Переводы интерфейса
        this.translations = {
            ru: {
                title: "Учимся вместе",
                statusReady: "Готов слушать",
                statusListening: "Слушаю тебя...",
                statusSpeaking: "Говорю...",
                greeting: "Привет! Я твой помощник. Говори со мной, и я помогу тебе учиться.",
                hint1: "Нажми большую кнопку \"Начать\" или клавишу Space/Enter, чтобы начать.",
                hint2: "При первом использовании браузер попросит разрешение на микрофон - нажми \"Разрешить\".",
                startBtn: "Начать",
                stopBtn: "Пауза",
                commandsTitle: "Команды, которые я понимаю:",
                commandNext: "перейти к следующему шагу",
                commandRepeat: "повторить задание",
                commandHelp: "дать подсказку",
                commandStop: "сделать паузу",
                commandAgain: "повторить урок",
                lessonComplete: "Отлично! Урок завершён. Ты справился!",
                waitingForAnswer: "Жду твой ответ. Можешь говорить или просто молчать — я подожду.",
                goodAttempt: "Хорошая попытка! Ты стараешься, это важно.",
                clarify: "Ты имел в виду",
                clarifyQuestion: "Скажи 'да' или 'нет'.",
                pauseOffer: "Ты устал? Можешь сказать 'стоп' для паузы.",
                simplified: "Давай упростим задание.",
                browserNotSupported: "К сожалению, твой браузер не поддерживает голосовое управление. Попробуй использовать Chrome или Edge.",
                noSpeech: "Я не услышал ответ. Попробуй сказать ещё раз, пожалуйста.",
                micNotAllowed: "Нужно разрешить доступ к микрофону. Посмотри на адресную строку браузера, там будет иконка микрофона. Нажми на неё и разреши доступ.",
                micNotAllowedShort: "Нужно разрешить доступ к микрофону. Нажми на иконку микрофона в адресной строке браузера и разреши доступ.",
                error: "Что-то пошло не так. Давай попробуем ещё раз.",
                startError: "Не удалось начать запись. Попробуй ещё раз.",
                noTask: "Скажи 'дальше', чтобы начать задание, или 'помоги', если нужна помощь.",
                noTaskStart: "Сначала скажи 'дальше', чтобы начать задание.",
                praises: ["Отлично! Ты справился!", "Молодец! Правильно!", "Здорово! Ты всё понял!", "Верно! Ты умница!", "Правильно! Ты хорошо подумал!"],
                nextTask: " Скажи 'дальше', чтобы перейти к следующему заданию.",
                goodTry: "Хорошая попытка! Давай подумаем ещё.",
                tryAgain: " Попробуй ответить снова или скажи 'помоги' для подсказки.",
                break: "Хорошо, делаем паузу. Отдохни. Когда будешь готов, скажи 'дальше'."
            },
            kk: {
                title: "Бірге үйренеміз",
                statusReady: "Тыңдауға дайын",
                statusListening: "Сені тыңдап жатырмын...",
                statusSpeaking: "Айтып жатырмын...",
                greeting: "Сәлем! Мен сенің көмекшің. Менімен сөйлес, мен саған үйренуге көмектесемін.",
                hint1: "Бастау үшін \"Бастау\" батырмасын немесе Space/Enter пернесін бас.",
                hint2: "Алғаш рет пайдаланғанда браузер микрофонға рұқсат сұрайды - \"Рұқсат бер\" деп бас.",
                startBtn: "Бастау",
                stopBtn: "Кідіріс",
                commandsTitle: "Мен түсінетін командалар:",
                commandNext: "келесі қадамға өту",
                commandRepeat: "тапсырманы қайталау",
                commandHelp: "көмек көрсету",
                commandStop: "кідіріс жасау",
                commandAgain: "сабақты қайталау",
                lessonComplete: "Керемет! Сабақ аяқталды. Сен тапсырдың!",
                waitingForAnswer: "Жауабыңды күтемін. Айта аласың немесе жай ұнтап тұр — мен күтемін.",
                goodAttempt: "Жақсы тырысу! Сен тырысып жатырсың, бұл маңызды.",
                clarify: "Сен дегенің",
                clarifyQuestion: "'Иә' немесе 'жоқ' деп айт.",
                pauseOffer: "Шаршадың ба? Кідіріс үшін 'тоқта' деп айта аласың.",
                simplified: "Тапсырманы жеңілдетейік.",
                browserNotSupported: "Өкінішке орай, сенің браузерің дауыстық басқаруды қолдамайды. Chrome немесе Edge пайдалан.",
                noSpeech: "Мен жауапты естімедім. Қайта айтып көр, өтінемін.",
                micNotAllowed: "Микрофонға қол жеткізуге рұқсат беру керек. Браузердің мекенжай жолына қара, онда микрофон белгішесі болады. Оған басып, рұқсат бер.",
                micNotAllowedShort: "Микрофонға қол жеткізуге рұқсат беру керек. Браузердің мекенжай жолындағы микрофон белгішесіне басып, рұқсат бер.",
                error: "Бір нәрсе дұрыс болмады. Қайта көріп көрейік.",
                startError: "Жазбаны бастау мүмкін болмады. Қайта көріп көрейік.",
                noTask: "Тапсырманы бастау үшін 'келесі' деп айт немесе көмек керек болса 'көмектес' деп айт.",
                noTaskStart: "Алдымен тапсырманы бастау үшін 'келесі' деп айт.",
                praises: ["Керемет! Сен тапсырдың!", "Жақсы! Дұрыс!", "Керемет! Сен бәрін түсіндің!", "Дұрыс! Сен ақылдысың!", "Дұрыс! Сен жақсы ойладың!"],
                nextTask: " Келесі тапсырмаға өту үшін 'келесі' деп айт.",
                goodTry: "Жақсы тырысу! Тағы ойланайық.",
                tryAgain: " Қайта жауап бер немесе көмек алу үшін 'көмектес' деп айт.",
                break: "Жақсы, кідіріс жасаймыз. Демал. Дайын болғанда 'келесі' деп айт."
            }
        };
        
        // Уроки в формате Duolingo - одно слово/понятие за раз
        this.lessons = {
            ru: [
                {
                    word: "кошка",
                    explanation: "Кошка — это пушистое животное. Она говорит 'мяу'.",
                    question: "Какое животное говорит 'мяу'?",
                    answer: "кошка",
                    alternatives: ["кот", "кошечка", "котёнок"],
                    hint: "Это пушистое животное, которое любит молоко.",
                    image: "🐱"
                },
                {
                    word: "солнце",
                    explanation: "Солнце — это яркая звезда на небе. Оно жёлтое.",
                    question: "Какого цвета солнце?",
                    answer: "желтое",
                    alternatives: ["желтый", "оранжевое", "оранжевый"],
                    hint: "Оно яркое и светит на небе днём.",
                    image: "☀️"
                },
                {
                    word: "зима",
                    explanation: "Зима — это время года, когда идет снег и холодно.",
                    question: "Какое время года, когда идет снег?",
                    answer: "зима",
                    alternatives: ["зимой"],
                    hint: "В это время года холодно и можно кататься на санках.",
                    image: "❄️"
                },
                {
                    word: "яблоко",
                    explanation: "Яблоко — это фрукт. Оно бывает красным, зелёным или жёлтым.",
                    question: "Какой это фрукт? Скажи название.",
                    answer: "яблоко",
                    alternatives: ["яблочко"],
                    hint: "Это круглый фрукт, который растёт на дереве.",
                    image: "🍎"
                },
                {
                    word: "машина",
                    explanation: "Машина — это транспорт. Она ездит по дороге.",
                    question: "Что ездит по дороге?",
                    answer: "машина",
                    alternatives: ["автомобиль", "машинка"],
                    hint: "Это транспорт с колёсами, который возит людей.",
                    image: "🚗"
                }
            ],
            kk: [
                {
                    word: "мысық",
                    explanation: "Мысық — бұл жұмсақ жануар. Ол 'мияу' дейді.",
                    question: "Қандай жануар 'мияу' дейді?",
                    answer: "мысық",
                    alternatives: ["мысықтың", "мысықша"],
                    hint: "Бұл сүтті ұнататын жұмсақ жануар.",
                    image: "🐱"
                },
                {
                    word: "күн",
                    explanation: "Күн — бұл аспандағы жарқыраған жұлдыз. Ол сары.",
                    question: "Күн қандай түсті?",
                    answer: "сары",
                    alternatives: ["сарысы", "қызғылт"],
                    hint: "Ол жарқырап, күндіз аспанда жарқырайды.",
                    image: "☀️"
                },
                {
                    word: "қыс",
                    explanation: "Қыс — бұл қар жауған және суық болатын мезгіл.",
                    question: "Қар жауғанда қандай мезгіл?",
                    answer: "қыс",
                    alternatives: ["қыста"],
                    hint: "Бұл мезгілде суық болады және шанамен серуендеуге болады.",
                    image: "❄️"
                },
                {
                    word: "алма",
                    explanation: "Алма — бұл жеміс. Ол қызыл, жасыл немесе сары болуы мүмкін.",
                    question: "Бұл қандай жеміс? Атауын айт.",
                    answer: "алма",
                    alternatives: ["алмаша"],
                    hint: "Бұл дөңгелек жеміс, ол ағашта өседі.",
                    image: "🍎"
                },
                {
                    word: "машина",
                    explanation: "Машина — бұл көлік. Ол жолмен жүреді.",
                    question: "Жолмен не жүреді?",
                    answer: "машина",
                    alternatives: ["автомобиль", "машинка"],
                    hint: "Бұл адамдарды таситын дөңгелектері бар көлік.",
                    image: "🚗"
                }
            ]
        };
        
        this.init();
    }
    
    init() {
        // Проверка поддержки Web Speech API
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            const t = this.translations[this.currentLang];
            this.showMessage(t.browserNotSupported);
            return;
        }
        
        // Инициализация распознавания речи
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        this.recognition = new SpeechRecognition();
        this.updateRecognitionLanguage();
        this.recognition.continuous = false;
        this.recognition.interimResults = false;
        
        // Обработчики событий распознавания
        this.recognition.onstart = () => {
            this.isListening = true;
            const t = this.translations[this.currentLang];
            this.updateStatus('listening', t.statusListening);
            this.showWaveAnimation(true);
        };
        
        this.recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript.toLowerCase().trim();
            this.handleUserInput(transcript);
        };
        
        this.recognition.onerror = (event) => {
            console.error('Recognition error:', event.error);
            const t = this.translations[this.currentLang];
            if (event.error === 'no-speech') {
                // Не ругаем за молчание - это нормально
                const t = this.translations[this.currentLang];
                this.speak(t.waitingForAnswer);
                // Продолжаем слушать
                setTimeout(() => {
                    if (!this.isListening) {
                        this.startListening();
                    }
                }, 2000);
            } else if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
                this.showMessage(t.micNotAllowedShort);
                this.speak(t.micNotAllowed);
                this.stopListening();
            } else {
                this.speak(t.error);
                this.stopListening();
            }
        };
        
        this.recognition.onend = () => {
            this.stopListening();
        };
        
        // Кнопки управления
        const startBtn = document.getElementById('startBtn');
        const stopBtn = document.getElementById('stopBtn');
        
        startBtn.addEventListener('click', () => this.startListening());
        stopBtn.addEventListener('click', () => this.stopListening());
        
        // Обработчики клавиатуры на кнопках
        startBtn.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.startListening();
            }
        });
        
        stopBtn.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.stopListening();
            }
        });
        
        // Глобальные горячие клавиши - работают в любой момент без Tab
        document.addEventListener('keydown', (e) => {
            // Проверяем, что не в поле ввода
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.isContentEditable) {
                return;
            }
            
            // Space или Enter активируют кнопку
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                
                // Проверяем, какая кнопка видна
                const startBtnVisible = startBtn.style.display !== 'none' && 
                                       window.getComputedStyle(startBtn).display !== 'none';
                const stopBtnVisible = stopBtn.style.display !== 'none' && 
                                      window.getComputedStyle(stopBtn).display !== 'none';
                
                if (stopBtnVisible) {
                    this.stopListening();
                } else if (startBtnVisible) {
                    this.startListening();
                }
            }
        });
        
        // Убеждаемся, что кнопки доступны для навигации с клавиатуры
        startBtn.setAttribute('tabindex', '0');
        stopBtn.setAttribute('tabindex', '0');
        
        // Переключатель языков
        const langRuBtn = document.getElementById('langRu');
        const langKkBtn = document.getElementById('langKk');
        
        langRuBtn.addEventListener('click', () => this.switchLanguage('ru'));
        langKkBtn.addEventListener('click', () => this.switchLanguage('kk'));
        
        // Загружаем сохранённый язык
        const savedLang = localStorage.getItem('tutorLanguage') || 'ru';
        if (savedLang !== this.currentLang) {
            this.switchLanguage(savedLang);
        } else {
            this.updateLanguage();
        }
    }
    
    switchLanguage(lang) {
        if (lang === this.currentLang) {
            return;
        }
        
        const oldLang = this.currentLang;
        
        // Получаем элементы
        const messageEl = document.getElementById('tutorMessage');
        const contentEl = messageEl ? messageEl.querySelector('.message-content') : null;
        const titleEl = document.querySelector('.app-title');
        const langRuBtn = document.getElementById('langRu');
        const langKkBtn = document.getElementById('langKk');
        
        if (!langRuBtn || !langKkBtn) {
            return;
        }
        
        // Добавляем класс анимации для плавного перехода
        if (messageEl) messageEl.classList.add('language-switching');
        if (contentEl) contentEl.classList.add('language-switching');
        if (titleEl) titleEl.classList.add('language-switching');
        
        // Убираем активный класс с обеих кнопок
        langRuBtn.classList.remove('active');
        langKkBtn.classList.remove('active');
        
        // Небольшая задержка для плавности анимации
        setTimeout(() => {
            this.currentLang = lang;
            localStorage.setItem('tutorLanguage', lang);
            
            // Обновляем язык распознавания
            this.updateRecognitionLanguage();
            
            // Добавляем активный класс с анимацией сразу
            langRuBtn.classList.toggle('active', lang === 'ru');
            langKkBtn.classList.toggle('active', lang === 'kk');
            
            // Обновляем интерфейс
            this.updateLanguage();
            
            // Если есть активный урок, обновляем его на новый язык
            if (this.currentTask) {
                const newLessons = this.lessons[lang];
                const oldLessons = this.lessons[oldLang];
                
                // Находим индекс текущего урока в старом языке
                const currentIndex = oldLessons.findIndex(lesson => 
                    lesson.word === this.currentTask.word
                );
                
                // Если нашли соответствующий урок, переключаемся на него
                if (currentIndex >= 0 && currentIndex < newLessons.length) {
                    this.currentTask = newLessons[currentIndex];
                    
                    // Обновляем отображение в зависимости от шага урока
                    setTimeout(() => {
                        if (this.lessonStep === 0) {
                            const explanation = this.currentTask.explanation;
                            this.showMessage(`${this.currentTask.image} ${explanation}`);
                        } else {
                            const question = this.currentTask.question;
                            this.showMessage(`${this.currentTask.image} ${question}`);
                        }
                    }, 100);
                } else {
                    // Если не нашли, начинаем новый урок
                    this.currentTask = null;
                    this.lessonStep = 0;
                }
            }
            
            // Убираем класс анимации после обновления
            setTimeout(() => {
                messageEl.classList.remove('language-switching');
                contentEl.classList.remove('language-switching');
                titleEl.classList.remove('language-switching');
            }, 300);
        }, 150);
    }
    
    
    updateRecognitionLanguage() {
        if (this.recognition) {
            this.recognition.lang = this.currentLang === 'ru' ? 'ru-RU' : 'kk-KZ';
        }
    }
    
    updateLanguage() {
        const t = this.translations[this.currentLang];
        
        // Обновляем заголовок с анимацией
        const titleEl = document.querySelector('.app-title');
        titleEl.classList.add('language-switching');
        setTimeout(() => {
            titleEl.textContent = `🌟 ${t.title}`;
            setTimeout(() => {
                titleEl.classList.remove('language-switching');
            }, 50);
        }, 100);
        
        // Обновляем статус
        this.updateStatus('ready', t.statusReady);
        
        // Обновляем кнопки с плавной анимацией
        const startBtnText = document.querySelector('#startBtn .btn-text');
        const stopBtnText = document.querySelector('#stopBtn .btn-text');
        startBtnText.style.opacity = '0.5';
        stopBtnText.style.opacity = '0.5';
        setTimeout(() => {
            startBtnText.textContent = t.startBtn;
            stopBtnText.textContent = t.stopBtn;
            startBtnText.style.opacity = '1';
            stopBtnText.style.opacity = '1';
        }, 150);
        
        // Обновляем метки
        const helpTitle = document.querySelector('.help-title');
        if (helpTitle) {
            helpTitle.style.opacity = '0.5';
            setTimeout(() => {
                helpTitle.textContent = t.commandsTitle;
                helpTitle.style.opacity = '1';
            }, 150);
        }
        
        // Обновляем команды с анимацией
        const commands = document.querySelectorAll('.command-item');
        commands.forEach((cmd, index) => {
            cmd.style.opacity = '0.5';
            cmd.style.transform = 'translateY(-5px)';
        });
        
        setTimeout(() => {
            if (this.currentLang === 'ru') {
                if (commands[0]) commands[0].querySelector('.command-word').textContent = '"дальше"';
                if (commands[1]) commands[1].querySelector('.command-word').textContent = '"повтори"';
                if (commands[2]) commands[2].querySelector('.command-word').textContent = '"помоги"';
                if (commands[3]) commands[3].querySelector('.command-word').textContent = '"ещё раз"';
                if (commands[4]) commands[4].querySelector('.command-word').textContent = '"стоп"';
            } else {
                if (commands[0]) commands[0].querySelector('.command-word').textContent = '"келесі"';
                if (commands[1]) commands[1].querySelector('.command-word').textContent = '"қайтала"';
                if (commands[2]) commands[2].querySelector('.command-word').textContent = '"көмектес"';
                if (commands[3]) commands[3].querySelector('.command-word').textContent = '"қайта"';
                if (commands[4]) commands[4].querySelector('.command-word').textContent = '"тоқта"';
            }
            if (commands[0]) commands[0].querySelector('.command-desc').textContent = `— ${t.commandNext}`;
            if (commands[1]) commands[1].querySelector('.command-desc').textContent = `— ${t.commandRepeat}`;
            if (commands[2]) commands[2].querySelector('.command-desc').textContent = `— ${t.commandHelp}`;
            if (commands[3]) commands[3].querySelector('.command-desc').textContent = `— ${t.commandAgain}`;
            if (commands[4]) commands[4].querySelector('.command-desc').textContent = `— ${t.commandStop}`;
            
            commands.forEach((cmd) => {
                cmd.style.opacity = '1';
                cmd.style.transform = 'translateY(0)';
                cmd.style.transition = 'all 0.3s ease';
            });
        }, 200);
    }
    
    startListening() {
        if (this.isSpeaking) {
            this.synthesis.cancel();
            this.isSpeaking = false;
        }
        
        if (!this.isListening && this.recognition) {
            try {
                this.recognition.start();
                document.getElementById('startBtn').style.display = 'none';
                document.getElementById('stopBtn').style.display = 'flex';
            } catch (e) {
                console.error('Error starting recognition:', e);
                const t = this.translations[this.currentLang];
                if (e.name === 'NotAllowedError' || e.message.includes('not allowed')) {
                    this.showMessage(t.micNotAllowedShort);
                    this.speak(t.micNotAllowed);
                } else {
                    this.showMessage(t.startError);
                }
            }
        }
    }
    
    stopListening() {
        this.isListening = false;
        const t = this.translations[this.currentLang];
        this.updateStatus('ready', t.statusReady);
        this.showWaveAnimation(false);
        document.getElementById('startBtn').style.display = 'flex';
        document.getElementById('stopBtn').style.display = 'none';
        
        if (this.recognition) {
            try {
                this.recognition.stop();
            } catch (e) {
                // Игнорируем ошибки при остановке
            }
        }
    }
    
    handleUserInput(input) {
        // Универсальные команды интерфейса (номера/клик/скролл/назад) — не мешают обучению
        if (window.VoiceUI && window.VoiceUI.handleTranscript(input, true)) {
            return;
        }

        this.showUserResponse(input);
        
        // Обработка команд
        if (this.isCommand(input)) {
            this.handleCommand(input);
            return;
        }
        
        // Обработка подтверждения (да/нет)
        if (this.waitingForConfirmation) {
            this.handleConfirmation(input);
            return;
        }
        
        // Обработка ответа на задание
        if (this.currentTask) {
            this.checkAnswer(input);
        } else {
            // Если нет активного задания, предлагаем начать
            const t = this.translations[this.currentLang];
            this.speak(t.noTask);
        }
    }
    
    isCommand(input) {
        const commandsRu = ['дальше', 'повтори', 'помоги', 'помощь', 'стоп', 'я устал', 'устал', 'пауза', 'следующ', 'ещё раз', 'еще раз', 'заново'];
        const commandsKk = ['келесі', 'қайтала', 'көмектес', 'көмек', 'тоқта', 'шаршадым', 'шарша', 'кідіріс', 'кейін', 'қайта', 'тағы'];
        const commands = this.currentLang === 'ru' ? commandsRu : commandsKk;
        return commands.some(cmd => input.includes(cmd));
    }
    
    handleCommand(command) {
        if (this.currentLang === 'ru') {
            if (command.includes('дальше') || command.includes('следующ')) {
                this.nextStep();
            } else if (command.includes('повтори')) {
                this.repeatTask();
            } else if (command.includes('помоги') || command.includes('помощь')) {
                this.giveHint();
            } else if (command.includes('стоп') || command.includes('устал') || command.includes('пауза')) {
                this.takeBreak();
            } else if (command.includes('ещё раз') || command.includes('еще раз') || command.includes('заново')) {
                this.repeatLesson();
            }
        } else {
            if (command.includes('келесі') || command.includes('кейін')) {
                this.nextStep();
            } else if (command.includes('қайтала')) {
                this.repeatTask();
            } else if (command.includes('көмектес') || command.includes('көмек')) {
                this.giveHint();
            } else if (command.includes('тоқта') || command.includes('шарша') || command.includes('кідіріс')) {
                this.takeBreak();
            } else if (command.includes('қайта') || command.includes('тағы')) {
                this.repeatLesson();
            }
        }
    }
    
    nextStep() {
        // Если нет текущего урока, начинаем новый
        if (!this.currentTask) {
            this.startNewLesson();
            return;
        }
        
        // Переходим к следующему шагу урока
        if (this.lessonStep === 0) {
            // Шаг 1: Задаём вопрос
            this.lessonStep = 1;
            this.attemptsCount = 0;
            const message = this.currentTask.question;
            this.showMessage(`${this.currentTask.image} ${message}`);
            this.speak(message);
        } else {
            // Урок завершён, начинаем следующий
            this.completeLesson();
        }
    }
    
    startNewLesson() {
        const currentLessons = this.lessons[this.currentLang];
        if (this.taskIndex >= currentLessons.length) {
            this.taskIndex = 0; // Начинаем заново
        }
        
        this.currentTask = currentLessons[this.taskIndex];
        this.taskIndex++;
        this.lessonStep = 0;
        this.attemptsCount = 0;
        this.difficultyLevel = 1;
        this.waitingForConfirmation = false;
        this.suggestedAnswer = null;
        
        // Шаг 0: Объясняем слово
        const explanation = this.currentTask.explanation;
        this.showMessage(`${this.currentTask.image} ${explanation}`);
        this.speak(explanation);
        
        // Через 2 секунды предлагаем перейти к вопросу
        setTimeout(() => {
            const t = this.translations[this.currentLang];
            const nextStepText = this.currentLang === 'ru'
                ? "Скажи 'дальше', чтобы ответить на вопрос."
                : "Сұраққа жауап беру үшін 'келесі' деп айт.";
            this.speak(nextStepText);
        }, 2000);
    }
    
    completeLesson() {
        const t = this.translations[this.currentLang];
        this.showMessage(`✅ ${t.lessonComplete}`);
        this.speak(t.lessonComplete);
        
        this.currentTask = null;
        this.lessonStep = 0;
        this.attemptsCount = 0;
        this.difficultyLevel = 1;
        this.waitingForConfirmation = false;
        this.suggestedAnswer = null;
        
        // Через 2 секунды предлагаем следующий урок
        setTimeout(() => {
            const t = this.translations[this.currentLang];
            const nextLessonText = this.currentLang === 'ru' 
                ? "Скажи 'дальше', чтобы начать следующий урок."
                : "'Келесі' деп айтып, келесі сабақты баста.";
            this.speak(nextLessonText);
        }, 2000);
    }
    
    repeatLesson() {
        if (this.currentTask) {
            // Начинаем урок заново
            this.lessonStep = 0;
            this.attemptsCount = 0;
            this.difficultyLevel = 1;
            this.waitingForConfirmation = false;
            this.suggestedAnswer = null;
            
            const explanation = this.currentTask.explanation;
            this.showMessage(`${this.currentTask.image} ${explanation}`);
            this.speak(explanation);
        } else {
            const t = this.translations[this.currentLang];
            this.speak(t.noTaskStart);
        }
    }
    
    repeatTask() {
        const t = this.translations[this.currentLang];
        if (this.currentTask) {
            if (this.lessonStep === 0) {
                // Повторяем объяснение
                const explanation = this.currentTask.explanation;
                this.showMessage(`${this.currentTask.image} ${explanation}`);
                this.speak(explanation);
            } else {
                // Повторяем вопрос
                const message = this.currentTask.question;
                this.showMessage(`${this.currentTask.image} ${message}`);
                this.speak(message);
            }
        } else {
            this.speak(t.noTaskStart);
        }
    }
    
    giveHint() {
        const t = this.translations[this.currentLang];
        if (this.currentTask) {
            const hint = this.currentTask.hint;
            this.showMessage(`${this.currentTask.image} ${hint}`);
            this.speak(hint);
        } else {
            this.speak(t.noTaskStart);
        }
    }
    
    takeBreak() {
        const t = this.translations[this.currentLang];
        this.currentTask = null;
        this.lessonStep = 0;
        this.attemptsCount = 0;
        this.difficultyLevel = 1;
        this.waitingForConfirmation = false;
        this.suggestedAnswer = null;
        this.showMessage(t.break);
        this.speak(t.break);
    }
    
    checkAnswer(userAnswer) {
        if (!this.currentTask || this.lessonStep !== 1) return;
        
        // Всегда хвалим за попытку
        const t = this.translations[this.currentLang];
        
        // Если ответ пустой или очень короткий - это тоже попытка
        if (!userAnswer || userAnswer.trim().length < 2) {
            this.attemptsCount++;
            this.speak(t.goodAttempt + " " + t.waitingForAnswer);
            
            // После 2 попыток предлагаем упростить
            if (this.attemptsCount >= 2) {
                setTimeout(() => {
                    this.speak(t.simplified);
                    this.simplifyTask();
                }, 1500);
            }
            return;
        }
        
        const correctAnswer = this.currentTask.answer.toLowerCase();
        const alternatives = this.currentTask.alternatives || [];
        const allAnswers = [correctAnswer, ...alternatives.map(a => a.toLowerCase())];
        
        // Проверяем, содержит ли ответ правильный вариант (более мягкая проверка)
        const isCorrect = allAnswers.some(ans => {
            const userLower = userAnswer.toLowerCase().trim();
            return userLower.includes(ans) || ans.includes(userLower) || 
                   this.fuzzyMatch(userLower, ans);
        });
        
        if (isCorrect) {
            // Правильный ответ - хвалим
            const praise = t.praises[Math.floor(Math.random() * t.praises.length)];
            this.showMessage(`✅ ${praise}`);
            this.speak(praise);
            
            // Завершаем урок
            setTimeout(() => {
                this.completeLesson();
            }, 2000);
        } else {
            // Неправильный ответ - мягко помогаем, всегда хвалим за попытку
            this.attemptsCount++;
            this.speak(t.goodAttempt);
            
            // Пробуем уточнить, если ответ похож
            if (this.isSimilarAnswer(userAnswer, correctAnswer)) {
                this.waitingForConfirmation = true;
                this.suggestedAnswer = correctAnswer;
                setTimeout(() => {
                    this.speak(`${t.clarify} '${correctAnswer}'? ${t.clarifyQuestion}`);
                    // Продолжаем слушать для подтверждения
                    setTimeout(() => {
                        if (!this.isListening) {
                            this.startListening();
                        }
                    }, 500);
                }, 1000);
            } else {
                // Даём подсказку
                setTimeout(() => {
                    this.speak(this.currentTask.hint);
                }, 1000);
            }
            
            // После 3 попыток упрощаем задание
            if (this.attemptsCount >= 3) {
                setTimeout(() => {
                    this.speak(t.simplified);
                    this.simplifyTask();
                }, 2000);
            }
        }
    }
    
    fuzzyMatch(str1, str2) {
        // Простое сравнение на похожесть (первые 3 символа)
        const s1 = str1.substring(0, 3);
        const s2 = str2.substring(0, 3);
        return s1 === s2;
    }
    
    isSimilarAnswer(userAnswer, correctAnswer) {
        // Проверяем, похож ли ответ (первые буквы совпадают)
        const userStart = userAnswer.toLowerCase().substring(0, 2);
        const correctStart = correctAnswer.substring(0, 2);
        return userStart === correctStart;
    }
    
    simplifyTask() {
        // Упрощаем задание - даём больше подсказок
        this.difficultyLevel = Math.max(1, this.difficultyLevel - 1);
        const t = this.translations[this.currentLang];
        
        // Повторяем вопрос с дополнительной подсказкой
        const simplifiedQuestion = `${this.currentTask.question} ${this.currentTask.hint}`;
        this.showMessage(`${this.currentTask.image} ${simplifiedQuestion}`);
        this.speak(simplifiedQuestion);
    }
    
    handleConfirmation(input) {
        const t = this.translations[this.currentLang];
        const yesWords = this.currentLang === 'ru' ? ['да', 'ага', 'угу', 'давай'] : ['иә', 'жарайды', 'кәне'];
        const noWords = this.currentLang === 'ru' ? ['нет', 'не', 'неа'] : ['жоқ', 'емес'];
        
        const isYes = yesWords.some(word => input.includes(word));
        const isNo = noWords.some(word => input.includes(word));
        
        if (isYes && this.suggestedAnswer) {
            // Подтвердили правильный ответ
            const praise = t.praises[Math.floor(Math.random() * t.praises.length)];
            this.showMessage(`✅ ${praise}`);
            this.speak(praise);
            
            this.waitingForConfirmation = false;
            this.suggestedAnswer = null;
            
            // Завершаем урок
            setTimeout(() => {
                this.completeLesson();
            }, 2000);
        } else if (isNo) {
            // Не подтвердили - продолжаем помогать
            this.waitingForConfirmation = false;
            this.suggestedAnswer = null;
            this.speak(t.goodAttempt + " " + this.currentTask.hint);
        } else {
            // Не поняли ответ - уточняем
            this.speak(t.clarifyQuestion);
        }
    }
    
    speak(text) {
        if (this.isSpeaking) {
            this.synthesis.cancel();
        }
        
        this.isSpeaking = true;
        const t = this.translations[this.currentLang];
        this.updateStatus('speaking', t.statusSpeaking);
        
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = this.currentLang === 'ru' ? 'ru-RU' : 'kk-KZ';
        utterance.rate = 0.85; // Медленнее для детей с моторными нарушениями
        utterance.pitch = 1.1;
        utterance.volume = 1.0;

        const voices = this.synthesis.getVoices();
        const savedVoiceName = localStorage.getItem('smart_ai_prefs_v1') ? JSON.parse(localStorage.getItem('smart_ai_prefs_v1')).voice : null;
        let preferred = null;
        if (utterance.lang.startsWith('ru')) {
            preferred = voices.find(v => v.name.toLowerCase().includes('pavel') || 
                                     v.name.toLowerCase().includes('dmitry') || 
                                     v.name.toLowerCase().includes('dmitri') ||
                                     v.name.toLowerCase().includes('ivan'));
        }

        // 2. Any Male
        if (!preferred) {
            const baseLang = String(utterance.lang).split('-')[0];
            preferred = voices.find(v => v.lang.startsWith(baseLang) && (v.name.toLowerCase().includes('male') || v.name.toLowerCase().includes('man')));
        }

        // 3. Avoid Female
        if (!preferred && utterance.lang.startsWith('ru')) {
             preferred = voices.find(v => v.lang.startsWith('ru') && 
                                     !v.name.toLowerCase().includes('irina') && 
                                     !v.name.toLowerCase().includes('elena') && 
                                     !v.name.toLowerCase().includes('zira') &&
                                     !v.name.toLowerCase().includes('female') &&
                                     !v.name.toLowerCase().includes('tatiana'));
        }

        // 4. Saved (if not female)
        if (!preferred && savedVoiceName) {
            const sv = savedVoiceName.toLowerCase();
            if (!sv.includes('irina') && !sv.includes('elena')) {
                preferred = voices.find(v => v.name === savedVoiceName);
            }
        }

        // 5. Fallback
        if (!preferred) {
            const baseLang = String(utterance.lang).split('-')[0];
            preferred = voices.find(v => v.lang.startsWith(baseLang));
        }
        if (preferred) utterance.voice = preferred;
        
        utterance.onend = () => {
            this.isSpeaking = false;
            this.updateStatus('ready', 'Готов слушать');
            
            // Автоматически начинаем слушать после того, как закончили говорить
            // Но даём больше времени для ответа (не торопим)
            if (this.currentTask && this.lessonStep === 1) {
                setTimeout(() => {
                    if (!this.isListening) {
                        this.startListening();
                    }
                }, 1000); // Больше времени на обдумывание
            }
        };
        
        utterance.onerror = (event) => {
            console.error('Speech synthesis error:', event);
            this.isSpeaking = false;
            const t = this.translations[this.currentLang];
            this.updateStatus('ready', t.statusReady);
        };
        
        this.synthesis.speak(utterance);
    }
    
    showMessage(text) {
        const messageEl = document.getElementById('tutorMessage');
        const contentEl = messageEl.querySelector('.message-content');
        
        if (!text || text.trim() === '') {
            // Скрываем блок, если текст пустой
            messageEl.style.display = 'none';
            contentEl.innerHTML = '';
        } else {
            // Показываем блок и добавляем текст
            messageEl.style.display = 'flex';
            
            // Извлекаем эмодзи из начала текста, если есть
            const emojiMatch = text.match(/^[\u{1F300}-\u{1F9FF}]|[\u{2600}-\u{26FF}]|[\u{2700}-\u{27BF}]/u);
            let emoji = '';
            let cleanText = text;
            
            if (emojiMatch) {
                emoji = emojiMatch[0];
                cleanText = text.replace(emoji, '').trim();
            }
            
            contentEl.innerHTML = `<p>${emoji ? emoji + ' ' : ''}${cleanText}</p>`;
        }
    }
    
    showUserResponse(text) {
        // Блок ответа пользователя удалён
        // Можно добавить логирование в консоль для отладки
        // console.log('User said:', text);
    }
    
    updateStatus(status, text) {
        const dot = document.getElementById('statusDot');
        const textEl = document.getElementById('statusText');
        
        dot.className = 'status-dot ' + status;
        textEl.textContent = text;
    }
    
    showWaveAnimation(show) {
        const waveEl = document.getElementById('waveAnimation');
        if (show) {
            waveEl.parentElement.classList.add('active');
        } else {
            waveEl.parentElement.classList.remove('active');
        }
    }
}

// Инициализация при загрузке страницы
let tutorInstance = null;

function initTutor() {
    if (!tutorInstance) {
        tutorInstance = new VoiceTutor();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    // Инициализируем сразу
    initTutor();

    // Слушаем команды от кнопки «Нажми и говори» (push-to-talk)
    window.addEventListener('voice-command', (e) => {
        if (tutorInstance) tutorInstance.handleUserInput(e.detail.transcript);
    });
    
    // Также ждём загрузки голосов для лучшей поддержки
    if (speechSynthesis.onvoiceschanged !== undefined) {
        speechSynthesis.onvoiceschanged = () => {
            initTutor();
        };
    }
    
    // Дополнительная попытка через небольшую задержку
    setTimeout(() => {
        initTutor();
    }, 100);
});
