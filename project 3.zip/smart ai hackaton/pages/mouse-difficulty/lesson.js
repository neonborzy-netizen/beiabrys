// Система уроков в стиле Duolingo
// Для детей с моторными нарушениями

// Голосовой помощник для уроков
class LessonVoiceAssistant {
    constructor(lessonSystem) {
        this.lessonSystem = lessonSystem;
        this.recognition = null;
        this.isListening = false;
        this.isActive = false;
        this.currentOptions = [];
        this.lastSpokenForQuestionIndex = -1;
        this.pendingSpeakTimeout = null;
        this.init();
    }
    
    init() {
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            console.log('Голосовое управление не поддерживается');
            return;
        }
        
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        this.recognition = new SpeechRecognition();
        this.recognition.lang = this.lessonSystem.currentLang === 'ru' ? 'ru-RU' : 'kk-KZ';
        this.recognition.continuous = true;
        this.recognition.interimResults = false;
        
        this.recognition.onresult = (event) => {
            const transcript = event.results[event.results.length - 1][0].transcript.toLowerCase().trim();
            this.handleVoiceCommand(transcript);
        };
        
        this.recognition.onerror = (event) => {
            if (event.error === 'no-speech') {
                return;
            } else if (event.error === 'not-allowed') {
                console.log('Разрешение на микрофон не дано');
                this.stop();
            }
        };
        
        this.recognition.onend = () => {
            if (!this.isActive) return;
            // Всегда перезапускаем, чтобы после неверного ответа команда «продолжить» распознавалась
            setTimeout(() => {
                if (this.isActive && this.recognition) {
                    try {
                        this.recognition.start();
                        this.isListening = true;
                    } catch (e) {
                        console.log('Ошибка перезапуска:', e);
                    }
                }
            }, 150);
        };

        // Запускаем микрофон только если в настройках включено «Голосовое управление»
        try {
            const s = localStorage.getItem('appSettings');
            const prefs = s ? JSON.parse(s) : {};
            if (prefs.voiceNavigation === true) this.start();
        } catch (e) {}
    }
    
    start() {
        if (!this.recognition) return;
        
        this.isActive = true;
        if (!this.isListening) {
            try {
                this.recognition.start();
                this.isListening = true;
            } catch (e) {
                console.log('Ошибка запуска:', e);
            }
        }
    }
    
    stop() {
        this.isActive = false;
        this.isListening = false;
        if (this.recognition) {
            try {
                this.recognition.stop();
            } catch (e) {
                // Игнорируем ошибки
            }
        }
    }
    
    handleVoiceCommand(transcript) {
        const t = transcript.toLowerCase().trim();

        // Экран завершения урока: «Следующий урок» и «Вернуться»
        const completeEl = document.getElementById('lessonComplete');
        if (completeEl && !completeEl.classList.contains('hidden')) {
            const nextKeywords = ['следующий урок', 'следующий', 'дальше', 'вперёд', 'вперед', 'келесі сабақ', 'келесі', 'жалғастыру', 'жалғастыр'];
            const backKeywords = ['вернуться', 'вернись', 'назад', 'к модулям', 'к курсам', 'оралу', 'артқа', 'қайту'];
            if (nextKeywords.some(kw => t.includes(kw))) {
                const nextBtn = document.getElementById('nextLessonBtn');
                if (nextBtn) {
                    nextBtn.click();
                    this.speak(this.lessonSystem.currentLang === 'ru' ? 'Следующий урок' : 'Келесі сабақ');
                }
                return;
            }
            if (backKeywords.some(kw => t.includes(kw))) {
                const backBtn = document.getElementById('backToModulesBtn');
                if (backBtn) {
                    backBtn.click();
                    this.speak(this.lessonSystem.currentLang === 'ru' ? 'Возвращаюсь' : 'Оралу');
                }
                return;
            }
        }

        // Кнопки «Проверить» и «Продолжить» — реагируем на голос в первую очередь
        const checkKeywords = ['проверить', 'проверь', 'проверка', 'проверяю', 'тексеру', 'тексер'];
        const continueKeywords = [
            'продолжить', 'продолжи', 'продольжить', 'продольжи', 'продолжть', 'продолж', 'продолжить',
            'дальше', 'вперёд', 'вперед', 'следующий', 'жалғастыру', 'жалғастыр', 'келесі'
        ];
        const isContinueCommand = continueKeywords.some(kw => t.includes(kw)) ||
            (t.includes('продолж') && t.length <= 14) ||
            (t.includes('продольж') && t.length <= 14); // «продолжить»/«продольжить» и ошибки распознавания
        if (checkKeywords.some(kw => t.includes(kw))) {
            const checkBtn = document.getElementById('checkBtn');
            if (checkBtn && !checkBtn.classList.contains('hidden') && !checkBtn.disabled) {
                checkBtn.click();
                this.speak(this.lessonSystem.currentLang === 'ru' ? 'Проверяю' : 'Тексеруде');
                return;
            }
        }
        if (isContinueCommand) {
            const continueBtn = document.getElementById('continueBtn');
            if (continueBtn && !continueBtn.classList.contains('hidden')) {
                continueBtn.click();
                this.speak(this.lessonSystem.currentLang === 'ru' ? 'Продолжаем' : 'Жалғастыру');
                return;
            }
        }

        const lang = this.lessonSystem.currentLang;
        const question = this.lessonSystem.questions[this.lessonSystem.currentQuestionIndex];

        // Для вводных уроков используем минимальные команды
        if (question && question.type === 'intro-screen' && question.expectedCommand) {
            this.handleMinimalCommand(transcript, question);
            return;
        }

        // Сначала выбор по тексту варианта: что написано на кнопке — то и говорим («па па», «ка ша», «ма ма» и т.д.)
        if (this.selectAnswerByText(transcript)) return;

        // Для счёта и чисел: «один», «два», «пять» или «вариант один» — выбор по номеру
        const numberMatch = this.extractNumber(transcript, lang);
        if (numberMatch !== null && this.currentOptions.length > 0) {
            const answerKeywords = lang === 'ru'
                ? ['вариант', 'ответ', 'выбери', 'выбрать', 'номер', 'цифра', 'нажми', 'нажать', 'первый', 'второй', 'третий', 'четвёртый', 'пятый', 'шестой', 'седьмой', 'восьмой', 'девятый', 'десятый', 'один', 'два', 'три', 'четыре', 'пять', 'шесть', 'семь', 'восемь', 'девять', 'десять']
                : ['нұсқа', 'жауап', 'таңдау', 'таңда', 'номер', 'сан', 'бас', 'бірінші', 'екінші', 'үшінші', 'төртінші', 'бесінші', 'бір', 'екі', 'үш', 'төрт', 'бес'];
            const trimmed = t.replace(/\s+/g, ' ');
            const isShortNumberPhrase = /^(один|два|три|четыре|пять|шесть|семь|восемь|девять|десять|первый|второй|третий|четвёртый|пятый|шестой|седьмой|восьмой|девятый|десятый|раз|1|2|3|4|5|6|7|8|9|10)$/.test(trimmed);
            if (answerKeywords.some(kw => t.includes(kw)) || isShortNumberPhrase) {
                this.selectAnswerByNumber(numberMatch);
                return;
            }
        }

        // Универсальные команды интерфейса (номера/клик/скролл/назад) — после выбора варианта ответа
        if (window.VoiceUI && window.VoiceUI.handleTranscript(transcript, true)) {
            return;
        }
        
        // Команды навигации
        const navKeywords = lang === 'ru'
            ? ['повтори', 'повторить', 'еще раз', 'ещё раз']
            : ['қайтала', 'қайталау', 'тағы бір рет'];
        
        if (navKeywords.some(kw => transcript.includes(kw))) {
            this.repeatQuestion();
            return;
        }
        
        // Команда помощи
        const helpKeywords = lang === 'ru'
            ? ['помощь', 'помоги', 'подсказка', 'что делать']
            : ['көмек', 'көмектес', 'кеңес', 'не істеу керек'];
        
        if (helpKeywords.some(kw => transcript.includes(kw))) {
            this.showHelp();
            return;
        }
    }
    
    handleMinimalCommand(transcript, question) {
        const expectedCommands = question.expectedCommand || [];
        const acceptFuzzy = question.acceptFuzzy || false;
        
        // Проверяем точное совпадение
        for (const cmd of expectedCommands) {
            if (transcript.includes(cmd.toLowerCase())) {
                this.processMinimalCommand(cmd, question);
                return;
            }
        }
        
        // Если разрешено нечёткое распознавание
        if (acceptFuzzy) {
            // Проверяем частичные совпадения
            for (const cmd of expectedCommands) {
                const cmdLower = cmd.toLowerCase();
                // Проверяем первые 3-4 символа команды
                if (cmdLower.length >= 3 && transcript.includes(cmdLower.substring(0, 3))) {
                    this.processMinimalCommand(cmd, question);
                    return;
                }
            }
            
            // Для чисел проверяем словами
            const numberMatch = this.extractNumber(transcript, this.lessonSystem.currentLang);
            if (numberMatch !== null) {
                // Проверяем, есть ли в ожидаемых командах число
                for (const cmd of expectedCommands) {
                    if (cmd.includes(String(numberMatch)) || 
                        (numberMatch === 1 && (cmd.includes('первый') || cmd.includes('один'))) ||
                        (numberMatch === 2 && (cmd.includes('второй') || cmd.includes('два')))) {
                        this.processMinimalCommand(cmd, question);
                        return;
                    }
                }
            }
        }
        
        // Если команда не распознана, повторяем вопрос
        if (question.voiceText) {
            setTimeout(() => {
                this.speak(question.voiceText);
            }, 1000);
        }
    }
    
    processMinimalCommand(command, question) {
        // Обрабатываем команду
        if (command === 'стоп' || command.includes('стоп') || command.includes('отдохнуть')) {
            // Выход из урока
            this.speak(this.lessonSystem.currentLang === 'ru' 
                ? 'Хорошо. Отдыхай. Возвращайся когда захочешь.'
                : 'Жақсы. Демалу. Қашан қаласаң, қайта кел.');
            setTimeout(() => {
                window.location.href = 'index.html';
            }, 2000);
        } else if (command === 'дальше' || command.includes('дальше') || command.includes('ещё раз')) {
            // Продолжаем урок
            this.lessonSystem.continueLesson();
        } else {
            // Для других команд просто продолжаем
            if (!question.noEvaluation) {
                // Если это не вводный урок, обрабатываем как ответ
                this.lessonSystem.userAnswer = command;
            }
            // Продолжаем через небольшую задержку
            setTimeout(() => {
                this.lessonSystem.continueLesson();
            }, 1000);
        }
    }
    
    setupMinimalCommands(expectedCommands, acceptFuzzy) {
        this.minimalCommands = expectedCommands;
        this.acceptFuzzy = acceptFuzzy || false;
    }
    
    extractNumber(transcript, lang) {
        const text = transcript.toLowerCase().trim();
        const numberWords = lang === 'ru'
            ? {
                'десятый': 10, 'девятый': 9, 'восьмой': 8, 'седьмой': 7, 'шестой': 6, 'пятый': 5,
                'четвёртый': 4, 'четвертый': 4, 'третий': 3, 'второй': 2, 'первый': 1,
                'десять': 10, 'девять': 9, 'восемь': 8, 'семь': 7, 'шесть': 6, 'пять': 5,
                'четыре': 4, 'три': 3, 'два': 2, 'один': 1, 'одна': 1, 'одно': 1, 'раз': 1
            }
            : {
                'оныншы': 10, 'тоғызыншы': 9, 'сегізинші': 8, 'жетінші': 7, 'алтыншы': 6, 'бесінші': 5,
                'төртінші': 4, 'үшінші': 3, 'екінші': 2, 'бірінші': 1,
                'он': 10, 'тоғыз': 9, 'сегіз': 8, 'жеті': 7, 'алты': 6, 'бес': 5,
                'төрт': 4, 'үш': 3, 'екі': 2, 'бір': 1
            };
        for (const [word, num] of Object.entries(numberWords)) {
            if (text.includes(word)) return num;
        }
        // "вариант 1", "вариант 2", "ответ 3" и т.д.
        const afterKeyword = text.match(/(?:вариант|ответ|номер|цифра)\s*([1-9]|10)/);
        if (afterKeyword) return parseInt(afterKeyword[1], 10);
        const digitMatch = text.match(/\b([1-9]|10)\b/) || text.match(/([1-9]|10)/);
        if (digitMatch) return parseInt(digitMatch[1], 10);
        return null;
    }

    /** Нормализация для сравнения речи с текстом варианта (без дефисов, пробелы схлопнуты). */
    normalizeOptionForSpeech(s) {
        return String(s || '')
            .toLowerCase()
            .replace(/-/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
    }

    /** Выбор варианта по тексту: распознаёт то, что написано на кнопке (например «па па», «ка ша», или «пять» для кнопки «5»). */
    selectAnswerByText(transcript) {
        if (!this.currentOptions.length) return false;
        const t = this.normalizeOptionForSpeech(transcript);
        if (!t) return false;
        const tCompact = t.replace(/\s/g, '');
        const lang = this.lessonSystem.currentLang;
        for (let i = 0; i < this.currentOptions.length; i++) {
            const opt = this.currentOptions[i];
            const optNorm = this.normalizeOptionForSpeech(opt);
            const optCompact = optNorm.replace(/\s/g, '');
            let match = optNorm === t || t === optNorm ||
                t.includes(optNorm) || optNorm.includes(t) ||
                tCompact === optCompact || tCompact.includes(optCompact) || optCompact.includes(tCompact);
            if (!match && /^\d+$/.test(String(opt).trim())) {
                const num = this.extractNumber(transcript, lang);
                if (num !== null && parseInt(opt, 10) === num) match = true;
            }
            if (match && optNorm.length >= 1) {
                const button = document.querySelector(`.option-btn[data-index="${i}"], .image-option-btn[data-index="${i}"]`);
                if (button && !button.disabled) {
                    button.click();
                    this.speak(this.lessonSystem.currentLang === 'ru' ? 'Выбрано' : 'Таңдалды');
                    return true;
                }
            }
        }
        return false;
    }
    
    selectAnswerByNumber(number) {
        const index = number - 1;
        if (index >= 0 && index < this.currentOptions.length) {
            const button = document.querySelector(`[data-index="${index}"]`);
            if (button && !button.disabled) {
                button.click();
                this.speak(this.lessonSystem.currentLang === 'ru' ? 'Выбрано' : 'Таңдалды');
            }
        }
    }
    
    repeatQuestion() {
        const question = this.lessonSystem.questions[this.lessonSystem.currentQuestionIndex];
        if (question) {
            this.speakQuestion(question);
        }
    }
    
    showHelp() {
        const lang = this.lessonSystem.currentLang;
        const helpText = lang === 'ru'
            ? 'Скажи то, что написано на кнопке (например «па па», «ка ша»), или число для счёта. Потом «проверить», после результата «продолжить». «Повтори» — услышите вопрос снова.'
            : 'Батырмада жазылғанды айтыңыз (мысалы «па па», «ка ша») немесе санды. Содан кейін «тексеру», нәтижеден кейін «жалғастыру». «Қайтала» — сұрақты қайталау.';
        this.speak(helpText);
    }
    
    speakQuestion(question) {
        let text = question.question || '';
        
        if (question.type === 'multiple-choice' && question.options) {
            text += '. ' + (this.lessonSystem.currentLang === 'ru' ? 'Скажи то, что написано на кнопке: ' : 'Батырмада жазылғанды айт: ');
            text += question.options.map(opt => opt).join('. ');
        } else if (question.type === 'image-choice' && question.options) {
            text += '. ' + (this.lessonSystem.currentLang === 'ru' 
                ? `Выберите картинку. Варианты: ${question.options.length}`
                : `Суретті таңдаңыз. Нұсқалар: ${question.options.length}`);
        } else if (question.type === 'counting' && question.images) {
            text += '. ' + (this.lessonSystem.currentLang === 'ru'
                ? `Посчитайте картинки. Всего: ${question.images.length}`
                : `Суреттерді санаңыз. Барлығы: ${question.images.length}`);
        } else if (question.type === 'addition') {
            text = question.question || '';
        }
        
        this.speak(text);
    }

    /** Одна фраза: прогресс + вопрос. Чтобы не повторяло одно и то же и не резало вторым speak(). */
    speakQuestionWithProgress(question, currentIndex, total) {
        if (this.lastSpokenForQuestionIndex === currentIndex - 1) return;
        this.lastSpokenForQuestionIndex = currentIndex - 1;

        const lang = this.lessonSystem.currentLang;
        const progressText = lang === 'ru'
            ? `Вопрос ${currentIndex} из ${total}`
            : `${currentIndex} сұрақ ${total} ден`;

        let questionText = question.question || '';
        if (question.type === 'multiple-choice' && question.options) {
            questionText += '. ' + (lang === 'ru' ? 'Скажи то, что написано на кнопке: ' : 'Батырмада жазылғанды айт: ');
            questionText += question.options.map(opt => opt).join('. ');
        } else if (question.type === 'image-choice' && question.options) {
            questionText += '. ' + (lang === 'ru'
                ? `Выберите картинку. Варианты: ${question.options.length}`
                : `Суретті таңдаңыз. Нұсқалар: ${question.options.length}`);
        } else if (question.type === 'counting' && question.images) {
            questionText += '. ' + (lang === 'ru'
                ? `Посчитайте картинки. Всего: ${question.images.length}`
                : `Суреттерді санаңыз. Барлығы: ${question.images.length}`);
        }

        const combined = questionText ? `${progressText}. ${questionText}` : progressText;
        this.speak(combined);
    }
    
    speak(text) {
        if (!('speechSynthesis' in window) || !text || !String(text).trim()) return;
        
        speechSynthesis.cancel();
        
        const utterance = new SpeechSynthesisUtterance(String(text).trim());
        utterance.lang = this.lessonSystem.currentLang === 'ru' ? 'ru-RU' : 'kk-KZ';
        utterance.rate = 0.85;
        utterance.pitch = 1.0; // Slightly lower pitch for male voice
        utterance.volume = 1;

        let voices = speechSynthesis.getVoices();
        if (voices.length === 0) {
             // Try to force load
             speechSynthesis.onvoiceschanged = () => {
                 voices = speechSynthesis.getVoices();
             };
        }

        const savedVoiceName = localStorage.getItem('smart_ai_prefs_v1') ? JSON.parse(localStorage.getItem('smart_ai_prefs_v1')).voice : null;
        let preferred = null;

        // 1. Strict priority: Microsoft Pavel or Dmitry (Russian) - checks English and Cyrillic
        if (utterance.lang.startsWith('ru')) {
            preferred = voices.find(v => v.name.toLowerCase().includes('pavel') || 
                                     v.name.toLowerCase().includes('павел') ||
                                     v.name.toLowerCase().includes('dmitry') || 
                                     v.name.toLowerCase().includes('dmitri') ||
                                     v.name.toLowerCase().includes('дмитрий') ||
                                     v.name.toLowerCase().includes('ivan') ||
                                     v.name.toLowerCase().includes('иван'));
        }

        // 2. Any Male voice in the target language
        if (!preferred) {
            const baseLang = String(utterance.lang).split('-')[0];
            preferred = voices.find(v => v.lang.startsWith(baseLang) && 
                                   (v.name.toLowerCase().includes('male') || 
                                    v.name.toLowerCase().includes('man') || 
                                    v.name.toLowerCase().includes('муж')));
        }

        // 3. Any voice that is NOT explicitly female
        if (!preferred && utterance.lang.startsWith('ru')) {
             preferred = voices.find(v => v.lang.startsWith('ru') && 
                                     !v.name.toLowerCase().includes('irina') && 
                                     !v.name.toLowerCase().includes('ирина') &&
                                     !v.name.toLowerCase().includes('elena') && 
                                     !v.name.toLowerCase().includes('елена') &&
                                     !v.name.toLowerCase().includes('zira') &&
                                     !v.name.toLowerCase().includes('female') &&
                                     !v.name.toLowerCase().includes('tatiana') &&
                                     !v.name.toLowerCase().includes('victoria') &&
                                     !v.name.toLowerCase().includes('arina') &&
                                     !v.name.toLowerCase().includes('alisa') &&
                                     !v.name.toLowerCase().includes('milena'));
        }

        // 4. Saved voice (fallback, if not female)
        if (!preferred && savedVoiceName) {
            const sv = savedVoiceName.toLowerCase();
            if (!sv.includes('irina') && !sv.includes('elena') && !sv.includes('zira')) {
                preferred = voices.find(v => v.name === savedVoiceName);
            }
        }
        
        // 5. Fallback: Pick explicit Microsoft voice if possible, BUT NOT FEMALE ones
        if (!preferred && utterance.lang.startsWith('ru')) {
             preferred = voices.find(v => v.lang.startsWith('ru') && 
                                     v.name.toLowerCase().includes('microsoft') &&
                                     !v.name.toLowerCase().includes('irina') && 
                                     !v.name.toLowerCase().includes('elena') &&
                                     !v.name.toLowerCase().includes('zira'));
        }

        // 6. Last resort fallback: Any voice that is not explicitly female
        if (!preferred && utterance.lang.startsWith('ru')) {
             preferred = voices.find(v => v.lang.startsWith('ru') && !v.name.toLowerCase().includes('female'));
        }

        if (preferred) utterance.voice = preferred;
        
        // Use a small timeout to ensure voices are loaded if this is the first call
        if (voices.length === 0) {
            setTimeout(() => {
                const retryVoices = speechSynthesis.getVoices();
                if (retryVoices.length > 0) {
                    this.speak(text); // Retry once
                }
            }, 100);
            return;
        }

        speechSynthesis.speak(utterance);
    }
    
    updateOptions(options) {
        this.currentOptions = options || [];
    }
    
    announceCorrect() {
        const lang = this.lessonSystem.currentLang;
        const messages = lang === 'ru'
            ? ['Правильно!', 'Молодец!', 'Отлично!', 'Верно!', 'Так держать!']
            : ['Дұрыс!', 'Жақсы!', 'Керемет!', 'Дұрыс!', 'Жалғастыр!'];
        const message = messages[Math.floor(Math.random() * messages.length)];
        this.speak(message);
    }
    
    announceIncorrect() {
        const lang = this.lessonSystem.currentLang;
        const messages = lang === 'ru'
            ? ['Попробуй еще раз', 'Не расстраивайся, попробуй снова', 'Подумай еще', 'Попробуй другой вариант']
            : ['Тағы бір рет тырыс', 'Қайғырма, қайта тырыс', 'Тағы ойла', 'Басқа нұсқаны тырыс'];
        const message = messages[Math.floor(Math.random() * messages.length)];
        this.speak(message);
    }
    
    announceProgress(current, total) {
        const lang = this.lessonSystem.currentLang;
        const text = lang === 'ru'
            ? `Вопрос ${current} из ${total}`
            : `${current} сұрақ ${total} ден`;
        this.speak(text);
    }
    
    announceCompletion() {
        const lang = this.lessonSystem.currentLang;
        const text = lang === 'ru'
            ? 'Отлично! Ты справился со всеми вопросами! Молодец!'
            : 'Керемет! Сіз барлық сұрақтарды орындадыңыз! Жақсы!';
        this.speak(text);
    }
}

class LessonSystem {
    constructor() {
        this.currentLang = localStorage.getItem('appLanguage') || 'ru';
        this.currentProfile = this.loadCurrentProfile();
        this.lessonKey = this.getLessonKeyFromURL();
        this.lessonData = this.getLessonData();
        
        this.currentQuestionIndex = 0;
        this.correctAnswers = 0;
        this.totalXP = 0;
        this.hearts = 5;
        this.userAnswer = null;
        
        // Переменные для вводных уроков
        this.waitingForCommand = false;
        this.expectedCommands = [];
        this.currentQuestionData = null;
        
        // Инициализируем голосового помощника
        this.voiceAssistant = new LessonVoiceAssistant(this);
        
        this.init();
    }

    init() {
        this.initLanguage();
        this.initNavigation();
        this.loadLesson();
        this.updateLanguage();

        // Слушаем команды от кнопки «Нажми и говори» (push-to-talk)
        window.addEventListener('voice-command', (e) => {
            if (this.voiceAssistant) this.voiceAssistant.handleVoiceCommand(e.detail.transcript);
        });
    }

    getLessonKeyFromURL() {
        const params = new URLSearchParams(window.location.search);
        return params.get('key') || '';
    }

    loadCurrentProfile() {
        const profileId = localStorage.getItem('currentProfileId');
        if (!profileId) {
            window.location.href = 'index.html';
            return null;
        }
        
        const profiles = JSON.parse(localStorage.getItem('profiles') || '[]');
        return profiles.find(p => p.id === profileId) || null;
    }

    getLessonData() {
        // Парсим ключ урока: courseId_moduleId_lessonId
        const parts = this.lessonKey.split('_');
        if (parts.length < 3) {
            console.error('Неверный формат ключа урока:', this.lessonKey);
            return null;
        }
        
        const [courseId, moduleId, lessonId] = parts;
        
        // Загружаем данные курсов (getCourses возвращает { ru: [...], kk: [...] })
        const coursesByLang = this.getCourses();
        const courses = coursesByLang[this.currentLang] || coursesByLang.ru || [];
        if (!courses.length) {
            console.error('Курсы не найдены');
            return null;
        }
        
        const course = courses.find(c => c.id === courseId);
        if (!course) {
            console.error('Курс не найден:', courseId, 'Доступные курсы:', courses.map(c => c.id));
            return null;
        }
        
        const module = course.modules.find(m => m.id === moduleId);
        if (!module) {
            console.error('Модуль не найден:', moduleId, 'В курсе', courseId, 'доступны модули:', course.modules.map(m => m.id));
            return null;
        }
        
        const lesson = module.lessons.find(l => l.id === lessonId);
        if (!lesson) {
            console.error('Урок не найден:', lessonId, 'В модуле', moduleId, 'доступны уроки:', module.lessons.map(l => l.id));
            return null;
        }
        
        return {
            courseId,
            moduleId,
            lessonId,
            course,
            module,
            lesson
        };
    }

    /** Ключ следующего урока в том же модуле (урок 1 → урок 2). Если следующего нет — null. */
    getNextLessonKey() {
        const data = this.getLessonData();
        if (!data || !data.module || !data.module.lessons) return null;
        const idx = data.module.lessons.findIndex(l => l.id === data.lessonId);
        if (idx < 0 || idx >= data.module.lessons.length - 1) return null;
        const next = data.module.lessons[idx + 1];
        return `${data.courseId}_${data.moduleId}_${next.id}`;
    }

    getCourses() {
        return {
            ru: [
                {
                    id: 'reading',
                    title: 'Чтение',
                    icon: '📚',
                    description: 'Учимся читать: от букв до историй (1-4 класс)',
                    color: '#4CAF50',
                    modules: [
                        // 1 КЛАСС
                        {
                            id: 'reading-g1-letters',
                            title: '1 класс: Буквы и слоги',
                            lessons: [
                                { id: 'let1', title: 'Гласные буквы (А, О, У, И)', type: 'word' },
                                { id: 'let2', title: 'Согласные (М, С, Х, Ш)', type: 'word' },
                                { id: 'syl1', title: 'Читаем слоги (МА, СО, ХУ)', type: 'word' },
                                { id: 'syl2', title: 'Собери слово из слогов', type: 'word' }
                            ]
                        },
                        {
                            id: 'reading-g1-words',
                            title: '1 класс: Первые слова',
                            lessons: [
                                { id: 'cat', title: 'Кошка, Дом, Лес', type: 'word' },
                                { id: 'dog', title: 'Собака, Мяч, Сон', type: 'word' },
                                { id: 'family', title: 'Мама, Папа, Брат', type: 'word' }
                            ]
                        },
                        // 2 КЛАСС
                        {
                            id: 'reading-g2-sentences',
                            title: '2 класс: Предложения',
                            lessons: [
                                { id: 's1', title: 'Кто что делает?', type: 'sentence' },
                                { id: 's2', title: 'Какой предмет?', type: 'sentence' },
                                { id: 's3', title: 'Короткие фразы', type: 'sentence' },
                                { id: 's4', title: 'Загадки', type: 'sentence' }
                            ]
                        },
                        // 3 КЛАСС
                        {
                            id: 'reading-g3-stories',
                            title: '3 класс: Короткие рассказы',
                            lessons: [
                                { id: 'story1', title: 'Рассказ о лете', type: 'sentence' },
                                { id: 'story2', title: 'Поход в магазин', type: 'sentence' },
                                { id: 'story3', title: 'Мой друг', type: 'sentence' }
                            ]
                        },
                        // 4 КЛАСС
                        {
                            id: 'reading-g4-literacy',
                            title: '4 класс: Грамотность',
                            lessons: [
                                { id: 'lit1', title: 'Синонимы (Смелый - Храбрый)', type: 'pair' },
                                { id: 'lit2', title: 'Антонимы (День - Ночь)', type: 'pair' },
                                { id: 'lit3', title: 'Пословицы', type: 'sentence' }
                            ]
                        }
                    ]
                },
                {
                    id: 'math',
                    title: 'Математика',
                    icon: '🔢',
                    description: 'Счёт, сложение, умножение и задачи (1-4 класс)',
                    color: '#2196F3',
                    modules: [
                        // 1 КЛАСС
                        {
                            id: 'math-g1-count',
                            title: '1 класс: Счёт до 20',
                            lessons: [
                                { id: 'c1', title: 'Считаем до 10', type: 'counting' },
                                { id: 'c2', title: 'Считаем до 20', type: 'counting' },
                                { id: 'add1', title: 'Сложение до 10 (2+3)', type: 'addition' },
                                { id: 'sub1', title: 'Вычитание до 10 (5-2)', type: 'subtraction' }
                            ]
                        },
                        // 2 КЛАСС
                        {
                            id: 'math-g2-calc',
                            title: '2 класс: Счёт до 100',
                            lessons: [
                                { id: 'add2', title: 'Сложение десятками (20+30)', type: 'addition' },
                                { id: 'sub2', title: 'Вычитание десятков (50-20)', type: 'subtraction' },
                                { id: 'cmp1', title: 'Больше, меньше или равно', type: 'comparison' }
                            ]
                        },
                        // 3 КЛАСС
                        {
                            id: 'math-g3-mul',
                            title: '3 класс: Умножение',
                            lessons: [
                                { id: 'mul1', title: 'Умножение на 2 и 3', type: 'addition' },
                                { id: 'mul2', title: 'Умножение на 4 и 5', type: 'addition' },
                                { id: 'div1', title: 'Простое деление', type: 'subtraction' }
                            ]
                        },
                        // 4 КЛАСС
                        {
                            id: 'math-g4-complex',
                            title: '4 класс: Задачи',
                            lessons: [
                                { id: 'task1', title: 'Текстовые задачи', type: 'intro' },
                                { id: 'big1', title: 'Сложение больших чисел', type: 'addition' },
                                { id: 'geom1', title: 'Периметр и площадь', type: 'shape' }
                            ]
                        }
                    ]
                },
                {
                    id: 'logic',
                    title: 'Логика',
                    icon: '🧩',
                    description: 'Развитие мышления, памяти и внимания (1-4 класс)',
                    color: '#9C27B0',
                    modules: [
                        // 1 КЛАСС
                        {
                            id: 'logic-g1-basic',
                            title: '1 класс: Формы и Цвета',
                            lessons: [
                                { id: 'colors', title: 'Учим цвета', type: 'word' },
                                { id: 'shapes', title: 'Круг, Квадрат, Треугольник', type: 'shape' },
                                { id: 'same', title: 'Найди такой же предмет', type: 'pattern' }
                            ]
                        },
                        // 2 КЛАСС
                        {
                            id: 'logic-g2-seq',
                            title: '2 класс: Последовательности',
                            lessons: [
                                { id: 'seq1', title: 'Продолжи ряд (🔴🔵🔴...)', type: 'sequence' },
                                { id: 'seq2', title: 'Что лишнее?', type: 'sorting' },
                                { id: 'pairs', title: 'Найди пару', type: 'pair' }
                            ]
                        },
                        // 3 КЛАСС
                        {
                            id: 'logic-g3-analogy',
                            title: '3 класс: Аналогии',
                            lessons: [
                                { id: 'an1', title: 'Холодно : Зима = Тепло : ?', type: 'pair' },
                                { id: 'class1', title: 'Живое и неживое', type: 'classification' },
                                { id: 'part1', title: 'Часть и целое', type: 'parts' }
                            ]
                        },
                        // 4 КЛАСС
                        {
                            id: 'logic-g4-puzzle',
                            title: '4 класс: Головоломки',
                            lessons: [
                                { id: 'puz1', title: 'Логические задачи', type: 'intro' },
                                { id: 'pat1', title: 'Сложные узоры', type: 'pattern' },
                                { id: 'reason', title: 'Причина и следствие', type: 'cause' }
                            ]
                        }
                    ]
                }
            ],
            kk: [
                {
                    id: 'reading',
                    title: 'Оқу',
                    icon: '📚',
                    description: 'Әріптерден бастап мәтіндерге дейін (1-4 сынып)',
                    color: '#4CAF50',
                    modules: [
                        // 1 СЫНЫП
                        {
                            id: 'reading-g1-letters',
                            title: '1 сынып: Әріптер мен буындар',
                            lessons: [
                                { id: 'let1', title: 'Дауысты дыбыстар (А, О, Ұ, І)', type: 'word' },
                                { id: 'let2', title: 'Дауыссыз дыбыстар', type: 'word' },
                                { id: 'syl1', title: 'Буындарды оқимыз', type: 'word' }
                            ]
                        },
                        {
                            id: 'reading-g1-words',
                            title: '1 сынып: Алғашқы сөздер',
                            lessons: [
                                { id: 'cat', title: 'Мысық, Үй, Ағаш', type: 'word' },
                                { id: 'family', title: 'Ана, Әке, Ата', type: 'word' }
                            ]
                        },
                        // 2 СЫНЫП
                        {
                            id: 'reading-g2-sentences',
                            title: '2 сынып: Сөйлемдер',
                            lessons: [
                                { id: 's1', title: 'Кім не істейді?', type: 'sentence' },
                                { id: 's2', title: 'Жұмбақтар', type: 'sentence' }
                            ]
                        },
                        // 3 СЫНЫП
                        {
                            id: 'reading-g3-stories',
                            title: '3 сынып: Қысқа әңгімелер',
                            lessons: [
                                { id: 'story1', title: 'Жазғы демалыс', type: 'sentence' },
                                { id: 'story2', title: 'Дүкенде', type: 'sentence' }
                            ]
                        },
                        // 4 СЫНЫП
                        {
                            id: 'reading-g4-literacy',
                            title: '4 сынып: Сауаттылық',
                            lessons: [
                                { id: 'lit1', title: 'Синонимдер', type: 'pair' },
                                { id: 'lit2', title: 'Антонимдер', type: 'pair' },
                                { id: 'lit3', title: 'Мақал-мәтелдер', type: 'sentence' }
                            ]
                        }
                    ]
                },
                {
                    id: 'math',
                    title: 'Математика',
                    icon: '🔢',
                    description: 'Санау, қосу, азайту және есептер (1-4 сынып)',
                    color: '#2196F3',
                    modules: [
                        // 1 СЫНЫП
                        {
                            id: 'math-g1-count',
                            title: '1 сынып: 20-ға дейін санау',
                            lessons: [
                                { id: 'c1', title: '10-ға дейін санау', type: 'counting' },
                                { id: 'c2', title: '20-ға дейін санау', type: 'counting' },
                                { id: 'add1', title: 'Қосу (2+3)', type: 'addition' }
                            ]
                        },
                        // 2 СЫНЫП
                        {
                            id: 'math-g2-calc',
                            title: '2 сынып: 100-ге дейін санау',
                            lessons: [
                                { id: 'add2', title: 'Ондықтармен қосу', type: 'addition' },
                                { id: 'sub2', title: 'Азайту', type: 'subtraction' },
                                { id: 'cmp1', title: 'Артық, кем, тең', type: 'comparison' }
                            ]
                        },
                        // 3 СЫНЫП
                        {
                            id: 'math-g3-mul',
                            title: '3 сынып: Көбейту',
                            lessons: [
                                { id: 'mul1', title: '2-ге және 3-ке көбейту', type: 'addition' },
                                { id: 'div1', title: 'Бөлу', type: 'subtraction' }
                            ]
                        },
                        // 4 СЫНЫП
                        {
                            id: 'math-g4-complex',
                            title: '4 сынып: Есептер',
                            lessons: [
                                { id: 'task1', title: 'Мәтіндік есептер', type: 'intro' },
                                { id: 'geom1', title: 'Периметр және аудан', type: 'shape' }
                            ]
                        }
                    ]
                },
                {
                    id: 'logic',
                    title: 'Логика',
                    icon: '🧩',
                    description: 'Ойлауды дамыту (1-4 сынып)',
                    color: '#9C27B0',
                    modules: [
                        // 1 СЫНЫП
                        {
                            id: 'logic-g1-basic',
                            title: '1 сынып: Пішіндер мен Түстер',
                            lessons: [
                                { id: 'colors', title: 'Түстерді үйренеміз', type: 'word' },
                                { id: 'shapes', title: 'Пішіндер', type: 'shape' }
                            ]
                        },
                        // 2 СЫНЫП
                        {
                            id: 'logic-g2-seq',
                            title: '2 сынып: Тізбектер',
                            lessons: [
                                { id: 'seq1', title: 'Тізбекті жалғастыр', type: 'sequence' },
                                { id: 'pairs', title: 'Жұбын тап', type: 'pair' }
                            ]
                        },
                        // 3 СЫНЫП
                        {
                            id: 'logic-g3-analogy',
                            title: '3 сынып: Ұқсастықтар',
                            lessons: [
                                { id: 'class1', title: 'Тірі және өлі табиғат', type: 'classification' }
                            ]
                        },
                        // 4 СЫНЫП
                        {
                            id: 'logic-g4-puzzle',
                            title: '4 сынып: Басқатырғыштар',
                            lessons: [
                                { id: 'puz1', title: 'Логикалық есептер', type: 'intro' },
                                { id: 'pat1', title: 'Күрделі өрнектер', type: 'pattern' }
                            ]
                        }
                    ]
                }
            ]
        };
    }

    loadLesson() {
        if (!this.lessonData) {
            const errorMsg = this.currentLang === 'ru' 
                ? `Урок не найден. Ключ: ${this.lessonKey}`
                : `Сабақ табылмады. Кілт: ${this.lessonKey}`;
            console.error(errorMsg);
            
            // Показываем более информативное сообщение
            const confirmMsg = this.currentLang === 'ru'
                ? `Урок не найден.\nКлюч урока: ${this.lessonKey}\n\nВернуться к списку курсов?`
                : `Сабақ табылмады.\nСабақ кілті: ${this.lessonKey}\n\nКурстар тізіміне оралу керек пе?`;
            
            if (confirm(confirmMsg)) {
                window.location.href = 'index.html';
            }
            return;
        }

        // Генерируем вопросы для урока
        this.questions = this.generateQuestions();
        
        if (!this.questions || this.questions.length === 0) {
            console.error('Не удалось сгенерировать вопросы для урока:', this.lessonData.lesson);
            const errorMsg = this.currentLang === 'ru'
                ? 'Не удалось загрузить вопросы урока. Вернуться к списку курсов?'
                : 'Сабақ сұрақтарын жүктеу мүмкін болмады. Курстар тізіміне оралу керек пе?';
            if (confirm(errorMsg)) {
                window.location.href = 'index.html';
            }
            return;
        }
        
        this.renderQuestion();
    }

    generateQuestions() {
        const { lesson } = this.lessonData;
        const questions = [];

        // Генерируем вопросы в зависимости от типа урока
        if (lesson.type === 'intro') {
            questions.push(...this.generateIntroLesson(lesson));
        } else if (lesson.type === 'intro-addition') {
            questions.push(...this.generateIntroAdditionLesson(lesson));
        } else if (lesson.type === 'letter') {
            questions.push(...this.generateLetterQuestions(lesson));
        } else if (lesson.type === 'word') {
            questions.push(...this.generateWordQuestions(lesson));
        } else if (lesson.type === 'counting') {
            questions.push(...this.generateCountingQuestions(lesson));
        } else if (lesson.type === 'addition') {
            questions.push(...this.generateAdditionQuestions(lesson));
        } else if (lesson.type === 'subtraction') {
            questions.push(...this.generateSubtractionQuestions(lesson));
        } else if (lesson.type === 'comparison') {
            questions.push(...this.generateComparisonQuestions(lesson));
        } else if (lesson.type === 'shape') {
            questions.push(...this.generateShapeQuestions(lesson));
        } else if (lesson.type === 'sequence') {
            questions.push(...this.generateSequenceQuestions(lesson));
        } else if (lesson.type === 'pattern') {
            questions.push(...this.generatePatternQuestions(lesson));
        } else if (lesson.type === 'pair') {
            questions.push(...this.generatePairQuestions(lesson));
        } else if (lesson.type === 'classification') {
            questions.push(...this.generateClassificationQuestions(lesson));
        } else if (lesson.type === 'parts') {
            questions.push(...this.generatePartsQuestions(lesson));
        } else if (lesson.type === 'sentence') {
            questions.push(...this.generateSentenceQuestions(lesson));
        } else if (lesson.type === 'cause') {
            questions.push(...this.generateReasonQuestions(lesson)); // Cause/Reason
        } else if (lesson.type === 'opposite') {
            questions.push(...this.generateOppositeQuestions(lesson));
        } else if (lesson.type === 'sorting') {
            questions.push(...this.generateSortingQuestions(lesson));
        } else if (lesson.type === 'multiplication') {
            questions.push(...this.generateMultiplicationQuestions(lesson));
        } else if (lesson.type === 'division') {
            questions.push(...this.generateDivisionQuestions(lesson));
        } else if (lesson.type === 'story') {
            questions.push(...this.generateStoryQuestions(lesson));
        } else if (lesson.type === 'literacy') {
            questions.push(...this.generateLiteracyQuestions(lesson));
        }

        return questions;
    }
    
    generateIntroLesson(lesson) {
        // Первый вводный урок "Считаем вместе" для 2 класса
        if (lesson.id === 'intro-math-1' && lesson.subject === 'math') {
            return [
                {
                    type: 'intro-screen',
                    screen: 'greeting',
                    text: 'Привет. Мы будем учиться спокойно.',
                    voiceText: 'Привет. Я буду рядом. Если готов — скажи: да.',
                    expectedCommand: ['да', 'готов', 'хорошо'],
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'voice-control',
                    text: 'ГОВОРИ',
                    icon: '🎤',
                    voiceText: 'Ты можешь говорить. Я тебя слышу. Скажи: дальше.',
                    expectedCommand: ['дальше', 'продолжить', 'да'],
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'visual-count',
                    text: 'Посмотри внимательно',
                    circles: [1],
                    voiceText: 'Посмотри. Здесь один.',
                    delay: 2000,
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'visual-count',
                    text: 'И ещё один',
                    circles: [1, 1],
                    voiceText: 'И ещё один.',
                    delay: 2000,
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'visual-result',
                    text: 'Вместе — два',
                    circles: [1, 1],
                    voiceText: 'Вместе — два.',
                    delay: 3000,
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'simple-question',
                    text: 'Сколько здесь?',
                    circles: [1, 1],
                    options: ['два', 'три'],
                    voiceText: 'Сколько здесь? Можешь сказать слово.',
                    expectedCommand: ['два', '2', 'двое'],
                    acceptFuzzy: true,
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'support',
                    text: 'Хорошо. Ты сказал. Я тебя понял.',
                    icon: '🌱',
                    voiceText: 'Хорошо. Ты сказал. Я тебя понял.',
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'completion',
                    text: 'Мы начали учиться.',
                    voiceText: 'Если хочешь ещё — скажи: дальше. Если хочешь отдохнуть — скажи: стоп.',
                    expectedCommand: ['дальше', 'стоп', 'отдохнуть'],
                    noEvaluation: true
                }
            ];
        } else if (lesson.id === 'intro-reading-1' && lesson.subject === 'reading') {
            return [
                {
                    type: 'intro-screen',
                    screen: 'greeting',
                    text: 'Привет. Мы будем учиться читать.',
                    voiceText: 'Привет. Я буду читать слова. Если готов — скажи: да.',
                    expectedCommand: ['да', 'готов'],
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'word-listening',
                    text: 'Слушай слово',
                    word: 'кошка',
                    voiceText: 'Слушай слово: кошка. Если услышал — скажи: да.',
                    expectedCommand: ['да', 'услышал', 'хорошо'],
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'support',
                    text: 'Хорошо. Ты слушал. Молодец.',
                    icon: '⭐',
                    voiceText: 'Хорошо. Ты слушал. Молодец.',
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'completion',
                    text: 'Мы начали учиться читать.',
                    voiceText: 'Если хочешь ещё — скажи: дальше. Если хочешь отдохнуть — скажи: стоп.',
                    expectedCommand: ['дальше', 'стоп'],
                    noEvaluation: true
                }
            ];
        } else if (lesson.id === 'intro-logic-1' && lesson.subject === 'logic') {
            return [
                {
                    type: 'intro-screen',
                    screen: 'greeting',
                    text: 'Привет. Мы будем думать вместе.',
                    voiceText: 'Привет. Мы будем смотреть и выбирать. Если готов — скажи: да.',
                    expectedCommand: ['да', 'готов'],
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'visual-choice',
                    text: 'Посмотри и выбери',
                    images: ['🔴', '🔵'],
                    voiceText: 'Посмотри. Здесь красный и синий. Какой тебе больше нравится? Скажи: первый или второй.',
                    expectedCommand: ['первый', 'второй', 'красный', 'синий'],
                    acceptFuzzy: true,
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'support',
                    text: 'Хорошо. Ты выбрал. Я тебя понял.',
                    icon: '🌱',
                    voiceText: 'Хорошо. Ты выбрал. Я тебя понял.',
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'completion',
                    text: 'Мы начали учиться думать.',
                    voiceText: 'Если хочешь ещё — скажи: дальше. Если хочешь отдохнуть — скажи: стоп.',
                    expectedCommand: ['дальше', 'стоп'],
                    noEvaluation: true
                }
            ];
        } else {
            // Generic fallback for any other intro lesson
            return [
                {
                    type: 'intro-screen',
                    screen: 'greeting',
                    text: lesson.title || 'Введение',
                    icon: '👋',
                    voiceText: 'Привет. Давай начнем урок. Если готов — скажи: да.',
                    expectedCommand: ['да', 'готов'],
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'support',
                    text: 'Слушай внимательно и выполняй задания.',
                    icon: '👂',
                    voiceText: 'Слушай внимательно и выполняй задания.',
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'completion',
                    text: 'Давай начнем!',
                    voiceText: 'Давай начнем! Скажи: дальше.',
                    expectedCommand: ['дальше', 'вперед'],
                    noEvaluation: true
                }
            ];
        }
    }
    
    generateIntroAdditionLesson(lesson) {
        // Урок "2 + 3 = ?" для 2 класса
        if (lesson.id === 'intro-math-2' && lesson.subject === 'math') {
            return [
                {
                    type: 'intro-screen',
                    screen: 'greeting',
                    text: 'Сегодня мы будем складывать',
                    icon: '➕',
                    voiceText: 'Скажи: начать',
                    expectedCommand: ['начать', 'да', 'готов'],
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'visual-explanation',
                    text: 'Два и ещё три',
                    circles: [2, 3],
                    voiceText: 'Два и ещё три. Посмотри внимательно.',
                    delay: 3000,
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'visual-result',
                    text: 'Теперь кружки вместе',
                    circles: [5],
                    voiceText: 'Теперь кружки вместе. Мы считаем.',
                    delay: 3000,
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'simple-question',
                    text: 'Сколько всего?',
                    circles: [5],
                    options: ['5', '6'],
                    voiceText: 'Скажи: первый или второй',
                    expectedCommand: ['первый', 'пять', '5', 'второй', 'шесть', '6'],
                    acceptFuzzy: true,
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'support',
                    text: 'Хорошо. Ты попробовал. Молодец.',
                    icon: '⭐',
                    voiceText: 'Хорошо. Ты попробовал. Молодец.',
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'simple-question',
                    text: 'Сколько теперь?',
                    circles: [4, 1],
                    options: ['5', '6'],
                    voiceText: 'Сколько теперь?',
                    expectedCommand: ['пять', '5', 'первый'],
                    acceptFuzzy: true,
                    noEvaluation: true
                },
                {
                    type: 'intro-screen',
                    screen: 'completion',
                    text: 'Ты сегодня учился.',
                    icon: '🌱',
                    voiceText: 'Ты сегодня учился. Если хочешь — скажи: ещё раз. Или скажи: стоп.',
                    expectedCommand: ['ещё раз', 'стоп'],
                    noEvaluation: true
                }
            ];
        }
        
        // Fallback for intro-addition if needed
        return [
             {
                type: 'intro-screen',
                screen: 'greeting',
                text: lesson.title || 'Введение в сложение',
                voiceText: 'Давай учиться складывать.',
                expectedCommand: ['да', 'готов'],
                noEvaluation: true
            },
            {
                type: 'intro-screen',
                screen: 'visual-explanation',
                text: 'Смотри внимательно',
                circles: [2, 1],
                voiceText: 'Складываем вместе.',
                noEvaluation: true
            },
            {
                type: 'intro-screen',
                screen: 'completion',
                text: 'Молодец!',
                voiceText: 'Ты справился.',
                expectedCommand: ['дальше', 'стоп'],
                noEvaluation: true
            }
        ];
    }

    generateLetterQuestions(lesson) {
        const letterMap = {
            // Vowels (let1)
            'a': { letter: 'А', word: 'арбуз', image: '🍉', sound: 'а' },
            'o': { letter: 'О', word: 'облако', image: '☁️', sound: 'о' },
            'u': { letter: 'У', word: 'утка', image: '🦆', sound: 'у' },
            'i': { letter: 'И', word: 'игла', image: '🪡', sound: 'и' },
            
            // Consonants (let2)
            'm': { letter: 'М', word: 'машина', image: '🚗', sound: 'м' },
            's': { letter: 'С', word: 'солнце', image: '☀️', sound: 'с' },
            'x': { letter: 'Х', word: 'хлеб', image: '🍞', sound: 'х' },
            'sh': { letter: 'Ш', word: 'шар', image: '🎈', sound: 'ш' },
            'b': { letter: 'Б', word: 'банан', image: '🍌', sound: 'б' },
            'v': { letter: 'В', word: 'вишня', image: '🍒', sound: 'в' }
        };

        // If lesson.id is 'let1', pick random vowels. If 'let2', pick consonants.
        // If specific ID like 'a', use that.
        let targetKey = 'a';
        if (lesson.id === 'let1') {
             // Random vowel
             const vowels = ['a', 'o', 'u', 'i'];
             targetKey = vowels[Math.floor(Math.random() * vowels.length)];
        } else if (lesson.id === 'let2') {
             // Random consonant
             const cons = ['m', 's', 'x', 'sh', 'b', 'v'];
             targetKey = cons[Math.floor(Math.random() * cons.length)];
        } else {
             targetKey = lesson.id;
        }

        const data = letterMap[targetKey] || letterMap['a'];
        const t = this.getTranslations();

        return [
            {
                type: 'multiple-choice',
                question: t.letterQuestion ? t.letterQuestion.replace('{letter}', data.letter) : `Какая это буква?`,
                options: this.shuffle([data.letter, 'К', 'Р', 'Т', 'П', 'Л'].slice(0, 3).concat([data.letter])),
                correct: 0, // Fixed by shuffle later if needed? No, logic below fixes it?
                // Wait, logic below handles correction?
                // Check original code:
                // options: [data.letter, 'Б', 'В', 'Г'], correct: 0. 
                // The shuffle creates random order. But we must set correct index AFTER shuffle.
                // My logic below in generateWordQuestions handled it. 
                // generateLetterQuestions didn't have that map logic at the end.
                // I need to implement it here or return fixed structure.
                image: data.image,
                xp: 10
            },
            {
                type: 'image-choice',
                question: t.findWordQuestion ? t.findWordQuestion.replace('{letter}', data.letter) : `Найди слово на букву ${data.letter}`,
                image: data.image,
                options: this.shuffle([data.word, 'яблоко', 'кошка', 'дом', 'рыба', 'стул'].slice(0, 3).concat([data.word])),
                correct: 0,
                xp: 10
            },
            {
                type: 'drag-drop',
                question: t.buildWordQuestion ? t.buildWordQuestion.replace('{word}', data.word) : `Составь слово "${data.word}"`,
                word: data.word,
                letters: data.word.split('').map(l => l.toUpperCase()),
                xp: 15
            }
        ].map(q => {
            if (q.type === 'multiple-choice') {
                q.correct = q.options.indexOf(data.letter);
            }
            if (q.type === 'image-choice') {
                q.correct = q.options.indexOf(data.word);
            }
            return q;
        });
    }

    generateWordQuestions(lesson) {
        // ВАЖНО: варианты ответа не должны быть "похожими" (синонимы/уменьшительные формы).
        // Поэтому правильный ответ + 3 отвлекающих слова берём из разных базовых слов.
        const wordMap = {
            // Животные
            cat: { word: 'кошка', image: '🐱', category: 'animals' },
            dog: { word: 'собака', image: '🐶', category: 'animals' },
            bear: { word: 'медведь', image: '🐻', category: 'animals' },
            rabbit: { word: 'заяц', image: '🐰', category: 'animals' },
            fox: { word: 'лиса', image: '🦊', category: 'animals' },
            wolf: { word: 'волк', image: '🐺', category: 'animals' },
            lion: { word: 'лев', image: '🦁', category: 'animals' },
            elephant: { word: 'слон', image: '🐘', category: 'animals' },
            tiger: { word: 'тигр', image: '🐯', category: 'animals' },
            horse: { word: 'лошадь', image: '🐴', category: 'animals' },
            cow: { word: 'корова', image: '🐮', category: 'animals' },
            pig: { word: 'свинья', image: '🐷', category: 'animals' },
            sheep: { word: 'овца', image: '🐑', category: 'animals' },
            goat: { word: 'коза', image: '🐐', category: 'animals' },
            duck: { word: 'утка', image: '🦆', category: 'animals' },
            chicken: { word: 'курица', image: '🐔', category: 'animals' },
            rooster: { word: 'петух', image: '🐓', category: 'animals' },

            // Еда
            apple: { word: 'яблоко', image: '🍎', category: 'food' },
            banana: { word: 'банан', image: '🍌', category: 'food' },
            orange: { word: 'апельсин', image: '🍊', category: 'food' },
            strawberry: { word: 'клубника', image: '🍓', category: 'food' },
            carrot: { word: 'морковь', image: '🥕', category: 'food' },
            tomato: { word: 'помидор', image: '🍅', category: 'food' },
            cucumber: { word: 'огурец', image: '🥒', category: 'food' },
            potato: { word: 'картошка', image: '🥔', category: 'food' },
            bread: { word: 'хлеб', image: '🍞', category: 'food' },
            milk: { word: 'молоко', image: '🥛', category: 'food' },
            water: { word: 'вода', image: '💧', category: 'food' },
            juice: { word: 'сок', image: '🧃', category: 'food' },

            // Транспорт
            car: { word: 'машина', image: '🚗', category: 'transport' },
            bus: { word: 'автобус', image: '🚌', category: 'transport' },
            train: { word: 'поезд', image: '🚆', category: 'transport' },
            plane: { word: 'самолёт', image: '✈️', category: 'transport' },
            bike: { word: 'велосипед', image: '🚲', category: 'transport' },
            ship: { word: 'корабль', image: '🚢', category: 'transport' },

            // Цвета (эмодзи условные)
            red: { word: 'красный', image: '🟥', category: 'colors' },
            blue: { word: 'синий', image: '🟦', category: 'colors' },
            green: { word: 'зелёный', image: '🟩', category: 'colors' },
            yellow: { word: 'жёлтый', image: '🟨', category: 'colors' },
            purple: { word: 'фиолетовый', image: '🟪', category: 'colors' },
            orange_c: { word: 'оранжевый', image: '🟧', category: 'colors' },
            black: { word: 'чёрный', image: '⬛', category: 'colors' },
            white: { word: 'белый', image: '⬜', category: 'colors' },

            // Семья (для урока "Мама, Папа, Брат")
            family: { word: 'мама', image: '👩', category: 'items' },
            mom: { word: 'мама', image: '👩', category: 'items' },
            dad: { word: 'папа', image: '👨', category: 'items' },
            brother: { word: 'брат', image: '👦', category: 'items' },

            // Предметы
            house: { word: 'дом', image: '🏠', category: 'items' },
            ball: { word: 'мяч', image: '⚽', category: 'items' },
            book: { word: 'книга', image: '📚', category: 'items' },
            toy: { word: 'игрушка', image: '🧸', category: 'items' },
            table: { word: 'стол', image: '🪑', category: 'items' },
            chair: { word: 'стул', image: '🪑', category: 'items' },
            bed: { word: 'кровать', image: '🛏️', category: 'items' },
            window: { word: 'окно', image: '🪟', category: 'items' },
            door: { word: 'дверь', image: '🚪', category: 'items' },
            tree: { word: 'дерево', image: '🌳', category: 'items' },

            // Школа (school)
            pen: { word: 'ручка', image: '🖊️', category: 'school' },
            book_s: { word: 'учебник', image: '📖', category: 'school' },
            pencil: { word: 'карандаш', image: '✏️', category: 'school' },
            bag: { word: 'портфель', image: '🎒', category: 'school' },
            ruler: { word: 'линейка', image: '📏', category: 'school' },
            teacher: { word: 'учитель', image: '👩‍🏫', category: 'school' },
            desk: { word: 'парта', image: '🪑', category: 'school' },
            globe: { word: 'глобус', image: '🌍', category: 'school' }
        };

        const syllableMap = {
            'syl1': [
                { word: 'МА', image: '🗣️' }, { word: 'ПА', image: '🗣️' }, { word: 'БА', image: '🗣️' },
                { word: 'ДА', image: '🗣️' }, { word: 'ТА', image: '🗣️' }, { word: 'КА', image: '🗣️' }
            ],
            'syl2': [
                { word: 'МА-МА', image: '👩' }, { word: 'ПА-ПА', image: '👨' }, { word: 'КА-ША', image: '🥣' },
                { word: 'НО-ТЫ', image: '🎵' }, { word: 'РЫ-БА', image: '🐟' }
            ]
        };

        let targetData = null;
        
        // Handle Syllables special case
        if (syllableMap[lesson.id]) {
             const pool = syllableMap[lesson.id];
             targetData = pool[Math.floor(Math.random() * pool.length)]; // Pick one random syllable/word for this run?
             // Actually, we want 5 questions.
             const questions = [];
             for(let i=0; i<5; i++) {
                 const item = pool[Math.floor(Math.random() * pool.length)];
                 // Distractors
                 const distractors = pool.filter(x => x.word !== item.word).map(x => x.word).sort(() => 0.5 - Math.random()).slice(0, 3);
                 if (distractors.length < 3) distractors.push('...','???'); // Fallback
                 questions.push({
                     type: 'multiple-choice',
                     question: `Прочитай: ${item.word}`,
                     options: this.shuffle([item.word, ...distractors]),
                     correct: 0, 
                     xp: 10
                 });
             }
             return questions.map(q => {
                 q.correct = q.options.indexOf(q.question.replace('Прочитай: ', '')); // Extract word roughly
                 return q;
             });
        }

        // Handle Categories (colors, animals, food, school)
        // If lesson.id matches a category
        const categoryMatch = Object.values(wordMap).filter(w => w.category === lesson.id);
        if (categoryMatch.length > 0) {
             // Generate 5 questions picking different items from this category
             const questions = [];
             for(let i=0; i<5; i++) {
                 const data = categoryMatch[Math.floor(Math.random() * categoryMatch.length)];
                 const t = this.getTranslations();
                 // Create image choice
                 const distractorEmojis = this.pickDistinctEmojis(data.image, 3, Object.values(wordMap).map(x=>x.image));
                 
                 questions.push({
                    type: 'image-choice',
                    question: t.findWordQuestion ? t.findWordQuestion.replace('{letter}', data.word) : `Найди ${data.word}`, // "Find Red"
                    image: null,
                    options: this.shuffle([data.image, ...distractorEmojis]),
                    correct: 0,
                    xp: 10,
                    target: data.image
                });
             }
             return questions.map(q => { q.correct = q.options.indexOf(q.target); return q; });
        }

        // Default: Specific Word (cat, dog, family). Если id нет в wordMap — берём случайное слово из словаря, чтобы не показывать ❓.
        const wordList = Object.entries(wordMap).map(([k, v]) => ({ key: k, ...v }));
        const data = wordMap[lesson.id] || (wordList[Math.floor(Math.random() * wordList.length)] || { word: 'кошка', image: '🐱' });
        const t = this.getTranslations();

        const wordPool = Object.values(wordMap)
            .map((x) => x.word)
            .filter(Boolean);
        const emojiPool = Object.values(wordMap)
            .map((x) => x.image)
            .filter(Boolean);

        const distractorWords = this.pickDistinctWords(data.word, 3, wordPool);
        const distractorEmojis = this.pickDistinctEmojis(data.image, 3, emojiPool);

        return [
            {
                type: 'image-choice',
                question: t.findImageQuestion ? t.findImageQuestion.replace('{word}', data.word) : `Где ${data.word}?`,
                image: null,
                options: this.shuffle([data.image, ...distractorEmojis]),
                correct: 0,
                xp: 10
            },
            {
                type: 'multiple-choice',
                question: t.readWordQuestion || 'Прочитай слово',
                image: data.image,
                emoji: null,
                options: this.shuffle([data.word, ...distractorWords]),
                correct: 0, // ниже мы поправим индекс после shuffle
                xp: 10
            }
        ].map((q) => {
            // После перемешивания надо обновить индекс правильного ответа
            if (q.type === 'multiple-choice') {
                q.correct = q.options.indexOf(data.word);
            }
            if (q.type === 'image-choice') {
                q.correct = q.options.indexOf(data.image);
            }
            return q;
        });
    }

    // ===== helpers: не даём "похожие" слова =====
    normalizeWord(w) {
        return String(w || '')
            .toLowerCase()
            .replaceAll('ё', 'е')
            .replaceAll('й', 'и')
            .trim();
    }

    roughStem(w) {
        // Примитивный "стемминг" для детских слов (чтобы отсечь "пёс/пёсик/пёса", "кошка/кошечка" и т.п.)
        let s = this.normalizeWord(w);
        const suffixes = [
            'енька', 'онька', 'ечка', 'очка', 'ушка', 'юшка',
            'ёнок', 'енок', 'онок',
            'чик', 'щик', 'ик', 'ок', 'ек',
            'ка', 'ко', 'ки', 'ы', 'а', 'я', 'о', 'е'
        ];
        for (const suf of suffixes) {
            if (s.length > suf.length + 2 && s.endsWith(suf)) {
                s = s.slice(0, -suf.length);
                break;
            }
        }
        return s;
    }

    isTooSimilar(a, b) {
        const na = this.normalizeWord(a);
        const nb = this.normalizeWord(b);
        if (!na || !nb) return false;
        if (na === nb) return true;

        const sa = this.roughStem(na);
        const sb = this.roughStem(nb);
        if (sa && sb && sa === sb) return true;

        // дополнительная защита: одинаковые первые 4 буквы
        if (na.length >= 4 && nb.length >= 4 && na.slice(0, 4) === nb.slice(0, 4)) return true;
        return false;
    }

    pickDistinctWords(correctWord, count, pool) {
        const result = [];
        const used = new Set();
        used.add(this.normalizeWord(correctWord));

        const candidates = Array.from(new Set(pool || [])).filter(Boolean);
        // перемешаем
        for (const w of this.shuffle([...candidates])) {
            if (result.length >= count) break;
            if (this.isTooSimilar(correctWord, w)) continue;
            const nw = this.normalizeWord(w);
            if (used.has(nw)) continue;
            used.add(nw);
            result.push(w);
        }
        // если пула не хватило, добиваем "нейтральными" словами
        const fallback = ['дом', 'дерево', 'мяч', 'книга', 'машина', 'яблоко', 'рыба', 'птица', 'цветок', 'стол'];
        for (const w of fallback) {
            if (result.length >= count) break;
            if (this.isTooSimilar(correctWord, w)) continue;
            const nw = this.normalizeWord(w);
            if (used.has(nw)) continue;
            used.add(nw);
            result.push(w);
        }
        return result.slice(0, count);
    }

    pickDistinctEmojis(correctEmoji, count, pool) {
        const result = [];
        const used = new Set([String(correctEmoji || '')]);
        const candidates = Array.from(new Set(pool || [])).filter(Boolean);
        for (const e of this.shuffle([...candidates])) {
            if (result.length >= count) break;
            if (String(e) === String(correctEmoji)) continue;
            if (used.has(String(e))) continue;
            used.add(String(e));
            result.push(e);
        }
        const fallback = ['🐱', '🐶', '🍎', '🏠', '🌳', '🚗', '📚', '⚽'];
        for (const e of fallback) {
            if (result.length >= count) break;
            if (String(e) === String(correctEmoji)) continue;
            if (used.has(String(e))) continue;
            used.add(String(e));
            result.push(e);
        }
        return result.slice(0, count);
    }

    shuffle(arr) {
        const a = [...(arr || [])];
        for (let i = a.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [a[i], a[j]] = [a[j], a[i]];
        }
        return a;
    }

    generateCountingQuestions(lesson) {
        const maxCount = lesson.id === 'count1' ? 5 : 10;
        const t = this.getTranslations();
        const questions = [];

        for (let i = 1; i <= 5; i++) {
            const count = Math.floor(Math.random() * maxCount) + 1;
            const images = Array(count).fill('🍎');
            
            questions.push({
                type: 'counting',
                question: t.countQuestion,
                images: images,
                correct: count,
                options: Array.from({ length: maxCount }, (_, i) => i + 1),
                xp: 10
            });
        }

        return questions;
    }

    generateAdditionQuestions(lesson) {
        const t = this.getTranslations();
        const questions = [];
        const maxSum = lesson.id === 'add2' ? 100 : 10;
        const range = lesson.id === 'add2' ? 50 : 5;

        for (let i = 0; i < 6; i++) {
            const a = lesson.id === 'add2' ? Math.floor(Math.random() * range) + 1 : Math.floor(Math.random() * 5) + 1;
            const b = lesson.id === 'add2' ? Math.floor(Math.random() * range) + 1 : Math.floor(Math.random() * 5) + 1;
            const correct = a + b;
            const opts = [correct, correct + 1, correct - 1, correct + 2].filter(n => n > 0 && n <= (maxSum + 5));
            const uniq = [...new Set(opts)];
            while (uniq.length < 4 && correct + uniq.length < 50) uniq.push(correct + uniq.length + 2);
            questions.push({
                type: 'addition',
                question: (t.addQuestion || `${a} + ${b} = ?`).replace('{a}', a).replace('{b}', b),
                a: a,
                b: b,
                correct: correct,
                options: this.shuffle(uniq.slice(0, 4)),
                xp: 10
            });
        }
        return questions;
    }

    generateSubtractionQuestions(lesson) {
        const t = this.getTranslations();
        const questions = [];
        const useBig = lesson.id === 'sub2';
        for (let i = 0; i < 6; i++) {
            const a = useBig ? Math.floor(Math.random() * 40) + 20 : Math.floor(Math.random() * 8) + 2;
            const b = useBig ? Math.floor(Math.random() * (a - 1)) + 1 : Math.floor(Math.random() * (a - 1)) + 1;
            const correct = a - b;
            const opts = [correct, correct + 1, correct > 1 ? correct - 1 : correct + 2, correct + 3].filter(n => n >= 0);
            const uniq = [...new Set(opts)].slice(0, 4);
            questions.push({
                type: 'subtraction',
                question: (t.subQuestion || `${a} − ${b} = ?`).replace('{a}', a).replace('{b}', b),
                a: a,
                b: b,
                correct: correct,
                options: this.shuffle(uniq),
                xp: 10
            });
        }
        return questions;
    }

    generateComparisonQuestions(lesson) {
        const t = this.getTranslations();
        const questions = [];
        const isMath = lesson.id.startsWith('comp') || lesson.id.startsWith('math');
        
        if (isMath) {
            for (let i = 0; i < 5; i++) {
                const a = Math.floor(Math.random() * 10) + 1;
                const b = Math.floor(Math.random() * 10) + 1;
                if (a === b) continue; 
                const correct = a > b ? '>' : '<';
                questions.push({
                    type: 'comparison-math',
                    question: t.compQuestion ? t.compQuestion : 'Сравни числа',
                    left: a,
                    right: b,
                    correct: correct,
                    options: ['>', '<', '='],
                    xp: 10
                });
            }
        } else {
            questions.push({
                type: 'comparison-logic',
                question: 'Что больше?',
                left: '🐘',
                right: '🐭',
                correct: '🐘',
                options: ['🐘', '🐭'],
                xp: 10
            });
        }
        return questions;
    }

    generateSequenceQuestions(lesson) {
        const pool = [
            { sequence: ['🟥', '🟦', '🟥', '🟦'], correct: '🟥', options: ['🟥', '🟦', '🟩'], question: 'Продолжи ряд' },
            { sequence: ['1', '2', '3'], correct: '4', options: ['4', '5', '2'], question: 'Какое число дальше?' },
            { sequence: ['⭐', '⭕', '⭐', '⭕'], correct: '⭐', options: ['⭐', '⭕', '🔺'], question: 'Что дальше?' },
            { sequence: ['🔴', '🔴', '🔵', '🔵'], correct: '🔴', options: ['🔴', '🔵', '🟢'], question: 'Продолжи узор' },
            { sequence: ['2', '4', '6'], correct: '8', options: ['8', '10', '7'], question: 'Следующее число?' },
            { sequence: ['🐱', '🐶', '🐱', '🐶'], correct: '🐱', options: ['🐱', '🐶', '🐻'], question: 'Кто следующий?' },
            { sequence: ['🟩', '🟨', '🟩', '🟨'], correct: '🟩', options: ['🟩', '🟨', '🟥'], question: 'Продолжи ряд' },
            { sequence: ['1', '3', '5'], correct: '7', options: ['7', '6', '9'], question: 'Какое число дальше?' },
            { sequence: ['🔺', '⬜', '🔺', '⬜'], correct: '🔺', options: ['🔺', '⬜', '⭕'], question: 'Что дальше?' },
            { sequence: ['3', '6', '9'], correct: '12', options: ['12', '10', '15'], question: 'Следующее число?' },
            { sequence: ['🐰', '🐻', '🐰', '🐻'], correct: '🐰', options: ['🐰', '🐻', '🐶'], question: 'Кто следующий?' }
        ];
        const shuffled = this.shuffle([...pool]);
        const pick = shuffled.slice(0, 6);
        return pick.map((q) => ({
            type: 'sequence',
            question: q.question,
            sequence: q.sequence,
            correct: q.correct,
            options: this.shuffle(q.options.slice()),
            xp: 15
        }));
    }

    generatePatternQuestions(lesson) {
        const pool = [
            { pattern: '⭐⭕⭐', correct: '⭐⭕⭐', options: ['⭐⭕⭐', '⭕⭐⭕', '⭐⭐⭕'] },
            { pattern: '🔴🔵🔴', correct: '🔴🔵🔴', options: ['🔴🔵🔴', '🔵🔴🔵', '🔴🔴🔵'] },
            { pattern: '▲■▲', correct: '▲■▲', options: ['▲■▲', '■▲■', '▲▲■'] },
            { pattern: '🟥🟦🟥', correct: '🟥🟦🟥', options: ['🟥🟦🟥', '🟦🟥🟦', '🟥🟥🟦'] },
            { pattern: '1-2-1', correct: '1-2-1', options: ['1-2-1', '2-1-2', '1-1-2'] },
            { pattern: '🟩🟨🟩', correct: '🟩🟨🟩', options: ['🟩🟨🟩', '🟨🟩🟨', '🟩🟩🟨'] },
            { pattern: '🐱🐶🐱', correct: '🐱🐶🐱', options: ['🐱🐶🐱', '🐶🐱🐶', '🐱🐱🐶'] },
            { pattern: '🔺⭕🔺', correct: '🔺⭕🔺', options: ['🔺⭕🔺', '⭕🔺⭕', '🔺🔺⭕'] }
        ];
        const shuffled = this.shuffle([...pool]);
        const pick = shuffled.slice(0, 6);
        return pick.map((q) => ({
            type: 'pattern',
            question: 'Найди такой же узор',
            pattern: q.pattern,
            correct: q.correct,
            options: this.shuffle(q.options.slice()),
            xp: 15
        }));
    }

    generatePairQuestions(lesson) {
        const pool = [
            { question: 'Найди пару к носку', correct: '🧦', options: ['🧦', '🧤', '🧢'] },
            { question: 'Что подходит к лисе?', correct: '🦊', options: ['🦊', '🐻', '🐰'] },
            { question: 'Продолжи: холодно — зима, тепло — ...', correct: 'Лето', options: ['Лето', 'Осень', 'Весна'] },
            { question: 'День — наоборот?', correct: 'Ночь', options: ['Ночь', 'Утро', 'Вечер'] },
            { question: 'Найди пару к варежке', correct: '🧤', options: ['🧤', '🧦', '🧢'] },
            { question: 'Молоко — что к нему подходит?', correct: '🥛', options: ['🥛', '🍎', '🚗'] },
            { question: 'Книга — найди пару по смыслу', correct: '📖', options: ['📖', '✏️', '🎒'] },
            { question: 'Солнце — день. Луна — ...', correct: 'Ночь', options: ['Ночь', 'Утро', 'День'] },
            { question: 'Найди пару к тарелке', correct: '🍽️', options: ['🍽️', '🥤', '📚'] }
        ];
        const shuffled = this.shuffle([...pool]);
        const pick = shuffled.slice(0, 6);
        return pick.map((q) => ({
            type: 'pair',
            question: q.question,
            correct: q.correct,
            options: this.shuffle(q.options.slice()),
            xp: 10
        }));
    }

    generateClassificationQuestions(lesson) {
        const pool = [
            { question: 'Кто живёт в лесу?', correct: '🦊', options: ['🦊', '🐮', '🐔'] },
            { question: 'Что едят?', correct: '🍎', options: ['🍎', '🚗', '📚'] },
            { question: 'Кто не животное?', correct: '🌳', options: ['🌳', '🐶', '🐱'] },
            { question: 'Что растёт в саду?', correct: '🥕', options: ['🥕', '✈️', '🪑'] },
            { question: 'Что из школы?', correct: '📖', options: ['📖', '🐺', '🍕'] },
            { question: 'Что можно пить?', correct: '🥛', options: ['🥛', '🚌', '🪑'] },
            { question: 'Кто летает?', correct: '🐦', options: ['🐦', '🐟', '🐻'] },
            { question: 'Что не еда?', correct: '✈️', options: ['✈️', '🍞', '🥕'] },
            { question: 'Что нужно для письма?', correct: '✏️', options: ['✏️', '🐱', '🍎'] },
            { question: 'Что растёт на дереве?', correct: '🍎', options: ['🍎', '🥕', '📚'] }
        ];
        const shuffled = this.shuffle([...pool]);
        const pick = shuffled.slice(0, 6);
        return pick.map((q) => ({
            type: 'classification',
            question: q.question,
            correct: q.correct,
            options: this.shuffle(q.options.slice()),
            xp: 10
        }));
    }

    generatePartsQuestions(lesson) {
        const pool = [
            { question: 'Что есть у машины?', correct: 'Колесо', options: ['Колесо', 'Лапа', 'Хвост'] },
            { question: 'Что есть у птицы?', correct: 'Крыло', options: ['Крыло', 'Плавник', 'Колесо'] },
            { question: 'Часть дерева?', correct: 'Лист', options: ['Лист', 'Колесо', 'Крыло'] },
            { question: 'Что есть у рыбы?', correct: 'Плавник', options: ['Плавник', 'Лапа', 'Крыло'] },
            { question: 'Часть дома?', correct: 'Крыша', options: ['Крыша', 'Хвост', 'Лапа'] },
            { question: 'Что есть у собаки?', correct: 'Лапа', options: ['Лапа', 'Крыло', 'Плавник'] },
            { question: 'Часть книги?', correct: 'Страница', options: ['Страница', 'Колесо', 'Крыша'] }
        ];
        const shuffled = this.shuffle([...pool]);
        return shuffled.slice(0, 6).map((q) => ({
            type: 'parts',
            question: q.question,
            correct: q.correct,
            options: this.shuffle(q.options.slice()),
            xp: 10
        }));
    }

    generateSentenceQuestions(lesson) {
        const pool = [
            { question: 'Кто что делает?', correct: 'Кошка спит', options: ['Кошка спит', 'Спит кошка', 'Кошка ест'] },
            { question: 'Выбери правильное предложение', correct: 'Мама готовит', options: ['Мама готовит', 'Готовит мама', 'Мама спит'] },
            { question: 'Какой вариант верный?', correct: 'Собака бежит', options: ['Собака бежит', 'Бежит собака', 'Собака сидит'] },
            { question: 'Составь предложение', correct: 'Папа читает', options: ['Папа читает', 'Читает папа', 'Папа спит'] },
            { question: 'Найди правильную фразу', correct: 'Дети играют', options: ['Дети играют', 'Играют дети', 'Дети спят'] },
            { question: 'Что делает солнце?', correct: 'Солнце светит', options: ['Солнце светит', 'Светит солнце', 'Солнце спит'] },
            { question: 'Выбери верное', correct: 'Дождь идёт', options: ['Дождь идёт', 'Идёт дождь', 'Дождь светит'] },
            { question: 'Какое предложение правильное?', correct: 'Птица летит', options: ['Птица летит', 'Летит птица', 'Птица бежит'] },
            { question: 'Выбери правильную фразу', correct: 'Учитель учит', options: ['Учитель учит', 'Учит учитель', 'Учитель спит'] },
            { question: 'Найди верное предложение', correct: 'Птицы поют', options: ['Птицы поют', 'Поют птицы', 'Птицы молчат'] }
        ];
        const shuffled = this.shuffle([...pool]);
        const pick = shuffled.slice(0, 6);
        return pick.map((q) => ({
            type: 'sentence',
            question: q.question,
            correct: q.correct,
            options: this.shuffle(q.options.slice()),
            xp: 15
        }));
    }
    
    generateReasonQuestions(lesson) {
        const pool = [
            { question: 'Почему тает снег?', correct: 'Тепло', options: ['Тепло', 'Холодно', 'Ночь'] },
            { question: 'Почему мокрый зонт?', correct: 'Дождь', options: ['Дождь', 'Солнце', 'Ветер'] },
            { question: 'Почему темно ночью?', correct: 'Нет солнца', options: ['Нет солнца', 'Холодно', 'Дождь'] },
            { question: 'Почему цветок вырос?', correct: 'Поливали', options: ['Поливали', 'Мороз', 'Темно'] },
            { question: 'Почему мы надеваем шапку?', correct: 'Холодно', options: ['Холодно', 'Жарко', 'Дождь'] },
            { question: 'Почему птицы улетают осенью?', correct: 'Холодно', options: ['Холодно', 'Жарко', 'Светло'] },
            { question: 'Почему мы едим?', correct: 'Голод', options: ['Голод', 'Холод', 'Сон'] }
        ];
        const shuffled = this.shuffle([...pool]);
        return shuffled.slice(0, 6).map((q) => ({
            type: 'cause',
            question: q.question,
            correct: q.correct,
            options: this.shuffle(q.options.slice()),
            xp: 15
        }));
    }

    generateOppositeQuestions(lesson) {
        const pool = [
            { question: 'День — наоборот?', correct: 'Ночь', options: ['Ночь', 'Утро', 'Вечер'] },
            { question: 'Горячо — наоборот?', correct: 'Холодно', options: ['Холодно', 'Тёпло', 'Мокро'] },
            { question: 'Высоко — наоборот?', correct: 'Низко', options: ['Низко', 'Далеко', 'Широко'] },
            { question: 'Большой — наоборот?', correct: 'Маленький', options: ['Маленький', 'Средний', 'Узкий'] },
            { question: 'Быстро — наоборот?', correct: 'Медленно', options: ['Медленно', 'Тихо', 'Редко'] },
            { question: 'Светло — наоборот?', correct: 'Темно', options: ['Темно', 'Ярко', 'Ранно'] },
            { question: 'Громко — наоборот?', correct: 'Тихо', options: ['Тихо', 'Быстро', 'Редко'] }
        ];
        const shuffled = this.shuffle([...pool]);
        return shuffled.slice(0, 6).map((q) => ({
            type: 'opposite',
            question: q.question,
            correct: q.correct,
            options: this.shuffle(q.options.slice()),
            xp: 10
        }));
    }
    
    generateSortingQuestions(lesson) {
        const pool = [
            { question: 'Выбери красное', correct: '🍎', options: ['🍎', '🍏', '🍋'] },
            { question: 'Найди жёлтое', correct: '🍋', options: ['🍋', '🍎', '🍇'] },
            { question: 'Что круглое?', correct: '⭕', options: ['⭕', '⬜', '🔺'] },
            { question: 'Выбери животное', correct: '🐶', options: ['🐶', '🚗', '📚'] },
            { question: 'Что можно съесть?', correct: '🍕', options: ['🍕', '✈️', '🪑'] },
            { question: 'Выбери синее', correct: '🟦', options: ['🟦', '🟥', '🟩'] },
            { question: 'Что из школы?', correct: '📖', options: ['📖', '🐱', '🍎'] }
        ];
        const shuffled = this.shuffle([...pool]);
        return shuffled.slice(0, 6).map((q) => ({
            type: 'sorting',
            question: q.question,
            correct: q.correct,
            options: this.shuffle(q.options.slice()),
            xp: 10
        }));
    }

    generateShapeQuestions(lesson) {
        const shapeMap = {
            'circle': { shape: 'круг', emoji: '⭕', sides: 0 },
            'square': { shape: 'квадрат', emoji: '⬜', sides: 4 },
            'triangle': { shape: 'треугольник', emoji: '🔺', sides: 3 },
            'rectangle': { shape: 'прямоугольник', emoji: '▭', sides: 4 },
            'star': { shape: 'звезда', emoji: '⭐', sides: 10 },
            'heart': { shape: 'сердце', emoji: '❤️', sides: 0 },
        };

        const data = shapeMap[lesson.id] || shapeMap['circle'];
        const t = this.getTranslations();
        const allNames = ['круг', 'квадрат', 'треугольник', 'прямоугольник', 'звезда', 'сердце'];
        const distractors = allNames.filter(n => n !== data.shape);
        const opts = this.shuffle([data.shape, ...this.shuffle(distractors).slice(0, 3)]);
        const correctIndex = opts.indexOf(data.shape);

        return [
            {
                type: 'multiple-choice',
                question: t.findShapeQuestion ? t.findShapeQuestion.replace('{shape}', data.shape) : `Найди ${data.shape}`,
                emoji: data.emoji,
                options: opts,
                correct: correctIndex >= 0 ? correctIndex : 0,
                xp: 10
            }
        ];
    }

    generateMultiplicationQuestions(lesson) {
        const questions = [];
        for (let i = 0; i < 5; i++) {
            const a = Math.floor(Math.random() * 5) + 1;
            const b = Math.floor(Math.random() * 5) + 1;
            const correct = a * b;
            
            questions.push({
                type: 'multiplication',
                question: `${a} • ${b} = ?`,
                a: a,
                b: b,
                correct: correct,
                options: this.shuffle([correct, correct + a, correct - 1, correct + b].filter(n => n > 0)).slice(0, 4),
                xp: 15
            });
        }
        return questions;
    }

    generateDivisionQuestions(lesson) {
        const questions = [];
        for (let i = 0; i < 5; i++) {
            const b = Math.floor(Math.random() * 5) + 1;
            const correct = Math.floor(Math.random() * 5) + 1;
            const a = b * correct;
            
            questions.push({
                type: 'division',
                question: `${a} : ${b} = ?`,
                a: a,
                b: b,
                correct: correct,
                options: this.shuffle([correct, correct + 1, correct > 1 ? correct - 1 : correct + 2, correct + 3].filter(n => n > 0)).slice(0, 4),
                xp: 15
            });
        }
        return questions;
    }

    generateStoryQuestions(lesson) {
        const stories = {
            'story1': {
                text: 'Летом очень тепло. Солнце светит ярко. Дети играют на улице.',
                title: 'Лето',
                questions: [
                    { q: 'Какое время года?', correct: 'Лето', options: ['Лето', 'Зима', 'Осень', 'Весна'] },
                    { q: 'Что делает солнце?', correct: 'Светит', options: ['Светит', 'Спит', 'Ест'] },
                    { q: 'Кто играет на улице?', correct: 'Дети', options: ['Дети', 'Птицы', 'Коты'] }
                ]
            },
            'story2': {
                text: 'Мама пошла в магазин. Она купила молоко и хлеб.',
                title: 'Магазин',
                questions: [
                    { q: 'Куда пошла мама?', correct: 'В магазин', options: ['В магазин', 'В парк', 'В школу'] },
                    { q: 'Что купила мама?', correct: 'Молоко', options: ['Молоко', 'Машину', 'Книгу'] }
                ]
            },
            'story3': {
                text: 'У Вани есть собака. Её зовут Бобик. Бобик любит играть с мячом.',
                title: 'Друг',
                questions: [
                    { q: 'У кого есть собака?', correct: 'У Вани', options: ['У Вани', 'У Маши', 'У Пети'] },
                    { q: 'Как зовут собаку?', correct: 'Бобик', options: ['Бобик', 'Мурзик', 'Шарик'] },
                    { q: 'С чем играет Бобик?', correct: 'С мячом', options: ['С мячом', 'С котом', 'С палкой'] }
                ]
            },
            'story4': {
                text: 'В школе звенит звонок. Дети садятся за парты. Учитель открывает учебник и начинает урок.',
                title: 'В школе',
                questions: [
                    { q: 'Где звенит звонок?', correct: 'В школе', options: ['В школе', 'Дома', 'В парке'] },
                    { q: 'Куда садятся дети?', correct: 'За парты', options: ['За парты', 'На пол', 'На улицу'] },
                    { q: 'Кто открывает учебник?', correct: 'Учитель', options: ['Учитель', 'Ученик', 'Мама'] }
                ]
            }
        };
        const data = stories[lesson.id] || stories['story1'];
        return data.questions.map(q => ({
            type: 'story',
            storyTitle: data.title,
            text: data.text,
            question: q.q,
            correct: q.correct,
            options: this.shuffle(q.options.slice()),
            xp: 20
        }));
    }

    generateLiteracyQuestions(lesson) {
        // lit1: Synonyms, lit2: Antonyms, lit3: Пословицы (proverbs)
        if (lesson.id === 'lit1') {
            const pool = [
                { question: 'Смелый — это...', correct: 'Храбрый', options: ['Храбрый', 'Трусливый', 'Слабый'] },
                { question: 'Большой — это...', correct: 'Огромный', options: ['Огромный', 'Маленький', 'Синий'] },
                { question: 'Бежать — это...', correct: 'Мчаться', options: ['Мчаться', 'Стоять', 'Спать'] },
                { question: 'Грустный — это...', correct: 'Печальный', options: ['Печальный', 'Весёлый', 'Быстрый'] },
                { question: 'Думать — это...', correct: 'Размышлять', options: ['Размышлять', 'Бежать', 'Молчать'] }
            ];
            return this.shuffle([...pool]).slice(0, 5).map(q => ({
                type: 'pair', question: q.question, correct: q.correct, options: this.shuffle(q.options.slice()), xp: 10
            }));
        }
        if (lesson.id === 'lit2') {
            const pool = [
                { question: 'День — наоборот...', correct: 'Ночь', options: ['Ночь', 'Утро', 'Вечер'] },
                { question: 'Холодно — наоборот...', correct: 'Жарко', options: ['Жарко', 'Мокро', 'Светло'] },
                { question: 'Быстро — наоборот...', correct: 'Медленно', options: ['Медленно', 'Весело', 'Громко'] },
                { question: 'Высоко — наоборот...', correct: 'Низко', options: ['Низко', 'Далеко', 'Широко'] },
                { question: 'Громко — наоборот...', correct: 'Тихо', options: ['Тихо', 'Ярко', 'Редко'] }
            ];
            return this.shuffle([...pool]).slice(0, 5).map(q => ({
                type: 'pair', question: q.question, correct: q.correct, options: this.shuffle(q.options.slice()), xp: 10
            }));
        }
        if (lesson.id === 'lit3') {
            // Пословицы: закончи фразу
            const pool = [
                { question: 'Закончи: Ученье свет...', correct: 'а неученье — тьма', options: ['а неученье — тьма', 'а лень — враг', 'а книга — друг'] },
                { question: 'Закончи: Семь раз отмерь...', correct: 'один раз отрежь', options: ['один раз отрежь', 'два раза проверь', 'не спеши'] },
                { question: 'Закончи: Дело мастера...', correct: 'боится', options: ['боится', 'любит', 'ждёт'] },
                { question: 'Закончи: Терпение и труд...', correct: 'всё перетрут', options: ['всё перетрут', 'вместе сила', 'всё сметут'] },
                { question: 'Закончи: Не спеши языком...', correct: 'торопись делом', options: ['торопись делом', 'думай головой', 'смотри вперёд'] }
            ];
            return this.shuffle([...pool]).slice(0, 5).map(q => ({
                type: 'pair', question: q.question, correct: q.correct, options: this.shuffle(q.options.slice()), xp: 15
            }));
        }
        return [
            { type: 'pair', question: 'Найди пару', correct: '🧦', options: this.shuffle(['🧦', '🧤', '🧢']), xp: 10 }
        ];
    }

    renderQuestion() {
        if (this.currentQuestionIndex >= this.questions.length) {
            this.completeLesson();
            return;
        }

        const question = this.questions[this.currentQuestionIndex];
        const taskContainer = document.getElementById('taskContainer');
        const checkBtn = document.getElementById('checkBtn');
        const continueBtn = document.getElementById('continueBtn');

        const progress = ((this.currentQuestionIndex + 1) / this.questions.length) * 100;
        document.getElementById('lessonProgressFill').style.width = `${progress}%`;
        document.getElementById('currentQuestion').textContent = this.currentQuestionIndex + 1;
        document.getElementById('totalQuestions').textContent = this.questions.length;

        checkBtn.disabled = true;
        checkBtn.classList.remove('hidden');
        continueBtn.classList.add('hidden');
        this.userAnswer = null;

        if (question.type === 'intro-screen') {
            taskContainer.innerHTML = this.renderIntroScreen(question);
            this.setupIntroScreenHandlers(question);
        } else if (question.type === 'multiple-choice') {
            taskContainer.innerHTML = this.renderMultipleChoice(question);
        } else if (question.type === 'image-choice') {
            taskContainer.innerHTML = this.renderImageChoice(question);
        } else if (question.type === 'counting') {
            taskContainer.innerHTML = this.renderCounting(question);
        } else if (question.type === 'addition') {
            taskContainer.innerHTML = this.renderAddition(question);
        } else if (question.type === 'subtraction') {
            taskContainer.innerHTML = this.renderSubtraction(question);
        } else if (question.type === 'comparison-math') {
            taskContainer.innerHTML = this.renderComparisonMath(question);
        } else if (question.type === 'comparison-logic') {
            taskContainer.innerHTML = this.renderComparisonLogic(question);
        } else if (question.type === 'sequence' || question.type === 'pattern') {
            taskContainer.innerHTML = this.renderSequence(question);
        } else if (question.type === 'pair' || question.type === 'opposite' || question.type === 'classification' || question.type === 'sorting' || question.type === 'parts' || question.type === 'cause') {
            taskContainer.innerHTML = this.renderMultipleChoice(question); 
        } else if (question.type === 'drag-drop') {
            taskContainer.innerHTML = this.renderDragDrop(question);
        } else if (question.type === 'sentence') {
             taskContainer.innerHTML = this.renderMultipleChoice(question);
        } else if (question.type === 'multiplication') {
            taskContainer.innerHTML = this.renderMultiplication(question);
        } else if (question.type === 'division') {
            taskContainer.innerHTML = this.renderDivision(question);
        } else if (question.type === 'story') {
            taskContainer.innerHTML = this.renderStory(question);
        }

        // Заполняем зелёную область сообщения тьютора (подсказка «Нажми и говори»)
        const messageContent = document.getElementById('messageContent');
        if (messageContent) {
            const promptText = question.type === 'intro-screen'
                ? (question.text || question.voiceText || '')
                : (question.question || '');
            const hintText = question.voiceText && question.type === 'intro-screen'
                ? question.voiceText
                : promptText;
            messageContent.textContent = hintText || (this.currentLang === 'ru' ? 'Скажи ответ или нажми кнопку «Нажми и говори»' : 'Жауапты айтыңыз немесе «Басып айтыңыз» батырмасын басыңыз');
        }

        if (question.type !== 'intro-screen') {
            this.attachQuestionHandlers(question);
        }
        
        if (this.voiceAssistant) {
            const options = question.options || [];
            this.voiceAssistant.updateOptions(options);
            if (question.type !== 'intro-screen') {
                if (this.voiceAssistant.pendingSpeakTimeout) {
                    clearTimeout(this.voiceAssistant.pendingSpeakTimeout);
                }
                this.voiceAssistant.pendingSpeakTimeout = setTimeout(() => {
                    this.voiceAssistant.pendingSpeakTimeout = null;
                    this.voiceAssistant.speakQuestionWithProgress(
                        question,
                        this.currentQuestionIndex + 1,
                        this.questions.length
                    );
                }, 500);
            }
        }
    }

    renderSubtraction(question) {
        return `
            <div class="question-content">
                <div class="question-text">${question.question}</div>
                <div class="addition-visual">
                    <div class="addition-part">${question.a}</div>
                    <div class="addition-sign">-</div>
                    <div class="addition-part">${question.b}</div>
                    <div class="addition-equals">=</div>
                    <div class="addition-result">?</div>
                </div>
                <div class="options-grid">
                    ${question.options.map((option, index) => `
                        <button class="option-btn" data-index="${index}">
                            ${option}
                        </button>
                    `).join('')}
                </div>
            </div>
        `;
    }

    renderMultiplication(question) {
        return `
            <div class="question-content">
                <div class="question-text">${question.question}</div>
                <div class="addition-visual">
                    <div class="addition-part">${question.a}</div>
                    <div class="addition-sign">✖</div>
                    <div class="addition-part">${question.b}</div>
                    <div class="addition-equals">=</div>
                    <div class="addition-result">?</div>
                </div>
                <div class="options-grid">
                    ${question.options.map((option, index) => `
                        <button class="option-btn" data-index="${index}">
                            ${option}
                        </button>
                    `).join('')}
                </div>
            </div>
        `;
    }

    renderDivision(question) {
        return `
            <div class="question-content">
                <div class="question-text">${question.question}</div>
                <div class="addition-visual">
                    <div class="addition-part">${question.a}</div>
                    <div class="addition-sign">:</div>
                    <div class="addition-part">${question.b}</div>
                    <div class="addition-equals">=</div>
                    <div class="addition-result">?</div>
                </div>
                <div class="options-grid">
                    ${question.options.map((option, index) => `
                        <button class="option-btn" data-index="${index}">
                            ${option}
                        </button>
                    `).join('')}
                </div>
            </div>
        `;
    }

    renderStory(question) {
        return `
            <div class="question-content">
                <div class="story-block" style="background: #FFF3E0; padding: 20px; border-radius: 12px; margin-bottom: 20px; font-size: 24px; text-align: left; line-height: 1.5;">
                    <div style="font-weight: bold; margin-bottom: 10px; color: #E65100;">${question.storyTitle}</div>
                    ${question.text}
                </div>
                <div class="question-text">${question.question}</div>
                <div class="options-grid">
                    ${question.options.map((option, index) => `
                        <button class="option-btn" data-index="${index}">
                            ${option}
                        </button>
                    `).join('')}
                </div>
            </div>
        `;
    }

    renderComparisonMath(question) {
        return `
            <div class="question-content">
                <div class="question-text">${question.question}</div>
                <div class="addition-visual">
                    <div class="addition-part">${question.left}</div>
                    <div class="addition-result">?</div>
                    <div class="addition-part">${question.right}</div>
                </div>
                <div class="options-grid">
                    ${question.options.map((option, index) => `
                        <button class="option-btn" data-index="${index}">
                            ${option}
                        </button>
                    `).join('')}
                </div>
            </div>
        `;
    }

    renderComparisonLogic(question) {
        return `
            <div class="question-content">
                <div class="question-text">${question.question}</div>
                <div class="intro-images" style="display: flex; gap: 40px; justify-content: center; margin: 30px 0;">
                    <div class="intro-image-card" style="font-size: 60px;">${question.left}</div>
                    <div class="intro-image-card" style="font-size: 60px;">${question.right}</div>
                </div>
                <div class="options-grid">
                     ${question.options.map((option, index) => `
                        <button class="option-btn" data-index="${index}">
                            ${option}
                        </button>
                    `).join('')}
                </div>
            </div>
        `;
    }

    renderSequence(question) {
         return `
            <div class="question-content">
                <div class="question-text">${question.question}</div>
                <div class="sequence-display" style="font-size: 40px; margin: 20px; display:flex; gap: 10px; justify-content:center;">
                    ${question.sequence ? question.sequence.join(' ➝ ') + ' ➝ ❓' : question.pattern + ' ❓'}
                </div>
                <div class="options-grid">
                    ${question.options.map((option, index) => `
                        <button class="option-btn" data-index="${index}">
                            ${option}
                        </button>
                    `).join('')}
                </div>
            </div>
        `;
    }

    renderMultipleChoice(question) {
        return `
            <div class="question-content">
                <div class="question-text">${question.question}</div>
                ${question.image ? `<div class="question-image">${question.image}</div>` : ''}
                ${question.emoji ? `<div class="question-emoji">${question.emoji}</div>` : ''}
                <div class="options-grid">
                    ${question.options.map((option, index) => `
                        <button class="option-btn" data-index="${index}">
                            ${option}
                        </button>
                    `).join('')}
                </div>
            </div>
        `;
    }

    renderImageChoice(question) {
        return `
            <div class="question-content">
                <div class="question-text">${question.question}</div>
                <div class="image-options-grid">
                    ${question.options.map((option, index) => `
                        <button class="image-option-btn" data-index="${index}">
                            <div class="image-option-icon">${option}</div>
                        </button>
                    `).join('')}
                </div>
            </div>
        `;
    }

    renderCounting(question) {
        return `
            <div class="question-content">
                <div class="question-text">${question.question}</div>
                <div class="counting-images">
                    ${question.images.map(img => `<span class="count-image">${img}</span>`).join('')}
                </div>
                <div class="options-grid">
                    ${question.options.map((option, index) => `
                        <button class="option-btn" data-index="${index}">
                            ${option}
                        </button>
                    `).join('')}
                </div>
            </div>
        `;
    }

    renderAddition(question) {
        return `
            <div class="question-content">
                <div class="question-text">${question.question}</div>
                <div class="addition-visual">
                    <div class="addition-part">${question.a}</div>
                    <div class="addition-sign">+</div>
                    <div class="addition-part">${question.b}</div>
                    <div class="addition-equals">=</div>
                    <div class="addition-result">?</div>
                </div>
                <div class="options-grid">
                    ${question.options.map((option, index) => `
                        <button class="option-btn" data-index="${index}">
                            ${option}
                        </button>
                    `).join('')}
                </div>
            </div>
        `;
    }

    renderDragDrop(question) {
        return `
            <div class="question-content">
                <div class="question-text">${question.question}</div>
                <div class="drag-drop-container">
                    <div class="drop-zone" id="dropZone">
                        ${Array(question.letters.length).fill(0).map(() => `
                            <div class="drop-slot"></div>
                        `).join('')}
                    </div>
                    <div class="drag-items" id="dragItems">
                        ${question.letters.map((letter, index) => `
                            <div class="drag-item" draggable="true" data-letter="${letter}">
                                ${letter}
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;
    }

    renderIntroScreen(question) {
        const screen = question.screen;
        
        if (screen === 'greeting') {
            return `
                <div class="intro-screen intro-greeting">
                    <div class="intro-text-large">${question.text}</div>
                    ${question.icon ? `<div class="intro-icon-large">${question.icon}</div>` : ''}
                </div>
            `;
        } else if (screen === 'voice-control') {
            return `
                <div class="intro-screen intro-voice-control">
                    <div class="intro-icon-large">${question.icon || '🎤'}</div>
                    <div class="intro-text-large">${question.text}</div>
                </div>
            `;
        } else if (screen === 'visual-count' || screen === 'visual-result') {
            const circlesHtml = question.circles ? question.circles.map(count => 
                Array(count).fill('⭕').join('')
            ).join(' ') : '';
            return `
                <div class="intro-screen intro-visual">
                    <div class="intro-text-large">${question.text}</div>
                    <div class="intro-circles" style="font-size: 60px; margin: 30px 0; display: flex; gap: 20px; justify-content: center; flex-wrap: wrap;">
                        ${circlesHtml}
                    </div>
                </div>
            `;
        } else if (screen === 'visual-explanation') {
            const circlesHtml = question.circles ? question.circles.map((count, idx) => {
                const circles = Array(count).fill('⭕').join('');
                return `<div class="circle-group" style="margin: 20px; display: flex; gap: 10px; justify-content: center; font-size: 50px;">${circles}</div>`;
            }).join('') : '';
            return `
                <div class="intro-screen intro-visual-explanation">
                    <div class="intro-text-large">${question.text}</div>
                    <div class="intro-circles-container">
                        ${circlesHtml}
                    </div>
                </div>
            `;
        } else if (screen === 'simple-question') {
            const circlesHtml = question.circles ? question.circles.map(count => 
                Array(count).fill('⭕').join('')
            ).join(' ') : '';
            return `
                <div class="intro-screen intro-question">
                    <div class="intro-text-large">${question.text}</div>
                    ${circlesHtml ? `<div class="intro-circles" style="font-size: 60px; margin: 30px 0; display: flex; gap: 20px; justify-content: center; flex-wrap: wrap;">${circlesHtml}</div>` : ''}
                    ${question.options ? `
                        <div class="intro-options" style="display: flex; gap: 20px; justify-content: center; margin-top: 30px;">
                            ${question.options.map((opt, idx) => `
                                <div class="intro-option-card" style="padding: 20px 40px; background: #E1BEE7; border-radius: 16px; font-size: 32px; font-weight: bold;">
                                    ${opt}
                                </div>
                            `).join('')}
                        </div>
                    ` : ''}
                </div>
            `;
        } else if (screen === 'word-listening') {
            return `
                <div class="intro-screen intro-word-listening">
                    <div class="intro-text-large">${question.text}</div>
                    <div class="intro-word-large" style="font-size: 48px; margin: 30px 0; color: #9C27B0; font-weight: bold;">
                        ${question.word}
                    </div>
                </div>
            `;
        } else if (screen === 'visual-choice') {
            return `
                <div class="intro-screen intro-visual-choice">
                    <div class="intro-text-large">${question.text}</div>
                    <div class="intro-images" style="display: flex; gap: 40px; justify-content: center; margin: 30px 0;">
                        ${question.images.map((img, idx) => `
                            <div class="intro-image-card" style="font-size: 80px; padding: 30px; background: #F3E5F5; border-radius: 20px;">
                                ${img}
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        } else if (screen === 'support') {
            return `
                <div class="intro-screen intro-support">
                    <div class="intro-icon-large" style="font-size: 80px; margin: 20px 0;">${question.icon || '🌱'}</div>
                    <div class="intro-text-large">${question.text}</div>
                </div>
            `;
        } else if (screen === 'completion') {
            return `
                <div class="intro-screen intro-completion">
                    <div class="intro-text-large">${question.text}</div>
                    ${question.icon ? `<div class="intro-icon-large" style="font-size: 80px; margin: 20px 0;">${question.icon}</div>` : ''}
                </div>
            `;
        }
        
        return `<div class="intro-screen">${question.text}</div>`;
    }
    
    setupIntroScreenHandlers(question) {
        // Скрываем стандартные кнопки для вводных уроков
        const checkBtn = document.getElementById('checkBtn');
        const continueBtn = document.getElementById('continueBtn');
        if (checkBtn) checkBtn.classList.add('hidden');
        if (continueBtn) continueBtn.classList.add('hidden');
        
        // Озвучиваем текст экрана
        if (this.voiceAssistant && question.voiceText) {
            setTimeout(() => {
                this.voiceAssistant.speak(question.voiceText);
            }, question.delay || 500);
        }
        
        // Настраиваем ожидание голосовой команды
        if (question.expectedCommand) {
            this.waitingForCommand = true;
            this.expectedCommands = question.expectedCommand;
            this.currentQuestionData = question;
            
            // Обновляем голосового помощника для минимальных команд
            if (this.voiceAssistant) {
                this.voiceAssistant.setupMinimalCommands(question.expectedCommand, question.acceptFuzzy);
            }
        }
        
        // Автоматический переход для экранов без команд
        if (!question.expectedCommand && question.delay) {
            setTimeout(() => {
                this.continueLesson();
            }, question.delay);
        }
    }

    attachQuestionHandlers(question) {
        const questionObj = this.questions[this.currentQuestionIndex];
        
        if (question.type === 'drag-drop') {
            this.initDragDrop(questionObj);
        } else {
            // Обработчики для кнопок выбора
            document.querySelectorAll('.option-btn, .image-option-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    // Убираем выделение с других кнопок
                    document.querySelectorAll('.option-btn, .image-option-btn').forEach(b => {
                        b.classList.remove('selected');
                    });
                    
                    // Выделяем выбранную кнопку
                    btn.classList.add('selected');
                    this.userAnswer = parseInt(btn.dataset.index);
                    
                    // Активируем кнопку проверки
                    document.getElementById('checkBtn').disabled = false;
                });

                // Клавиатурная навигация
                btn.setAttribute('tabindex', '0');
                btn.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        btn.click();
                    }
                });
            });
        }
    }

    initDragDrop(question) {
        const dragItems = document.querySelectorAll('.drag-item');
        const dropSlots = document.querySelectorAll('.drop-slot');
        const dropZone = document.getElementById('dropZone');
        
        let draggedItem = null;
        let filledSlots = [];

        dragItems.forEach(item => {
            item.addEventListener('dragstart', (e) => {
                draggedItem = item;
                e.dataTransfer.effectAllowed = 'move';
            });

            item.addEventListener('dragend', () => {
                draggedItem = null;
            });
        });

        dropSlots.forEach((slot, index) => {
            slot.addEventListener('dragover', (e) => {
                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';
                if (!slot.querySelector('.drag-item')) {
                    slot.classList.add('drag-over');
                }
            });

            slot.addEventListener('dragleave', () => {
                slot.classList.remove('drag-over');
            });

            slot.addEventListener('drop', (e) => {
                e.preventDefault();
                slot.classList.remove('drag-over');
                
                if (draggedItem && !slot.querySelector('.drag-item')) {
                    slot.appendChild(draggedItem);
                    filledSlots[index] = draggedItem.dataset.letter;
                    
                    // Проверяем, все ли слоты заполнены
                    if (filledSlots.filter(s => s).length === dropSlots.length) {
                        this.userAnswer = filledSlots.join('');
                        document.getElementById('checkBtn').disabled = false;
                    }
                }
            });
        });
    }

    checkAnswer() {
        const question = this.questions[this.currentQuestionIndex];
        
        // Для вводных уроков не проверяем правильность
        if (question.type === 'intro-screen' && question.noEvaluation) {
            // Просто продолжаем без оценки
            setTimeout(() => {
                this.continueLesson();
            }, 2000);
            return;
        }
        
        const checkBtn = document.getElementById('checkBtn');
        const continueBtn = document.getElementById('continueBtn');
        
        let isCorrect = false;

        if (question.type === 'drag-drop') {
            const correctWord = question.word.toUpperCase();
            isCorrect = this.userAnswer === correctWord;
        } else if (question.type === 'counting' && question.options && typeof this.userAnswer === 'number') {
            // В счёте correct — это количество предметов (значение), userAnswer — индекс кнопки
            const selectedValue = question.options[this.userAnswer];
            isCorrect = Number(selectedValue) === Number(question.correct);
        } else if (question.options && typeof this.userAnswer === 'number') {
            const selectedValue = question.options[this.userAnswer];
            // question.correct может быть индексом (0,1,2,3) или значением (сумма, слово, эмодзи)
            const isCorrectIndex = typeof question.correct === 'number' &&
                question.correct >= 0 &&
                question.correct < question.options.length &&
                String(question.options[question.correct]) !== String(question.correct);
            if (isCorrectIndex) {
                isCorrect = this.userAnswer === question.correct;
            } else {
                isCorrect = String(selectedValue) === String(question.correct);
            }
        } else {
            // Прямое сравнение (для ввода текстом или других типов)
            isCorrect = String(this.userAnswer) === String(question.correct);
        }

        // Визуальная обратная связь
        if (isCorrect) {
            this.handleCorrectAnswer(question);
            // Голосовая обратная связь
            if (this.voiceAssistant) {
                this.voiceAssistant.announceCorrect();
            }
        } else {
            this.handleIncorrectAnswer(question);
            // Голосовая обратная связь
            if (this.voiceAssistant) {
                this.voiceAssistant.announceIncorrect();
            }
        }

        checkBtn.classList.add('hidden');
        continueBtn.classList.remove('hidden');
    }

    handleCorrectAnswer(question) {
        // Обновляем статистику
        this.correctAnswers++;
        this.totalXP += question.xp;
        
        // Обновляем отображение XP
        document.getElementById('currentXP').textContent = this.totalXP;
        
        // Показываем правильный ответ
        const selectedBtn = document.querySelector('.option-btn.selected, .image-option-btn.selected');
        if (selectedBtn) {
            selectedBtn.classList.add('correct');
        }

        // Анимация персонажа
        const character = document.getElementById('lessonCharacter');
        character.classList.add('celebrate');
        setTimeout(() => character.classList.remove('celebrate'), 1000);

        // Звуковая обратная связь (если включено)
        this.playSuccessSound();
    }

    handleIncorrectAnswer(question) {
        // Уменьшаем сердца
        this.hearts--;
        document.getElementById('heartsCount').textContent = this.hearts;

        // Индекс правильного ответа: question.correct может быть индексом (0,1,2,3) или значением (строка/число-результат)
        let correctIndex = -1;
        if (question.options && question.options.length) {
            if (typeof question.correct === 'number' && question.correct >= 0 && question.correct < question.options.length) {
                const valueAtIdx = question.options[question.correct];
                if (String(valueAtIdx) === String(question.correct)) {
                    correctIndex = question.correct;
                }
                if (correctIndex === -1) correctIndex = question.options.indexOf(question.correct);
            } else {
                correctIndex = question.options.indexOf(question.correct);
            }
        }
        if (correctIndex === -1) correctIndex = question.correct;

        const correctBtn = document.querySelector(`[data-index="${correctIndex}"]`);
        if (correctBtn) {
            correctBtn.classList.add('correct');
        }

        const selectedBtn = document.querySelector('.option-btn.selected, .image-option-btn.selected');
        if (selectedBtn && selectedBtn !== correctBtn) {
            selectedBtn.classList.add('incorrect');
        }

        // Если сердца закончились, предлагаем повторить
        if (this.hearts === 0) {
            setTimeout(() => {
                if (confirm(this.currentLang === 'ru' 
                    ? 'У тебя закончились сердца. Хочешь повторить урок?' 
                    : 'Сенің жүректерің бітті. Сабақты қайталағың келе ме?')) {
                    this.restartLesson();
                } else {
                    window.location.href = 'index.html';
                }
            }, 2000);
        }
    }

    continueLesson() {
        this.currentQuestionIndex++;
        this.renderQuestion();
    }

    completeLesson() {
        // Сохраняем прогресс
        this.saveProgress();
        
        // Обновляем XP профиля
        this.updateProfileXP();
        
        // Обновляем streak (серию дней)
        this.updateStreak();
        
        // Озвучиваем завершение урока
        if (this.voiceAssistant) {
            this.voiceAssistant.announceCompletion();
        }
        
        // Показываем экран завершения
        document.querySelector('.lesson-main').classList.add('hidden');
        document.getElementById('lessonComplete').classList.remove('hidden');
        
        document.getElementById('earnedXP').textContent = `+${this.totalXP}`;
        document.getElementById('correctAnswers').textContent = `${this.correctAnswers}/${this.questions.length}`;
    }

    saveProgress() {
        const progress = JSON.parse(localStorage.getItem(`progress_${this.currentProfile.id}`) || '{}');
        progress[this.lessonKey] = true;
        localStorage.setItem(`progress_${this.currentProfile.id}`, JSON.stringify(progress));
    }

    updateProfileXP() {
        const profiles = JSON.parse(localStorage.getItem('profiles') || '[]');
        const profile = profiles.find(p => p.id === this.currentProfile.id);
        if (profile) {
            profile.xp = (profile.xp || 0) + this.totalXP;
            localStorage.setItem('profiles', JSON.stringify(profiles));
        }
    }

    updateStreak() {
        const profiles = JSON.parse(localStorage.getItem('profiles') || '[]');
        const profile = profiles.find(p => p.id === this.currentProfile.id);
        if (!profile) return;

        const today = new Date().toDateString();
        const lastActivityDate = profile.lastActivityDate ? new Date(profile.lastActivityDate).toDateString() : null;
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const yesterdayString = yesterday.toDateString();

        if (!lastActivityDate) {
            // Первая активность
            profile.streak = 1;
            profile.lastActivityDate = new Date().toISOString();
        } else if (lastActivityDate === today) {
            // Уже занимались сегодня - не увеличиваем streak
            // Но обновляем дату последней активности
            profile.lastActivityDate = new Date().toISOString();
        } else if (lastActivityDate === yesterdayString) {
            // Занимались вчера - продолжаем серию
            profile.streak = (profile.streak || 0) + 1;
            profile.lastActivityDate = new Date().toISOString();
        } else {
            // Пропустили день - сбрасываем серию
            profile.streak = 1;
            profile.lastActivityDate = new Date().toISOString();
        }

        localStorage.setItem('profiles', JSON.stringify(profiles));
    }

    restartLesson() {
        this.currentQuestionIndex = 0;
        this.correctAnswers = 0;
        this.totalXP = 0;
        this.hearts = 5;
        document.getElementById('heartsCount').textContent = '5';
        if (this.voiceAssistant) {
            this.voiceAssistant.lastSpokenForQuestionIndex = -1;
            if (this.voiceAssistant.pendingSpeakTimeout) {
                clearTimeout(this.voiceAssistant.pendingSpeakTimeout);
                this.voiceAssistant.pendingSpeakTimeout = null;
            }
        }
        this.renderQuestion();
    }

    initNavigation() {
        document.getElementById('backBtn').addEventListener('click', () => {
            window.location.href = 'index.html';
        });

        document.getElementById('checkBtn').addEventListener('click', () => {
            this.checkAnswer();
        });

        document.getElementById('continueBtn').addEventListener('click', () => {
            this.continueLesson();
        });

        document.getElementById('nextLessonBtn').addEventListener('click', () => {
            const nextKey = this.getNextLessonKey();
            if (nextKey) {
                window.location.href = `lesson.html?key=${nextKey}`;
            } else {
                window.location.href = 'index.html';
            }
        });

        document.getElementById('backToModulesBtn').addEventListener('click', () => {
            window.location.href = 'index.html';
        });
    }

    initLanguage() {
        this.currentLang = localStorage.getItem('appLanguage') || 'ru';
    }

    updateLanguage() {
        document.querySelectorAll('[data-lang-ru]').forEach(el => {
            const ruText = el.dataset.langRu;
            const kkText = el.dataset.langKk;
            el.textContent = this.currentLang === 'ru' ? ruText : kkText;
        });
    }

    getTranslations() {
        return {
            ru: {
                letterQuestion: 'Какая это буква?',
                findWordQuestion: 'Найди слово на букву {letter}',
                buildWordQuestion: 'Составь слово "{word}"',
                findImageQuestion: 'Найди картинку для слова "{word}"',
                readWordQuestion: 'Прочитай это слово',
                countQuestion: 'Сколько здесь предметов?',
                addQuestion: 'Сколько будет {a} + {b}?',
                findShapeQuestion: 'Найди фигуру "{shape}"'
            },
            kk: {
                letterQuestion: 'Бұл қандай әріп?',
                findWordQuestion: '{letter} әріпінен сөз тап',
                buildWordQuestion: '"{word}" сөзін құрастыр',
                findImageQuestion: '"{word}" сөзіне сурет тап',
                readWordQuestion: 'Бұл сөзді оқы',
                countQuestion: 'Мұнда қанша зат бар?',
                addQuestion: '{a} + {b} қанша болады?',
                findShapeQuestion: '"{shape}" пішінін тап'
            }
        }[this.currentLang];
    }

    playSuccessSound() {
        // Простая звуковая обратная связь через Web Audio API
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.value = 800;
        oscillator.type = 'sine';
        
        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.3);
    }
}

// Инициализация
document.addEventListener('DOMContentLoaded', () => {
    new LessonSystem();
});
