/**
 * Модуль «Умное управление мышью» — расширенные упражнения для детей 5–10 лет.
 * Блок A — Нажатие (A1–A5). Блок B — Передвижение (B1–B5). Блок C — Комбинированные (C1–C3).
 * Без таймеров, рейтингов и «проигрыша». Разные механики, адаптация под ребёнка.
 */
(function () {
    'use strict';

    var W = 960, H = 520;
    var pointer = { x: 0, y: 0, lastX: 0, lastY: 0 };
    function updatePointer(e) {
        pointer.x = e.clientX;
        pointer.y = e.clientY;
        pointer.lastX = e.clientX;
        pointer.lastY = e.clientY;
    }
    window.addEventListener('mousemove', updatePointer, { passive: true });

    function getCanvasXY(canvas, clientX, clientY) {
        if (canvas == null || typeof clientX !== 'number' || typeof clientY !== 'number') return { x: 0, y: 0 };
        var r = canvas.getBoundingClientRect();
        if (r.width <= 0 || r.height <= 0) return { x: 0, y: 0 };
        var scaleX = canvas.width / r.width, scaleY = canvas.height / r.height;
        return { x: (clientX - r.left) * scaleX, y: (clientY - r.top) * scaleY };
    }
    function dist(ax, ay, bx, by) {
        return Math.sqrt((ax - bx) * (ax - bx) + (ay - by) * (ay - by));
    }
    function speak(text) {
        if (typeof window !== 'undefined' && window.speechSynthesis && text) {
            window.speechSynthesis.cancel();
            var u = new SpeechSynthesisUtterance(text);
            u.lang = document.documentElement.lang === 'kk' ? 'kk-KZ' : 'ru-RU';
            u.rate = 0.85;
            u.pitch = 1.1;
            u.volume = 1;

            var voices = window.speechSynthesis.getVoices();
            var savedVoiceName = localStorage.getItem('smart_ai_prefs_v1') ? JSON.parse(localStorage.getItem('smart_ai_prefs_v1')).voice : null;
            var preferred = null;
            if (u.lang.startsWith('ru')) {
                preferred = voices.find(function(v) { 
                    return v.name.toLowerCase().includes('pavel') || 
                           v.name.toLowerCase().includes('dmitry') || 
                           v.name.toLowerCase().includes('dmitri') ||
                           v.name.toLowerCase().includes('ivan');
                });
            }

            // 2. Any Male voice
            if (!preferred) {
                var baseLang = String(u.lang).split('-')[0];
                preferred = voices.find(function (v) { return v.lang.startsWith(baseLang) && (v.name.toLowerCase().includes('male') || v.name.toLowerCase().includes('man')); });
            }

            // 3. Not female
            if (!preferred && u.lang.startsWith('ru')) {
                preferred = voices.find(function(v) {
                    return v.lang.startsWith('ru') && 
                           !v.name.toLowerCase().includes('irina') && 
                           !v.name.toLowerCase().includes('elena') && 
                           !v.name.toLowerCase().includes('zira') &&
                           !v.name.toLowerCase().includes('female');
                });
            }

            // 4. Saved (if not female)
            if (!preferred && savedVoiceName) {
                if (!savedVoiceName.toLowerCase().includes('irina') && !savedVoiceName.toLowerCase().includes('elena')) {
                    preferred = voices.find(function (v) { return v.name === savedVoiceName; });
                }
            }

            // 5. Fallback
            if (!preferred) {
                var baseLang = String(u.lang).split('-')[0];
                preferred = voices.find(function (v) { return v.lang.startsWith(baseLang); });
            }
            if (preferred) u.voice = preferred;
            window.speechSynthesis.speak(u);
        }
    }
    function roundRectSimple(ctx, x, y, w, h, r) {
        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.lineTo(x + w - r, y);
        ctx.quadraticCurveTo(x + w, y, x + w, y + r);
        ctx.lineTo(x + w, y + h - r);
        ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
        ctx.lineTo(x + r, y + h);
        ctx.quadraticCurveTo(x, y + h, x, y + h - r);
        ctx.lineTo(x, y + r);
        ctx.quadraticCurveTo(x, y, x + r, y);
        ctx.closePath();
    }

    var isKk = function () { return document.documentElement.lang === 'kk'; };

    // ========== БЛОК A — НАЖАТИЕ МЫШИ (обновлён) ==========

    // A1. «Слушай → нажми» — клик только по сигналу «да»
    function runListenClick(canvas, ctx, onSuccess, setHint) {
        var wordsRu = ['солнце', 'нет', 'да', 'дом', 'нет', 'да', 'мама'];
        var wordsKk = ['күн', 'жоқ', 'иә', 'үй', 'жоқ', 'иә', 'ана'];
        var words = isKk() ? wordsKk : wordsRu;
        var triggerWord = isKk() ? 'иә' : 'да';
        var idx = 0;
        var currentWord = '';
        var done = false;
        var showSuccess = false;
        var animId;
        var tId;

        setHint(isKk() ? '«Иә» дегенді естігенде басыңыз.' : 'Нажми, когда услышишь «да».');
        speak(isKk() ? '«Иә» дегенді естігенде бас.' : 'Нажми, когда услышишь «да».');

        function sayNext() {
            if (done) return;
            currentWord = words[idx % words.length];
            speak(currentWord);
            idx++;
            tId = setTimeout(sayNext, 2200);
        }
        tId = setTimeout(sayNext, 1500);

        function onDown(e) {
            if (done) return;
            var p = getCanvasXY(canvas, e.clientX, e.clientY);
            if (p.x >= 0 && p.x <= W && p.y >= 0 && p.y <= H) {
                if (currentWord === triggerWord) {
                    done = true;
                    clearTimeout(tId);
                    canvas.removeEventListener('mousedown', onDown);
                    showSuccess = true;
                    speak(isKk() ? 'Жарайсың!' : 'Молодец!');
                    setTimeout(function () { cleanup(); onSuccess(); }, 1200);
                }
            }
        }
        canvas.addEventListener('mousedown', onDown);

        function draw() {
            ctx.clearRect(0, 0, W, H);
            ctx.fillStyle = '#E0E7FF';
            ctx.font = '600 24px Inter';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(isKk() ? '«Иә» дегенде бас' : 'Нажми на «да»', W / 2, H / 2 - 20);
            if (currentWord) ctx.fillText(currentWord, W / 2, H / 2 + 30);
            if (showSuccess) ctx.fillText('⭐', W / 2, H / 2 - 80);
            animId = requestAnimationFrame(draw);
        }
        draw();
        function cleanup() {
            if (tId) clearTimeout(tId);
            if (animId) cancelAnimationFrame(animId);
            canvas.removeEventListener('mousedown', onDown);
        }
        return cleanup;
    }

    // A2. «Сила нажатия» — индикатор заполняется при удержании, без штрафов
    function runStrength(canvas, ctx, onSuccess, setHint) {
        var cx = W / 2, cy = H / 2;
        var bw = 320, bh = 100;
        var left = cx - bw / 2, top = cy - bh / 2;
        var holdStart = null;
        var progress = 0;
        var done = false;
        var targetMs = 2500;
        var animId;

        setHint(isKk() ? 'Батырманы басып ұстаңыз. Индикатор толысады. Қатаң жаза жоқ.' : 'Нажми и удержи. Индикатор заполняется. Штрафов нет.');
        speak(isKk() ? 'Бас және ұста. Индикатор толысады.' : 'Нажми и удержи. Индикатор заполняется.');

        function hitTest(px, py) { return px >= left && px <= left + bw && py >= top && py <= top + bh; }
        function onDown(e) {
            var p = getCanvasXY(canvas, e.clientX, e.clientY);
            if (hitTest(p.x, p.y)) holdStart = Date.now();
        }
        function onUp() {
            if (holdStart !== null && !done) {
                var elapsed = Date.now() - holdStart;
                if (elapsed >= targetMs) {
                    done = true;
                    canvas.removeEventListener('mousedown', onDown);
                    window.removeEventListener('mouseup', onUp);
                    speak(isKk() ? 'Жарайсың!' : 'Молодец!');
                    setTimeout(function () { cleanup(); onSuccess(); }, 1000);
                }
                holdStart = null;
            }
        }
        canvas.addEventListener('mousedown', onDown);
        window.addEventListener('mouseup', onUp);

        function draw() {
            if (holdStart !== null && !done) {
                progress = Math.min(1, (Date.now() - holdStart) / targetMs);
                if (progress >= 1) {
                    done = true;
                    canvas.removeEventListener('mousedown', onDown);
                    window.removeEventListener('mouseup', onUp);
                    speak(isKk() ? 'Жарайсың!' : 'Молодец!');
                    setTimeout(function () { cleanup(); onSuccess(); }, 1000);
                }
            } else if (!done) progress = Math.max(0, progress - 0.02);
            ctx.clearRect(0, 0, W, H);
            ctx.fillStyle = '#C4B5FD';
            roundRectSimple(ctx, left, top, bw, bh, 20);
            ctx.fill();
            ctx.strokeStyle = '#6366F1';
            ctx.lineWidth = 3;
            ctx.stroke();
            ctx.fillStyle = '#22C55E';
            roundRectSimple(ctx, left + 10, top + 10, (bw - 20) * progress, bh - 20, 12);
            ctx.fill();
            ctx.fillStyle = '#1e1b4b';
            ctx.font = '600 20px Inter';
            ctx.textAlign = 'center';
            ctx.fillText(isKk() ? 'Бас және ұста' : 'Нажми и удержи', cx, cy);
            animId = requestAnimationFrame(draw);
        }
        draw();
        function cleanup() {
            if (animId) cancelAnimationFrame(animId);
            canvas.removeEventListener('mousedown', onDown);
            window.removeEventListener('mouseup', onUp);
        }
        return cleanup;
    }

    // A3. «Выбор по смыслу» — Где животное? 2–3 кнопки с картинками
    function runChoiceByMeaning(canvas, ctx, onSuccess, setHint) {
        var zones = [
            { x: W * 0.25, y: H / 2, w: 140, h: 140, emoji: '🐱', isAnimal: true },
            { x: W * 0.5, y: H / 2, w: 140, h: 140, emoji: '🌸', isAnimal: false },
            { x: W * 0.75, y: H / 2, w: 140, h: 140, emoji: '🚗', isAnimal: false }
        ];
        var done = false;
        var showStar = false;
        var animId;

        setHint(isKk() ? 'Жануар қайда? Сұрақты ойлап, басыңыз.' : 'Где животное? Выбери и нажми.');
        speak(isKk() ? 'Жануар қайда? Басыңыз.' : 'Где животное? Нажми на него.');

        function hitTest(px, py) {
            for (var i = 0; i < zones.length; i++) {
                var z = zones[i];
                if (px >= z.x - z.w / 2 && px <= z.x + z.w / 2 && py >= z.y - z.h / 2 && py <= z.y + z.h / 2) return z;
            }
            return null;
        }
        function onDown(e) {
            if (done) return;
            var p = getCanvasXY(canvas, e.clientX, e.clientY);
            var z = hitTest(p.x, p.y);
            if (z && z.isAnimal) {
                done = true;
                showStar = true;
                canvas.removeEventListener('mousedown', onDown);
                speak(isKk() ? 'Жарайсың!' : 'Молодец!');
                setTimeout(function () { cleanup(); onSuccess(); }, 1200);
            }
        }
        canvas.addEventListener('mousedown', onDown);

        function draw() {
            ctx.clearRect(0, 0, W, H);
            ctx.fillStyle = '#1e1b4b';
            ctx.font = '600 22px Inter';
            ctx.textAlign = 'center';
            ctx.fillText(isKk() ? 'Жануар қайда?' : 'Где животное?', W / 2, 60);
            for (var i = 0; i < zones.length; i++) {
                var z = zones[i];
                ctx.fillStyle = '#E0E7FF';
                roundRectSimple(ctx, z.x - z.w / 2, z.y - z.h / 2, z.w, z.h, 16);
                ctx.fill();
                ctx.strokeStyle = '#6366F1';
                ctx.lineWidth = 2;
                ctx.stroke();
                ctx.font = '56px Inter';
                ctx.fillText(z.emoji, z.x, z.y);
            }
            if (showStar) ctx.fillText('⭐', W / 2, 120);
            animId = requestAnimationFrame(draw);
        }
        draw();
        function cleanup() {
            if (animId) cancelAnimationFrame(animId);
            canvas.removeEventListener('mousedown', onDown);
        }
        return cleanup;
    }

    // A4. «Нажми в правильный момент» — объект «дышит», любой клик = успех, оптимальный = бонус
    function runRightMoment(canvas, ctx, onSuccess, setHint) {
        var cx = W / 2, cy = H / 2;
        var radius = 100;
        var phase = 0;
        var done = false;
        var showBonus = false;
        var animId;
        var optimalZone = 0.45; // 0.4–0.5 по фазе = «оптимальный» момент

        setHint(isKk() ? 'Кез келген сәтте баса аласыз. Жақын сәт — бонус анимация.' : 'Нажать можно в любой момент. Близкий момент — бонус-анимация.');
        speak(isKk() ? 'Кез келген сәтте бас. Жақын сәт — бонус.' : 'Нажми в любой момент. Близкий — бонус.');

        function hitTest(px, py) { return dist(px, py, cx, cy) <= radius + 40; }
        function onDown(e) {
            if (done) return;
            var p = getCanvasXY(canvas, e.clientX, e.clientY);
            if (hitTest(p.x, p.y)) {
                done = true;
                var inOptimal = (phase % 1 >= optimalZone && phase % 1 <= 0.55);
                showBonus = inOptimal;
                canvas.removeEventListener('mousedown', onDown);
                speak(isKk() ? 'Жарайсың!' : 'Молодец!');
                setTimeout(function () { cleanup(); onSuccess(); }, 1400);
            }
        }
        canvas.addEventListener('mousedown', onDown);

        function draw() {
            phase += 0.008;
            var scale = 0.92 + Math.sin(phase * Math.PI * 2) * 0.08;
            ctx.clearRect(0, 0, W, H);
            ctx.save();
            ctx.translate(cx, cy);
            ctx.scale(scale, scale);
            ctx.translate(-cx, -cy);
            ctx.fillStyle = '#FCD34D';
            ctx.beginPath();
            ctx.arc(cx, cy, radius, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#F59E0B';
            ctx.lineWidth = 4;
            ctx.stroke();
            ctx.restore();
            ctx.fillStyle = '#1e1b4b';
            ctx.font = '20px Inter';
            ctx.textAlign = 'center';
            ctx.fillText(isKk() ? 'Бас' : 'Нажми', cx, cy + radius + 30);
            if (showBonus) ctx.fillText('✨', cx, cy - radius - 30);
            animId = requestAnimationFrame(draw);
        }
        draw();
        function cleanup() {
            if (animId) cancelAnimationFrame(animId);
            canvas.removeEventListener('mousedown', onDown);
        }
        return cleanup;
    }

    // A5. «Нажми по очереди» — 3 зоны подсвечиваются по одной, нажимать в порядке
    function runClickSequence(canvas, ctx, onSuccess, setHint) {
        var zones = [
            { x: W * 0.2, y: H / 2, r: 70 },
            { x: W * 0.5, y: H / 2, r: 70 },
            { x: W * 0.8, y: H / 2, r: 70 }
        ];
        var step = 0;
        var done = false;
        var showStar = false;
        var animId;
        var highlightPhase = 0;

        setHint(isKk() ? 'Жарықтанғанды ретімен басыңыз.' : 'Нажимай по очереди подсвеченное.');
        speak(isKk() ? 'Жарықтанғанды ретімен бас.' : 'Нажимай по очереди.');

        function hitTest(px, py) {
            for (var i = 0; i < zones.length; i++) {
                if (dist(px, py, zones[i].x, zones[i].y) <= zones[i].r + 15) return i;
            }
            return -1;
        }
        function onDown(e) {
            if (done) return;
            var p = getCanvasXY(canvas, e.clientX, e.clientY);
            var i = hitTest(p.x, p.y);
            if (i === step) {
                step++;
                if (step >= 3) {
                    done = true;
                    showStar = true;
                    canvas.removeEventListener('mousedown', onDown);
                    speak(isKk() ? 'Жарайсың!' : 'Молодец!');
                    setTimeout(function () { cleanup(); onSuccess(); }, 1200);
                }
            }
        }
        canvas.addEventListener('mousedown', onDown);

        function draw() {
            highlightPhase += 0.03;
            var lit = Math.floor(highlightPhase) % 3;
            ctx.clearRect(0, 0, W, H);
            for (var i = 0; i < zones.length; i++) {
                var z = zones[i];
                ctx.fillStyle = (i === lit) ? '#A7F3D0' : '#E5E7EB';
                ctx.beginPath();
                ctx.arc(z.x, z.y, z.r, 0, Math.PI * 2);
                ctx.fill();
                ctx.strokeStyle = (i === lit) ? '#22C55E' : '#9CA3AF';
                ctx.lineWidth = (i === lit) ? 4 : 2;
                ctx.stroke();
                ctx.fillStyle = '#1e1b4b';
                ctx.font = '600 24px Inter';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText(String(i + 1), z.x, z.y);
            }
            if (showStar) ctx.fillText('⭐', W / 2, 80);
            animId = requestAnimationFrame(draw);
        }
        draw();
        function cleanup() {
            if (animId) cancelAnimationFrame(animId);
            canvas.removeEventListener('mousedown', onDown);
        }
        return cleanup;
    }

    // ========== БЛОК B — ПЕРЕДВИЖЕНИЕ МЫШИ (обновлён) ==========

    // B1. «Избегай, но не бойся» — препятствия, столкновение = замедление, не ошибка
    function runAvoidObstacles(canvas, ctx, onSuccess, setHint) {
        var goalX = W * 0.85, goalY = H / 2, goalR = 80;
        var hitRadius = 100;
        var obstacles = [
            { x: W * 0.35, y: H * 0.35, r: 60 },
            { x: W * 0.5, y: H * 0.65, r: 55 },
            { x: W * 0.65, y: H * 0.4, r: 50 }
        ];
        var speedScale = 1;
        var slowUntil = 0;
        var done = false;
        var animId;

        setHint(isKk() ? 'Кедергілерді айналдырып өтіңіз. Тию — қате емес, тек баяулатады.' : 'Обходи препятствия. Столкновение не ошибка — только замедляет.');
        speak(isKk() ? 'Кедергілерді айналдырып өт. Тию — қате емес.' : 'Обходи препятствия. Столкновение не ошибка.');

        function draw() {
            var now = Date.now();
            if (now < slowUntil) speedScale = 0.5; else speedScale = 1;
            var p = getCanvasXY(canvas, pointer.x, pointer.y);
            for (var i = 0; i < obstacles.length; i++) {
                if (dist(p.x, p.y, obstacles[i].x, obstacles[i].y) <= obstacles[i].r + 30) {
                    slowUntil = now + 800;
                    break;
                }
            }
            if (!done && dist(p.x, p.y, goalX, goalY) <= hitRadius) {
                done = true;
                cleanup();
                speak(isKk() ? 'Жарайсың!' : 'Молодец!');
                onSuccess();
                return;
            }
            ctx.clearRect(0, 0, W, H);
            ctx.fillStyle = '#FEF3C7';
            for (var j = 0; j < obstacles.length; j++) {
                var o = obstacles[j];
                ctx.beginPath();
                ctx.arc(o.x, o.y, o.r, 0, Math.PI * 2);
                ctx.fill();
                ctx.strokeStyle = '#F59E0B';
                ctx.lineWidth = 3;
                ctx.stroke();
            }
            ctx.fillStyle = '#DCFCE7';
            ctx.beginPath();
            ctx.arc(goalX, goalY, goalR, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#22C55E';
            ctx.lineWidth = 4;
            ctx.stroke();
            ctx.fillStyle = '#166534';
            ctx.font = '400 18px Inter';
            ctx.textAlign = 'center';
            ctx.fillText(isKk() ? 'Мақсат' : 'Цель', goalX, goalY + 5);
            animId = requestAnimationFrame(draw);
        }
        draw();
        function cleanup() { if (animId) cancelAnimationFrame(animId); }
        return cleanup;
    }

    // B2. «Разные поверхности» — зоны с разной «скользкостью», визуально различимы
    function runDifferentSurfaces(canvas, ctx, onSuccess, setHint) {
        var goalX = W * 0.82, goalY = H / 2, goalR = 80;
        var hitRadius = 110;
        var zones = [
            { x: W * 0.2, y: H / 2, w: 160, h: 110, friction: 0.7, color: '#FEE2E2', label: isKk() ? 'Тұйық' : 'Липко' },
            { x: W * 0.45, y: H / 2, w: 160, h: 110, friction: 1, color: '#E0E7FF', label: isKk() ? 'Қалыпты' : 'Норм' },
            { x: W * 0.7, y: H / 2, w: 140, h: 110, friction: 1.2, color: '#DBEAFE', label: isKk() ? 'Сырғанақ' : 'Скользко' }
        ];
        var done = false;
        var animId;
        var onCanvasMove = function (e) {
            pointer.x = e.clientX;
            pointer.y = e.clientY;
        };
        canvas.addEventListener('mousemove', onCanvasMove);

        setHint(isKk() ? 'Өрнектелген аймақтар әртүрлі. Мақсатқа жетіңіз.' : 'Зоны с разной поверхностью. Дойди до цели.');
        speak(isKk() ? 'Өрнектелген аймақтар. Мақсатқа жет.' : 'Разные поверхности. Дойди до цели.');

        function draw() {
            var p = getCanvasXY(canvas, pointer.x, pointer.y);
            if (!done && dist(p.x, p.y, goalX, goalY) <= hitRadius) {
                done = true;
                cleanup();
                speak(isKk() ? 'Жарайсың!' : 'Молодец!');
                onSuccess();
                return;
            }
            ctx.clearRect(0, 0, W, H);
            for (var i = 0; i < zones.length; i++) {
                var z = zones[i];
                ctx.fillStyle = z.color;
                roundRectSimple(ctx, z.x - z.w / 2, z.y - z.h / 2, z.w, z.h, 12);
                ctx.fill();
                ctx.strokeStyle = '#64748B';
                ctx.lineWidth = 2;
                ctx.stroke();
                ctx.fillStyle = '#1e1b4b';
                ctx.font = '400 16px Inter';
                ctx.textAlign = 'center';
                ctx.fillText(z.label, z.x, z.y);
            }
            ctx.fillStyle = '#DCFCE7';
            ctx.beginPath();
            ctx.arc(goalX, goalY, goalR, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#22C55E';
            ctx.lineWidth = 4;
            ctx.stroke();
            ctx.fillText(isKk() ? 'Мақсат' : 'Цель', goalX, goalY + 5);
            animId = requestAnimationFrame(draw);
        }
        draw();
        function cleanup() {
            if (animId) cancelAnimationFrame(animId);
            canvas.removeEventListener('mousemove', onCanvasMove);
        }
        return cleanup;
    }

    // B3. «Следуй за другом» — персонаж движется медленно, ребёнок повторяет путь, большой допуск
    function runFollowFriend(canvas, ctx, onSuccess, setHint) {
        var path = [];
        for (var i = 0; i <= 20; i++) path.push({ x: W * (0.1 + 0.8 * i / 20), y: H / 2 + Math.sin(i * 0.4) * 80 });
        var npcIdx = 0;
        var npcSpeed = 0.012;
        var done = false;
        var goodTime = 0;
        var targetGood = 2000;
        var animId;

        setHint(isKk() ? 'Досыңды ұста. Жақын жүр — үлгі бойынша.' : 'Следуй за другом. Держись рядом — по пути.');
        speak(isKk() ? 'Досыңды ұста. Жақын жүр.' : 'Следуй за другом. Держись рядом.');

        function draw() {
            npcIdx = Math.min(path.length - 1, npcIdx + npcSpeed);
            var npc = path[Math.floor(npcIdx)];
            var p = getCanvasXY(canvas, pointer.x, pointer.y);
            if (!done && npc && dist(p.x, p.y, npc.x, npc.y) <= 100) goodTime += 16;
            if (!done && goodTime >= targetGood) {
                done = true;
                cleanup();
                speak(isKk() ? 'Жарайсың!' : 'Молодец!');
                onSuccess();
                return;
            }
            ctx.clearRect(0, 0, W, H);
            ctx.strokeStyle = '#E5E7EB';
            ctx.lineWidth = 60;
            ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(path[0].x, path[0].y);
            for (var j = 1; j < path.length; j++) ctx.lineTo(path[j].x, path[j].y);
            ctx.stroke();
            ctx.fillStyle = '#22C55E';
            ctx.beginPath();
            ctx.arc(npc.x, npc.y, 28, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#166534';
            ctx.lineWidth = 2;
            ctx.stroke();
            ctx.fillStyle = '#fff';
            ctx.font = '20px Inter';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('👤', npc.x, npc.y);
            animId = requestAnimationFrame(draw);
        }
        draw();
        function cleanup() { if (animId) cancelAnimationFrame(animId); }
        return cleanup;
    }

    // B4. «Лабиринт без стен» — путь подсвечен, за пределами просто фон, нет столкновений
    function runMazeNoWalls(canvas, ctx, onSuccess, setHint) {
        var pathPoints = [];
        for (var i = 0; i <= 30; i++) {
            var t = i / 30;
            pathPoints.push({
                x: W * (0.15 + 0.7 * t + 0.15 * Math.sin(t * 6)),
                y: H * (0.2 + 0.6 * t * t + 0.1 * Math.cos(t * 4))
            });
        }
        var endX = pathPoints[pathPoints.length - 1].x;
        var endY = pathPoints[pathPoints.length - 1].y;
        var endR = 60;
        var done = false;
        var animId;

        setHint(isKk() ? 'Жол жарық. Шықсаң — қате емес. Соңына жет.' : 'Путь подсвечен. Выход за край — не ошибка. Дойди до конца.');
        speak(isKk() ? 'Жол жарық. Соңына жет.' : 'Путь подсвечен. Дойди до конца.');

        function draw() {
            var p = getCanvasXY(canvas, pointer.x, pointer.y);
            if (!done && dist(p.x, p.y, endX, endY) <= endR) {
                done = true;
                cleanup();
                speak(isKk() ? 'Жарайсың!' : 'Молодец!');
                onSuccess();
                return;
            }
            ctx.clearRect(0, 0, W, H);
            ctx.fillStyle = '#F3F4F6';
            ctx.fillRect(0, 0, W, H);
            ctx.strokeStyle = '#A7F3D0';
            ctx.lineWidth = 80;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.beginPath();
            ctx.moveTo(pathPoints[0].x, pathPoints[0].y);
            for (var j = 1; j < pathPoints.length; j++) ctx.lineTo(pathPoints[j].x, pathPoints[j].y);
            ctx.stroke();
            ctx.fillStyle = '#22C55E';
            ctx.beginPath();
            ctx.arc(endX, endY, endR - 10, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#166534';
            ctx.lineWidth = 3;
            ctx.stroke();
            ctx.fillStyle = '#fff';
            ctx.font = '18px Inter';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(isKk() ? 'Соңы' : 'Конец', endX, endY);
            animId = requestAnimationFrame(draw);
        }
        draw();
        function cleanup() { if (animId) cancelAnimationFrame(animId); }
        return cleanup;
    }

    // B5. «Медленно = лучше» — поощряем плавность; резкие движения замедляют мир
    function runSlowBetter(canvas, ctx, onSuccess, setHint) {
        var goalX = W * 0.85, goalY = H / 2, goalR = 70;
        var hitRadius = 90;
        var lastP = { x: pointer.x, y: pointer.y };
        var velocity = 0;
        var worldScale = 1;
        var done = false;
        var animId;

        setHint(isKk() ? 'Тегіс қозғал — әлем баяуламайды. Резке қозғалыс — баяулатады.' : 'Двигай плавно — мир не замедляется. Резкое движение — замедляет.');
        speak(isKk() ? 'Тегіс қозғал. Баяу — жақсы.' : 'Двигай плавно. Медленно — лучше.');

        function draw() {
            var p = getCanvasXY(canvas, pointer.x, pointer.y);
            var dx = p.x - lastP.x, dy = p.y - lastP.y;
            velocity = Math.sqrt(dx * dx + dy * dy) * 0.3 + velocity * 0.7;
            lastP = { x: p.x, y: p.y };
            if (velocity > 15) worldScale = 0.6; else worldScale = 0.6 + (1 - 0.6) * (1 - Math.min(1, velocity / 15));
            if (!done && dist(p.x, p.y, goalX, goalY) <= hitRadius) {
                done = true;
                cleanup();
                speak(isKk() ? 'Жарайсың!' : 'Молодец!');
                onSuccess();
                return;
            }
            ctx.clearRect(0, 0, W, H);
            ctx.fillStyle = '#ECFDF5';
            ctx.fillRect(0, 0, W, H);
            ctx.fillStyle = '#DCFCE7';
            ctx.beginPath();
            ctx.arc(goalX, goalY, goalR, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#22C55E';
            ctx.lineWidth = 4;
            ctx.stroke();
            ctx.fillStyle = '#166534';
            ctx.font = '400 18px Inter';
            ctx.textAlign = 'center';
            ctx.fillText(isKk() ? 'Мақсат' : 'Цель', goalX, goalY + 5);
            if (worldScale < 1) {
                ctx.fillStyle = 'rgba(254,243,199,0.6)';
                ctx.font = '16px Inter';
                ctx.fillText(isKk() ? 'Тегіс қозғал' : 'Двигай плавнее', W / 2, 40);
            }
            animId = requestAnimationFrame(draw);
        }
        draw();
        function cleanup() { if (animId) cancelAnimationFrame(animId); }
        return cleanup;
    }

    // ========== БЛОК C — КОМБИНИРОВАННЫЕ ==========

    // C1. «Подвёл → выбрал» — довести курсор, затем голосом «Выбрать»
    function runLeadAndVoice(canvas, ctx, onSuccess, setHint) {
        var cx = W / 2, cy = H / 2;
        var targetR = 90;
        var hitRadius = 110;
        var cursorInZone = false;
        var done = false;
        var showStar = false;
        var animId;
        var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        var recognition = null;

        setHint(isKk() ? 'Курсорды аймаққа жеткізіңіз, содан кейін «Таңда» деңіз.' : 'Подведи курсор к зоне, затем скажи «Выбрать».');
        speak(isKk() ? 'Курсорды жеткіз, содан кейін «Таңда» де.' : 'Подведи курсор, потом скажи «Выбрать».');

        function startListening() {
            if (!SpeechRecognition || done) return;
            try {
                recognition = new SpeechRecognition();
                recognition.lang = isKk() ? 'kk-KZ' : 'ru-RU';
                recognition.continuous = true;
                recognition.interimResults = false;
                recognition.onresult = function (e) {
                    if (done) return;
                    var t = (e.results[e.results.length - 1][0].transcript || '').toLowerCase();
                    if ((t.indexOf('выбрать') !== -1 || t.indexOf('таңда') !== -1 || t.indexOf('выбери') !== -1) && cursorInZone) {
                        done = true;
                        showStar = true;
                        if (recognition) try { recognition.stop(); } catch (err) {}
                        speak(isKk() ? 'Жарайсың!' : 'Молодец!');
                        setTimeout(function () { cleanup(); onSuccess(); }, 1200);
                    }
                };
                recognition.onerror = function () {};
                recognition.start();
            } catch (err) {}
        }

        function draw() {
            var p = getCanvasXY(canvas, pointer.x, pointer.y);
            cursorInZone = dist(p.x, p.y, cx, cy) <= hitRadius;
            if (cursorInZone && recognition === null) startListening();
            if (!done && cursorInZone && recognition) { /* already listening */ }
            ctx.clearRect(0, 0, W, H);
            ctx.fillStyle = '#C4B5FD';
            ctx.beginPath();
            ctx.arc(cx, cy, targetR, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#6366F1';
            ctx.lineWidth = 4;
            ctx.stroke();
            ctx.fillStyle = '#1e1b4b';
            ctx.font = '600 18px Inter';
            ctx.textAlign = 'center';
            ctx.fillText(isKk() ? 'Курсорды жеткіз, «Таңда» де' : 'Подведи курсор, скажи «Выбрать»', cx, cy + targetR + 30);
            if (cursorInZone) ctx.fillText(isKk() ? '«Таңда» деңіз' : 'Скажи «Выбрать»', cx, cy);
            if (showStar) ctx.fillText('⭐', cx, cy - targetR - 40);
            animId = requestAnimationFrame(draw);
        }
        draw();
        function cleanup() {
            if (animId) cancelAnimationFrame(animId);
            if (recognition) try { recognition.stop(); } catch (e) {}
        }
        return cleanup;
    }

    // C2. «Найди и подтверди» — подвести курсор, система спрашивает, подтверждение кликом
    function runFindAndConfirm(canvas, ctx, onSuccess, setHint) {
        var cx = W / 2, cy = H / 2;
        var targetR = 100;
        var hitRadius = 120;
        var cursorWasInZone = false;
        var asked = false;
        var done = false;
        var showStar = false;
        var animId;

        setHint(isKk() ? 'Курсорды мақсатқа жеткізіңіз. Содан кейін басу арқылы растаңыз.' : 'Подведи курсор к цели. Затем подтверди кликом.');
        speak(isKk() ? 'Мақсатқа жеткіз. Содан кейін басу арқылы раста.' : 'Подведи курсор к цели. Потом подтверди кликом.');

        function onDown(e) {
            if (done) return;
            var p = getCanvasXY(canvas, e.clientX, e.clientY);
            if (dist(p.x, p.y, cx, cy) <= hitRadius && cursorWasInZone) {
                done = true;
                showStar = true;
                canvas.removeEventListener('mousedown', onDown);
                speak(isKk() ? 'Жарайсың!' : 'Молодец!');
                setTimeout(function () { cleanup(); onSuccess(); }, 1200);
            }
        }
        canvas.addEventListener('mousedown', onDown);

        function draw() {
            var p = getCanvasXY(canvas, pointer.x, pointer.y);
            if (dist(p.x, p.y, cx, cy) <= hitRadius) {
                cursorWasInZone = true;
                if (!asked) {
                    asked = true;
                    speak(isKk() ? 'Растаңыз — басыңыз.' : 'Подтверди — нажми.');
                }
            }
            ctx.clearRect(0, 0, W, H);
            ctx.fillStyle = cursorWasInZone ? '#A7F3D0' : '#E0E7FF';
            ctx.beginPath();
            ctx.arc(cx, cy, targetR, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = cursorWasInZone ? '#22C55E' : '#6366F1';
            ctx.lineWidth = 4;
            ctx.stroke();
            ctx.fillStyle = '#1e1b4b';
            ctx.font = '600 18px Inter';
            ctx.textAlign = 'center';
            ctx.fillText(asked ? (isKk() ? 'Бас — растау' : 'Нажми — подтвердить') : (isKk() ? 'Мақсатқа жеткіз' : 'Подведи к цели'), cx, cy + targetR + 35);
            if (showStar) ctx.fillText('⭐', cx, cy - targetR - 30);
            animId = requestAnimationFrame(draw);
        }
        draw();
        function cleanup() {
            if (animId) cancelAnimationFrame(animId);
            canvas.removeEventListener('mousedown', onDown);
        }
        return cleanup;
    }

    // C3. «Два действия — один успех» — движение + удержание, считается как один шаг
    function runTwoActionsOneSuccess(canvas, ctx, onSuccess, setHint) {
        var zoneA = { x: W * 0.25, y: H / 2, r: 70 };
        var zoneB = { x: W * 0.75, y: H / 2, r: 70 };
        var step = 0; // 0 = move to A, 1 = hold in B
        var inA = false;
        var inB = false;
        var holdStart = null;
        var holdMs = 1500;
        var done = false;
        var showStar = false;
        var animId;

        setHint(isKk() ? 'Алдымен бір аймаққа жетіңіз, содан кейін екіншіде басып ұстаңыз.' : 'Сначала дойди до одной зоны, затем в другой нажми и удержи.');
        speak(isKk() ? 'Бір аймаққа жет, екіншіде басып ұста.' : 'Дойди до одной зоны, в другой нажми и удержи.');

        function onDown(e) {
            if (done) return;
            var p = getCanvasXY(canvas, e.clientX, e.clientY);
            if (step === 1 && dist(p.x, p.y, zoneB.x, zoneB.y) <= zoneB.r + 20) holdStart = Date.now();
        }
        function onUp() {
            if (step === 1) holdStart = null;
        }
        canvas.addEventListener('mousedown', onDown);
        window.addEventListener('mouseup', onUp);

        function draw() {
            var p = getCanvasXY(canvas, pointer.x, pointer.y);
            inA = dist(p.x, p.y, zoneA.x, zoneA.y) <= zoneA.r + 25;
            inB = dist(p.x, p.y, zoneB.x, zoneB.y) <= zoneB.r + 25;
            if (step === 0 && inA) step = 1;
            if (step === 1 && holdStart !== null) {
                var elapsed = Date.now() - holdStart;
                if (elapsed >= holdMs) {
                    done = true;
                    showStar = true;
                    canvas.removeEventListener('mousedown', onDown);
                    window.removeEventListener('mouseup', onUp);
                    speak(isKk() ? 'Жарайсың!' : 'Молодец!');
                    setTimeout(function () { cleanup(); onSuccess(); }, 1200);
                }
            }
            ctx.clearRect(0, 0, W, H);
            ctx.fillStyle = step >= 1 ? '#A7F3D0' : '#E0E7FF';
            ctx.beginPath();
            ctx.arc(zoneA.x, zoneA.y, zoneA.r, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = step >= 1 ? '#22C55E' : '#6366F1';
            ctx.lineWidth = 3;
            ctx.stroke();
            ctx.fillStyle = step === 1 ? '#FEF3C7' : '#E0E7FF';
            ctx.beginPath();
            ctx.arc(zoneB.x, zoneB.y, zoneB.r, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#F59E0B';
            ctx.lineWidth = 3;
            ctx.stroke();
            ctx.fillStyle = '#1e1b4b';
            ctx.font = '600 16px Inter';
            ctx.textAlign = 'center';
            ctx.fillText(step === 0 ? (isKk() ? 'Жет' : 'Дойди') : (isKk() ? 'Бас және ұста' : 'Нажми и удержи'), zoneA.x, zoneA.y + zoneA.r + 25);
            ctx.fillText(step === 0 ? (isKk() ? 'Келесі' : 'Дальше') : (isKk() ? 'Бас және ұста' : 'Нажми и удержи'), zoneB.x, zoneB.y + zoneB.r + 25);
            if (showStar) ctx.fillText('⭐', W / 2, 80);
            animId = requestAnimationFrame(draw);
        }
        draw();
        function cleanup() {
            if (animId) cancelAnimationFrame(animId);
            canvas.removeEventListener('mousedown', onDown);
            window.removeEventListener('mouseup', onUp);
        }
        return cleanup;
    }

    // ---------- Список: Блок A (5) + Блок B (5) + Блок C (3) ----------
    function createExercisesArray() {
        var blockClick = [
            { id: 'listen', block: 'click', title: { ru: 'Слушай → нажми', kk: 'Тыңда → бас' }, desc: { ru: 'Клик только по сигналу «да». Контроль и внимание', kk: '«Иә» дегенде бас. Бақылау және назар' }, icon: '👂', run: runListenClick },
            { id: 'strength', block: 'click', title: { ru: 'Сила нажатия', kk: 'Басу күші' }, desc: { ru: 'Индикатор заполняется. Без штрафов', kk: 'Индикатор толысады. Жаза жоқ' }, icon: '💪', run: runStrength },
            { id: 'choice', block: 'click', title: { ru: 'Выбор по смыслу', kk: 'Мағына бойынша таңдау' }, desc: { ru: 'Где животное? Когнитивная + моторная нагрузка', kk: 'Жануар қайда? Таңдау + басу' }, icon: '🐱', run: runChoiceByMeaning },
            { id: 'moment', block: 'click', title: { ru: 'Нажми в правильный момент', kk: 'Дұрыс сәтте бас' }, desc: { ru: 'Объект «дышит». Любой клик — успех, оптимальный — бонус', kk: 'Кез келген басу — табыс. Жақын сәт — бонус' }, icon: '✨', run: runRightMoment },
            { id: 'sequence', block: 'click', title: { ru: 'Нажми по очереди', kk: 'Ретімен бас' }, desc: { ru: 'Подсвеченные зоны — нажимать в порядке', kk: 'Жарықтанғанды ретімен бас' }, icon: '1️⃣', run: runClickSequence }
        ];
        var blockMove = [
            { id: 'avoid', block: 'move', title: { ru: 'Избегай, но не бойся', kk: 'Айналдырып өт, қорқпа' }, desc: { ru: 'Препятствия. Столкновение — не ошибка, только замедление', kk: 'Кедергілер. Тию — қате емес' }, icon: '🟡', run: runAvoidObstacles },
            { id: 'surfaces', block: 'move', title: { ru: 'Разные поверхности', kk: 'Әртүрлі беттер' }, desc: { ru: 'Зоны с разной «скользкостью». Дойди до цели', kk: 'Әртүрлі аймақтар. Мақсатқа жет' }, icon: '🟦', run: runDifferentSurfaces },
            { id: 'follow', block: 'move', title: { ru: 'Следуй за другом', kk: 'Досыңды ұста' }, desc: { ru: 'Персонаж движется медленно. Держись рядом', kk: 'Кейіпкер баяу жүреді. Жақын жүр' }, icon: '👤', run: runFollowFriend },
            { id: 'maze', block: 'move', title: { ru: 'Лабиринт без стен', kk: 'Қабырғасыз лабиринт' }, desc: { ru: 'Путь подсвечен. За пределами — не ошибка', kk: 'Жол жарық. Шықу — қате емес' }, icon: '🛤️', run: runMazeNoWalls },
            { id: 'slow', block: 'move', title: { ru: 'Медленно = лучше', kk: 'Баяу — жақсы' }, desc: { ru: 'Плавность поощряется. Резкое движение замедляет мир', kk: 'Тегіс қозғалыс — жақсы' }, icon: '🐢', run: runSlowBetter }
        ];
        var blockCombined = [
            { id: 'leadvoice', block: 'combined', title: { ru: 'Подвёл → выбрал', kk: 'Жеткіз → таңда' }, desc: { ru: 'Довести курсор, затем голосом «Выбрать». Мышь + голос', kk: 'Курсорды жеткіз, «Таңда» де' }, icon: '🎤', run: runLeadAndVoice },
            { id: 'findconfirm', block: 'combined', title: { ru: 'Найди и подтверди', kk: 'Тап және раста' }, desc: { ru: 'Подвести курсор, система спрашивает, подтверждение кликом', kk: 'Жеткіз, содан кейін басу арқылы раста' }, icon: '✅', run: runFindAndConfirm },
            { id: 'twoactions', block: 'combined', title: { ru: 'Два действия — один успех', kk: 'Екі әрекет — бір табыс' }, desc: { ru: 'Движение + удержание. Считается как один шаг', kk: 'Қозғалыс + ұстау. Бір қадам ретінде' }, icon: '🔄', run: runTwoActionsOneSuccess }
        ];
        return blockClick.concat(blockMove).concat(blockCombined);
    }

    function init() {
        var grid = document.getElementById('exercisesGrid');
        var stage = document.getElementById('stage');
        var stageTitle = document.getElementById('stageTitle');
        var stageHint = document.getElementById('stageHint');
        var stageClose = document.getElementById('stageClose');
        var canvas = document.getElementById('stageCanvas');
        if (!grid || !canvas) return;

        canvas.width = W;
        canvas.height = H;

        var exercises = createExercisesArray();
        var lang = document.documentElement.lang || 'ru';
        function t(obj) { return (obj && obj[lang]) ? obj[lang] : (obj && obj.ru) ? obj.ru : ''; }

        var sectionTitles = {
            click: { ru: 'Нажатие мышкой', kk: 'Тышқанмен басу' },
            move: { ru: 'Передвижение мышки', kk: 'Тышқанды жылжыту' },
            combined: { ru: 'Комбинированные', kk: 'Қосарланған' }
        };
        var html = '';
        var lastBlock = '';
        for (var i = 0; i < exercises.length; i++) {
            var ex = exercises[i];
            var block = ex.block || 'click';
            if (block !== lastBlock) {
                lastBlock = block;
                var st = sectionTitles[block];
                var sectionTitle = st ? t(st) : block;
                var ru = st ? st.ru : '';
                var kk = st ? st.kk : '';
                html += '<h3 class="motor-section-title" data-lang-ru="' + ru + '" data-lang-kk="' + kk + '">' + sectionTitle + '</h3>';
            }
            html += '<div class="motor-card" tabindex="0" role="button" data-idx="' + i + '">' +
                '<div class="motor-card__icon" aria-hidden="true">' + (ex.icon || '•') + '</div>' +
                '<h4 class="motor-card__title">' + (t(ex.title) || ex.title) + '</h4>' +
                '<p class="motor-card__desc">' + (t(ex.desc) || ex.desc) + '</p></div>';
        }
        grid.innerHTML = html;

        var currentCleanup = function () {};

        function openExercise(idx) {
            var ex = exercises[idx];
            if (!ex || !ex.run) return;
            stage.classList.remove('hidden');
            stageTitle.textContent = t(ex.title) || ex.title;
            stageHint.textContent = '';
            var ctx = canvas.getContext('2d');
            if (!ctx) return;
            currentCleanup();
            currentCleanup = ex.run(canvas, ctx, function () {
                currentCleanup();
                stageHint.textContent = lang === 'ru' ? 'Молодец!' : 'Жарайсың!';
                setTimeout(function () { stage.classList.add('hidden'); }, 1200);
            }, function (text) { stageHint.textContent = text || ''; });
        }

        stageClose.addEventListener('click', function () {
            currentCleanup();
            stage.classList.add('hidden');
        });

        grid.querySelectorAll('.motor-card').forEach(function (card) {
            var idx = parseInt(card.getAttribute('data-idx'), 10);
            card.addEventListener('click', function () { openExercise(idx); });
            card.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openExercise(idx); }
            });
        });

        var langBtns = document.querySelectorAll('.motor-lang-btn');
        langBtns.forEach(function (btn) {
            btn.addEventListener('click', function () {
                var l = btn.getAttribute('data-lang') || 'ru';
                document.documentElement.lang = l;
                langBtns.forEach(function (b) { b.classList.remove('active'); });
                btn.classList.add('active');
                document.querySelectorAll('[data-lang-ru]').forEach(function (el) {
                    var ru = el.getAttribute('data-lang-ru');
                    var kk = el.getAttribute('data-lang-kk');
                    el.textContent = (l === 'kk' && kk) ? kk : (ru || el.textContent);
                });
            });
        });

        var cursorEl = document.createElement('div');
        cursorEl.className = 'motor-cursor';
        cursorEl.setAttribute('aria-hidden', 'true');
        cursorEl.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="#6366F1" stroke-width="2"><path d="M5 3l14 9-6 6-3-6-5-3z"/></svg>';
        document.body.appendChild(cursorEl);
        window.addEventListener('mousemove', function (e) {
            cursorEl.style.left = e.clientX + 'px';
            cursorEl.style.top = e.clientY + 'px';
        });
    }

    function runInit() {
        try {
            init();
        } catch (err) {
            console.error('Motor exercises init error:', err);
            var grid = document.getElementById('exercisesGrid');
            if (grid) {
                grid.innerHTML = '<p class="motor-error-msg">Не удалось загрузить упражнения. Обновите страницу или вернитесь <a href="./index.html">назад</a>.</p>';
            }
        }
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', runInit);
    } else {
        runInit();
    }
})();
