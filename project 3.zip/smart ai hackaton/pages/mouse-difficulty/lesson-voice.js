// ============================================================================
// ИНКЛЮЗИВНЫЙ ОБУЧАЮЩИЙ САЙТ ДЛЯ ДЕТЕЙ С МОТОРНЫМИ НАРУШЕНИЯМИ
// ============================================================================
//
// ОСНОВНЫЕ ПРИНЦИПЫ:
// - Один экран = одно действие
// - Минимум шагов для любого действия
// - Никакой спешки и давления
// - Подстройка под возможности ребёнка
//
// УПРАВЛЕНИЕ КЛАВИАТУРОЙ:
// - ← → ↑ ↓ — перемещение между элементами
// - Enter (удержание 2 сек) — подтвердить выбор
// - Space — перейти дальше или сделать паузу
// - Esc — вернуться назад
// - Цифры 1-4 — прямой выбор варианта (4 варианта ответа)
//
// ПОВЕДЕНИЕ:
// 1. Никогда не используй слова «ошибка», «неправильно», «плохо»
// 2. Всегда поддерживай и хвали за попытку
// 3. Если ребёнок не действует — жди или повтори инструкцию
// 4. Если ребёнку трудно — упрощай интерфейс и задания
// 5. Никогда не заставляй выполнять задание до конца
//
// ОБУЧЕНИЕ (DUOLINGO-СТИЛЬ):
// - Уроки короткие (1–3 минуты)
// - Один навык за урок
// - Выбор вместо ввода текста
// - Не более 2 вариантов ответа
//
// ГЛАВНЫЙ ПРИНЦИП:
// Сайт подстраивается под ребёнка.
// Ребёнок управляет процессом через клавиатуру.
//
// ЦЕЛЬ:
// Помочь ребёнку почувствовать:
// «Я могу. Я понимаю. У меня получается».
//
// ============================================================================

class KeyboardLesson {
    constructor() {
        this.currentLang = localStorage.getItem('appLanguage') || 'ru';
        this.currentProfile = this.loadCurrentProfile();
        this.lessonKey = this.getLessonKeyFromURL();
        this.lessonData = this.getLessonData();
        
        // Состояние урока
        this.lessonStep = 0; // 0 - объяснение, 1 - вопрос, 2 - завершён
        this.currentQuestion = null;
        this.attemptsCount = 0;
        this.selectedOptionIndex = 0; // Индекс выбранного варианта ответа
        this.answerOptions = []; // Массив вариантов ответов
        this.autoNextTimeout = null; // Таймер для автоматического перехода
        this.enterHoldStartTime = null; // Время начала удержания Enter
        this.enterHoldDuration = 2000; // Длительность удержания Enter (2 секунды)
        this.singleKeyMode = false; // Режим одной клавиши
        
        // Настройки
        this.settings = this.loadSettings();
        
        this.init();
    }

    init() {
        this.initNavigation();
        this.initKeyboardControls();
        this.updateLanguage();
        this.loadLesson();
    }


    loadCurrentProfile() {
        const profileId = localStorage.getItem('currentProfileId');
        if (!profileId) {
            window.location.href = 'index.html';
            return null;
        }
        
        const profiles = JSON.parse(localStorage.getItem('profiles') || '[]');
        return profiles.find(p => p.id === profileId) || null;
    }

    getLessonKeyFromURL() {
        const params = new URLSearchParams(window.location.search);
        return params.get('key') || '';
    }

    getLessonData() {
        const [courseId, moduleId, lessonId] = this.lessonKey.split('_');
        
        // Упрощённая структура уроков
        const lessons = this.getLessonsData();
        const lesson = lessons.find(l => 
            l.courseId === courseId && 
            l.moduleId === moduleId && 
            l.id === lessonId
        );
        
        return lesson || null;
    }

    getLessonsData() {
        const lessons = {
            ru: [
                // Слова - животные
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'cat',
                    word: 'кошка',
                    explanation: 'Это кошка. Кошка — пушистое животное. Она говорит "мяу".',
                    question: 'Выбери правильное название этого животного',
                    image: '🐱',
                    correctAnswer: 'кошка',
                    alternatives: ['кот', 'кошечка', 'котёнок', 'котик', 'собака', 'лиса']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'dog',
                    word: 'собака',
                    explanation: 'Это собака. Собака — верный друг человека. Она говорит "гав".',
                    question: 'Выбери правильное название этого животного',
                    image: '🐶',
                    correctAnswer: 'собака',
                    alternatives: ['пес', 'собачка', 'пёсик', 'кошка', 'волк', 'лиса']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'bear',
                    word: 'медведь',
                    explanation: 'Это медведь. Медведь — большой и сильный. Он живёт в лесу.',
                    question: 'Выбери правильное название этого животного',
                    image: '🐻',
                    correctAnswer: 'медведь',
                    alternatives: ['мишка', 'медвежонок', 'медведик', 'волк', 'тигр', 'лев']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'rabbit',
                    word: 'заяц',
                    explanation: 'Это заяц. Заяц — быстрый и пушистый. Он любит морковку.',
                    question: 'Выбери правильное название этого животного',
                    image: '🐰',
                    correctAnswer: 'заяц',
                    alternatives: ['зайчик', 'зайка', 'зайчонок', 'кролик', 'белка', 'мышь']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'fox',
                    word: 'лиса',
                    explanation: 'Это лиса. Лиса — рыжая и хитрая. У неё пушистый хвост.',
                    question: 'Выбери правильное название этого животного',
                    image: '🦊',
                    correctAnswer: 'лиса',
                    alternatives: ['лисичка', 'лисёнок', 'волк', 'собака', 'кошка', 'тигр']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'wolf',
                    word: 'волк',
                    explanation: 'Это волк. Волк — сильный и смелый. Он живёт в лесу.',
                    question: 'Выбери правильное название этого животного',
                    image: '🐺',
                    correctAnswer: 'волк',
                    alternatives: ['волчок', 'волчонок', 'собака', 'лиса', 'медведь', 'тигр']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'lion',
                    word: 'лев',
                    explanation: 'Это лев. Лев — царь зверей. У него большая грива.',
                    question: 'Выбери правильное название этого животного',
                    image: '🦁',
                    correctAnswer: 'лев',
                    alternatives: ['львёнок', 'львица', 'тигр', 'леопард', 'пантера', 'кошка']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'elephant',
                    word: 'слон',
                    explanation: 'Это слон. Слон — очень большой. У него длинный хобот.',
                    question: 'Выбери правильное название этого животного',
                    image: '🐘',
                    correctAnswer: 'слон',
                    alternatives: ['слонёнок', 'слоник', 'бегемот', 'носорог', 'жираф', 'зебра']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'tiger',
                    word: 'тигр',
                    explanation: 'Это тигр. Тигр — полосатый и сильный. Он живёт в джунглях.',
                    question: 'Выбери правильное название этого животного',
                    image: '🐯',
                    correctAnswer: 'тигр',
                    alternatives: ['тигрёнок', 'тигрик', 'лев', 'леопард', 'пантера', 'рысь']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'horse',
                    word: 'лошадь',
                    explanation: 'Это лошадь. Лошадь — быстрая и красивая. На ней можно ездить.',
                    question: 'Выбери правильное название этого животного',
                    image: '🐴',
                    correctAnswer: 'лошадь',
                    alternatives: ['лошадка', 'конь', 'жеребёнок', 'осёл', 'пони', 'зебра']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'cow',
                    word: 'корова',
                    explanation: 'Это корова. Корова даёт молоко. Она говорит "му".',
                    question: 'Выбери правильное название этого животного',
                    image: '🐄',
                    correctAnswer: 'корова',
                    alternatives: ['коровка', 'тёлка', 'бык', 'телёнок', 'буйвол', 'олень']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'pig',
                    word: 'свинья',
                    explanation: 'Это свинья. Свинья — розовая и весёлая. Она говорит "хрю".',
                    question: 'Выбери правильное название этого животного',
                    image: '🐷',
                    correctAnswer: 'свинья',
                    alternatives: ['свинка', 'поросёнок', 'кабан', 'хряк', 'бегемот', 'носорог']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'sheep',
                    word: 'овца',
                    explanation: 'Это овца. Овца — пушистая и мягкая. Она говорит "бе".',
                    question: 'Выбери правильное название этого животного',
                    image: '🐑',
                    correctAnswer: 'овца',
                    alternatives: ['овечка', 'ягнёнок', 'коза', 'баран', 'козёл', 'олень']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'goat',
                    word: 'коза',
                    explanation: 'Это коза. Коза — ловкая и упрямая. Она говорит "ме".',
                    question: 'Выбери правильное название этого животного',
                    image: '🐐',
                    correctAnswer: 'коза',
                    alternatives: ['козочка', 'козлёнок', 'овца', 'баран', 'олень', 'антилопа']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'duck',
                    word: 'утка',
                    explanation: 'Это утка. Утка — плавает в воде. Она говорит "кря".',
                    question: 'Выбери правильное название этого животного',
                    image: '🦆',
                    correctAnswer: 'утка',
                    alternatives: ['уточка', 'утёнок', 'гусь', 'лебедь', 'курица', 'петух']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'chicken',
                    word: 'курица',
                    explanation: 'Это курица. Курица — несёт яйца. Она говорит "ко-ко-ко".',
                    question: 'Выбери правильное название этого животного',
                    image: '🐔',
                    correctAnswer: 'курица',
                    alternatives: ['курочка', 'цыплёнок', 'петух', 'утка', 'гусь', 'индюк']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'rooster',
                    word: 'петух',
                    explanation: 'Это петух. Петух — будит всех утром. Он говорит "ку-ка-ре-ку".',
                    question: 'Выбери правильное название этого животного',
                    image: '🐓',
                    correctAnswer: 'петух',
                    alternatives: ['петушок', 'курица', 'индюк', 'павлин', 'фазан', 'селезень']
                },
                // Слова - фрукты и овощи
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'apple',
                    word: 'яблоко',
                    explanation: 'Это яблоко. Яблоко — красное или зелёное. Оно сладкое и полезное.',
                    question: 'Выбери правильное название этого фрукта',
                    image: '🍎',
                    correctAnswer: 'яблоко',
                    alternatives: ['яблочко', 'яблочко', 'груша', 'апельсин', 'банан', 'персик']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'banana',
                    word: 'банан',
                    explanation: 'Это банан. Банан — жёлтый и длинный. Он очень вкусный.',
                    question: 'Выбери правильное название этого фрукта',
                    image: '🍌',
                    correctAnswer: 'банан',
                    alternatives: ['бананы', 'яблоко', 'апельсин', 'лимон', 'груша', 'персик']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'orange',
                    word: 'апельсин',
                    explanation: 'Это апельсин. Апельсин — оранжевый и круглый. Он сочный.',
                    question: 'Выбери правильное название этого фрукта',
                    image: '🍊',
                    correctAnswer: 'апельсин',
                    alternatives: ['апельсины', 'лимон', 'мандарин', 'яблоко', 'груша', 'персик']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'strawberry',
                    word: 'клубника',
                    explanation: 'Это клубника. Клубника — красная и сладкая. Она растёт на грядке.',
                    question: 'Выбери правильное название этой ягоды',
                    image: '🍓',
                    correctAnswer: 'клубника',
                    alternatives: ['клубничка', 'клубнички', 'малина', 'вишня', 'черника', 'смородина']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'carrot',
                    word: 'морковь',
                    explanation: 'Это морковь. Морковь — оранжевая и длинная. Она очень полезная.',
                    question: 'Выбери правильное название этого овоща',
                    image: '🥕',
                    correctAnswer: 'морковь',
                    alternatives: ['морковка', 'морковочка', 'свёкла', 'репа', 'редька', 'репка']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'tomato',
                    word: 'помидор',
                    explanation: 'Это помидор. Помидор — красный и круглый. Он сочный и вкусный.',
                    question: 'Выбери правильное название этого овоща',
                    image: '🍅',
                    correctAnswer: 'помидор',
                    alternatives: ['помидорчик', 'томат', 'яблоко', 'груша', 'апельсин', 'банан']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'cucumber',
                    word: 'огурец',
                    explanation: 'Это огурец. Огурец — зелёный и длинный. Он хрустящий и свежий.',
                    question: 'Выбери правильное название этого овоща',
                    image: '🥒',
                    correctAnswer: 'огурец',
                    alternatives: ['огурчик', 'огурцы', 'помидор', 'морковь', 'капуста', 'лук']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'potato',
                    word: 'картошка',
                    explanation: 'Это картошка. Картошка — коричневая и круглая. Из неё делают пюре.',
                    question: 'Выбери правильное название этого овоща',
                    image: '🥔',
                    correctAnswer: 'картошка',
                    alternatives: ['картофель', 'картошечка', 'морковь', 'свёкла', 'репа', 'лук']
                },
                // Слова - транспорт
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'car',
                    word: 'машина',
                    explanation: 'Это машина. Машина — ездит по дороге. На ней можно путешествовать.',
                    question: 'Выбери правильное название этого транспорта',
                    image: '🚗',
                    correctAnswer: 'машина',
                    alternatives: ['автомобиль', 'машинка', 'авто', 'автобус', 'поезд', 'самолёт']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'bus',
                    word: 'автобус',
                    explanation: 'Это автобус. Автобус — большой и длинный. В нём много мест.',
                    question: 'Выбери правильное название этого транспорта',
                    image: '🚌',
                    correctAnswer: 'автобус',
                    alternatives: ['автобусик', 'машина', 'поезд', 'трамвай', 'троллейбус', 'метро']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'train',
                    word: 'поезд',
                    explanation: 'Это поезд. Поезд — ездит по рельсам. Он очень длинный.',
                    question: 'Как называется этот транспорт?',
                    image: '🚂',
                    correctAnswer: 'поезд',
                    alternatives: ['поездик', 'паровоз']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'plane',
                    word: 'самолёт',
                    explanation: 'Это самолёт. Самолёт — летает в небе. Он очень быстрый.',
                    question: 'Как называется этот транспорт?',
                    image: '✈️',
                    correctAnswer: 'самолёт',
                    alternatives: ['самолётик', 'аэроплан']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'bike',
                    word: 'велосипед',
                    explanation: 'Это велосипед. Велосипед — ездит на двух колёсах. На нём нужно крутить педали.',
                    question: 'Как называется этот транспорт?',
                    image: '🚲',
                    correctAnswer: 'велосипед',
                    alternatives: ['велосипедик', 'велик', 'вело']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'ship',
                    word: 'корабль',
                    explanation: 'Это корабль. Корабль — плавает по морю. Он очень большой.',
                    question: 'Как называется этот транспорт?',
                    image: '🚢',
                    correctAnswer: 'корабль',
                    alternatives: ['кораблик', 'судно']
                },
                // Слова - цвета
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'red',
                    word: 'красный',
                    explanation: 'Это красный цвет. Красный — как помидор или яблоко.',
                    question: 'Выбери правильное название этого цвета',
                    image: '🔴',
                    correctAnswer: 'красный',
                    alternatives: ['красная', 'красное', 'синий', 'зелёный', 'жёлтый', 'оранжевый']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'blue',
                    word: 'синий',
                    explanation: 'Это синий цвет. Синий — как небо или море.',
                    question: 'Выбери правильное название этого цвета',
                    image: '🔵',
                    correctAnswer: 'синий',
                    alternatives: ['синяя', 'синее', 'голубой', 'красный', 'зелёный', 'фиолетовый']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'green',
                    word: 'зелёный',
                    explanation: 'Это зелёный цвет. Зелёный — как трава или листья.',
                    question: 'Выбери правильное название этого цвета',
                    image: '🟢',
                    correctAnswer: 'зелёный',
                    alternatives: ['зелёная', 'зелёное', 'синий', 'жёлтый', 'красный', 'голубой']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'yellow',
                    word: 'жёлтый',
                    explanation: 'Это жёлтый цвет. Жёлтый — как солнце или банан.',
                    question: 'Выбери правильное название этого цвета',
                    image: '🟡',
                    correctAnswer: 'жёлтый',
                    alternatives: ['жёлтая', 'жёлтое', 'оранжевый', 'красный', 'зелёный', 'белый']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'orange',
                    word: 'оранжевый',
                    explanation: 'Это оранжевый цвет. Оранжевый — как апельсин или морковь.',
                    question: 'Выбери правильное название этого цвета',
                    image: '🟠',
                    correctAnswer: 'оранжевый',
                    alternatives: ['оранжевая', 'оранжевое', 'жёлтый', 'красный', 'розовый', 'коричневый']
                },
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'purple',
                    word: 'фиолетовый',
                    explanation: 'Это фиолетовый цвет. Фиолетовый — как баклажан или слива.',
                    question: 'Какой это цвет?',
                    image: '🟣',
                    correctAnswer: 'фиолетовый',
                    alternatives: ['фиолетовая', 'фиолетовое']
                },
                // Математика - счёт
                {
                    courseId: 'math',
                    moduleId: 'counting',
                    id: 'count1',
                    word: 'счёт',
                    explanation: 'Давай посчитаем яблоки. Один, два, три.',
                    question: 'Посчитай и выбери правильное число яблок',
                    image: '🍎',
                    count: 3,
                    correctAnswer: '3',
                    alternatives: ['три', 'трех', 'трое', '2', '4', '5']
                },
                {
                    courseId: 'math',
                    moduleId: 'counting',
                    id: 'count2',
                    word: 'счёт',
                    explanation: 'Давай посчитаем. Один, два, три, четыре, пять.',
                    question: 'Посчитай и выбери правильное число яблок',
                    image: '🍎',
                    count: 5,
                    correctAnswer: '5',
                    alternatives: ['пять', 'пяти', '4', '6', '7', '3']
                },
                {
                    courseId: 'math',
                    moduleId: 'counting',
                    id: 'count3',
                    word: 'счёт',
                    explanation: 'Давай посчитаем мячики. Один, два.',
                    question: 'Посчитай и выбери правильное число мячиков',
                    image: '⚽',
                    count: 2,
                    correctAnswer: '2',
                    alternatives: ['два', 'две', 'двое', '1', '3', '4']
                },
                {
                    courseId: 'math',
                    moduleId: 'counting',
                    id: 'count4',
                    word: 'счёт',
                    explanation: 'Давай посчитаем звёздочки. Один, два, три, четыре.',
                    question: 'Посчитай и выбери правильное число звёздочек',
                    image: '⭐',
                    count: 4,
                    correctAnswer: '4',
                    alternatives: ['четыре', 'четверо', '3', '5', '6', '2']
                },
                {
                    courseId: 'math',
                    moduleId: 'counting',
                    id: 'count5',
                    word: 'счёт',
                    explanation: 'Давай посчитаем цветочки. Один, два, три, четыре, пять, шесть.',
                    question: 'Посчитай и выбери правильное число цветочков',
                    image: '🌸',
                    count: 6,
                    correctAnswer: '6',
                    alternatives: ['шесть', 'шестеро', '5', '7', '8', '4']
                },
                {
                    courseId: 'math',
                    moduleId: 'counting',
                    id: 'count6',
                    word: 'счёт',
                    explanation: 'Давай посчитаем машинки. Один, два, три, четыре, пять, шесть, семь.',
                    question: 'Посчитай и выбери правильное число машинок',
                    image: '🚗',
                    count: 7,
                    correctAnswer: '7',
                    alternatives: ['семь', 'семеро', '6', '8', '9', '5']
                },
                {
                    courseId: 'math',
                    moduleId: 'counting',
                    id: 'count7',
                    word: 'счёт',
                    explanation: 'Давай посчитаем кубики. Один, два, три, четыре, пять, шесть, семь, восемь.',
                    question: 'Посчитай и выбери правильное число кубиков',
                    image: '🧱',
                    count: 8,
                    correctAnswer: '8',
                    alternatives: ['восемь', 'восьмеро', '7', '9', '10', '6']
                },
                {
                    courseId: 'math',
                    moduleId: 'counting',
                    id: 'count8',
                    word: 'счёт',
                    explanation: 'Давай посчитаем шарики. Один, два, три, четыре, пять, шесть, семь, восемь, девять.',
                    question: 'Посчитай и выбери правильное число шариков',
                    image: '🎈',
                    count: 9,
                    correctAnswer: '9',
                    alternatives: ['девять', 'девятеро', '8', '10', '11', '7']
                },
                {
                    courseId: 'math',
                    moduleId: 'counting',
                    id: 'count9',
                    word: 'счёт',
                    explanation: 'Давай посчитаем конфетки. Один, два, три, четыре, пять, шесть, семь, восемь, девять, десять.',
                    question: 'Посчитай и выбери правильное число конфеток',
                    image: '🍬',
                    count: 10,
                    correctAnswer: '10',
                    alternatives: ['десять', 'десяток', '9', '11', '12', '8']
                },
                {
                    courseId: 'math',
                    moduleId: 'counting',
                    id: 'count10',
                    word: 'счёт',
                    explanation: 'Давай посчитаем. Один.',
                    question: 'Посчитай и выбери правильное число яблок',
                    image: '🍎',
                    count: 1,
                    correctAnswer: '1',
                    alternatives: ['один', 'одно', 'одна', '2', '3', '4']
                },
                // Логика - Формы
                {
                    courseId: 'logic',
                    moduleId: 'shapes',
                    id: 'circle',
                    word: 'круг',
                    explanation: 'Это круг. Круг — это форма, похожая на солнце или мяч.',
                    question: 'Выбери правильное название этой формы',
                    image: '⭕',
                    correctAnswer: 'круг',
                    alternatives: ['круглый', 'кружок', 'кружочек', 'квадрат', 'треугольник', 'овал']
                },
                {
                    courseId: 'logic',
                    moduleId: 'shapes',
                    id: 'square',
                    word: 'квадрат',
                    explanation: 'Это квадрат. У квадрата четыре одинаковые стороны.',
                    question: 'Выбери правильное название этой формы',
                    image: '⬜',
                    correctAnswer: 'квадрат',
                    alternatives: ['квадратик', 'квадратный', 'круг', 'прямоугольник', 'ромб', 'треугольник']
                },
                {
                    courseId: 'logic',
                    moduleId: 'shapes',
                    id: 'triangle',
                    word: 'треугольник',
                    explanation: 'Это треугольник. У треугольника три угла и три стороны.',
                    question: 'Какая это форма?',
                    image: '🔺',
                    correctAnswer: 'треугольник',
                    alternatives: ['треугольничек', 'треугольный']
                },
                {
                    courseId: 'logic',
                    moduleId: 'shapes',
                    id: 'rectangle',
                    word: 'прямоугольник',
                    explanation: 'Это прямоугольник. У прямоугольника четыре стороны, как у книги.',
                    question: 'Какая это форма?',
                    image: '▭',
                    correctAnswer: 'прямоугольник',
                    alternatives: ['прямоугольничек']
                },
                {
                    courseId: 'logic',
                    moduleId: 'shapes',
                    id: 'oval',
                    word: 'овал',
                    explanation: 'Это овал. Овал похож на яйцо или на лицо.',
                    question: 'Какая это форма?',
                    image: '🥚',
                    correctAnswer: 'овал',
                    alternatives: ['овальный', 'овальчик']
                },
                {
                    courseId: 'logic',
                    moduleId: 'shapes',
                    id: 'star',
                    word: 'звезда',
                    explanation: 'Это звезда. Звезда светит на небе ночью.',
                    question: 'Что это?',
                    image: '⭐',
                    correctAnswer: 'звезда',
                    alternatives: ['звёздочка', 'звёздочка']
                },
                // Логика - Сравнение
                {
                    courseId: 'logic',
                    moduleId: 'comparison',
                    id: 'big-small',
                    word: 'размер',
                    explanation: 'Это большой мяч, а это маленький мяч. Большой — это когда предмет крупный.',
                    question: 'Какой мяч большой?',
                    image: '⚽',
                    correctAnswer: 'большой',
                    alternatives: ['большая', 'большое', 'крупный']
                },
                {
                    courseId: 'logic',
                    moduleId: 'comparison',
                    id: 'long-short',
                    word: 'длина',
                    explanation: 'Это длинная палка, а это короткая палка. Длинный — это когда предмет вытянутый.',
                    question: 'Какая палка длинная?',
                    image: '📏',
                    correctAnswer: 'длинная',
                    alternatives: ['длинный', 'длинное', 'длиннее']
                },
                {
                    courseId: 'logic',
                    moduleId: 'comparison',
                    id: 'high-low',
                    word: 'высота',
                    explanation: 'Это высокий дом, а это низкий дом. Высокий — это когда предмет высоко.',
                    question: 'Какой дом высокий?',
                    image: '🏠',
                    correctAnswer: 'высокий',
                    alternatives: ['высокая', 'высокое', 'выше']
                },
                {
                    courseId: 'logic',
                    moduleId: 'comparison',
                    id: 'wide-narrow',
                    word: 'ширина',
                    explanation: 'Это широкая дорога, а это узкая дорога. Широкий — это когда предмет широкий.',
                    question: 'Какая дорога широкая?',
                    image: '🛣️',
                    correctAnswer: 'широкая',
                    alternatives: ['широкий', 'широкое', 'шире']
                },
                // Логика - Последовательности
                {
                    courseId: 'logic',
                    moduleId: 'sequences',
                    id: 'seq1',
                    word: 'последовательность',
                    explanation: 'Смотри: красный, синий, красный, синий. Что дальше? Красный!',
                    question: 'Продолжи: красный, синий, красный...',
                    image: '🔴',
                    correctAnswer: 'синий',
                    alternatives: ['синяя', 'голубой']
                },
                {
                    courseId: 'logic',
                    moduleId: 'sequences',
                    id: 'seq2',
                    word: 'закономерность',
                    explanation: 'Смотри: круг, квадрат, круг, квадрат. Это закономерность. Что дальше?',
                    question: 'Продолжи: круг, квадрат, круг...',
                    image: '⭕',
                    correctAnswer: 'квадрат',
                    alternatives: ['квадратик']
                },
                {
                    courseId: 'logic',
                    moduleId: 'sequences',
                    id: 'seq3',
                    word: 'ряд',
                    explanation: 'Смотри: один, два, три. Что дальше? Четыре!',
                    question: 'Продолжи: один, два, три...',
                    image: '1️⃣',
                    correctAnswer: 'четыре',
                    alternatives: ['4', 'четверо']
                },
                // Логика - Пары
                {
                    courseId: 'logic',
                    moduleId: 'pairs',
                    id: 'pair1',
                    word: 'пара',
                    explanation: 'Кошка и мышь — это пара. Они связаны друг с другом.',
                    question: 'Что подходит к кошке?',
                    image: '🐱',
                    correctAnswer: 'мышь',
                    alternatives: ['мышка', 'мышонок']
                },
                {
                    courseId: 'logic',
                    moduleId: 'pairs',
                    id: 'pair2',
                    word: 'подходит',
                    explanation: 'Ключ подходит к замку. Они работают вместе.',
                    question: 'Что подходит к ключу?',
                    image: '🗝️',
                    correctAnswer: 'замок',
                    alternatives: ['замочек', 'дверь']
                },
                {
                    courseId: 'logic',
                    moduleId: 'pairs',
                    id: 'pair3',
                    word: 'соедини',
                    explanation: 'Собака и кость — это пара. Собака любит кость.',
                    question: 'Что подходит к собаке?',
                    image: '🐶',
                    correctAnswer: 'кость',
                    alternatives: ['косточка', 'еда']
                },
                // Логика - Классификация
                {
                    courseId: 'logic',
                    moduleId: 'classification',
                    id: 'class1',
                    word: 'животное',
                    explanation: 'Кошка — это животное. Животные умеют двигаться и есть.',
                    question: 'Кошка — это животное или растение?',
                    image: '🐱',
                    correctAnswer: 'животное',
                    alternatives: ['животные', 'зверь']
                },
                {
                    courseId: 'logic',
                    moduleId: 'classification',
                    id: 'class2',
                    word: 'фрукт',
                    explanation: 'Яблоко — это фрукт. Фрукты растут на деревьях и сладкие.',
                    question: 'Яблоко — это фрукт или овощ?',
                    image: '🍎',
                    correctAnswer: 'фрукт',
                    alternatives: ['фрукты', 'фруктовый']
                },
                {
                    courseId: 'logic',
                    moduleId: 'classification',
                    id: 'class3',
                    word: 'транспорт',
                    explanation: 'Машина — это транспорт. Транспорт помогает ездить.',
                    question: 'Машина — это транспорт или животное?',
                    image: '🚗',
                    correctAnswer: 'транспорт',
                    alternatives: ['машина', 'автомобиль']
                },
                // Логика - Противоположности
                {
                    courseId: 'logic',
                    moduleId: 'opposites',
                    id: 'opp1',
                    word: 'день',
                    explanation: 'День — это когда светло и солнце светит. Противоположность дня — это ночь.',
                    question: 'Противоположность дня — это?',
                    image: '☀️',
                    correctAnswer: 'ночь',
                    alternatives: ['ночная', 'ночью']
                },
                {
                    courseId: 'logic',
                    moduleId: 'opposites',
                    id: 'opp2',
                    word: 'свет',
                    explanation: 'Свет — это когда ярко. Противоположность света — это тень.',
                    question: 'Противоположность света — это?',
                    image: '💡',
                    correctAnswer: 'тень',
                    alternatives: ['тёмный', 'темнота']
                },
                {
                    courseId: 'logic',
                    moduleId: 'opposites',
                    id: 'opp3',
                    word: 'вверх',
                    explanation: 'Вверх — это когда поднимаешься. Противоположность вверх — это вниз.',
                    question: 'Противоположность вверх — это?',
                    image: '⬆️',
                    correctAnswer: 'вниз',
                    alternatives: ['низ', 'ниже']
                },
                // Логика - Части и целое
                {
                    courseId: 'logic',
                    moduleId: 'parts-whole',
                    id: 'part1',
                    word: 'части тела',
                    explanation: 'У человека есть голова, руки, ноги. Это части тела.',
                    question: 'Что является частью тела?',
                    image: '👤',
                    correctAnswer: 'голова',
                    alternatives: ['рука', 'нога', 'руки', 'ноги']
                },
                {
                    courseId: 'logic',
                    moduleId: 'parts-whole',
                    id: 'part2',
                    word: 'части дома',
                    explanation: 'У дома есть стены, крыша, окна, дверь. Это части дома.',
                    question: 'Что является частью дома?',
                    image: '🏠',
                    correctAnswer: 'окно',
                    alternatives: ['дверь', 'крыша', 'стена']
                },
                // Логика - Причина и следствие
                {
                    courseId: 'logic',
                    moduleId: 'cause-effect',
                    id: 'cause1',
                    word: 'после',
                    explanation: 'Сначала идёт дождь, потом на земле лужи. Лужи появляются после дождя.',
                    question: 'Что происходит после дождя?',
                    image: '🌧️',
                    correctAnswer: 'лужи',
                    alternatives: ['лужа', 'вода', 'мокро']
                },
                {
                    courseId: 'logic',
                    moduleId: 'cause-effect',
                    id: 'cause2',
                    word: 'до',
                    explanation: 'Перед тем как есть, нужно помыть руки. Сначала моем руки, потом едим.',
                    question: 'Что нужно сделать до еды?',
                    image: '🍎',
                    correctAnswer: 'помыть руки',
                    alternatives: ['руки', 'помыть', 'вымыть']
                },
                // Логика - Узоры
                {
                    courseId: 'logic',
                    moduleId: 'patterns',
                    id: 'pattern1',
                    word: 'узор',
                    explanation: 'Смотри: красный, синий, красный, синий. Это узор. Повтори его.',
                    question: 'Повтори узор: красный, синий...',
                    image: '🔴',
                    correctAnswer: 'красный',
                    alternatives: ['красная', 'красное']
                },
                {
                    courseId: 'logic',
                    moduleId: 'patterns',
                    id: 'pattern2',
                    word: 'одинаковый',
                    explanation: 'Найди два одинаковых предмета. Они похожи друг на друга.',
                    question: 'Найди одинаковые предметы',
                    image: '🔴',
                    correctAnswer: 'одинаковые',
                    alternatives: ['одинаковый', 'похожие', 'такие же']
                },
                // Логика - Сортировка
                {
                    courseId: 'logic',
                    moduleId: 'sorting',
                    id: 'sort1',
                    word: 'цвет',
                    explanation: 'Разложи предметы по цветам. Красные к красным, синие к синим.',
                    question: 'Какого цвета этот предмет?',
                    image: '🔴',
                    correctAnswer: 'красный',
                    alternatives: ['красная', 'красное']
                },
                {
                    courseId: 'logic',
                    moduleId: 'sorting',
                    id: 'sort2',
                    word: 'форма',
                    explanation: 'Разложи предметы по формам. Круги к кругам, квадраты к квадратам.',
                    question: 'Какая это форма?',
                    image: '⭕',
                    correctAnswer: 'круг',
                    alternatives: ['круглый', 'кружок']
                },
                {
                    courseId: 'logic',
                    moduleId: 'sorting',
                    id: 'sort5',
                    word: 'лишнее',
                    explanation: 'Смотри: яблоко, банан, апельсин, машина. Машина лишняя, потому что это не фрукт.',
                    question: 'Что здесь лишнее?',
                    image: '🍎',
                    correctAnswer: 'машина',
                    alternatives: ['автомобиль', 'транспорт']
                }
            ],
            kk: [
                {
                    courseId: 'reading',
                    moduleId: 'words',
                    id: 'cat',
                    word: 'мысық',
                    explanation: 'Бұл мысық. Мысық — жұмсақ жануар. Ол "мияу" дейді.',
                    question: 'Бұл қандай жануар?',
                    image: '🐱',
                    correctAnswer: 'мысық',
                    alternatives: ['мысықтың']
                },
                // Логика - Формы
                {
                    courseId: 'logic',
                    moduleId: 'shapes',
                    id: 'circle',
                    word: 'шеңбер',
                    explanation: 'Бұл шеңбер. Шеңбер — күн немесе доп сияқты пішін.',
                    question: 'Бұл қандай пішін?',
                    image: '⭕',
                    correctAnswer: 'шеңбер',
                    alternatives: ['дөңгелек', 'дөңгелекті']
                },
                {
                    courseId: 'logic',
                    moduleId: 'shapes',
                    id: 'square',
                    word: 'шаршы',
                    explanation: 'Бұл шаршы. Шаршыда төрт бірдей қабырға бар.',
                    question: 'Бұл қандай пішін?',
                    image: '⬜',
                    correctAnswer: 'шаршы',
                    alternatives: ['шаршылық']
                },
                {
                    courseId: 'logic',
                    moduleId: 'shapes',
                    id: 'triangle',
                    word: 'үшбұрыш',
                    explanation: 'Бұл үшбұрыш. Үшбұрышта үш бұрыш және үш қабырға бар.',
                    question: 'Бұл қандай пішін?',
                    image: '🔺',
                    correctAnswer: 'үшбұрыш',
                    alternatives: ['үшбұрышты']
                },
                // Логика - Сравнение
                {
                    courseId: 'logic',
                    moduleId: 'comparison',
                    id: 'big-small',
                    word: 'өлшем',
                    explanation: 'Бұл үлкен доп, ал бұл кішкентай доп. Үлкен — бұл зат үлкен болғанда.',
                    question: 'Қай доп үлкен?',
                    image: '⚽',
                    correctAnswer: 'үлкен',
                    alternatives: ['үлкені', 'үлкенірек', 'үлкенірек']
                },
                {
                    courseId: 'logic',
                    moduleId: 'comparison',
                    id: 'high-low',
                    word: 'биіктік',
                    explanation: 'Бұл биік үй, ал бұл төмен үй. Биік — бұл зат биік болғанда.',
                    question: 'Қай үй биік?',
                    image: '🏠',
                    correctAnswer: 'биік',
                    alternatives: ['биігі', 'биігірек']
                },
                // Логика - Последовательности
                {
                    courseId: 'logic',
                    moduleId: 'sequences',
                    id: 'seq1',
                    word: 'тізбек',
                    explanation: 'Қара: қызыл, көк, қызыл, көк. Келесі не? Қызыл!',
                    question: 'Жалғастыр: қызыл, көк, қызыл...',
                    image: '🔴',
                    correctAnswer: 'көк',
                    alternatives: ['көгі', 'көгілдір']
                },
                // Логика - Пары
                {
                    courseId: 'logic',
                    moduleId: 'pairs',
                    id: 'pair1',
                    word: 'жұп',
                    explanation: 'Мысық пен тышқан — бұл жұп. Олар бір-бірімен байланысты.',
                    question: 'Мысыққа не сәйкес келеді?',
                    image: '🐱',
                    correctAnswer: 'тышқан',
                    alternatives: ['тышқанша', 'тышқандар']
                },
                // Логика - Классификация
                {
                    courseId: 'logic',
                    moduleId: 'classification',
                    id: 'class1',
                    word: 'жануар',
                    explanation: 'Мысық — бұл жануар. Жануарлар қозғала алады және тамақтана алады.',
                    question: 'Мысық — бұл жануар ма, әлде өсімдік пе?',
                    image: '🐱',
                    correctAnswer: 'жануар',
                    alternatives: ['жануарлар', 'аң']
                },
                // Логика - Противоположности
                {
                    courseId: 'logic',
                    moduleId: 'opposites',
                    id: 'opp1',
                    word: 'күн',
                    explanation: 'Күн — бұл жарық және күн сәулеленгенде. Күннің қарама-қарсысы — түн.',
                    question: 'Күннің қарама-қарсысы — бұл?',
                    image: '☀️',
                    correctAnswer: 'түн',
                    alternatives: ['түнде', 'түнгі']
                }
            ]
        };
        
        return lessons[this.currentLang] || [];
    }

    loadLesson() {
        if (!this.lessonData) {
            // Голосовые функции удалены
            this.showMessage(this.currentLang === 'ru' 
                ? 'Урок не найден. Вернёмся назад.' 
                : 'Сабақ табылмады. Артқа оралайық.');
            setTimeout(() => window.location.href = 'index.html', 2000);
            return;
        }

        // Начинаем урок с объяснения
        this.startLesson();
    }

    startLesson() {
        this.lessonStep = 0;
        this.attemptsCount = 0;
        
        // Показываем объяснение
        this.showExplanation();
    }

    showExplanation() {
        const { explanation, image, word } = this.lessonData;
        
        // Обновляем интерфейс
        let explanationHTML = `<div class="lesson-image-large">${image}</div>`;
        if (word) {
            explanationHTML += `<div class="lesson-word-large">${word}</div>`;
        }
        explanationHTML += `<div class="lesson-question-text">${explanation}</div>`;
        explanationHTML += `<div class="keyboard-hint" style="margin-top: 20px; text-align: center; color: #666; font-size: 18px;">
            ${this.currentLang === 'ru' ? 'Нажми Space или Enter, чтобы перейти к вопросу' : 'Сұраққа өту үшін Space немесе Enter басыңыз'}
        </div>`;
        
        document.getElementById('taskContainer').innerHTML = explanationHTML;
        
        // Автоматически переходим к вопросу через 3 секунды или по нажатию Space/Enter
        setTimeout(() => {
            if (this.lessonStep === 0) {
                this.showQuestion();
            }
        }, 3000);
    }

    showQuestion() {
        this.lessonStep = 1;
        this.attemptsCount = 0;
        this.selectedOptionIndex = 0;
        
        const { question, image, word, count, correctAnswer, alternatives } = this.lessonData;
        
        // Создаём варианты ответов
        this.answerOptions = this.generateAnswerOptions(correctAnswer, alternatives, count);
        
        // Обновляем интерфейс
        let questionHTML = `<div class="lesson-image-large">${image}</div>`;
        
        if (count) {
            // Для счёта показываем несколько изображений
            questionHTML = `<div class="counting-images-large">${Array(count).fill(image).join('')}</div>`;
        }
        
        questionHTML += `<div class="lesson-question-text">${question}</div>`;
        
        // Добавляем варианты ответов в виде кнопок (4 варианта для более сложных тестов)
        questionHTML += `<div class="answer-options-container" id="answerOptions">`;
        
        // Показываем 4 варианта ответа для более сложных тестов
        const optionsToShow = this.answerOptions.slice(0, 4);
        
        optionsToShow.forEach((option, index) => {
            const isCorrect = option.isCorrect;
            questionHTML += `
                <button class="answer-option-btn ${index === 0 ? 'selected' : ''}" 
                        data-index="${index}" 
                        data-correct="${isCorrect}"
                        tabindex="${index + 1}">
                    <span class="option-number">${index + 1}</span>
                    <span class="option-text">${option.text}</span>
                </button>
            `;
        });
        questionHTML += `</div>`;
        
        // Обновляем answerOptions, чтобы они соответствовали отображаемым
        this.answerOptions = optionsToShow;
        
        document.getElementById('taskContainer').innerHTML = questionHTML;
        
        // Добавляем обработчики для кнопок
        this.attachAnswerOptionHandlers();
        
        // Вопрос готов, ждём выбора ответа
    }

    generateAnswerOptions(correctAnswer, alternatives, count) {
        const options = [];
        
        // Добавляем правильный ответ
        const correctText = this.formatAnswerText(correctAnswer, count);
        options.push({
            text: correctText,
            isCorrect: true
        });
        
        // Добавляем неправильные варианты из alternatives
        if (alternatives && alternatives.length > 0) {
            alternatives.forEach(alt => {
                const altText = this.formatAnswerText(alt, count);
                if (altText && altText !== correctText && !options.some(opt => opt.text === altText)) {
                    options.push({
                        text: altText,
                        isCorrect: false
                    });
                }
            });
        }
        
        // Если вариантов мало, добавляем случайные неправильные
        let attempts = 0;
        while (options.length < 4 && attempts < 30) {
            attempts++;
            const randomOption = this.generateRandomWrongAnswer(correctAnswer, count, this.lessonData);
            if (randomOption && randomOption !== correctText && !options.some(opt => opt.text === randomOption)) {
                options.push({
                    text: randomOption,
                    isCorrect: false
                });
            }
        }
        
        // Если всё ещё меньше 4 вариантов, добавляем базовые варианты
        const basicWrongOptions = this.getBasicWrongOptions(this.lessonData);
        for (const wrongOption of basicWrongOptions) {
            if (options.length >= 4) break;
            const wrongText = this.formatAnswerText(wrongOption, count);
            if (wrongText && wrongText !== correctText && !options.some(opt => opt.text === wrongText)) {
                options.push({
                    text: wrongText,
                    isCorrect: false
                });
            }
        }
        
        // Если всё ещё меньше 4, добавляем дополнительные варианты
        if (options.length < 4) {
            const additionalWrong = this.generateAdditionalWrongOptions(correctAnswer, count, this.lessonData);
            for (const wrongOption of additionalWrong) {
                if (options.length >= 4) break;
                const wrongText = this.formatAnswerText(wrongOption, count);
                if (wrongText && wrongText !== correctText && !options.some(opt => opt.text === wrongText)) {
                    options.push({
                        text: wrongText,
                        isCorrect: false
                    });
                }
            }
        }
        
        // Оставляем 4 варианта: один правильный и три неправильных
        const correctOption = options.find(opt => opt.isCorrect);
        const wrongOptions = options.filter(opt => !opt.isCorrect);
        
        const finalOptions = [correctOption];
        // Добавляем 3 неправильных варианта для сложности
        for (let i = 0; i < Math.min(3, wrongOptions.length); i++) {
            finalOptions.push(wrongOptions[i]);
        }
        
        // Перемешиваем варианты
        return this.shuffleArray(finalOptions);
    }

    getBasicWrongOptions(lessonData) {
        const { courseId, moduleId, correctAnswer } = lessonData;
        
        // Базовые неправильные варианты в зависимости от типа урока (расширенные для сложности)
        if (courseId === 'reading') {
            if (moduleId === 'letters') {
                // Для букв - другие буквы алфавита (больше вариантов)
                const alphabet = 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя';
                const wrongLetters = alphabet.split('').filter(l => l !== correctAnswer.toLowerCase());
                // Возвращаем больше вариантов для сложности
                return wrongLetters.slice(0, 10);
            } else {
                // Для слов - похожие слова (больше вариантов)
                return ['слово', 'буква', 'текст', 'предложение', 'фраза', 'выражение'];
            }
        } else if (courseId === 'math') {
            if (moduleId === 'counting' || moduleId === 'addition' || moduleId === 'subtraction') {
                // Для математики - другие числа (больше вариантов)
                const num = parseInt(correctAnswer) || 0;
                const wrongNumbers = [];
                // Добавляем числа в диапазоне ±5
                for (let i = -5; i <= 5; i++) {
                    const wrongNum = num + i;
                    if (wrongNum > 0 && wrongNum !== num && wrongNum <= 100) {
                        wrongNumbers.push(wrongNum.toString());
                    }
                }
                return wrongNumbers.slice(0, 10);
            } else {
                return ['число', 'много', 'мало', 'несколько', 'пара', 'тройка'];
            }
        } else if (courseId === 'logic') {
            // Для логики - больше вариантов
            return ['другой', 'неправильный', 'нет', 'неверно', 'ложь', 'не так'];
        }
        
        // Общие варианты по умолчанию (расширенные)
        return ['другой', 'неправильный', 'нет', 'неверно', 'ложь'];
    }

    generateAdditionalWrongOptions(correctAnswer, count, lessonData) {
        // Генерируем дополнительные неправильные варианты для усложнения
        const { courseId, moduleId } = lessonData;
        const additional = [];
        
        if (courseId === 'reading' && moduleId === 'letters') {
            // Для букв - добавляем похожие по звучанию буквы
            const similarLetters = {
                'а': ['о', 'я', 'э'],
                'б': ['п', 'в', 'д'],
                'в': ['ф', 'б', 'г'],
                'г': ['к', 'х', 'ж'],
                'д': ['т', 'б', 'з'],
                'е': ['э', 'и', 'ё'],
                'ж': ['ш', 'з', 'ч'],
                'з': ['с', 'ж', 'ц'],
                'и': ['ы', 'й', 'э'],
                'к': ['г', 'х', 'т'],
                'л': ['р', 'н', 'м'],
                'м': ['н', 'л', 'б'],
                'н': ['м', 'л', 'р'],
                'о': ['а', 'у', 'ё'],
                'п': ['б', 'т', 'ф'],
                'р': ['л', 'н', 'м'],
                'с': ['з', 'ш', 'ц'],
                'т': ['д', 'п', 'к'],
                'у': ['о', 'ю', 'ы'],
                'ф': ['в', 'п', 'х'],
                'х': ['к', 'г', 'ф'],
                'ц': ['с', 'ч', 'з'],
                'ч': ['ш', 'щ', 'ж'],
                'ш': ['щ', 'ж', 'ч'],
                'щ': ['ш', 'ч', 'ж'],
                'ы': ['и', 'у', 'э'],
                'э': ['е', 'и', 'ы'],
                'ю': ['у', 'я', 'ё'],
                'я': ['а', 'ю', 'е']
            };
            const lowerAnswer = correctAnswer.toLowerCase();
            if (similarLetters[lowerAnswer]) {
                additional.push(...similarLetters[lowerAnswer]);
            }
        } else if (courseId === 'math') {
            // Для математики - добавляем числа в более широком диапазоне
            const num = parseInt(correctAnswer) || 0;
            for (let i = -10; i <= 10; i++) {
                const wrongNum = num + i;
                if (wrongNum > 0 && wrongNum !== num && wrongNum <= 100) {
                    additional.push(wrongNum.toString());
                }
            }
        }
        
        return additional;
    }

    formatAnswerText(text, count) {
        if (!text) return '';
        
        // Если это число или строка с числом
        if (typeof text === 'number' || !isNaN(text)) {
            return text.toString();
        }
        
        // Если это строка, возвращаем как есть
        if (typeof text === 'string') {
            return text.trim();
        }
        
        return String(text);
    }

    generateRandomWrongAnswer(correctAnswer, count, lessonData) {
        if (count !== undefined) {
            // Для заданий на счёт генерируем неправильные числа (более широкий диапазон для сложности)
            const wrongCount = count + Math.floor(Math.random() * 10) - 5;
            if (wrongCount > 0 && wrongCount !== count && wrongCount <= 100) {
                return wrongCount.toString();
            }
            // Если не получилось, пробуем другие варианты (больше вариантов)
            const alternatives = [];
            for (let i = -5; i <= 5; i++) {
                const alt = count + i;
                if (alt > 0 && alt !== count && alt <= 100) {
                    alternatives.push(alt);
                }
            }
            if (alternatives.length > 0) {
                return alternatives[Math.floor(Math.random() * alternatives.length)].toString();
            }
            return (count + 1).toString();
        }
        
        // Для других заданий используем базовые варианты из урока
        const basicOptions = this.getBasicWrongOptions(lessonData || this.lessonData);
        if (basicOptions && basicOptions.length > 0) {
            return basicOptions[Math.floor(Math.random() * basicOptions.length)];
        }
        
        // Дополнительные варианты для усложнения
        const additionalOptions = this.generateAdditionalWrongOptions(correctAnswer, count, lessonData || this.lessonData);
        if (additionalOptions && additionalOptions.length > 0) {
            return additionalOptions[Math.floor(Math.random() * additionalOptions.length)];
        }
        
        // Fallback варианты (расширенные)
        const wrongOptions = ['другой', 'неправильный', 'нет', 'неверно', 'ложь'];
        return wrongOptions[Math.floor(Math.random() * wrongOptions.length)];
    }

    shuffleArray(array) {
        const shuffled = [...array];
        for (let i = shuffled.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
        }
        return shuffled;
    }

    attachAnswerOptionHandlers() {
        const buttons = document.querySelectorAll('.answer-option-btn');
        buttons.forEach((btn, index) => {
            btn.addEventListener('click', () => {
                this.selectOption(index);
                this.submitAnswer();
            });
            
            btn.addEventListener('keydown', (e) => {
                // Поддержка всех клавиш для выбора
                if (e.key === 'Enter' || 
                    e.key === ' ' || 
                    e.key === 'Space' || 
                    e.key === 'Tab' ||
                    e.key === 'Return' ||
                    e.key === 'NumpadEnter') {
                    e.preventDefault();
                    this.selectOption(index);
                    this.submitAnswer();
                }
            });
        });
    }

    selectOption(index) {
        this.selectedOptionIndex = index;
        
        // Обновляем визуальное выделение
        const buttons = document.querySelectorAll('.answer-option-btn');
        buttons.forEach((btn, i) => {
            if (i === index) {
                btn.classList.add('selected');
                btn.focus();
            } else {
                btn.classList.remove('selected');
            }
        });
    }

    submitAnswer() {
        const selectedOption = this.answerOptions[this.selectedOptionIndex];
        const button = document.querySelector(`.answer-option-btn[data-index="${this.selectedOptionIndex}"]`);
        
        // Блокируем все кнопки во время обработки ответа
        document.querySelectorAll('.answer-option-btn').forEach(btn => {
            btn.disabled = true;
            btn.style.pointerEvents = 'none';
        });
        
        if (selectedOption.isCorrect) {
            // Правильный ответ
            button.classList.add('correct');
            this.handleCorrectAnswer();
        } else {
            // ИНКЛЮЗИВНЫЙ ПРИНЦИП: Не говорим "неправильно", просто показываем правильный ответ
            button.classList.add('incorrect');
            // Показываем правильный ответ мягко и поддерживающе
            const correctButton = document.querySelector('.answer-option-btn[data-correct="true"]');
            if (correctButton) {
                setTimeout(() => {
                    correctButton.classList.add('show-correct');
                }, 500); // Небольшая задержка для мягкого перехода
            }
            this.handleAttempt(selectedOption.text);
        }
    }

    // ========== КЛАВИАТУРНОЕ УПРАВЛЕНИЕ ==========
    
    // Все голосовые функции удалены - используется только клавиатура

    checkAnswerFromButton(selectedOption) {
        // Проверяем выбранный вариант ответа
        if (selectedOption.isCorrect) {
            this.attemptsCount++;
            this.handleCorrectAnswer();
        } else {
            this.attemptsCount++;
            this.handleAttempt(selectedOption.text);
        }
    }

    getSubjectForCounting(image, word) {
        // Определяем предмет для заданий на счёт по эмодзи или слову
        const subjectMap = {
            '🍎': 'яблоко',
            '🍌': 'банан',
            '🍉': 'арбуз',
            '🍒': 'вишня',
            '🍐': 'груша',
            '⚽': 'мячик',
            '🎈': 'шарик',
            '⭐': 'звёздочка',
            '🌸': 'цветочек',
            '🚗': 'машинка',
            '🧱': 'кубик',
            '🍬': 'конфетка'
        };
        
        if (image && subjectMap[image]) {
            return subjectMap[image];
        }
        
        // Если не нашли по эмодзи, используем слово из урока
        return word || 'предмет';
    }

    getSubjectWithEnding(subject, count) {
        // Правильные окончания для русского языка
        if (this.currentLang !== 'ru') return subject;
        
        const endings = {
            'яблоко': { 1: 'яблоко', 2: 'яблока', 3: 'яблока', 4: 'яблока', 5: 'яблок' },
            'банан': { 1: 'банан', 2: 'банана', 3: 'банана', 4: 'банана', 5: 'бананов' },
            'мячик': { 1: 'мячик', 2: 'мячика', 3: 'мячика', 4: 'мячика', 5: 'мячиков' },
            'шарик': { 1: 'шарик', 2: 'шарика', 3: 'шарика', 4: 'шарика', 5: 'шариков' },
            'звёздочка': { 1: 'звёздочка', 2: 'звёздочки', 3: 'звёздочки', 4: 'звёздочки', 5: 'звёздочек' },
            'цветочек': { 1: 'цветочек', 2: 'цветочка', 3: 'цветочка', 4: 'цветочка', 5: 'цветочков' },
            'машинка': { 1: 'машинка', 2: 'машинки', 3: 'машинки', 4: 'машинки', 5: 'машинок' },
            'кубик': { 1: 'кубик', 2: 'кубика', 3: 'кубика', 4: 'кубика', 5: 'кубиков' },
            'конфетка': { 1: 'конфетка', 2: 'конфетки', 3: 'конфетки', 4: 'конфетки', 5: 'конфеток' }
        };
        
        if (endings[subject]) {
            const lastDigit = count % 10;
            if (lastDigit === 1 && count % 100 !== 11) {
                return endings[subject][1];
            } else if (lastDigit >= 2 && lastDigit <= 4 && (count % 100 < 10 || count % 100 >= 20)) {
                return endings[subject][2];
            } else {
                return endings[subject][5];
            }
        }
        
        return subject;
    }

    normalizeAnswer(answer) {
        if (!answer) return '';
        
        // Приводим к нижнему регистру и убираем лишние пробелы
        let normalized = answer.toLowerCase().trim();
        
        // Убираем знаки препинания и специальные символы
        normalized = normalized.replace(/[.,!?;:()\[\]{}'"«»—–-]/g, '');
        
        // Убираем множественные пробелы
        normalized = normalized.replace(/\s+/g, ' ');
        
        // Убираем лишние пробелы в начале и конце
        normalized = normalized.trim();
        
        return normalized;
    }

    // fixCommonRecognitionErrors() удалён - больше не нужен без голосового ввода

    matchAnswer(userAnswer, correctAnswer) {
        if (!userAnswer || !correctAnswer) return false;
        
        // Точное совпадение
        if (userAnswer === correctAnswer) return true;
        
        // Один содержит другой (улучшенная проверка)
        if (userAnswer.includes(correctAnswer) || correctAnswer.includes(userAnswer)) return true;
        
        // Проверяем похожесть по началу слова (более гибко)
        const minLength = Math.min(userAnswer.length, correctAnswer.length);
        if (minLength >= 2) {
            // Проверяем первые 2-4 символа
            for (let len = 4; len >= 2; len--) {
                if (userAnswer.length >= len && correctAnswer.length >= len) {
                    const userStart = userAnswer.substring(0, len);
                    const correctStart = correctAnswer.substring(0, len);
                    if (userStart === correctStart) return true;
                }
            }
        }
        
        // Проверяем окончания слов
        if (minLength >= 2) {
            for (let len = 3; len >= 2; len--) {
                if (userAnswer.length >= len && correctAnswer.length >= len) {
                    const userEnd = userAnswer.substring(userAnswer.length - len);
                    const correctEnd = correctAnswer.substring(correctAnswer.length - len);
                    if (userEnd === correctEnd) return true;
                }
            }
        }
        
        // Фонетическое сопоставление (для похожих звуков)
        if (this.phoneticMatch(userAnswer, correctAnswer)) return true;
        
        // Проверка по расстоянию Левенштейна (для опечаток)
        if (this.levenshteinDistance(userAnswer, correctAnswer) <= 2) return true;
        
        // Для чисел: проверяем, содержит ли ответ число
        const userNumbers = this.extractNumbers(userAnswer);
        const correctNumbers = this.extractNumbers(correctAnswer);
        
        if (userNumbers.length > 0 && correctNumbers.length > 0) {
            // Если есть совпадение чисел
            if (userNumbers.some(n => correctNumbers.includes(n))) {
                return true;
            }
        }
        
        // Проверяем слова-числа
        const userNumberWords = this.extractNumberWords(userAnswer);
        const correctNumberWords = this.extractNumberWords(correctAnswer);
        
        if (userNumberWords.length > 0 && correctNumberWords.length > 0) {
            if (userNumberWords.some(n => correctNumberWords.includes(n))) {
                return true;
            }
        }
        
        // Проверка по частям слова (для неполных ответов)
        const userWords = userAnswer.split(/\s+/);
        const correctWords = correctAnswer.split(/\s+/);
        
        // Если хотя бы одно слово совпадает
        for (const userWord of userWords) {
            for (const correctWord of correctWords) {
                if (userWord.length >= 2 && correctWord.length >= 2) {
                    if (userWord === correctWord || 
                        userWord.includes(correctWord) || 
                        correctWord.includes(userWord) ||
                        this.levenshteinDistance(userWord, correctWord) <= 1) {
                        return true;
                    }
                }
            }
        }
        
        return false;
    }

    phoneticMatch(str1, str2) {
        // Простое фонетическое сопоставление для похожих звуков
        const phoneticMap = {
            ru: {
                'к': ['г', 'х'],
                'г': ['к', 'х'],
                'п': ['б'],
                'б': ['п'],
                'т': ['д'],
                'д': ['т'],
                'с': ['з', 'ц'],
                'з': ['с', 'ц'],
                'ш': ['ж', 'щ', 'ч'],
                'ж': ['ш', 'щ'],
                'щ': ['ш', 'ч'],
                'ч': ['ш', 'щ'],
                'и': ['ы', 'й', 'е'],
                'ы': ['и', 'й'],
                'е': ['э', 'и'],
                'о': ['а'],
                'а': ['о']
            },
            kk: {
                'қ': ['к', 'г'],
                'к': ['қ', 'г'],
                'ғ': ['г'],
                'г': ['ғ']
            }
        };
        
        const map = phoneticMap[this.currentLang] || {};
        
        // Если строки одинаковой длины, проверяем посимвольно
        if (str1.length === str2.length && str1.length <= 10) {
            let differences = 0;
            for (let i = 0; i < str1.length; i++) {
                if (str1[i] !== str2[i]) {
                    // Проверяем, являются ли символы фонетически похожими
                    const similar = map[str1[i]] || [];
                    if (!similar.includes(str2[i])) {
                        differences++;
                        if (differences > 1) return false;
                    }
                }
            }
            return differences <= 1;
        }
        
        return false;
    }

    levenshteinDistance(str1, str2) {
        // Вычисление расстояния Левенштейна для проверки похожести
        const matrix = [];
        const len1 = str1.length;
        const len2 = str2.length;
        
        if (len1 === 0) return len2;
        if (len2 === 0) return len1;
        
        // Инициализация матрицы
        for (let i = 0; i <= len1; i++) {
            matrix[i] = [i];
        }
        for (let j = 0; j <= len2; j++) {
            matrix[0][j] = j;
        }
        
        // Заполнение матрицы
        for (let i = 1; i <= len1; i++) {
            for (let j = 1; j <= len2; j++) {
                if (str1[i - 1] === str2[j - 1]) {
                    matrix[i][j] = matrix[i - 1][j - 1];
                } else {
                    matrix[i][j] = Math.min(
                        matrix[i - 1][j] + 1,     // удаление
                        matrix[i][j - 1] + 1,     // вставка
                        matrix[i - 1][j - 1] + 1  // замена
                    );
                }
            }
        }
        
        return matrix[len1][len2];
    }

    extractNumbers(text) {
        // Извлекаем числа из текста (цифры)
        const matches = text.match(/\d+/g);
        return matches ? matches.map(m => parseInt(m)) : [];
    }

    extractNumberWords(text) {
        // Извлекаем слова-числа из текста (улучшенная версия)
        const numberWordsMap = {
            ru: {
                'один': 1, 'одна': 1, 'одно': 1, 'одиннадцать': 11, 'одиннадцать': 11,
                'два': 2, 'две': 2, 'двадцать': 20, 'двенадцать': 12,
                'три': 3, 'тринадцать': 13, 'тридцать': 30,
                'четыре': 4, 'четырнадцать': 14, 'сорок': 40,
                'пять': 5, 'пятнадцать': 15, 'пятьдесят': 50,
                'шесть': 6, 'шестнадцать': 16, 'шестьдесят': 60,
                'семь': 7, 'семнадцать': 17, 'семьдесят': 70,
                'восемь': 8, 'восемнадцать': 18, 'восемьдесят': 80,
                'девять': 9, 'девятнадцать': 19, 'девяносто': 90,
                'десять': 10, 'сто': 100
            },
            kk: {
                'бір': 1,
                'екі': 2,
                'үш': 3,
                'төрт': 4,
                'бес': 5,
                'алты': 6,
                'жеті': 7,
                'сегіз': 8,
                'тоғыз': 9,
                'он': 10
            }
        };
        
        const words = text.split(/\s+/);
        const numbers = [];
        const map = numberWordsMap[this.currentLang] || {};
        
        words.forEach(word => {
            // Прямое совпадение
            if (map[word]) {
                numbers.push(map[word]);
            } else {
                // Проверяем части слова (для неполных ответов)
                for (const [numWord, numValue] of Object.entries(map)) {
                    if (word.includes(numWord) || numWord.includes(word)) {
                        if (word.length >= 2 && numWord.length >= 2) {
                            numbers.push(numValue);
                            break;
                        }
                    }
                }
            }
        });
        
        return numbers;
    }

    getNumberWords(number) {
        const numberWordsMap = {
            ru: {
                1: ['один', 'одна', 'одно'],
                2: ['два', 'две'],
                3: ['три'],
                4: ['четыре'],
                5: ['пять'],
                6: ['шесть'],
                7: ['семь'],
                8: ['восемь'],
                9: ['девять'],
                10: ['десять']
            },
            kk: {
                1: ['бір'],
                2: ['екі'],
                3: ['үш'],
                4: ['төрт'],
                5: ['бес'],
                6: ['алты'],
                7: ['жеті'],
                8: ['сегіз'],
                9: ['тоғыз'],
                10: ['он']
            }
        };
        
        const map = numberWordsMap[this.currentLang] || {};
        return map[number] || [];
    }

    handleCorrectAnswer() {
        const t = this.getTranslations();
        const praise = t.praises[Math.floor(Math.random() * t.praises.length)];
        
        // Очищаем предыдущий таймер
        if (this.autoNextTimeout) {
            clearTimeout(this.autoNextTimeout);
        }
        
        // ИНКЛЮЗИВНЫЙ ПРИНЦИП: Показываем визуальную обратную связь - всегда позитивную
        const character = document.getElementById('lessonCharacter');
        character.classList.add('celebrate');
        setTimeout(() => character.classList.remove('celebrate'), 1000);
        
        // Показываем сообщение с похвалой
        this.showMessage(praise);
        
        // Инклюзивный принцип: автоматически переходим к следующему тесту через 2 секунды
        this.autoNextTimeout = setTimeout(() => {
            this.goToNextTest();
        }, 2000);
    }

    goToNextTest() {
        // Получаем следующий урок
        const nextLesson = this.getNextLesson();
        
        if (nextLesson) {
            // Переходим к следующему уроку
            const nextLessonKey = `${nextLesson.courseId}_${nextLesson.moduleId}_${nextLesson.id}`;
            window.location.href = `lesson.html?key=${nextLessonKey}`;
        } else {
            // Если уроков больше нет, завершаем
            this.completeLesson();
        }
    }

    getNextLesson() {
        const [courseId, moduleId, lessonId] = this.lessonKey.split('_');
        const allLessons = this.getLessonsData();
        
        // Находим текущий урок
        const currentIndex = allLessons.findIndex(l => 
            l.courseId === courseId && 
            l.moduleId === moduleId && 
            l.id === lessonId
        );
        
        if (currentIndex === -1 || currentIndex === allLessons.length - 1) {
            return null; // Текущий урок не найден или это последний урок
        }
        
        // Возвращаем следующий урок
        return allLessons[currentIndex + 1];
    }

    handleAttempt(userAnswer) {
        const t = this.getTranslations();
        
        // ИНКЛЮЗИВНЫЙ ПРИНЦИП: Никогда не говорим "ошибка", "неправильно", "плохо"
        // ВСЕГДА хвалим за попытку - используем случайную фразу из encouragements или goodAttempt
        const encouragement = t.encouragements && t.encouragements.length > 0
            ? t.encouragements[Math.floor(Math.random() * t.encouragements.length)]
            : t.goodAttempt;
        this.showMessage(encouragement);
        
        // Через 2 секунды после неправильного ответа снова показываем вопрос (не переходим к следующему)
        setTimeout(() => {
            if (this.lessonStep === 1) {
                // Убираем классы с кнопок
                document.querySelectorAll('.answer-option-btn').forEach(btn => {
                    btn.classList.remove('correct', 'incorrect', 'show-correct', 'selected');
                });
                // Сбрасываем выбор
                this.selectedOptionIndex = 0;
                this.selectOption(0);
                
                // Разблокируем кнопки для повторной попытки
                document.querySelectorAll('.answer-option-btn').forEach(btn => {
                    btn.disabled = false;
                    btn.style.pointerEvents = 'auto';
                });
            }
        }, 2000);
        
        // Проверяем, может быть ответ всё-таки правильный, но не распознался
        const normalizedUser = this.normalizeAnswer(userAnswer);
        const { correctAnswer, count, alternatives } = this.lessonData;
        
        // Для заданий на счёт проверяем число отдельно (улучшенная проверка)
        if (count !== undefined) {
            const userNumbers = this.extractNumbers(normalizedUser);
            const userNumberWords = this.extractNumberWords(normalizedUser);
            
            // Если пользователь назвал правильное число (даже с другими словами)
            if (userNumbers.includes(count) || userNumberWords.includes(count)) {
                // Даже если есть дополнительные слова, считаем правильным
                setTimeout(() => {
                    this.handleCorrectAnswer();
                }, 1000);
                return;
            }
            
            // Проверяем все альтернативные варианты чисел
            const allNumberVariants = [
                count.toString(),
                ...this.getNumberWords(count),
                ...(alternatives || []).filter(a => {
                    const num = this.extractNumbers(a);
                    const numWords = this.extractNumberWords(a);
                    return num.includes(count) || numWords.includes(count);
                })
            ];
            
            // Проверяем, содержит ли ответ любое из этих чисел
            for (const variant of allNumberVariants) {
                if (normalizedUser.includes(variant) || this.matchAnswer(normalizedUser, variant)) {
                    setTimeout(() => {
                        this.handleCorrectAnswer();
                    }, 1000);
                    return;
                }
            }
        }
        
        // Проверяем все альтернативные варианты ответов с улучшенным сопоставлением
        const allPossibleAnswers = [correctAnswer, ...(alternatives || [])];
        for (const possibleAnswer of allPossibleAnswers) {
            const normalizedPossible = this.normalizeAnswer(possibleAnswer);
            
            // Используем улучшенное сопоставление
            if (this.matchAnswer(normalizedUser, normalizedPossible)) {
                // Ответ правильный, но не распознался сразу
                setTimeout(() => {
                    this.handleCorrectAnswer();
                }, 1000);
                return;
            }
        }
        
        // После неправильного ответа просто ждём следующей попытки
    }


    completeLesson() {
        this.lessonStep = 2;
        
        // Останавливаем прослушивание
        // Голосовые функции удалены
        
        // Сохраняем прогресс (без баллов, просто факт завершения)
        this.saveProgress();
        
        const t = this.getTranslations();
        
        // Показываем экран завершения
        document.querySelector('.lesson-container-voice').classList.add('hidden');
        document.getElementById('lessonComplete').classList.remove('hidden');
        
        // Озвучиваем завершение
        // Голосовые функции удалены
    }

    saveProgress() {
        if (!this.currentProfile) return;
        
        const progress = JSON.parse(localStorage.getItem(`progress_${this.currentProfile.id}`) || '{}');
        progress[this.lessonKey] = true;
        localStorage.setItem(`progress_${this.currentProfile.id}`, JSON.stringify(progress));
        
        // Уведомляем главную страницу об обновлении прогресса
        window.dispatchEvent(new CustomEvent('progressUpdated', { 
            detail: { profileId: this.currentProfile.id } 
        }));
    }

    // Все голосовые методы (speak, startListening, stopListening) удалены

    // ========== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ==========
    
    // initButtons() удалён - кнопки микрофона больше не нужны

    initKeyboardControls() {
        // Обработка нажатия клавиш для навигации и выбора
        document.addEventListener('keydown', (e) => {
            // Space или Enter на этапе объяснения - переходим к вопросу
            if (this.lessonStep === 0) {
                if (e.key === ' ' || e.key === 'Space' || e.key === 'Enter' || e.key === 'Return' || e.key === 'NumpadEnter') {
                    e.preventDefault();
                    this.showQuestion();
                    return;
                }
            }
            
            // Работаем только на этапе вопроса
            if (this.lessonStep !== 1) return;
            
            const buttons = document.querySelectorAll('.answer-option-btn');
            if (buttons.length === 0) return;
            
            // Навигация вверх/влево
            if (e.key === 'ArrowUp' || e.key === 'ArrowLeft' || 
                e.key === 'w' || e.key === 'W' || e.key === 'a' || e.key === 'A' ||
                e.key === 'ц' || e.key === 'Ц' || e.key === 'ф' || e.key === 'Ф') {
                e.preventDefault();
                this.selectedOptionIndex = (this.selectedOptionIndex - 1 + buttons.length) % buttons.length;
                this.selectOption(this.selectedOptionIndex);
            }
            // Навигация вниз/вправо
            else if (e.key === 'ArrowDown' || e.key === 'ArrowRight' ||
                     e.key === 's' || e.key === 'S' || e.key === 'd' || e.key === 'D' ||
                     e.key === 'ы' || e.key === 'Ы' || e.key === 'в' || e.key === 'В') {
                e.preventDefault();
                this.selectedOptionIndex = (this.selectedOptionIndex + 1) % buttons.length;
                this.selectOption(this.selectedOptionIndex);
            }
            // Цифры 1-4 для прямого выбора варианта (4 варианта)
            else if (e.key >= '1' && e.key <= '4') {
                e.preventDefault();
                const index = parseInt(e.key) - 1;
                if (index < buttons.length) {
                    this.selectOption(index);
                    this.submitAnswer();
                }
            }
            // Цифры на цифровой клавиатуре
            else if (e.key === 'Numpad1' || e.key === 'Numpad2' || e.key === 'Numpad3' || e.key === 'Numpad4') {
                e.preventDefault();
                const index = parseInt(e.key.replace('Numpad', '')) - 1;
                if (index < buttons.length) {
                    this.selectOption(index);
                    this.submitAnswer();
                }
            }
            // Удержание Enter для подтверждения (инклюзивный принцип)
            else if (e.key === 'Enter' || e.key === 'Return' || e.key === 'NumpadEnter') {
                e.preventDefault();
                // Начинаем отсчёт времени удержания
                this.enterHoldStartTime = Date.now();
                this.showEnterHoldProgress(0);
                
                // Проверяем удержание через интервалы
                const checkHold = setInterval(() => {
                    if (!this.enterHoldStartTime) {
                        clearInterval(checkHold);
                        return;
                    }
                    
                    const holdDuration = Date.now() - this.enterHoldStartTime;
                    const progress = Math.min(holdDuration / this.enterHoldDuration, 1);
                    this.showEnterHoldProgress(progress);
                    
                    if (holdDuration >= this.enterHoldDuration) {
                        clearInterval(checkHold);
                        this.enterHoldStartTime = null;
                        this.hideEnterHoldProgress();
                        this.submitAnswer();
                    }
                }, 50);
            }
            // Space для быстрого подтверждения (без удержания)
            else if (e.key === ' ' || e.key === 'Space') {
                e.preventDefault();
                this.submitAnswer();
            }
            // Esc для возврата назад (инклюзивный принцип)
            else if (e.key === 'Escape' || e.key === 'Esc') {
                e.preventDefault();
                window.location.href = 'index.html';
            }
        });
        
        // Обработка отпускания клавиш
        document.addEventListener('keyup', (e) => {
            if (e.key === 'Enter' || e.key === 'Return' || e.key === 'NumpadEnter') {
                // Если отпустили Enter до завершения удержания, отменяем
                if (this.enterHoldStartTime) {
                    this.enterHoldStartTime = null;
                    this.hideEnterHoldProgress();
                }
            }
        });
    }

    showEnterHoldProgress(progress) {
        // Показываем визуальный индикатор удержания Enter
        let indicator = document.getElementById('enterHoldIndicator');
        if (!indicator) {
            indicator = document.createElement('div');
            indicator.id = 'enterHoldIndicator';
            indicator.className = 'enter-hold-indicator';
            document.body.appendChild(indicator);
        }
        
        indicator.style.width = `${progress * 100}%`;
        indicator.style.opacity = progress > 0 ? '1' : '0';
    }

    hideEnterHoldProgress() {
        const indicator = document.getElementById('enterHoldIndicator');
        if (indicator) {
            indicator.style.opacity = '0';
            setTimeout(() => {
                if (indicator && indicator.parentNode) {
                    indicator.parentNode.removeChild(indicator);
                }
            }, 300);
        }
    }

    initNavigation() {
        const backBtn = document.getElementById('backBtn');
        const nextLessonBtn = document.getElementById('nextLessonBtn');
        const backToModulesBtn = document.getElementById('backToModulesBtn');
        
        // Клик мышью
        backBtn.addEventListener('click', () => {
            window.location.href = 'index.html';
        });

        nextLessonBtn.addEventListener('click', () => {
            window.location.href = 'index.html';
        });

        backToModulesBtn.addEventListener('click', () => {
            window.location.href = 'index.html';
        });
        
        // Поддержка всех клавиш для всех кнопок навигации
        [backBtn, nextLessonBtn, backToModulesBtn].forEach(btn => {
            btn.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || 
                    e.key === ' ' || 
                    e.key === 'Space' || 
                    e.key === 'Tab' ||
                    e.key === 'Return' ||
                    e.key === 'NumpadEnter') {
                    e.preventDefault();
                    btn.click();
                    btn.classList.add('keyboard-activated');
                    setTimeout(() => {
                        btn.classList.remove('keyboard-activated');
                    }, 200);
                }
            });
        });
    }

    updateLanguage() {
        document.querySelectorAll('[data-lang-ru]').forEach(el => {
            const ruText = el.dataset.langRu;
            const kkText = el.dataset.langKk;
            el.textContent = this.currentLang === 'ru' ? ruText : kkText;
        });
    }

    updateStatus(status) {
        const dot = document.getElementById('statusDot');
        const textEl = document.getElementById('statusText');
        const t = this.getTranslations();
        
        dot.className = 'status-dot ' + status;
        
        if (status === 'listening') {
            textEl.textContent = t.statusListening;
        } else if (status === 'speaking') {
            textEl.textContent = t.statusSpeaking;
        } else {
            textEl.textContent = t.statusReady;
        }
    }

    showWaveAnimation(show) {
        const waveEl = document.getElementById('visualFeedback');
        if (show) {
            waveEl.classList.add('active');
        } else {
            waveEl.classList.remove('active');
        }
    }

    showMessage(text) {
        const messageEl = document.getElementById('messageContent');
        messageEl.textContent = text;
        document.getElementById('tutorMessage').classList.remove('hidden');
        
        setTimeout(() => {
            document.getElementById('tutorMessage').classList.add('hidden');
        }, 5000);
    }

    fuzzyMatch(str1, str2) {
        if (!str1 || !str2) return false;
        const s1 = str1.toLowerCase().substring(0, Math.min(3, str1.length));
        const s2 = str2.toLowerCase().substring(0, Math.min(3, str2.length));
        return s1 === s2;
    }

    isSimilarAnswer(userAnswer, correctAnswer) {
        if (!userAnswer || !correctAnswer) return false;
        const userStart = userAnswer.toLowerCase().substring(0, Math.min(2, userAnswer.length));
        const correctStart = correctAnswer.toLowerCase().substring(0, Math.min(2, correctAnswer.length));
        return userStart === correctStart;
    }

    loadSettings() {
        const saved = localStorage.getItem('appSettings');
        return saved ? JSON.parse(saved) : { lessonSpeed: 0.85 };
    }

    getTranslations() {
        return {
            ru: {
                statusReady: 'Готов слушать',
                statusListening: 'Слушаю тебя...',
                statusSpeaking: 'Говорю...',
                readyForQuestion: 'Скажи "дальше", когда будешь готов ответить на вопрос.',
                sayNextToStart: 'Скажи "дальше", чтобы начать.',
                greeting: 'Привет! Я твой помощник. Давай начнём урок.',
                goodAttempt: 'Хорошая попытка! Ты стараешься, это важно. Попробуй ещё раз.',
                clarify: 'Ты имел в виду',
                clarifyQuestion: 'Скажи "да" или "нет".',
                hintPrefix: 'Подсказка:',
                breakMessage: 'Хорошо, делаем паузу. Отдохни. Когда будешь готов, скажи "дальше".',
                completeMessage: 'Ты справился! Ты попробовал и у тебя получилось! Молодец!',
                praises: [
                    'Отлично! Ты справился!',
                    'Молодец! Ты попробовал и у тебя получилось!',
                    'Здорово! Ты всё понял!',
                    'Верно! Ты умница!',
                    'Правильно! Ты хорошо подумал!',
                    'Ты стараешься, это важно!',
                    'Ты справляешься!',
                    'Супер! У тебя отлично получается!',
                    'Замечательно! Ты молодец!',
                    'Великолепно! Ты всё делаешь правильно!',
                    'Превосходно! Ты очень стараешься!',
                    'Умница! Ты всё понимаешь!',
                    'Браво! Ты справляешься отлично!',
                    'Замечательная работа! Ты большой молодец!',
                    'Ты делаешь это так хорошо!',
                    'Я горжусь тобой! Ты стараешься!',
                    'Ты умный и внимательный!',
                    'Ты всё запоминаешь правильно!',
                    'Ты учишься так хорошо!',
                    'Ты настоящий умница!',
                    'Ты справляешься лучше с каждым разом!',
                    'Ты очень способный!',
                    'Ты внимательно слушаешь!',
                    'Ты правильно отвечаешь!',
                    'Ты делаешь большие успехи!',
                    'Ты понимаешь всё правильно!',
                    'Ты очень хорошо стараешься!',
                    'Ты молодец, продолжай!',
                    'Ты всё делаешь верно!',
                    'Ты отлично справляешься!'
                ],
                encouragements: [
                    'Не спеши, у тебя всё получится!',
                    'Ты можешь это сделать!',
                    'Попробуй ещё раз, я верю в тебя!',
                    'Ты справишься, я знаю!',
                    'Не волнуйся, всё хорошо!',
                    'Ты делаешь правильно, продолжай!',
                    'Я здесь, чтобы помочь тебе!',
                    'Ты учишься, и это главное!',
                    'Каждая попытка важна!',
                    'Ты становишься лучше с каждым разом!',
                    'Не бойся ошибиться, мы учимся вместе!',
                    'Ты очень стараешься, это видно!',
                    'У тебя всё получится, просто попробуй!',
                    'Я горжусь тем, как ты стараешься!',
                    'Ты делаешь отличную работу!',
                    'Продолжай в том же духе!',
                    'Ты на правильном пути!',
                    'Ты справляешься лучше, чем думаешь!',
                    'Ты умный и способный!',
                    'Я вижу, как ты стараешься!'
                ],
                greetings: [
                    'Привет! Я твой помощник. Давай начнём урок.',
                    'Здравствуй! Я рад тебя видеть. Готов начать?',
                    'Привет, друг! Давай вместе учиться.',
                    'Здравствуй! Сегодня мы узнаем что-то новое.',
                    'Привет! Я здесь, чтобы помочь тебе учиться.',
                    'Здравствуй! Готов к новому уроку?',
                    'Привет! Давай начнём наше приключение в обучении.',
                    'Здравствуй! Я твой учитель. Давай начнём!',
                    'Привет! Сегодня будет интересно!',
                    'Здравствуй! Я рад помочь тебе учиться.'
                ],
                hints: [
                    'Подумай внимательно, ты знаешь ответ!',
                    'Посмотри на картинку, она подскажет тебе.',
                    'Вспомни, что мы только что изучали.',
                    'Попробуй произнести слово вслух.',
                    'Не спеши, у тебя есть время подумать.',
                    'Помни, что мы учили об этом.',
                    'Послушай внимательно, я повторю.',
                    'Ты можешь попросить меня повторить.',
                    'Попробуй ещё раз, я помогу тебе.',
                    'Не волнуйся, мы разберёмся вместе.'
                ]
            },
            kk: {
                statusReady: 'Тыңдауға дайын',
                statusListening: 'Сені тыңдап жатырмын...',
                statusSpeaking: 'Айтып жатырмын...',
                readyForQuestion: 'Сұраққа жауап беруге дайын болғанда "келесі" деп айт.',
                sayNextToStart: 'Бастау үшін "келесі" деп айт.',
                greeting: 'Сәлем! Мен сенің көмекшің. Сабақты бастайық.',
                goodAttempt: 'Жақсы тырысу! Сен тырысып жатырсың, бұл маңызды. Тағы көріп көш.',
                clarify: 'Сен дегенің',
                clarifyQuestion: '"Иә" немесе "жоқ" деп айт.',
                hintPrefix: 'Кеңес:',
                breakMessage: 'Жақсы, кідіріс жасаймыз. Демал. Дайын болғанда "келесі" деп айт.',
                completeMessage: 'Сен тапсырдың! Сен тырыстың және сің таптың! Жақсы!',
                praises: [
                    'Керемет! Сен тапсырдың!',
                    'Жақсы! Сен тырыстың және сің таптың!',
                    'Керемет! Сен бәрін түсіндің!',
                    'Дұрыс! Сен ақылдысың!',
                    'Дұрыс! Сен жақсы ойладың!',
                    'Сен тырысып жатырсың, бұл маңызды!',
                    'Сен тапсырып жатырсың!',
                    'Керемет! Сен тамаша жасап жатырсың!',
                    'Жақсы! Сен керемет!',
                    'Тамаша! Сен бәрін дұрыс жасап жатырсың!',
                    'Керемет! Сен өте тырысып жатырсың!',
                    'Ақылды! Сен бәрін түсінесің!',
                    'Браво! Сен тамаша жасап жатырсың!',
                    'Жақсы жұмыс! Сен үлкен ақылды!',
                    'Сен мұны өте жақсы жасап жатырсың!',
                    'Мен сенімен мақтанамын! Сен тырысып жатырсың!',
                    'Сен ақылды және назар аударасың!',
                    'Сен бәрін дұрыс есте сақтайсың!',
                    'Сен өте жақсы оқып жатырсың!',
                    'Сен шынайы ақылды!',
                    'Сен әр уақытта жақсарақ боласың!',
                    'Сен өте қабілетті!',
                    'Сен мұқият тыңдап жатырсың!',
                    'Сен дұрыс жауап бересің!',
                    'Сен үлкен жетістіктерге қол жеткізіп жатырсың!',
                    'Сен бәрін дұрыс түсінесің!',
                    'Сен өте жақсы тырысып жатырсың!',
                    'Сен ақылды, жалғастыр!',
                    'Сен бәрін дұрыс жасап жатырсың!',
                    'Сен тамаша жасап жатырсың!'
                ],
                encouragements: [
                    'Асықпа, сен бәрін жасай аласың!',
                    'Сен мұны жасай аласың!',
                    'Тағы көріп көш, мен саған сенемін!',
                    'Сен тапсырасың, мен білемін!',
                    'Алаңдама, бәрі жақсы!',
                    'Сен дұрыс жасап жатырсың, жалғастыр!',
                    'Мен мұнда саған көмектесу үшін!',
                    'Сен оқып жатырсың, бұл негізгі!',
                    'Әр әрекет маңызды!',
                    'Сен әр уақытта жақсарақ боласың!',
                    'Қателесудан қорықпа, біз бірге оқып жатырмыз!',
                    'Сен өте тырысып жатырсың, бұл көрінеді!',
                    'Сен бәрін жасай аласың, тек көріп көш!',
                    'Мен сенің қалай тырысып жатқаныңмен мақтанамын!',
                    'Сен тамаша жұмыс істеп жатырсың!',
                    'Сол сияқты жалғастыр!',
                    'Сен дұрыс жолдасың!',
                    'Сен ойлағаннан жақсырақ жасап жатырсың!',
                    'Сен ақылды және қабілетті!',
                    'Мен сенің қалай тырысып жатқаныңды көріп жатырмын!'
                ],
                greetings: [
                    'Сәлем! Мен сенің көмекшің. Сабақты бастайық.',
                    'Сәлеметсіз бе! Мен сені көргеніме қуаныштымын. Бастауға дайынсың ба?',
                    'Сәлем, дос! Бірге оқып көрейік.',
                    'Сәлеметсіз бе! Бүгін біз жаңа нәрселерді білеміз.',
                    'Сәлем! Мен мұнда саған оқуға көмектесу үшін.',
                    'Сәлеметсіз бе! Жаңа сабаққа дайынсың ба?',
                    'Сәлем! Біздің оқу саяхатымызды бастайық.',
                    'Сәлеметсіз бе! Мен сенің мұғалімің. Бастайық!',
                    'Сәлем! Бүгін қызықты болады!',
                    'Сәлеметсіз бе! Мен саған оқуға көмектесуге қуаныштымын.'
                ],
                hints: [
                    'Мұқият ойла, сен жауапты білесің!',
                    'Суретке қара, ол саған көмектеседі.',
                    'Біздің жаңа оқығанымызды еске ал.',
                    'Сөзді дауыстап айтып көр.',
                    'Асықпа, ойлануға уақытың бар.',
                    'Біз бұл туралы оқығанымызды еске ал.',
                    'Мұқият тыңда, мен қайталаймын.',
                    'Сен маған қайталауды сұрай аласың.',
                    'Тағы көріп көш, мен саған көмектесемін.',
                    'Алаңдама, біз бірге түсінеміз.'
                ]
            }
        }[this.currentLang];
    }
}

// Инициализация
let tutorInstance = null;

document.addEventListener('DOMContentLoaded', () => {
    new KeyboardLesson();
});
