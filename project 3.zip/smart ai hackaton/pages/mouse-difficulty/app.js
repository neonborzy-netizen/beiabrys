// Основной файл приложения - система обучения в стиле Duolingo
// Для детей с моторными нарушениями (5-9 лет)

// Класс для голосового управления сайтом
class VoiceNavigation {
    constructor(app) {
        this.app = app;
        this.recognition = null;
        this.isListening = false;
        this.isActive = false;
        
        this.init();
    }

    init() {
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            return;
        }

        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        this.recognition = new SpeechRecognition();
        this.recognition.lang = this.app.currentLang === 'ru' ? 'ru-RU' : 'kk-KZ';
        this.recognition.continuous = true;
        this.recognition.interimResults = true;
        this.recognition.maxAlternatives = 3;

        this.recognition.onresult = (event) => {
            const results = event.results;
            if (!results.length) return;
            const last = results[results.length - 1];
            const transcript = (last[0] && last[0].transcript) ? last[0].transcript.toLowerCase().trim() : '';
            if (!transcript) return;
            if (last.isFinal) {
                this.handleCommand(transcript);
            }
        };

        this.recognition.onerror = (event) => {
            if (event.error === 'no-speech') {
                return;
            } else if (event.error === 'not-allowed') {
                this.stop();
                this.showMicError();
            }
        };

        this.recognition.onend = () => {
            if (!this.isActive) return;
            // На file:// не перезапускаем — иначе браузер бесконечно спрашивает разрешение или ломается
            if (window.location.protocol === 'file:') return;
            setTimeout(() => {
                if (this.isActive && this.recognition) {
                    try {
                        this.recognition.start();
                        this.isListening = true;
                    } catch (e) {
                        console.log('Ошибка перезапуска распознавания:', e);
                    }
                }
            }, 150);
        };
    }

    /** Запрашивает доступ к микрофону (нужно для работы SpeechRecognition в большинстве браузеров). */
    requestMicPermission() {
        return new Promise((resolve) => {
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                resolve(true);
                return;
            }
            navigator.mediaDevices.getUserMedia({ audio: true })
                .then((stream) => {
                    stream.getTracks().forEach((t) => t.stop());
                    resolve(true);
                })
                .catch(() => resolve(false));
        });
    }

    start() {
        if (!this.recognition) return;
        if (this._startPending) return; // защита от двойного вызова пока запрашиваем микрофон
        this.isActive = true;
        if (this.isListening) return;

        this._startPending = true;
        const doStart = () => {
            this._startPending = false;
            try {
                this.recognition.start();
                this.isListening = true;
                this.showVoiceIndicator(true);
            } catch (e) {
                console.log('Ошибка запуска распознавания:', e);
                this.showMicError();
            }
        };

        this.requestMicPermission().then((granted) => {
            this._startPending = false;
            if (granted) {
                doStart();
            } else {
                this.showMicError();
            }
        });
    }

    showMicError() {
        const msg = this.app.currentLang === 'ru'
            ? 'Нет доступа к микрофону. Разрешите доступ в настройках браузера или нажмите «Проверить микрофон» в настройках.'
            : 'Микрофонға қол жеткізу жоқ. Браузер параметрлерінде рұқсат беріңіз.';
        if (window.VoiceUI && window.VoiceUI.showIndicator) {
            window.VoiceUI.showIndicator(msg);
            setTimeout(() => window.VoiceUI?.hideIndicator?.(), 5000);
        }
    }

    stop() {
        this.isActive = false;
        this.isListening = false;
        if (this.recognition) {
            try {
                this.recognition.stop();
            } catch (e) {
                // Игнорируем ошибки при остановке
            }
        }
        this.showVoiceIndicator(false);
    }

    showVoiceIndicator(show) {
        let indicator = document.getElementById('voiceNavIndicator');
        if (!indicator && show) {
            indicator = document.createElement('div');
            indicator.id = 'voiceNavIndicator';
            indicator.innerHTML = '🎤 <span data-lang-ru="Голосовое управление активно" data-lang-kk="Дауыстық басқару белсенді">Голосовое управление активно</span>';
            indicator.style.cssText = `
                position: fixed;
                top: 80px;
                right: 20px;
                background: #4CAF50;
                color: white;
                padding: 12px 20px;
                border-radius: 8px;
                font-size: 14px;
                z-index: 10000;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                animation: pulse 2s infinite;
            `;
            document.body.appendChild(indicator);
        } else if (indicator && !show) {
            indicator.remove();
        }
    }

    handleCommand(transcript) {
        const t = (transcript || '').toLowerCase().trim();

        // Экран выбора профиля: по имени или «профиль 1», «профиль 2», «1», «2»
        const profileSection = document.getElementById('profileSection');
        if (profileSection && !profileSection.classList.contains('hidden')) {
            const profiles = JSON.parse(localStorage.getItem('profiles') || '[]');
            for (const profile of profiles) {
                const name = (profile.name || '').toLowerCase().trim();
                if (!name) continue;
                const saySelect = t.includes('выбрать') || t.includes('выбери') || t.includes('таңдау') || t.includes('таңда');
                const nameMatch = t === name || t.endsWith(' ' + name) || t.startsWith(name + ' ') || t.includes(' ' + name + ' ') || (saySelect && t.includes(name));
                if (nameMatch) {
                    this.app.selectProfile(profile.id);
                    this.speakFeedback(this.app.currentLang === 'ru' ? `Выбран профиль ${profile.name}` : `${profile.name} профилі таңдалды`);
                    return;
                }
                if (name.length >= 2 && t.includes(name)) {
                    this.app.selectProfile(profile.id);
                    this.speakFeedback(this.app.currentLang === 'ru' ? `Выбран профиль ${profile.name}` : `${profile.name} профилі таңдалды`);
                    return;
                }
            }
            // «профиль 1», «профил 1», «профиль один», или просто «1», «2», «один», «два»
            const profileNumKeywords = ['профиль', 'профил', 'профили', 'профильді', 'профил'];
            const num = this.extractNumberFromTranscript(transcript, this.app.currentLang);
            const isProfileNum = profileNumKeywords.some(kw => t.includes(kw)) && num != null;
            const isShortNum = /^(один|два|три|четыре|пять|шесть|семь|восемь|девять|десять|первый|второй|третий|1|2|3|4|5|6|7|8|9|10|бір|екі|үш|төрт|бес)$/.test(t.replace(/\s+/g, ' '));
            if ((isProfileNum || isShortNum) && num != null && num >= 1) {
                this.selectProfileByNumber(num);
                return;
            }
        }

        // Экран курсов: «вариант 4», «4», «для детей с моторными нарушениями» — открыть упражнения с мышью
        const coursesSection = document.getElementById('coursesSection');
        if (coursesSection && !coursesSection.classList.contains('hidden') && this.app.openMotorExercises) {
            const motorKeywords = [
                'для детей с моторными нарушениями', 'моторными нарушениями', 'моторные нарушения', 'моторных нарушений',
                'упражнения с мышью', 'упражнения мышью', 'открыть упражнения', 'мышь', 'мышью',
                'моторлық бұзылыстары', 'жаттығулар', 'тышқанмен'
            ];
            const num = this.extractNumberFromTranscript(transcript, this.app.currentLang);
            const isVariant4 = num === 4 && (t.includes('вариант') || /^(4|четыре|четвёртый|төрт|төртінші)$/.test(t.replace(/\s+/g, ' ')));
            if (motorKeywords.some(kw => t.includes(kw)) || isVariant4) {
                this.speakFeedback(this.app.currentLang === 'ru' ? 'Открываю упражнения с мышью' : 'Тышқанмен жаттығуларды ашып жатырмын');
                this.app.openMotorExercises();
                return;
            }
        }

        // Полное голосовое управление: каждая мелочь — через VoiceUI (force: true)
        if (window.VoiceUI && window.VoiceUI.handleTranscript(transcript, true)) {
            return;
        }

        const lang = this.app.currentLang;
        const commands = this.getCommands(lang);
        
        // Сначала проверяем команды с числами (профиль один, вариант два и т.д.)
        const numberMatch = this.extractNumberFromTranscript(transcript, lang);
        if (numberMatch !== null) {
            // Проверяем команды с числами
            if (this.handleNumberedCommand(transcript, numberMatch, lang)) {
                return;
            }
        }
        
        // Проверяем обычные команды
        for (const [action, keywords] of Object.entries(commands)) {
            if (keywords.some(keyword => transcript.includes(keyword))) {
                this.executeCommand(action);
                return;
            }
        }
    }
    
    extractNumberFromTranscript(transcript, lang) {
        const text = (transcript || '').toLowerCase().trim();
        const numberWords = lang === 'ru'
            ? {
                'десятый': 10, 'девятый': 9, 'восьмой': 8, 'седьмой': 7, 'шестой': 6, 'пятый': 5,
                'четвёртый': 4, 'четвертый': 4, 'третий': 3, 'второй': 2, 'первый': 1,
                'десять': 10, 'девять': 9, 'восемь': 8, 'семь': 7, 'шесть': 6, 'пять': 5,
                'четыре': 4, 'три': 3, 'два': 2, 'один': 1, 'одна': 1, 'одно': 1
            }
            : {
                'оныншы': 10, 'тоғызыншы': 9, 'сегізинші': 8, 'жетінші': 7, 'алтыншы': 6, 'бесінші': 5,
                'төртінші': 4, 'үшінші': 3, 'екінші': 2, 'бірінші': 1,
                'он': 10, 'тоғыз': 9, 'сегіз': 8, 'жеті': 7, 'алты': 6, 'бес': 5,
                'төрт': 4, 'үш': 3, 'екі': 2, 'бір': 1
            };
        for (const [word, num] of Object.entries(numberWords)) {
            if (text.includes(word)) return num;
        }
        const digitMatch = text.match(/\b([1-9]|10)\b/);
        if (digitMatch) return parseInt(digitMatch[1], 10);
        return null;
    }
    
    handleNumberedCommand(transcript, number, lang) {
        // Команды для выбора профиля («профиль 1», «профиль один», «профил 2» и т.д.)
        const profileKeywords = lang === 'ru' 
            ? ['профиль', 'профил', 'выбери профиль', 'открой профиль', 'профиль один', 'профиль два', 'профиль 1', 'профиль 2']
            : ['профиль', 'профил', 'профильді таңдау', 'профиль бір', 'профиль екі'];
        
        if (profileKeywords.some(kw => transcript.toLowerCase().includes(kw))) {
            this.selectProfileByNumber(number);
            return true;
        }
        
        // Команды для выбора курса
        const courseKeywords = lang === 'ru'
            ? ['курс', 'выбери курс', 'открой курс', 'курс один', 'курс два', 'первый курс', 'второй курс', 'третий курс']
            : ['курс', 'курсты таңдау', 'бірінші курс', 'екінші курс'];
        
        if (courseKeywords.some(kw => transcript.toLowerCase().includes(kw))) {
            this.selectCourseByNumber(number);
            return true;
        }
        
        // Команды для выбора модуля
        const moduleKeywords = lang === 'ru'
            ? ['модуль', 'выбери модуль', 'открой модуль']
            : ['модуль', 'модульді таңдау'];
        
        if (moduleKeywords.some(kw => transcript.includes(kw))) {
            this.selectModuleByNumber(number);
            return true;
        }
        
        // Команды для выбора урока
        const lessonKeywords = lang === 'ru'
            ? ['урок', 'выбери урок', 'открой урок', 'начать урок', 'урок один', 'урок два', 'первый урок', 'второй урок', 'начать']
            : ['сабақ', 'сабақты таңдау', 'сабақты бастау', 'бірінші сабақ', 'екінші сабақ'];
        
        if (lessonKeywords.some(kw => transcript.toLowerCase().includes(kw))) {
            this.selectLessonByNumber(number);
            return true;
        }
        
        return false;
    }
    
    selectProfileByNumber(number) {
        const profiles = JSON.parse(localStorage.getItem('profiles') || '[]');
        if (profiles.length === 0) {
            this.speakFeedback(this.app.currentLang === 'ru' ? 'Нет созданных профилей' : 'Профильдер жоқ');
            return;
        }
        
        const index = number - 1;
        if (index >= 0 && index < profiles.length) {
            const profile = profiles[index];
            this.app.selectProfile(profile.id);
            this.speakFeedback(
                this.app.currentLang === 'ru' 
                    ? `Выбран профиль ${profile.name}` 
                    : `${profile.name} профилі таңдалды`
            );
        } else {
            this.speakFeedback(
                this.app.currentLang === 'ru'
                    ? `Профиль номер ${number} не найден. Доступно профилей: ${profiles.length}`
                    : `${number} профилі табылмады. Қолжетімді профильдер: ${profiles.length}`
            );
        }
    }
    
    selectCourseByNumber(number) {
        if (!this.app.currentProfile) {
            this.speakFeedback(this.app.currentLang === 'ru' ? 'Сначала выберите профиль' : 'Алдымен профильді таңдаңыз');
            return;
        }
        
        const courses = this.app.courses[this.app.currentLang] || [];
        const index = number - 1;
        if (index >= 0 && index < courses.length) {
            const course = courses[index];
            this.app.selectCourse(course.id);
            this.speakFeedback(
                this.app.currentLang === 'ru'
                    ? `Открываю курс ${course.title}`
                    : `${course.title} курсын ашып жатырмын`
            );
        } else {
            this.speakFeedback(
                this.app.currentLang === 'ru'
                    ? `Курс номер ${number} не найден`
                    : `${number} курсы табылмады`
            );
        }
    }
    
    selectModuleByNumber(number) {
        if (!this.app.currentCourse) {
            this.speakFeedback(this.app.currentLang === 'ru' ? 'Сначала выберите курс' : 'Алдымен курсты таңдаңыз');
            return;
        }
        
        const modules = this.app.currentCourse.modules || [];
        const index = number - 1;
        if (index >= 0 && index < modules.length) {
            const module = modules[index];
            // Находим первый урок в модуле и начинаем его
            if (module.lessons && module.lessons.length > 0) {
                const lesson = module.lessons[0];
                const lessonKey = `${this.app.currentCourse.id}_${module.id}_${lesson.id}`;
                this.app.startLesson(lessonKey);
            }
        }
    }
    
    selectLessonByNumber(number) {
        if (!this.app.currentCourse) {
            this.speakFeedback(this.app.currentLang === 'ru' ? 'Сначала выберите курс' : 'Алдымен курсты таңдаңыз');
            return;
        }
        
        // Находим урок по номеру во всех модулях текущего курса
        let lessonIndex = 0;
        for (const module of this.app.currentCourse.modules || []) {
            for (const lesson of module.lessons || []) {
                lessonIndex++;
                if (lessonIndex === number) {
                    const lessonKey = `${this.app.currentCourse.id}_${module.id}_${lesson.id}`;
                    this.app.startLesson(lessonKey);
                    this.speakFeedback(
                        this.app.currentLang === 'ru'
                            ? `Начинаю урок ${lesson.title}`
                            : `${lesson.title} сабағын бастап жатырмын`
                    );
                    return;
                }
            }
        }
        
        this.speakFeedback(
            this.app.currentLang === 'ru'
                ? `Урок номер ${number} не найден`
                : `${number} сабақ табылмады`
        );
    }

    getCommands(lang) {
        if (lang === 'ru') {
            return {
                'openSettings': ['настройки', 'настройка', 'открой настройки', 'зайди в настройки', 'открыть настройки'],
                'closeSettings': ['закрой настройки', 'закрыть настройки', 'выйти из настроек'],
                'openParent': ['родительский кабинет', 'родительский', 'кабинет родителей', 'открой родительский'],
                'closeParent': ['закрой родительский', 'закрыть родительский'],
                'back': ['назад', 'вернись назад', 'вернуться назад', 'кнопка назад'],
                'startLearning': ['начать обучение', 'начать', 'начни обучение', 'старт'],
                'selectReading': ['чтение', 'выбери чтение', 'курс чтение', 'открой чтение'],
                'selectMath': ['математика', 'выбери математику', 'курс математика', 'открой математику'],
                'selectLogic': ['логика', 'выбери логику', 'курс логика', 'открой логику'],
                'openMotor': ['упражнения с мышью', 'моторные', 'мышь', 'открой упражнения с мышью', 'упражнения для детей с моторными', 'мышка'],
                'selectProfile': ['профиль', 'выбери профиль', 'открой профиль', 'профили'],
                'createProfile': ['создать профиль', 'новый профиль', 'добавить профиль'],
                'switchLanguageRu': ['русский', 'переключи на русский', 'русский язык'],
                'switchLanguageKk': ['казахский', 'казахский язык', 'переключи на казахский', 'қазақша'],
                'help': ['помощь', 'помоги', 'что можно сказать', 'команды'],
                'readCurrentScreen': ['что на экране', 'прочитай экран', 'что видно', 'что здесь'],
                'readOptions': ['какие варианты', 'прочитай варианты', 'что можно выбрать'],
                'home': ['главная', 'домой', 'на главную', 'главный экран']
            };
        } else {
            return {
                'openSettings': ['параметрлер', 'параметр', 'параметрлерді ашу', 'параметрлерге кіру'],
                'closeSettings': ['параметрлерді жабу', 'параметрлерден шығу'],
                'openParent': ['ата-ана кабинеті', 'ата-ана', 'ата-ана кабинетін ашу'],
                'closeParent': ['ата-ана кабинетін жабу'],
                'back': ['артқа', 'артқа оралу', 'артқа бару'],
                'startLearning': ['оқуды бастау', 'бастау', 'оқу'],
                'selectReading': ['оқу', 'оқуды таңдау', 'оқу курсы'],
                'selectMath': ['математика', 'математиканы таңдау', 'математика курсы'],
                'selectLogic': ['логика', 'логиканы таңдау', 'логика курсы'],
                'openMotor': ['тышқанмен жаттығулар', 'моторлық', 'тышқан', 'моторлық бұзылыстары бар балаларға'],
                'selectProfile': ['профиль', 'профильді таңдау', 'профильдер'],
                'createProfile': ['профиль құру', 'жаңа профиль', 'профиль қосу'],
                'switchLanguageRu': ['орысша', 'орыс тіліне ауысу'],
                'switchLanguageKk': ['қазақша', 'қазақ тіліне ауысу'],
                'help': ['көмек', 'көмектес', 'не айтуға болады', 'командалар'],
                'readCurrentScreen': ['экранда не бар', 'экранды оқу', 'не көрінеді'],
                'readOptions': ['қандай нұсқалар', 'нұсқаларды оқу', 'не таңдауға болады'],
                'home': ['басты', 'үйге', 'басты экран', 'басты бет']
            };
        }
    }

    executeCommand(action) {
        const app = this.app;
        
        switch (action) {
            case 'openSettings':
                document.getElementById('settingsModal').classList.remove('hidden');
                this.speakFeedback(app.currentLang === 'ru' ? 'Открываю настройки' : 'Параметрлерді ашып жатырмын');
                break;
                
            case 'closeSettings':
                document.getElementById('settingsModal').classList.add('hidden');
                this.speakFeedback(app.currentLang === 'ru' ? 'Закрываю настройки' : 'Параметрлерді жабып жатырмын');
                break;
                
            case 'openParent':
                document.getElementById('parentModal').classList.remove('hidden');
                app.renderParentDashboard();
                this.speakFeedback(app.currentLang === 'ru' ? 'Открываю родительский кабинет' : 'Ата-ана кабинетін ашып жатырмын');
                break;
                
            case 'closeParent':
                document.getElementById('parentModal').classList.add('hidden');
                this.speakFeedback(app.currentLang === 'ru' ? 'Закрываю родительский кабинет' : 'Ата-ана кабинетін жабып жатырмын');
                break;
                
            case 'back':
                // Определяем, на каком экране мы находимся
                if (!document.getElementById('modulesSection').classList.contains('hidden')) {
                    // На экране модулей - возвращаемся к курсам
                    document.getElementById('modulesSection').classList.add('hidden');
                    document.getElementById('coursesSection').classList.remove('hidden');
                    this.speakFeedback(app.currentLang === 'ru' ? 'Возвращаюсь к курсам' : 'Курстарға оралу');
                } else if (!document.getElementById('coursesSection').classList.contains('hidden')) {
                    // На экране курсов - возвращаемся к профилям
                    document.getElementById('coursesSection').classList.add('hidden');
                    document.getElementById('profileSection').classList.remove('hidden');
                    this.speakFeedback(app.currentLang === 'ru' ? 'Возвращаюсь к профилям' : 'Профильдерге оралу');
                } else if (!document.getElementById('accessibilitySection').classList.contains('hidden')) {
                    // На экране доступности - ничего не делаем
                    this.speakFeedback(app.currentLang === 'ru' ? 'Вы уже на главном экране' : 'Сіз қазір басты экрандасыз');
                }
                break;
            case 'home':
                // Независимо от текущего экрана возвращаем на главную страницу с выбором опций
                ['profileSection','coursesSection','modulesSection'].forEach(id => {
                    const el = document.getElementById(id);
                    if (el) el.classList.add('hidden');
                });
                const acc = document.getElementById('accessibilitySection');
                if (acc) acc.classList.remove('hidden');
                this.speakFeedback(app.currentLang === 'ru' ? 'Возвращаюсь на главный экран' : 'Басты экранға оралу');
                break;
                
            case 'startLearning':
                const startBtn = document.getElementById('startLearningBtn');
                if (startBtn && !startBtn.disabled) {
                    startBtn.click();
                    this.speakFeedback(app.currentLang === 'ru' ? 'Начинаю обучение' : 'Оқуды бастау');
                }
                break;
                
            case 'selectReading':
                if (app.currentProfile) {
                    app.selectCourse('reading');
                    this.speakFeedback(app.currentLang === 'ru' ? 'Открываю курс чтение' : 'Оқу курсын ашып жатырмын');
                }
                break;
                
            case 'selectMath':
                if (app.currentProfile) {
                    app.selectCourse('math');
                    this.speakFeedback(app.currentLang === 'ru' ? 'Открываю курс математика' : 'Математика курсын ашып жатырмын');
                }
                break;
                
            case 'selectLogic':
                if (app.currentProfile) {
                    app.selectCourse('logic');
                    this.speakFeedback(app.currentLang === 'ru' ? 'Открываю курс логика' : 'Логика курсын ашып жатырмын');
                }
                break;

            case 'openMotor':
                if (app.currentProfile) {
                    app.openMotorExercises();
                    this.speakFeedback(app.currentLang === 'ru' ? 'Открываю упражнения с мышью' : 'Тышқанмен жаттығуларды ашып жатырмын');
                }
                break;
                
            case 'selectProfile':
                app.showProfileScreen();
                this.speakFeedback(app.currentLang === 'ru' ? 'Открываю выбор профиля' : 'Профиль таңдау экранын ашып жатырмын');
                break;
                
            case 'createProfile':
                document.getElementById('profileModal').classList.remove('hidden');
                this.speakFeedback(app.currentLang === 'ru' ? 'Открываю создание профиля' : 'Профиль құру экранын ашып жатырмын');
                break;
                
            case 'switchLanguageRu':
                if (app.currentLang !== 'ru') {
                    app.switchLanguage('ru');
                    this.speakFeedback('Переключаю на русский язык');
                }
                break;
                
            case 'switchLanguageKk':
                if (app.currentLang !== 'kk') {
                    app.switchLanguage('kk');
                    this.speakFeedback('Қазақ тіліне ауыстырып жатырмын');
                }
                break;
                
            case 'help':
                this.showHelp();
                break;
                
            case 'readCurrentScreen':
                this.readCurrentScreen();
                break;
                
            case 'readOptions':
                this.readCurrentOptions();
                break;
        }
    }
    
    readCurrentScreen() {
        const lang = this.app.currentLang;
        let text = '';
        
        // Определяем текущий экран
        if (!document.getElementById('accessibilitySection').classList.contains('hidden')) {
            text = lang === 'ru' 
                ? 'Экран выбора особенностей обучения. Выберите подходящие варианты и нажмите начать обучение.'
                : 'Оқу ерекшеліктерін таңдау экраны. Сәйкес нұсқаларды таңдап, оқуды бастау батырмасын басыңыз.';
        } else if (!document.getElementById('profileSection').classList.contains('hidden')) {
            const profiles = JSON.parse(localStorage.getItem('profiles') || '[]');
            if (profiles.length === 0) {
                text = lang === 'ru'
                    ? 'Экран выбора профиля. Профилей пока нет. Создайте новый профиль.'
                    : 'Профиль таңдау экраны. Профильдер жоқ. Жаңа профиль құрыңыз.';
            } else {
                text = lang === 'ru'
                    ? `Экран выбора профиля. Доступно профилей: ${profiles.length}. Скажите "профиль один" или "профиль два" для выбора.`
                    : `Профиль таңдау экраны. Қолжетімді профильдер: ${profiles.length}. Таңдау үшін "профиль бір" немесе "профиль екі" деп айтыңыз.`;
            }
        } else if (!document.getElementById('coursesSection').classList.contains('hidden')) {
            const courses = this.app.courses[lang] || [];
            text = lang === 'ru'
                ? `Экран выбора курса. Доступно курсов: ${courses.length}. Скажите "курс один", "курс два" или название курса.`
                : `Курс таңдау экраны. Қолжетімді курс: ${courses.length}. "Курс бір", "курс екі" немесе курс атауын айтыңыз.`;
        } else if (!document.getElementById('modulesSection').classList.contains('hidden')) {
            text = lang === 'ru'
                ? 'Экран модулей курса. Выберите модуль или урок.'
                : 'Курс модульдері экраны. Модуль немесе сабақты таңдаңыз.';
        }
        
        this.speakFeedback(text);
    }
    
    readCurrentOptions() {
        const lang = this.app.currentLang;
        let text = '';
        
        // Читаем доступные опции в зависимости от экрана
        if (!document.getElementById('profileSection').classList.contains('hidden')) {
            const profiles = JSON.parse(localStorage.getItem('profiles') || '[]');
            if (profiles.length > 0) {
                const profileList = profiles.map((p, i) => 
                    lang === 'ru' ? `Профиль ${i + 1}: ${p.name}, ${p.age} лет` : `Профиль ${i + 1}: ${p.name}, ${p.age} жас`
                ).join('. ');
                text = profileList + '. ' + (lang === 'ru' ? 'Скажите "профиль" и номер для выбора.' : 'Таңдау үшін "профиль" және нөмірді айтыңыз.');
            }
        } else if (!document.getElementById('coursesSection').classList.contains('hidden')) {
            const courses = this.app.courses[lang] || [];
            const courseList = courses.map((c, i) => 
                lang === 'ru' ? `Курс ${i + 1}: ${c.title}` : `Курс ${i + 1}: ${c.title}`
            ).join('. ');
            text = courseList + '. ' + (lang === 'ru' ? 'Скажите "курс" и номер или название курса.' : 'Таңдау үшін "курс" және нөмірді немесе курс атауын айтыңыз.');
        }
        
        if (text) {
            this.speakFeedback(text);
        }
    }

    speakFeedback(text) {
        if (!this.app.settings.audioHints || !('speechSynthesis' in window) || !text || !String(text).trim()) return;
        speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(String(text).trim());
        utterance.lang = this.app.currentLang === 'ru' ? 'ru-RU' : 'kk-KZ';
        utterance.rate = 0.9;
        utterance.pitch = 1.1;
        utterance.volume = 1;

        // Ensure voices are loaded before selecting one
        const loadVoices = () => {
            const voices = speechSynthesis.getVoices();
            
            // 1. Strict priority: Microsoft Pavel or Dmitry (Russian)
            let preferred = null;
            if (utterance.lang.startsWith('ru')) {
                preferred = voices.find(v => v.name.toLowerCase().includes('pavel') || 
                                         v.name.toLowerCase().includes('dmitry') || 
                                         v.name.toLowerCase().includes('dmitri') ||
                                         v.name.toLowerCase().includes('ivan'));
            }

            // 2. Any Male voice in the target language (broad lang check)
            if (!preferred) {
                const baseLang = String(utterance.lang).split('-')[0];
                preferred = voices.find(v => v.lang.startsWith(baseLang) && (v.name.toLowerCase().includes('male') || v.name.toLowerCase().includes('man')));
            }

            // 3. Any voice that is NOT explicitly female (Irina, Elena, Zira, etc) if we are in Russian
            if (!preferred && utterance.lang.startsWith('ru')) {
                 preferred = voices.find(v => v.lang.startsWith('ru') && 
                                         !v.name.toLowerCase().includes('irina') && 
                                         !v.name.toLowerCase().includes('elena') && 
                                         !v.name.toLowerCase().includes('zira') &&
                                         !v.name.toLowerCase().includes('female') &&
                                         !v.name.toLowerCase().includes('tatiana') &&
                                         !v.name.toLowerCase().includes('victoria') &&
                                         !v.name.toLowerCase().includes('arina') &&
                                         !v.name.toLowerCase().includes('alisa') &&
                                         !v.name.toLowerCase().includes('milena'));
            }

            // 4. Saved voice (only if it's not one of the banned ones)
            if (!preferred) {
                const savedVoiceName = localStorage.getItem('smart_ai_prefs_v1') ? JSON.parse(localStorage.getItem('smart_ai_prefs_v1')).voice : null;
                if (savedVoiceName) {
                    const sv = savedVoiceName.toLowerCase();
                    if (!sv.includes('irina') && !sv.includes('elena') && !sv.includes('zira')) {
                        preferred = voices.find(v => v.name === savedVoiceName);
                    }
                }
            }
            
            // 5. Absolute fallback: Try to pick a voice that is NOT the default if the default is female? 
            // We just pick the first matching lang.
            if (!preferred) {
                const baseLang = String(utterance.lang).split('-')[0];
                preferred = voices.find(v => v.lang.startsWith(baseLang));
            }
            
            if (preferred) utterance.voice = preferred;
            speechSynthesis.speak(utterance);
        };

        // Check if voices are already loaded
        const voices = speechSynthesis.getVoices();
        if (voices.length > 0) {
            loadVoices();
        } else {
            // Wait for voices to be loaded
            speechSynthesis.onvoiceschanged = loadVoices;
        }
    }

    showHelp() {
        const lang = this.app.currentLang;
        const helpText = lang === 'ru' 
            ? 'Вы можете сказать: настройки, родительский кабинет, назад, чтение, математика, логика, профиль один, профиль два, курс один, курс два, урок один, урок два, что на экране, какие варианты, помощь'
            : 'Сіз айта аласыз: параметрлер, ата-ана кабинеті, артқа, оқу, математика, логика, профиль бір, профиль екі, курс бір, курс екі, сабақ бір, сабақ екі, экранда не бар, қандай нұсқалар, көмек';
        
        this.speakFeedback(helpText);
        
        // Показываем подсказку на экране
        const helpDiv = document.createElement('div');
        helpDiv.style.cssText = `
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: #2196F3;
            color: white;
            padding: 16px 24px;
            border-radius: 12px;
            font-size: 14px;
            z-index: 10001;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            max-width: 80%;
            text-align: center;
        `;
        helpDiv.textContent = helpText;
        document.body.appendChild(helpDiv);
        
        setTimeout(() => {
            helpDiv.remove();
        }, 8000);
    }
}

class SmartLearningApp {
    constructor() {
        this.currentLang = localStorage.getItem('appLanguage') || 'ru';
        this.currentProfile = null;
        this.currentCourse = null;
        this.currentModule = null;
        this.settings = this.loadSettings();
        this.selectedAccessibilityOptions = new Set();
        
        // Система курсов
        this.courses = this.initCourses();
        
        // Голосовое управление
        this.voiceNavigation = null;
        
        // Загружаем сохранённые опции доступности
        this.loadSavedAccessibilityOptions();
        
        // Инициализация
        this.init();
    }

    loadSavedAccessibilityOptions() {
        const saved = localStorage.getItem('selectedAccessibilityOptions');
        if (saved) {
            try {
                const options = JSON.parse(saved);
                options.forEach(opt => this.selectedAccessibilityOptions.add(opt));
            } catch (e) {
                console.error('Error loading saved accessibility options:', e);
            }
        }
    }

    init() {
        this.initLanguageSwitcher();
        this.initSettings();
        this.initModals();
        this.initProgressWidget();
        this.initAccessibilityScreen();
        this.initVoiceNavigation();
        this.loadProfiles();
        this.updateLanguage();
        this.applySettings();
        this.applyControlMethod(); // Применяем способ управления
        
        // Если пользователь уже выбрал особенности на главном экране (мт/index.html),
        // то сразу переходим к профилям. Иначе показываем экран выбора особенностей.
        if (this.selectedAccessibilityOptions && this.selectedAccessibilityOptions.size > 0) {
            this.showProfileScreen();
        } else {
            this.showAccessibilityScreen();
        }
    }

    initAccessibilityScreen() {
        // Рендерим карточки особенностей
        this.renderAccessibilityCards();
        
        // Инициализируем обработчики
        this.initAccessibilityHandlers();
    }

    renderAccessibilityCards() {
        const grid = document.getElementById('accessibilityGrid');
        if (!grid) return;

        const options = {
            ru: [
                {
                    id: 'vision',
                    icon: '👁️',
                    title: 'Я плохо вижу',
                    description: 'Крупный шрифт, озвучивание, контраст'
                },
                {
                    id: 'hearing',
                    icon: '👂',
                    title: 'Я плохо слышу',
                    description: 'Субтитры, жестовый язык, визуальные подсказки'
                },
                {
                    id: 'mouse',
                    icon: '🖱️',
                    title: 'Мне трудно управлять мышью',
                    description: 'Крупные кнопки, управление жестами, один клик'
                },
                {
                    id: 'motor',
                    icon: '♿',
                    title: 'Дети с моторными нарушениями',
                    description: 'Голосовое управление, крупные элементы, адаптивный интерфейс'
                },
                {
                    id: 'speech',
                    icon: '🗣️',
                    title: 'Мне трудно говорить',
                    description: 'Анализ артикуляции, голосовой помощник'
                },
                {
                    id: 'home',
                    icon: '🏠',
                    title: 'Я учусь из дома',
                    description: 'Полный курс, видеоуроки, интерактив'
                },
                {
                    id: 'diagrams',
                    icon: '📊',
                    title: 'Мне нужны схемы',
                    description: 'Генерация блок-схем, инфографики и временных линий'
                }
            ],
            kk: [
                {
                    id: 'vision',
                    icon: '👁️',
                    title: 'Мен нашар көремін',
                    description: 'Үлкен қаріп, дыбыстау, контраст'
                },
                {
                    id: 'hearing',
                    icon: '👂',
                    title: 'Мен нашар естимін',
                    description: 'Субтитрлер, қол тілі, көрнекі кеңестер'
                },
                {
                    id: 'mouse',
                    icon: '🖱️',
                    title: 'Менге тышқанмен басқару қиын',
                    description: 'Үлкен батырмалар, қол қимылдарымен басқару, бір басу'
                },
                {
                    id: 'motor',
                    icon: '♿',
                    title: 'Моторлық бұзылуы бар балалар',
                    description: 'Дауыстық басқару, үлкен элементтер, бейімделген интерфейс'
                },
                {
                    id: 'speech',
                    icon: '🗣️',
                    title: 'Менге сөйлеу қиын',
                    description: 'Артикуляция талдауы, дауыстық көмекші'
                },
                {
                    id: 'home',
                    icon: '🏠',
                    title: 'Мен үйден оқимын',
                    description: 'Толық курс, бейне сабақтар, интерактив'
                },
                {
                    id: 'diagrams',
                    icon: '📊',
                    title: 'Маған схемалар қажет',
                    description: 'Блок-схемалар, инфографика және уақыт сызықтарын генерациялау'
                }
            ]
        };

        const currentOptions = options[this.currentLang] || options.ru;
        
        grid.innerHTML = currentOptions.map(option => `
            <div class="accessibility-card" data-option="${option.id}">
                <div class="accessibility-card-icon">${option.icon}</div>
                <h3 class="accessibility-card-title">${option.title}</h3>
                <p class="accessibility-card-description">${option.description}</p>
            </div>
        `).join('');

        // Добавляем обработчики для карточек
        grid.querySelectorAll('.accessibility-card').forEach(card => {
            card.addEventListener('click', () => {
                this.toggleAccessibilityCard(card);
            });
            
            card.setAttribute('tabindex', '0');
            card.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    this.toggleAccessibilityCard(card);
                }
            });
        });
    }

    toggleAccessibilityCard(card) {
        const option = card.dataset.option;
        
        if (card.classList.contains('selected')) {
            card.classList.remove('selected');
            this.selectedAccessibilityOptions.delete(option);
        } else {
            card.classList.add('selected');
            this.selectedAccessibilityOptions.add(option);
        }
        
        this.updateStartButton();
        this.applyAccessibilitySettings();
    }

    updateStartButton() {
        const startBtn = document.getElementById('startLearningBtn');
        if (!startBtn) return;
        
        if (this.selectedAccessibilityOptions.size > 0) {
            startBtn.disabled = false;
        } else {
            startBtn.disabled = true;
        }
    }

    applyAccessibilitySettings() {
        // Применяем настройки в зависимости от выбранных опций
        if (this.selectedAccessibilityOptions.has('motor') || this.selectedAccessibilityOptions.has('mouse')) {
            // Автоматически включаем крупные кнопки для моторных нарушений
            this.settings.largeButtons = true;
            this.settings.largeFont = true;
            this.saveSettings();
            this.applySettings();
        }
        
        if (this.selectedAccessibilityOptions.has('vision')) {
            this.settings.largeFont = true;
            this.saveSettings();
            this.applySettings();
        }
        
        if (this.selectedAccessibilityOptions.has('motor')) {
            // Для моторных нарушений включаем голосовое управление по умолчанию
            this.settings.audioHints = true;
            this.saveSettings();
        }
    }

    initAccessibilityHandlers() {
        const startBtn = document.getElementById('startLearningBtn');
        const settingsBtn = document.getElementById('additionalSettingsBtn');
        const homeBtn = document.getElementById('homeBtn');
        
        if (startBtn) {
            startBtn.addEventListener('click', () => {
                this.handleStartLearning();
            });
            
            startBtn.addEventListener('keydown', (e) => {
                if ((e.key === 'Enter' || e.key === ' ') && !startBtn.disabled) {
                    e.preventDefault();
                    this.handleStartLearning();
                }
            });
        }
        
        if (settingsBtn) {
            settingsBtn.addEventListener('click', () => {
                document.getElementById('settingsModal').classList.remove('hidden');
                const fileHint = document.getElementById('fileProtocolHint');
                if (fileHint) fileHint.classList.toggle('hidden', window.location.protocol !== 'file:');
            });
        }
        
        if (homeBtn) {
            homeBtn.addEventListener('click', () => this.goHome());
        }
    }

    handleStartLearning() {
        if (this.selectedAccessibilityOptions.size === 0) {
            alert(this.currentLang === 'ru' 
                ? 'Пожалуйста, выберите хотя бы одну опцию' 
                : 'Кем дегенде бір нұсқаны таңдаңыз');
            return;
        }
        
        // Сохраняем выбранные опции (внутренний формат приложения)
        const options = Array.from(this.selectedAccessibilityOptions);
        localStorage.setItem('selectedAccessibilityOptions', JSON.stringify(options));

        // Также сохраняем в формате "окна Обучение" из папки `мт`
        // (чтобы `мт/learning.html` показал "Вы выбрали ...")
        const mapToMt = {
            vision: 'lowVision',
            hearing: 'lowHearing',
            mouse: 'motor',
            motor: 'motor',
            speech: 'speech',
            home: 'remote',
            diagrams: 'diagrams',
        };
        const mtSelected = options.map((id) => mapToMt[id]).filter(Boolean);

        const mtState = {
            lang: this.currentLang === 'kk' ? 'kk' : 'ru',
            selected: Array.from(new Set(mtSelected)),
            a11y: {
                // В `мт` theme=true означает тёмная тема. В вашем приложении тема не хранится —
                // оставим тёмную по умолчанию, а остальное подтянем из настроек.
                theme: true,
                contrast: this.selectedAccessibilityOptions.has('vision'),
                largeText: !!this.settings.largeFont,
                tts: !!this.settings.audioHints,
            },
        };
        localStorage.setItem('smart_ai_prefs_v1', JSON.stringify(mtState));
        
        // Переходим к выбору профиля (внутри этого же сайта)
        this.showProfileScreen();
    }

    goHome() {
        // Показываем экран выбора особенностей и скрываем всё остальное
        ['profileSection', 'coursesSection', 'modulesSection'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.classList.add('hidden');
        });
        const acc = document.getElementById('accessibilitySection');
        if (acc) acc.classList.remove('hidden');
        this.speakFeedback(this.currentLang === 'ru' ? 'Возвращаюсь на главный экран' : 'Басты экранға оралу');
    }

    showAccessibilityScreen() {
        const accessibilitySection = document.getElementById('accessibilitySection');
        const profileSection = document.getElementById('profileSection');
        const coursesSection = document.getElementById('coursesSection');
        const modulesSection = document.getElementById('modulesSection');
        
        // Плавное переключение экранов
        if (!accessibilitySection.classList.contains('hidden')) return;
        
        profileSection.classList.add('hidden');
        coursesSection.classList.add('hidden');
        modulesSection.classList.add('hidden');
        
        setTimeout(() => {
            accessibilitySection.classList.remove('hidden');
        }, 50);
        
        // На главных экранах виджет прогресса не показываем
        this.hideProgressWidget();
    }

    showProfileScreen() {
        const accessibilitySection = document.getElementById('accessibilitySection');
        const profileSection = document.getElementById('profileSection');
        const coursesSection = document.getElementById('coursesSection');
        const modulesSection = document.getElementById('modulesSection');
        
        // Плавное переключение экранов
        if (!profileSection.classList.contains('hidden')) return;
        
        accessibilitySection.classList.add('hidden');
        coursesSection.classList.add('hidden');
        modulesSection.classList.add('hidden');
        
        setTimeout(() => {
            profileSection.classList.remove('hidden');
        }, 50);
        
        // На экране профиля виджет прогресса не показываем
        this.hideProgressWidget();
    }

    initProgressWidget() {
        const widgetToggle = document.getElementById('widgetToggle');
        const content = document.getElementById('progressWidgetContent');
        
        if (widgetToggle && content) {
            // Устанавливаем начальное состояние: закрыто по умолчанию
            if (!content.classList.contains('collapsed')) {
                content.classList.add('collapsed');
            }
            if (!widgetToggle.classList.contains('collapsed')) {
                widgetToggle.classList.add('collapsed');
            }
            
            // Обновляем иконку
            const icon = widgetToggle.querySelector('.icon');
            if (icon) {
                icon.textContent = content.classList.contains('collapsed') ? '▲' : '▼';
            }
            
            widgetToggle.addEventListener('click', () => {
                const isCollapsed = content.classList.contains('collapsed');
                
                if (isCollapsed) {
                    content.classList.remove('collapsed');
                    widgetToggle.classList.remove('collapsed');
                    if (icon) icon.textContent = '▼';
                } else {
                    content.classList.add('collapsed');
                    widgetToggle.classList.add('collapsed');
                    if (icon) icon.textContent = '▲';
                }
            });
        }
    }

    // ========== СИСТЕМА ЯЗЫКОВ ==========
    
    initLanguageSwitcher() {
        const langButtons = document.querySelectorAll('.lang-btn');
        langButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const lang = btn.dataset.lang;
                this.switchLanguage(lang);
            });
        });
    }

    switchLanguage(lang) {
        if (lang === this.currentLang) return;
        
        this.currentLang = lang;
        localStorage.setItem('appLanguage', lang);
        
        // Обновляем активные кнопки
        document.querySelectorAll('.lang-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.lang === lang);
        });
        
        this.updateLanguage();
        
        // Перезапускаем голосовое управление с новым языком
        if (this.voiceNavigation && this.settings.voiceNavigation) {
            this.voiceNavigation.stop();
            setTimeout(() => {
                if (this.voiceNavigation) {
                    this.voiceNavigation.recognition.lang = lang === 'ru' ? 'ru-RU' : 'kk-KZ';
                    this.voiceNavigation.start();
                }
            }, 300);
        }
        
        // Обновляем карточки доступности при смене языка
        if (document.getElementById('accessibilityGrid')) {
            this.renderAccessibilityCards();
            // Восстанавливаем выбранные опции
            this.selectedAccessibilityOptions.forEach(option => {
                const card = document.querySelector(`[data-option="${option}"]`);
                if (card) {
                    card.classList.add('selected');
                }
            });
            this.updateStartButton();
        }
    }

    updateLanguage() {
        // Обновляем все элементы с data-lang-ru и data-lang-kk
        document.querySelectorAll('[data-lang-ru]').forEach(el => {
            const ruText = el.dataset.langRu;
            const kkText = el.dataset.langKk;
            el.textContent = this.currentLang === 'ru' ? ruText : kkText;
        });

        // Обновляем placeholder
        const nameInput = document.getElementById('childName');
        if (nameInput) {
            nameInput.placeholder = this.currentLang === 'ru' ? 'Введите имя' : 'Атыңызды енгізіңіз';
        }
    }

    // ========== СИСТЕМА ПРОФИЛЕЙ ==========
    
    loadProfiles() {
        const profiles = JSON.parse(localStorage.getItem('profiles') || '[]');
        const profilesList = document.getElementById('profilesList');
        
        if (profiles.length === 0) {
            profilesList.innerHTML = '';
            return;
        }

        profilesList.innerHTML = profiles.map((profile, index) => {
            // Проверяем актуальность streak
            const lastActivity = profile.lastActivityDate ? new Date(profile.lastActivityDate) : null;
            const today = new Date();
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            
            let currentStreak = profile.streak || 0;
            if (lastActivity) {
                const lastActivityDate = new Date(lastActivity.toDateString());
                const todayDate = new Date(today.toDateString());
                const yesterdayDate = new Date(yesterday.toDateString());
                
                // Если последняя активность была не сегодня и не вчера, streak мог сброситься
                if (lastActivityDate.getTime() !== todayDate.getTime() && 
                    lastActivityDate.getTime() !== yesterdayDate.getTime()) {
                    // Streak уже должен быть обновлён при последней активности
                }
            }
            
            return `
                <div class="profile-card" data-profile-id="${profile.id}">
                    <div class="profile-avatar">${profile.avatar}</div>
                    <div class="profile-info">
                        <div class="profile-name">${profile.name}</div>
                        <div class="profile-age">${profile.age} ${this.currentLang === 'ru' ? 'лет' : 'жас'}</div>
                        <div class="profile-stats">
                            <span class="stat-item">
                                <span class="stat-icon">⭐</span>
                                <span class="stat-value">${profile.xp || 0} XP</span>
                            </span>
                            <span class="stat-item">
                                <span class="stat-icon">🔥</span>
                                <span class="stat-value">${currentStreak} ${this.currentLang === 'ru' ? 'дней' : 'күн'}</span>
                            </span>
                        </div>
                    </div>
                    <button class="profile-select-btn" data-profile-id="${profile.id}">
                        ${this.currentLang === 'ru' ? 'Выбрать' : 'Таңдау'}
                    </button>
                </div>
            `;
        }).join('');

        // Добавляем обработчики выбора профиля
        document.querySelectorAll('.profile-select-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const profileId = btn.dataset.profileId;
                this.selectProfile(profileId);
            });
        });

        // Добавляем обработчики клавиатуры для доступности
        document.querySelectorAll('.profile-card').forEach(card => {
            card.setAttribute('tabindex', '0');
            card.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    const profileId = card.dataset.profileId;
                    this.selectProfile(profileId);
                }
            });
        });
    }

    selectProfile(profileId) {
        const profiles = JSON.parse(localStorage.getItem('profiles') || '[]');
        this.currentProfile = profiles.find(p => p.id === profileId);
        
        if (this.currentProfile) {
            localStorage.setItem('currentProfileId', profileId);
            
            // Сразу скрываем экран профилей
            const profileSection = document.getElementById('profileSection');
            if (profileSection) {
                profileSection.classList.add('hidden');
            }
            
            // Показываем мотивационное сообщение о streak
            this.showStreakMotivation();
            
            // Переходим к экрану курсов
            this.showCourses();
        }
    }

    showProgressWidget() {
        const widget = document.getElementById('progressWidget');
        if (widget) {
            widget.classList.remove('hidden');
            this.updateProgressWidget();
        }
    }

    hideProgressWidget() {
        const widget = document.getElementById('progressWidget');
        if (widget) {
            widget.classList.add('hidden');
        }
    }

    updateProgressWidget() {
        if (!this.currentProfile) return;

        const profile = this.currentProfile;
        const progress = JSON.parse(localStorage.getItem(`progress_${profile.id}`) || '{}');
        
        // Обновляем статистику с анимацией
        const xpElement = document.getElementById('widgetXP');
        const lessonsElement = document.getElementById('widgetLessons');
        
        if (xpElement) {
            const oldXP = parseInt(xpElement.textContent) || 0;
            const newXP = profile.xp || 0;
            if (oldXP !== newXP) {
                xpElement.style.transform = 'scale(1.2)';
                setTimeout(() => {
                    xpElement.textContent = `${newXP} XP`;
                    xpElement.style.transform = 'scale(1)';
                    xpElement.style.transition = 'transform 0.3s ease';
                }, 100);
            } else {
                xpElement.textContent = `${newXP} XP`;
            }
        }
        
        if (lessonsElement) {
            const completedLessons = Object.keys(progress).filter(k => progress[k] === true).length;
            lessonsElement.textContent = completedLessons;
        }
        
        // Обновляем streak
        const streak = profile.streak || 0;
        const lastActivity = profile.lastActivityDate ? new Date(profile.lastActivityDate) : null;
        const today = new Date().toDateString();
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const yesterdayString = yesterday.toDateString();
        
        const isStreakActive = lastActivity && (
            new Date(lastActivity).toDateString() === today ||
            new Date(lastActivity).toDateString() === yesterdayString
        );
        
        const streakElement = document.getElementById('widgetStreak');
        if (streakElement) {
            streakElement.innerHTML = `${streak} <span data-lang-ru="дней" data-lang-kk="күн">${this.currentLang === 'ru' ? 'дней' : 'күн'}</span>`;
        }
        
        const streakCard = document.getElementById('streakCard');
        if (streakCard) {
            if (streak > 0 && isStreakActive) {
                streakCard.classList.add('active');
                streakCard.classList.remove('inactive');
            } else if (streak > 0) {
                streakCard.classList.remove('active');
                streakCard.classList.add('inactive');
            } else {
                streakCard.classList.remove('active', 'inactive');
            }
        }
        
        // Обновляем общий прогресс с плавной анимацией
        const overallProgress = this.calculateOverallProgress(progress);
        const progressPercentElement = document.getElementById('overallProgress');
        const progressFillElement = document.getElementById('overallProgressFill');
        
        if (progressPercentElement) {
            progressPercentElement.textContent = `${overallProgress}%`;
        }
        
        if (progressFillElement) {
            // Сохраняем текущую ширину для плавного перехода
            const currentWidth = parseFloat(progressFillElement.style.width) || 0;
            progressFillElement.style.width = `${currentWidth}%`;
            
            // Используем requestAnimationFrame для плавной анимации
            requestAnimationFrame(() => {
                progressFillElement.style.width = `${overallProgress}%`;
            });
        }
        
        // Обновляем список незавершённых уроков
        this.updateUnfinishedLessons(progress);
    }

    calculateOverallProgress(progress) {
        let totalLessons = 0;
        let completedLessons = 0;
        
        const courses = this.courses[this.currentLang] || [];
        courses.forEach(course => {
            course.modules.forEach(module => {
                module.lessons.forEach(lesson => {
                    totalLessons++;
                    const lessonKey = `${course.id}_${module.id}_${lesson.id}`;
                    if (progress[lessonKey] === true) {
                        completedLessons++;
                    }
                });
            });
        });
        
        return totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0;
    }

    updateUnfinishedLessons(progress) {
        const unfinishedList = document.getElementById('unfinishedLessonsList');
        const unfinishedLessons = [];
        
        const courses = this.courses[this.currentLang] || [];
        courses.forEach(course => {
            course.modules.forEach(module => {
                module.lessons.forEach((lesson, lessonIndex) => {
                    const lessonKey = `${course.id}_${module.id}_${lesson.id}`;
                    const isCompleted = progress[lessonKey] === true;
                    
                    // Проверяем, заблокирован ли урок
                    const isLocked = lessonIndex > 0 && 
                        progress[`${course.id}_${module.id}_${module.lessons[lessonIndex - 1].id}`] !== true;
                    
                    if (!isCompleted && !isLocked) {
                        unfinishedLessons.push({
                            key: lessonKey,
                            name: lesson.title,
                            course: course.title,
                            courseId: course.id,
                            moduleId: module.id,
                            lessonId: lesson.id
                        });
                    }
                });
            });
        });
        
        // Сортируем по порядку и берём последние 5
        const recentUnfinished = unfinishedLessons.slice(0, 5);
        
        if (recentUnfinished.length === 0) {
            unfinishedList.innerHTML = `
                <div class="empty-unfinished">
                    ${this.currentLang === 'ru' 
                        ? 'Все уроки завершены! 🎉' 
                        : 'Барлық сабақтар аяқталды! 🎉'}
                </div>
            `;
        } else {
            unfinishedList.innerHTML = recentUnfinished.map((lesson, index) => `
                <div class="unfinished-lesson-item" 
                     data-lesson-key="${lesson.key}"
                     tabindex="0"
                     role="button">
                    <div class="unfinished-lesson-icon">${index + 1}</div>
                    <div class="unfinished-lesson-info">
                        <div class="unfinished-lesson-name">${lesson.name}</div>
                        <div class="unfinished-lesson-course">${lesson.course}</div>
                    </div>
                    <div class="unfinished-lesson-arrow">→</div>
                </div>
            `).join('');
            
            // Добавляем обработчики кликов
            unfinishedList.querySelectorAll('.unfinished-lesson-item').forEach(item => {
                item.addEventListener('click', () => {
                    const lessonKey = item.dataset.lessonKey;
                    this.startLesson(lessonKey);
                });
                
                item.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        const lessonKey = item.dataset.lessonKey;
                        this.startLesson(lessonKey);
                    }
                });
            });
        }
    }

    showStreakMotivation() {
        if (!this.currentProfile) return;
        
        const streak = this.currentProfile.streak || 0;
        const lastActivity = this.currentProfile.lastActivityDate ? new Date(this.currentProfile.lastActivityDate) : null;
        const today = new Date().toDateString();
        
        // Проверяем, занимался ли ребёнок сегодня
        const hasActivityToday = lastActivity && new Date(lastActivity).toDateString() === today;
        
        if (streak > 0 && !hasActivityToday) {
            // Мотивируем продолжать серию
            setTimeout(() => {
                const message = this.currentLang === 'ru' 
                    ? `🔥 У тебя серия ${streak} ${streak === 1 ? 'день' : streak < 5 ? 'дня' : 'дней'}! Продолжай!`
                    : `🔥 Сенің ${streak} ${streak === 1 ? 'күн' : 'күн'} қатарың бар! Жалғастыр!`;
                this.showNotification(message, 'success');
            }, 500);
        } else if (streak === 0) {
            // Мотивируем начать серию
            setTimeout(() => {
                const message = this.currentLang === 'ru'
                    ? '🌟 Начни свою серию дней сегодня!'
                    : '🌟 Бүгін күн қатарыңды баста!';
                this.showNotification(message, 'info');
            }, 500);
        }
    }

    showNotification(message, type = 'info') {
        // Удаляем предыдущие уведомления того же типа
        const existingNotifications = document.querySelectorAll('.notification');
        existingNotifications.forEach(n => {
            n.style.animation = 'slideOutRight 0.3s ease-out';
            setTimeout(() => n.remove(), 300);
        });
        
        // Создаём уведомление
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        
        const icon = type === 'success' ? '✅' : 'ℹ️';
        notification.innerHTML = `
            <div style="display: flex; align-items: center; gap: 12px;">
                <span style="font-size: 24px;">${icon}</span>
                <span>${message}</span>
            </div>
        `;
        
        notification.style.cssText = `
            position: fixed;
            top: 80px;
            right: 20px;
            background: ${type === 'success' ? '#4CAF50' : '#2196F3'};
            color: white;
            padding: 20px 28px;
            border-radius: 16px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25), 0 0 0 1px rgba(255, 255, 255, 0.1);
            z-index: 2000;
            font-weight: 600;
            font-size: calc(16px * var(--font-size));
            animation: slideInRight 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            max-width: 450px;
            backdrop-filter: blur(10px);
            will-change: transform, opacity;
        `;
        
        document.body.appendChild(notification);
        
        // Удаляем через 5 секунд с плавным исчезновением
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease-in';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 5000);
    }

    showCourses() {
        const accessibilitySection = document.getElementById('accessibilitySection');
        const profileSection = document.getElementById('profileSection');
        const coursesSection = document.getElementById('coursesSection');
        const modulesSection = document.getElementById('modulesSection');
        
        // Убеждаемся, что все другие экраны скрыты
        accessibilitySection.classList.add('hidden');
        profileSection.classList.add('hidden');
        modulesSection.classList.add('hidden');
        
        // Показываем экран курсов (отдельный экран)
        setTimeout(() => {
            coursesSection.classList.remove('hidden');
        }, 50);
        
        // Виджет прогресса показываем только в курсах/модулях
        if (this.currentProfile) {
            this.showProgressWidget();
        } else {
            this.hideProgressWidget();
        }
        this.renderCourses();
    }

    // ========== СИСТЕМА КУРСОВ ==========
    
    initCourses() {
        return {
            ru: [
                {
                    id: 'reading',
                    title: 'Чтение',
                    icon: '📚',
                    description: 'Учимся читать: от букв до историй (1-4 класс)',
                    color: '#4CAF50',
                    modules: [
                        // 1 КЛАСС
                        {
                            id: 'reading-g1-letters',
                            title: '1 класс: Буквы и слоги',
                            lessons: [
                                { id: 'let1', title: 'Гласные буквы (А, О, У, И)', type: 'letter' },
                                { id: 'let2', title: 'Согласные (М, С, Х, Ш)', type: 'letter' },
                                { id: 'syl1', title: 'Читаем слоги (МА, СО, ХУ)', type: 'word' },
                                { id: 'syl2', title: 'Собери слово из слогов', type: 'word' }
                            ]
                        },
                        {
                            id: 'reading-g1-words',
                            title: '1 класс: Первые слова',
                            lessons: [
                                { id: 'cat', title: 'Кошка, Дом, Лес', type: 'word' },
                                { id: 'dog', title: 'Собака, Мяч, Сон', type: 'word' },
                                { id: 'family', title: 'Мама, Папа, Брат', type: 'word' }
                            ]
                        },
                        // 2 КЛАСС
                        {
                            id: 'reading-g2-sentences',
                            title: '2 класс: Предложения',
                            lessons: [
                                { id: 's1', title: 'Кто что делает?', type: 'sentence' },
                                { id: 's2', title: 'Какой предмет?', type: 'sentence' },
                                { id: 's3', title: 'Короткие фразы', type: 'sentence' },
                                { id: 's4', title: 'Загадки', type: 'sentence' }
                            ]
                        },
                        {
                            id: 'reading-g2-topics',
                            title: '2 класс: Тематические слова',
                            lessons: [
                                { id: 'food', title: 'Еда и напитки', type: 'word' },
                                { id: 'animals', title: 'Дикие животные', type: 'word' },
                                { id: 'school', title: 'Школа', type: 'word' }
                            ]
                        },
                        // 3 КЛАСС
                        {
                            id: 'reading-g3-stories',
                            title: '3 класс: Короткие рассказы',
                            lessons: [
                                { id: 'story1', title: 'Рассказ о лете', type: 'story' },
                                { id: 'story2', title: 'Поход в магазин', type: 'story' },
                                { id: 'story3', title: 'Мой друг', type: 'story' },
                                { id: 'story4', title: 'В школе', type: 'story' }
                            ]
                        },
                        // 4 КЛАСС
                        {
                            id: 'reading-g4-literacy',
                            title: '4 класс: Грамотность',
                            lessons: [
                                { id: 'lit1', title: 'Синонимы (Смелый - Храбрый)', type: 'literacy' },
                                { id: 'lit2', title: 'Антонимы (День - Ночь)', type: 'literacy' },
                                { id: 'lit3', title: 'Пословицы', type: 'literacy' }
                            ]
                        }
                    ]
                },
                {
                    id: 'math',
                    title: 'Математика',
                    icon: '🔢',
                    description: 'Счёт, сложение, умножение и задачи (1-4 класс)',
                    color: '#2196F3',
                    modules: [
                        // 1 КЛАСС
                        {
                            id: 'math-g1-count',
                            title: '1 класс: Счёт до 20',
                            lessons: [
                                { id: 'c1', title: 'Считаем до 10', type: 'counting' },
                                { id: 'c2', title: 'Считаем до 20', type: 'counting' },
                                { id: 'add1', title: 'Сложение до 10 (2+3)', type: 'addition' },
                                { id: 'sub1', title: 'Вычитание до 10 (5-2)', type: 'subtraction' }
                            ]
                        },
                        // 2 КЛАСС
                        {
                            id: 'math-g2-calc',
                            title: '2 класс: Счёт до 100',
                            lessons: [
                                { id: 'add2', title: 'Сложение десятками (20+30)', type: 'addition' },
                                { id: 'sub2', title: 'Вычитание десятков (50-20)', type: 'subtraction' },
                                { id: 'cmp1', title: 'Больше, меньше или равно', type: 'comparison' }
                            ]
                        },
                        // 3 КЛАСС
                        {
                            id: 'math-g3-mul',
                            title: '3 класс: Умножение',
                            lessons: [
                                { id: 'mul1', title: 'Умножение на 2 и 3', type: 'multiplication' },
                                { id: 'mul2', title: 'Умножение на 4 и 5', type: 'multiplication' },
                                { id: 'div1', title: 'Простое деление', type: 'division' }
                            ]
                        },
                        // 4 КЛАСС
                        {
                            id: 'math-g4-complex',
                            title: '4 класс: Задачи',
                            lessons: [
                                { id: 'task1', title: 'Текстовые задачи', type: 'intro' },
                                { id: 'big1', title: 'Сложение больших чисел', type: 'addition' },
                                { id: 'geom1', title: 'Периметр и площадь', type: 'shape' }
                            ]
                        }
                    ]
                },
                {
                    id: 'logic',
                    title: 'Логика',
                    icon: '🧩',
                    description: 'Развитие мышления, памяти и внимания (1-4 класс)',
                    color: '#9C27B0',
                    modules: [
                        // 1 КЛАСС
                        {
                            id: 'logic-g1-basic',
                            title: '1 класс: Формы и Цвета',
                            lessons: [
                                { id: 'colors', title: 'Учим цвета', type: 'word' },
                                { id: 'shapes', title: 'Круг, Квадрат, Треугольник', type: 'shape' },
                                { id: 'same', title: 'Найди такой же предмет', type: 'pattern' }
                            ]
                        },
                        // 2 КЛАСС
                        {
                            id: 'logic-g2-seq',
                            title: '2 класс: Последовательности',
                            lessons: [
                                { id: 'seq1', title: 'Продолжи ряд (🔴🔵🔴...)', type: 'sequence' },
                                { id: 'seq2', title: 'Что лишнее?', type: 'sorting' },
                                { id: 'pairs', title: 'Найди пару', type: 'pair' }
                            ]
                        },
                        // 3 КЛАСС
                        {
                            id: 'logic-g3-analogy',
                            title: '3 класс: Аналогии',
                            lessons: [
                                { id: 'an1', title: 'Холодно : Зима = Тепло : ?', type: 'pair' },
                                { id: 'class1', title: 'Живое и неживое', type: 'classification' },
                                { id: 'part1', title: 'Часть и целое', type: 'parts' }
                            ]
                        },
                        // 4 КЛАСС
                        {
                            id: 'logic-g4-puzzle',
                            title: '4 класс: Головоломки',
                            lessons: [
                                { id: 'puz1', title: 'Логические задачи', type: 'intro' },
                                { id: 'pat1', title: 'Сложные узоры', type: 'pattern' },
                                { id: 'reason', title: 'Причина и следствие', type: 'cause' }
                            ]
                        }
                    ]
                }
            ],
            kk: [
                {
                    id: 'reading',
                    title: 'Оқу',
                    icon: '📚',
                    description: 'Әріптерден бастап мәтіндерге дейін (1-4 сынып)',
                    color: '#4CAF50',
                    modules: [
                        // 1 СЫНЫП
                        {
                            id: 'reading-g1-letters',
                            title: '1 сынып: Әріптер мен буындар',
                            lessons: [
                                { id: 'let1', title: 'Дауысты дыбыстар (А, О, Ұ, І)', type: 'letter' },
                                { id: 'let2', title: 'Дауыссыз дыбыстар', type: 'letter' },
                                { id: 'syl1', title: 'Буындарды оқимыз', type: 'word' }
                            ]
                        },
                        {
                            id: 'reading-g1-words',
                            title: '1 сынып: Алғашқы сөздер',
                            lessons: [
                                { id: 'cat', title: 'Мысық, Үй, Ағаш', type: 'word' },
                                { id: 'family', title: 'Ана, Әке, Ата', type: 'word' }
                            ]
                        },
                        // 2 СЫНЫП
                        {
                            id: 'reading-g2-sentences',
                            title: '2 сынып: Сөйлемдер',
                            lessons: [
                                { id: 's1', title: 'Кім не істейді?', type: 'sentence' },
                                { id: 's2', title: 'Жұмбақтар', type: 'sentence' }
                            ]
                        },
                        // 3 СЫНЫП
                        {
                            id: 'reading-g3-stories',
                            title: '3 сынып: Қысқа әңгімелер',
                            lessons: [
                                { id: 'story1', title: 'Жазғы демалыс', type: 'story' },
                                { id: 'story2', title: 'Дүкенде', type: 'story' },
                                { id: 'story3', title: 'Менің досым', type: 'story' },
                                { id: 'story4', title: 'Мектепте', type: 'story' }
                            ]
                        },
                        // 4 СЫНЫП
                        {
                            id: 'reading-g4-literacy',
                            title: '4 сынып: Сауаттылық',
                            lessons: [
                                { id: 'lit1', title: 'Синонимдер', type: 'literacy' },
                                { id: 'lit2', title: 'Антонимдер', type: 'literacy' },
                                { id: 'lit3', title: 'Мақал-мәтелдер', type: 'literacy' }
                            ]
                        }
                    ]
                },
                {
                    id: 'math',
                    title: 'Математика',
                    icon: '🔢',
                    description: 'Санау, қосу, азайту және есептер (1-4 сынып)',
                    color: '#2196F3',
                    modules: [
                        // 1 СЫНЫП
                        {
                            id: 'math-g1-count',
                            title: '1 сынып: 20-ға дейін санау',
                            lessons: [
                                { id: 'c1', title: '10-ға дейін санау', type: 'counting' },
                                { id: 'c2', title: '20-ға дейін санау', type: 'counting' },
                                { id: 'add1', title: 'Қосу (2+3)', type: 'addition' }
                            ]
                        },
                        // 2 СЫНЫП
                        {
                            id: 'math-g2-calc',
                            title: '2 сынып: 100-ге дейін санау',
                            lessons: [
                                { id: 'add2', title: 'Ондықтармен қосу', type: 'addition' },
                                { id: 'sub2', title: 'Азайту', type: 'subtraction' },
                                { id: 'cmp1', title: 'Артық, кем, тең', type: 'comparison' }
                            ]
                        },
                        // 3 СЫНЫП
                        {
                            id: 'math-g3-mul',
                            title: '3 сынып: Көбейту',
                            lessons: [
                                { id: 'mul1', title: '2-ге және 3-ке көбейту', type: 'multiplication' },
                                { id: 'div1', title: 'Бөлу', type: 'division' }
                            ]
                        },
                        // 4 СЫНЫП
                        {
                            id: 'math-g4-complex',
                            title: '4 сынып: Есептер',
                            lessons: [
                                { id: 'task1', title: 'Мәтіндік есептер', type: 'intro' },
                                { id: 'geom1', title: 'Периметр және аудан', type: 'shape' }
                            ]
                        }
                    ]
                },
                {
                    id: 'logic',
                    title: 'Логика',
                    icon: '🧩',
                    description: 'Ойлауды дамыту (1-4 сынып)',
                    color: '#9C27B0',
                    modules: [
                        // 1 СЫНЫП
                        {
                            id: 'logic-g1-basic',
                            title: '1 сынып: Пішіндер мен Түстер',
                            lessons: [
                                { id: 'colors', title: 'Түстерді үйренеміз', type: 'word' },
                                { id: 'shapes', title: 'Пішіндер', type: 'shape' }
                            ]
                        },
                        // 2 СЫНЫП
                        {
                            id: 'logic-g2-seq',
                            title: '2 сынып: Тізбектер',
                            lessons: [
                                { id: 'seq1', title: 'Тізбекті жалғастыр', type: 'sequence' },
                                { id: 'pairs', title: 'Жұбын тап', type: 'pair' }
                            ]
                        },
                        // 3 СЫНЫП
                        {
                            id: 'logic-g3-analogy',
                            title: '3 сынып: Ұқсастықтар',
                            lessons: [
                                { id: 'class1', title: 'Тірі және өлі табиғат', type: 'classification' }
                            ]
                        },
                        // 4 СЫНЫП
                        {
                            id: 'logic-g4-puzzle',
                            title: '4 сынып: Басқатырғыштар',
                            lessons: [
                                { id: 'puz1', title: 'Логикалық есептер', type: 'intro' },
                                { id: 'pat1', title: 'Күрделі өрнектер', type: 'pattern' }
                            ]
                        }
                    ]
                }
            ]
        };
    }

    renderCourses() {
        const courses = this.courses[this.currentLang];
        const coursesGrid = document.getElementById('coursesGrid');
        
        const coursesHtml = courses.map(course => {
            const progress = this.getCourseProgress(course.id);
            
            return `
                <div class="course-card" data-course-id="${course.id}">
                    <div class="course-icon" style="background: ${course.color}20; color: ${course.color}">
                        ${course.icon}
                    </div>
                    <div class="course-info">
                        <h3 class="course-title">${course.title}</h3>
                        <p class="course-description">${course.description}</p>
                        <div class="course-progress">
                            <div class="progress-bar-mini">
                                <div class="progress-fill-mini" style="width: ${progress}%; background: ${course.color}"></div>
                            </div>
                            <span class="progress-text">${progress}%</span>
                        </div>
                    </div>
                    <button class="course-select-btn" data-course-id="${course.id}">
                        ${this.currentLang === 'ru' ? 'Начать' : 'Бастау'}
                    </button>
                </div>
            `;
        }).join('');

        const motorCardHtml = `
            <div class="course-card motor-exercises" data-special="motor-exercises" role="button" aria-label="${this.currentLang === 'ru' ? 'Упражнения для детей с моторными нарушениями' : 'Моторлық бұзылыстары бар балаларға арналған жаттығулар'}">
                <div class="course-icon motor-exercises-icon">🖱️</div>
                <div class="course-info">
                    <h3 class="course-title" data-lang-ru="Для детей с моторными нарушениями" data-lang-kk="Моторлық бұзылыстары бар балаларға">Для детей с моторными нарушениями</h3>
                    <p class="course-description" data-lang-ru="Спокойные адаптивные упражнения с мышью" data-lang-kk="Тышқанмен тыныш, бейімделетін жаттығулар">Спокойные адаптивные упражнения с мышью</p>
                    <div class="course-progress">
                        <div class="progress-bar-mini motor-exercises-bar">
                            <div class="progress-fill-mini motor-exercises-fill" style="width: 100%"></div>
                        </div>
                        <span class="progress-text" data-lang-ru="13 упражнений" data-lang-kk="13 жаттығу">13 упражнений</span>
                    </div>
                </div>
                <button class="course-select-btn motor-exercises-btn" type="button" data-special="motor-exercises">${this.currentLang === 'ru' ? 'Открыть' : 'Ашу'}</button>
            </div>
        `;

        coursesGrid.innerHTML = coursesHtml + motorCardHtml;

        // Добавляем обработчики
        document.querySelectorAll('.course-select-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                if (btn.dataset.special === 'motor-exercises') {
                    this.openMotorExercises();
                    return;
                }
                const courseId = btn.dataset.courseId;
                if (courseId) {
                    this.selectCourse(courseId);
                }
            });
        });

        // Клавиатурная навигация
        document.querySelectorAll('.course-card').forEach(card => {
            card.setAttribute('tabindex', '0');
            card.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    if (card.dataset.special === 'motor-exercises') {
                        this.openMotorExercises();
                        return;
                    }
                    const courseId = card.dataset.courseId;
                    if (courseId) {
                        this.selectCourse(courseId);
                    }
                }
            });

            card.addEventListener('click', (e) => {
                if (card.dataset.special === 'motor-exercises') {
                    this.openMotorExercises();
                    return;
                }
                const courseId = card.dataset.courseId;
                if (courseId) {
                    this.selectCourse(courseId);
                }
            });
        });
        
        // Обновляем виджет прогресса
        if (this.currentProfile) {
            this.updateProgressWidget();
        }
    }

    openMotorExercises() {
        window.location.href = './motor-exercises.html';
    }

    selectCourse(courseId) {
        const courses = this.courses[this.currentLang];
        this.currentCourse = courses.find(c => c.id === courseId);
        
        if (this.currentCourse) {
            const accessibilitySection = document.getElementById('accessibilitySection');
            const coursesSection = document.getElementById('coursesSection');
            const modulesSection = document.getElementById('modulesSection');
            
            // Плавное переключение экранов
            accessibilitySection.classList.add('hidden');
            coursesSection.classList.add('hidden');
            
            setTimeout(() => {
                modulesSection.classList.remove('hidden');
            }, 50);
            
            // Виджет прогресса показываем только в курсах/модулях
            if (this.currentProfile) {
                this.showProgressWidget();
            } else {
                this.hideProgressWidget();
            }
            this.renderModules();
        }
    }

    renderModules() {
        const courseTitle = document.getElementById('courseTitle');
        courseTitle.textContent = this.currentCourse.title;

        // Обновляем прогресс курса
        const progress = this.getCourseProgress(this.currentCourse.id);
        document.getElementById('courseProgress').textContent = `${progress}%`;
        document.getElementById('courseProgressFill').style.width = `${progress}%`;

        const modulesTree = document.getElementById('modulesTree');
        modulesTree.innerHTML = this.currentCourse.modules.map((module, moduleIndex) => {
            const moduleProgress = this.getModuleProgress(this.currentCourse.id, module.id);
            const isLocked = moduleIndex > 0 && !this.isModuleCompleted(this.currentCourse.id, this.currentCourse.modules[moduleIndex - 1].id);
            
            return `
                <div class="module-card ${isLocked ? 'locked' : ''}" data-module-id="${module.id}">
                    <div class="module-header">
                        <div class="module-icon">${moduleIndex + 1}</div>
                        <div class="module-info">
                            <h4 class="module-title">${module.title}</h4>
                            <div class="module-progress">
                                <div class="progress-bar-mini">
                                    <div class="progress-fill-mini" style="width: ${moduleProgress}%"></div>
                                </div>
                                <span>${moduleProgress}%</span>
                            </div>
                        </div>
                    </div>
                    <div class="lessons-list">
                        ${module.lessons.map((lesson, lessonIndex) => {
                            const lessonKey = `${this.currentCourse.id}_${module.id}_${lesson.id}`;
                            const isLessonCompleted = this.isLessonCompleted(lessonKey);
                            const isLessonLocked = lessonIndex > 0 && !this.isLessonCompleted(`${this.currentCourse.id}_${module.id}_${module.lessons[lessonIndex - 1].id}`);
                            
                            return `
                                <div class="lesson-item ${isLessonCompleted ? 'completed' : ''} ${isLessonLocked || isLocked ? 'locked' : ''}" 
                                     data-lesson-key="${lessonKey}">
                                    <div class="lesson-icon">${isLessonCompleted ? '✓' : lessonIndex + 1}</div>
                                    <span class="lesson-title">${lesson.title}</span>
                                    ${!isLessonLocked && !isLocked ? `
                                        <button class="lesson-start-btn" data-lesson-key="${lessonKey}">
                                            ${this.currentLang === 'ru' ? 'Начать' : 'Бастау'}
                                        </button>
                                    ` : ''}
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            `;
        }).join('');

        // Обработчики для уроков
        document.querySelectorAll('.lesson-start-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const lessonKey = btn.dataset.lessonKey;
                this.startLesson(lessonKey);
            });
        });
    }

    startLesson(lessonKey) {
        // Сохраняем текущий урок и курс для возврата «Назад»
        localStorage.setItem('currentLessonKey', lessonKey);
        if (this.currentCourse && this.currentCourse.id) {
            localStorage.setItem('lessonReturnCourseId', this.currentCourse.id);
        }
        // Переходим на страницу голосового урока
        window.location.href = `lesson.html?key=${lessonKey}`;
    }

    // ========== СИСТЕМА ПРОГРЕССА ==========
    
    getCourseProgress(courseId) {
        if (!this.currentProfile) return 0;
        
        const course = this.courses[this.currentLang].find(c => c.id === courseId);
        if (!course) return 0;

        let totalLessons = 0;
        let completedLessons = 0;

        course.modules.forEach(module => {
            module.lessons.forEach(lesson => {
                totalLessons++;
                const lessonKey = `${courseId}_${module.id}_${lesson.id}`;
                if (this.isLessonCompleted(lessonKey)) {
                    completedLessons++;
                }
            });
        });

        return totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0;
    }

    getModuleProgress(courseId, moduleId) {
        if (!this.currentProfile) return 0;
        
        const course = this.courses[this.currentLang].find(c => c.id === courseId);
        if (!course) return 0;
        
        const module = course.modules.find(m => m.id === moduleId);
        if (!module) return 0;

        let completed = 0;
        module.lessons.forEach(lesson => {
            const lessonKey = `${courseId}_${moduleId}_${lesson.id}`;
            if (this.isLessonCompleted(lessonKey)) {
                completed++;
            }
        });

        return module.lessons.length > 0 ? Math.round((completed / module.lessons.length) * 100) : 0;
    }

    isModuleCompleted(courseId, moduleId) {
        const progress = this.getModuleProgress(courseId, moduleId);
        return progress === 100;
    }

    isLessonCompleted(lessonKey) {
        if (!this.currentProfile) return false;
        const progress = JSON.parse(localStorage.getItem(`progress_${this.currentProfile.id}`) || '{}');
        return progress[lessonKey] === true;
    }

    // ========== НАСТРОЙКИ ==========
    
    initSettings() {
        // Кнопка настроек
        document.getElementById('settingsBtn').addEventListener('click', () => {
            document.getElementById('settingsModal').classList.remove('hidden');
            const fileHint = document.getElementById('fileProtocolHint');
            if (fileHint) fileHint.classList.toggle('hidden', window.location.protocol !== 'file:');
        });

        // Закрытие модального окна
        document.getElementById('closeSettingsModal').addEventListener('click', () => {
            document.getElementById('settingsModal').classList.add('hidden');
        });

        // Применение настроек
        document.getElementById('largeButtons').checked = this.settings.largeButtons;
        document.getElementById('largeFont').checked = this.settings.largeFont;
        document.getElementById('disableAnimations').checked = this.settings.disableAnimations;
        document.getElementById('audioHints').checked = this.settings.audioHints;
        document.getElementById('lessonSpeed').value = this.settings.lessonSpeed;
        document.getElementById('speedValue').textContent = `${this.settings.lessonSpeed}x`;
        
        // Способ управления
        const controlMethod = this.settings.controlMethod || 'both';
        const methodMap = {
            'keyboard': 'controlKeyboard',
            'voice': 'controlVoice',
            'both': 'controlBoth'
        };
        const radioId = methodMap[controlMethod] || 'controlBoth';
        const radio = document.getElementById(radioId);
        if (radio) {
            radio.checked = true;
        }

        // Обработчики изменений
        document.getElementById('largeButtons').addEventListener('change', (e) => {
            this.settings.largeButtons = e.target.checked;
            this.saveSettings();
            this.applySettings();
        });

        document.getElementById('largeFont').addEventListener('change', (e) => {
            this.settings.largeFont = e.target.checked;
            this.saveSettings();
            this.applySettings();
        });

        document.getElementById('disableAnimations').addEventListener('change', (e) => {
            this.settings.disableAnimations = e.target.checked;
            this.saveSettings();
            this.applySettings();
        });

        document.getElementById('audioHints').addEventListener('change', (e) => {
            this.settings.audioHints = e.target.checked;
            this.saveSettings();
        });

        // Способ управления
        document.querySelectorAll('input[name="controlMethod"]').forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.settings.controlMethod = e.target.value;
                this.saveSettings();
                this.applyControlMethod();
            });
        });

        // Голосовое управление
        document.getElementById('voiceNavigation').checked = this.settings.voiceNavigation;
        document.getElementById('voiceNavigation').addEventListener('change', (e) => {
            this.settings.voiceNavigation = e.target.checked;
            this.saveSettings();
            if (this.voiceNavigation) {
                if (e.target.checked) {
                    this.voiceNavigation.start();
                } else {
                    this.voiceNavigation.stop();
                }
            }
        });

        document.getElementById('lessonSpeed').addEventListener('input', (e) => {
            this.settings.lessonSpeed = parseFloat(e.target.value);
            document.getElementById('speedValue').textContent = `${this.settings.lessonSpeed}x`;
            this.saveSettings();
        });

        // Проверка микрофона
        const testMicBtn = document.getElementById('testMicBtn');
        const testMicResult = document.getElementById('testMicResult');
        if (testMicBtn && testMicResult) {
            testMicBtn.addEventListener('click', () => {
                testMicResult.textContent = this.currentLang === 'ru' ? 'Проверяю…' : 'Тексеруде…';
                if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                    testMicResult.textContent = this.currentLang === 'ru'
                        ? 'Микрофон не поддерживается в этом браузере. Используйте Chrome или Edge.'
                        : 'Браузер микрофонды қолдамайды. Chrome немесе Edge пайдаланыңыз.';
                    return;
                }
                navigator.mediaDevices.getUserMedia({ audio: true })
                    .then((stream) => {
                        stream.getTracks().forEach(t => t.stop());
                        testMicResult.textContent = this.currentLang === 'ru'
                            ? 'Микрофон работает.'
                            : 'Микрофон жұмыс істейді.';
                        testMicResult.style.color = '#22C55E';
                    })
                    .catch(() => {
                        testMicResult.textContent = this.currentLang === 'ru'
                            ? 'Нет доступа к микрофону. Разрешите доступ в настройках браузера.'
                            : 'Микрофонға қол жеткізу жоқ. Браузер параметрлерінде рұқсат беріңіз.';
                        testMicResult.style.color = '#dc2626';
                    });
            });
        }
    }

    initVoiceNavigation() {
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            console.log('Голосовое управление не поддерживается в этом браузере');
            return;
        }

        this.voiceNavigation = new VoiceNavigation(this);
        // Микрофон включается только в настройках — не запускаем и не спрашиваем разрешение при загрузке.
        // Запуск только по чекбоксу «Голосовое управление сайтом» в настройках (см. initSettingsHandlers).

        this.setupAutoAnnouncements();

        window.addEventListener('voice-command', (e) => {
            if (this.voiceNavigation) this.voiceNavigation.handleCommand(e.detail.transcript);
        });
    }
    
    setupAutoAnnouncements() {
        this._lastAnnouncedScreen = null;
        this._lastAnnouncedTime = 0;
        const announceDebounceMs = 2500;

        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                const el = mutation.type === 'attributes' && mutation.attributeName === 'class' ? mutation.target : null;
                const nodes = el ? [el] : Array.from(mutation.addedNodes).filter(n => n.nodeType === 1);
                nodes.forEach((node) => {
                    if (!node.classList) return;
                    let screenType = null;
                    if (node.classList.contains('profile-section') && !node.classList.contains('hidden')) screenType = 'profile';
                    else if (node.classList.contains('courses-section') && !node.classList.contains('hidden')) screenType = 'courses';
                    else if (node.classList.contains('modules-section') && !node.classList.contains('hidden')) screenType = 'modules';
                    if (screenType) this.announceScreen(screenType, announceDebounceMs);
                });
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['class']
        });
    }

    announceScreen(screenType, debounceMs) {
        if (!this.voiceNavigation || !this.settings.audioHints) return;
        const now = Date.now();
        if (this._lastAnnouncedScreen === screenType && now - this._lastAnnouncedTime < (debounceMs || 2500)) return;
        this._lastAnnouncedScreen = screenType;
        this._lastAnnouncedTime = now;

        const lang = this.currentLang;
        let text = '';
        switch (screenType) {
            case 'profile':
                text = lang === 'ru'
                    ? 'Экран выбора профиля. Выберите профиль или создайте новый.'
                    : 'Профиль таңдау экраны. Профильді таңдаңыз немесе жаңасын құрыңыз.';
                break;
            case 'courses':
                text = lang === 'ru'
                    ? 'Экран выбора курса. Выберите курс для обучения.'
                    : 'Курс таңдау экраны. Оқу үшін курсты таңдаңыз.';
                break;
            case 'modules':
                text = lang === 'ru'
                    ? 'Экран модулей. Выберите модуль или урок.'
                    : 'Модульдер экраны. Модуль немесе сабақты таңдаңыз.';
                break;
        }
        if (text) {
            setTimeout(() => {
                this.voiceNavigation.speakFeedback(text);
            }, 400);
        }
    }

    loadSettings() {
        const defaultSettings = {
            largeButtons: false,
            largeFont: false,
            disableAnimations: false,
            audioHints: true,
            voiceNavigation: false,
            controlMethod: 'both', // 'keyboard', 'voice', 'both'
            lessonSpeed: 1
        };
        
        const saved = localStorage.getItem('appSettings');
        return saved ? { ...defaultSettings, ...JSON.parse(saved) } : defaultSettings;
    }

    saveSettings() {
        localStorage.setItem('appSettings', JSON.stringify(this.settings));
    }

    applySettings() {
        const root = document.documentElement;
        
        if (this.settings.largeButtons) {
            root.style.setProperty('--button-size', '1.3');
        } else {
            root.style.setProperty('--button-size', '1');
        }

        if (this.settings.largeFont) {
            root.style.setProperty('--font-size', '1.2');
        } else {
            root.style.setProperty('--font-size', '1');
        }

        if (this.settings.disableAnimations) {
            document.body.classList.add('no-animations');
        } else {
            document.body.classList.remove('no-animations');
        }
        
        // Применяем способ управления
        this.applyControlMethod();
    }

    applyControlMethod() {
        const method = this.settings.controlMethod || 'both';
        
        // Управляем голосовым управлением сайтом
        const voiceNavCheckbox = document.getElementById('voiceNavigation');
        
        if (method === 'keyboard') {
            // Только клавиатура - отключаем голосовое управление
            if (this.voiceNavigation && this.voiceNavigation.isActive) {
                this.voiceNavigation.stop();
            }
            // Отключаем чекбокс голосового управления
            if (voiceNavCheckbox) {
                voiceNavCheckbox.checked = false;
                voiceNavCheckbox.disabled = true;
                this.settings.voiceNavigation = false;
                this.saveSettings();
            }
        } else if (method === 'voice') {
            // Только голос - разрешаем включить голосовое управление
            if (voiceNavCheckbox) {
                voiceNavCheckbox.disabled = false;
                // Автоматически включаем, если ещё не включено
                if (!this.settings.voiceNavigation) {
                    voiceNavCheckbox.checked = true;
                    this.settings.voiceNavigation = true;
                    this.saveSettings();
                    if (this.voiceNavigation && !this.voiceNavigation.isActive) {
                        setTimeout(() => {
                            this.voiceNavigation.start();
                        }, 500);
                    }
                } else if (this.voiceNavigation && !this.voiceNavigation.isActive) {
                    this.voiceNavigation.start();
                }
            }
        } else {
            // Оба способа — разрешаем выбор и запускаем голос, если включён
            if (voiceNavCheckbox) {
                voiceNavCheckbox.disabled = false;
                if (this.settings.voiceNavigation && this.voiceNavigation && !this.voiceNavigation.isActive) {
                    this.voiceNavigation.start();
                }
            }
        }
        
        // Добавляем/убираем классы для визуальных подсказок
        document.body.classList.remove('keyboard-only', 'voice-only', 'both-controls');
        if (method === 'keyboard') {
            document.body.classList.add('keyboard-only');
        } else if (method === 'voice') {
            document.body.classList.add('voice-only');
        } else {
            document.body.classList.add('both-controls');
        }

        // Показываем подсказки для клавиатуры, если выбран клавиатурный или оба способа
        if (method === 'keyboard' || method === 'both') {
            this.showKeyboardHints();
        } else {
            this.hideKeyboardHints();
        }
    }

    showKeyboardHints() {
        // Добавляем подсказки для клавиатурного управления
        let hintsContainer = document.getElementById('keyboardHints');
        if (!hintsContainer) {
            hintsContainer = document.createElement('div');
            hintsContainer.id = 'keyboardHints';
            hintsContainer.className = 'keyboard-hints';
            hintsContainer.innerHTML = `
                <div class="hints-content">
                    <span class="hints-icon">⌨️</span>
                    <span class="hints-text" data-lang-ru="Используйте Tab для навигации, Enter/Space для выбора" data-lang-kk="Навигация үшін Tab, таңдау үшін Enter/Space пайдаланыңыз">Используйте Tab для навигации, Enter/Space для выбора</span>
                </div>
            `;
            document.body.appendChild(hintsContainer);
        }
        hintsContainer.classList.remove('hidden');
    }

    hideKeyboardHints() {
        const hintsContainer = document.getElementById('keyboardHints');
        if (hintsContainer) {
            hintsContainer.classList.add('hidden');
        }
    }

    // ========== МОДАЛЬНЫЕ ОКНА ==========
    
    initModals() {
        // Создание профиля
        document.getElementById('addProfileBtn').addEventListener('click', () => {
            document.getElementById('profileModal').classList.remove('hidden');
        });

        document.getElementById('closeProfileModal').addEventListener('click', () => {
            document.getElementById('profileModal').classList.add('hidden');
        });

        document.getElementById('createProfileBtn').addEventListener('click', () => {
            this.createProfile();
        });

        // Выбор аватара
        document.querySelectorAll('.avatar-option').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.avatar-option').forEach(b => b.classList.remove('selected'));
                btn.classList.add('selected');
            });
        });

        // Родительский кабинет
        document.getElementById('parentBtn').addEventListener('click', () => {
            document.getElementById('parentModal').classList.remove('hidden');
            this.renderParentDashboard();
        });

        document.getElementById('closeParentModal').addEventListener('click', () => {
            document.getElementById('parentModal').classList.add('hidden');
        });

        // Вкладки родительского кабинета
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                const tab = btn.dataset.tab;
                this.renderParentTab(tab);
            });
        });

        // Навигация назад
        document.getElementById('backToProfileBtn').addEventListener('click', () => {
            document.getElementById('coursesSection').classList.add('hidden');
            document.getElementById('profileSection').classList.remove('hidden');
        });

        document.getElementById('backToCoursesBtn').addEventListener('click', () => {
            document.getElementById('modulesSection').classList.add('hidden');
            document.getElementById('coursesSection').classList.remove('hidden');
        });
        
        // Кнопка "Дополнительные настройки" на экране доступности
        const additionalSettingsBtn = document.getElementById('additionalSettingsBtn');
        if (additionalSettingsBtn) {
            additionalSettingsBtn.addEventListener('click', () => {
                document.getElementById('settingsModal').classList.remove('hidden');
                const fileHint = document.getElementById('fileProtocolHint');
                if (fileHint) fileHint.classList.toggle('hidden', window.location.protocol !== 'file:');
            });
        }

        // Закрытие модальных окон по клику вне области
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    overlay.classList.add('hidden');
                }
            });
        });
    }

    createProfile() {
        const name = document.getElementById('childName').value.trim();
        const age = document.getElementById('childAge').value;
        const selectedAvatar = document.querySelector('.avatar-option.selected');
        const avatar = selectedAvatar ? selectedAvatar.dataset.avatar : '😊';

        if (!name) {
            alert(this.currentLang === 'ru' ? 'Введите имя ребёнка' : 'Баланың атын енгізіңіз');
            return;
        }

        const profile = {
            id: Date.now().toString(),
            name,
            age: parseInt(age),
            avatar,
            xp: 0,
            streak: 0,
            createdAt: new Date().toISOString()
        };

        const profiles = JSON.parse(localStorage.getItem('profiles') || '[]');
        profiles.push(profile);
        localStorage.setItem('profiles', JSON.stringify(profiles));

        // Очищаем форму
        document.getElementById('childName').value = '';
        document.getElementById('childAge').value = '5';
        document.querySelectorAll('.avatar-option').forEach(b => b.classList.remove('selected'));

        // Закрываем модальное окно
        document.getElementById('profileModal').classList.add('hidden');

        // Обновляем список профилей
        this.loadProfiles();
    }

    renderParentDashboard() {
        const profiles = JSON.parse(localStorage.getItem('profiles') || '[]');
        if (profiles.length === 0) {
            document.getElementById('parentTabContent').innerHTML = `
                <div class="empty-state">
                    <p>${this.currentLang === 'ru' ? 'Нет созданных профилей' : 'Профильдер жоқ'}</p>
                </div>
            `;
            return;
        }

        this.renderParentTab('progress');
    }

    renderParentTab(tab) {
        const profiles = JSON.parse(localStorage.getItem('profiles') || '[]');
        const content = document.getElementById('parentTabContent');

        if (tab === 'progress') {
            content.innerHTML = profiles.map(profile => {
                const progress = JSON.parse(localStorage.getItem(`progress_${profile.id}`) || '{}');
                const completedLessons = Object.keys(progress).filter(k => progress[k] === true).length;
                
                return `
                    <div class="parent-profile-card">
                        <div class="parent-profile-header">
                            <div class="parent-avatar">${profile.avatar}</div>
                            <div>
                                <h4>${profile.name}</h4>
                                <p>${profile.age} ${this.currentLang === 'ru' ? 'лет' : 'жас'}</p>
                            </div>
                        </div>
                        <div class="parent-stats">
                            <div class="parent-stat">
                                <span class="stat-label">${this.currentLang === 'ru' ? 'Опыт' : 'Тәжірибе'}</span>
                                <span class="stat-value">${profile.xp || 0} XP</span>
                            </div>
                            <div class="parent-stat">
                                <span class="stat-label">${this.currentLang === 'ru' ? 'Серия' : 'Қатар'}</span>
                                <span class="stat-value">${profile.streak || 0} ${this.currentLang === 'ru' ? 'дней' : 'күн'}</span>
                            </div>
                            <div class="parent-stat">
                                <span class="stat-label">${this.currentLang === 'ru' ? 'Уроков пройдено' : 'Сабақтар өтті'}</span>
                                <span class="stat-value">${completedLessons}</span>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
        } else if (tab === 'achievements') {
            content.innerHTML = `
                <div class="achievements-grid">
                    <div class="achievement-card">
                        <div class="achievement-icon">🏆</div>
                        <h4>${this.currentLang === 'ru' ? 'Первый урок' : 'Бірінші сабақ'}</h4>
                        <p>${this.currentLang === 'ru' ? 'Пройдите первый урок' : 'Бірінші сабақты өтіңіз'}</p>
                    </div>
                    <div class="achievement-card">
                        <div class="achievement-icon">⭐</div>
                        <h4>${this.currentLang === 'ru' ? '100 XP' : '100 XP'}</h4>
                        <p>${this.currentLang === 'ru' ? 'Заработайте 100 очков опыта' : '100 тәжірибе ұпайы жинаңыз'}</p>
                    </div>
                    <div class="achievement-card">
                        <div class="achievement-icon">🔥</div>
                        <h4>${this.currentLang === 'ru' ? '7 дней подряд' : '7 күн қатар'}</h4>
                        <p>${this.currentLang === 'ru' ? 'Занимайтесь 7 дней подряд' : '7 күн қатар оқыңыз'}</p>
                    </div>
                </div>
            `;
        } else if (tab === 'reports') {
            content.innerHTML = `
                <div class="reports-list">
                    <div class="report-card">
                        <h4>${this.currentLang === 'ru' ? 'Еженедельный отчёт' : 'Апталық есеп'}</h4>
                        <p>${this.currentLang === 'ru' ? 'Просмотр прогресса за неделю' : 'Апта бойығы прогресті көру'}</p>
                    </div>
                </div>
            `;
        }
    }
}

// Инициализация приложения
let app;
document.addEventListener('DOMContentLoaded', () => {
    app = new SmartLearningApp();
    
    // Загружаем текущий профиль
    const currentProfileId = localStorage.getItem('currentProfileId');
    if (currentProfileId) {
        const profiles = JSON.parse(localStorage.getItem('profiles') || '[]');
        const profile = profiles.find(p => p.id === currentProfileId);
        if (profile) {
            app.currentProfile = profile;
            app.showCourses();
            // Если вернулись с урока — показываем модули того же курса
            const returnCourseId = localStorage.getItem('lessonReturnCourseId');
            if (returnCourseId) {
                localStorage.removeItem('lessonReturnCourseId');
                app.selectCourse(returnCourseId);
            }
        }
    }
    
    // Обновляем виджет прогресса при изменении языка
    const originalSwitchLanguage = app.switchLanguage.bind(app);
    app.switchLanguage = function(lang) {
        originalSwitchLanguage(lang);
        if (this.currentProfile) {
            this.updateProgressWidget();
        }
        // Голосовое управление уже перезапускается в оригинальном методе
    };
    
    // Обновляем виджет при обновлении прогресса (если вернулись с урока)
    window.addEventListener('progressUpdated', (e) => {
        if (app.currentProfile && app.currentProfile.id === e.detail.profileId) {
            // Обновляем профиль из localStorage
            const profiles = JSON.parse(localStorage.getItem('profiles') || '[]');
            const updatedProfile = profiles.find(p => p.id === e.detail.profileId);
            if (updatedProfile) {
                app.currentProfile = updatedProfile;
                app.updateProgressWidget();
            }
        }
    });
    
    // Обновляем виджет при возвращении на страницу
    window.addEventListener('focus', () => {
        if (app.currentProfile) {
            const profiles = JSON.parse(localStorage.getItem('profiles') || '[]');
            const updatedProfile = profiles.find(p => p.id === app.currentProfile.id);
            if (updatedProfile) {
                app.currentProfile = updatedProfile;
                app.updateProgressWidget();
            }
        }
    });
});

