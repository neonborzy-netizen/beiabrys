// Language translations
const translations = {
    ru: {
        title: "Какие у вас особенности обучения?",
        subtitle: "Выберите все подходящие варианты, и мы адаптируем интерфейс специально для вас",
        options: {
            vision: {
                title: "Я плохо вижу",
                description: "Крупный шрифт, озвучивание, контраст"
            },
            hearing: {
                title: "Я плохо слышу",
                description: "Субтитры, жестовый язык, визуальные подсказки"
            },
            mouse: {
                title: "Мне трудно управлять мышью",
                description: "Крупные кнопки, управление жестами, один клик"
            },
            speech: {
                title: "Мне трудно говорить",
                description: "Анализ артикуляции, голосовой помощник"
            },
            home: {
                title: "Я учусь из дома",
                description: "Полный курс, видеоуроки, интерактив"
            },
            diagrams: {
                title: "Мне нужны схемы",
                description: "Генерация блок-схем, инфографики и временных линий"
            }
        },
        buttons: {
            start: "Начать обучение",
            settings: "Дополнительные настройки"
        }
    },
    kk: {
        title: "Сіздің оқу ерекшеліктеріңіз қандай?",
        subtitle: "Барлық сәйкес нұсқаларды таңдаңыз, біз интерфейсті сізге арнайы бейімдейміз",
        options: {
            vision: {
                title: "Мен нашар көремін",
                description: "Үлкен қаріп, дыбыстау, контраст"
            },
            hearing: {
                title: "Мен нашар естимін",
                description: "Субтитрлер, қол тілі, көрнекі кеңестер"
            },
            mouse: {
                title: "Менге тышқанмен басқару қиын",
                description: "Үлкен батырмалар, қол қимылдарымен басқару, бір басу"
            },
            speech: {
                title: "Менге сөйлеу қиын",
                description: "Артикуляция талдауы, дауыстық көмекші"
            },
            home: {
                title: "Мен үйден оқимын",
                description: "Толық курс, бейне сабақтар, интерактив"
            },
            diagrams: {
                title: "Маған схемалар қажет",
                description: "Блок-схемалар, инфографика және уақыт сызықтарын генерациялау"
            }
        },
        buttons: {
            start: "Оқуды бастау",
            settings: "Қосымша параметрлер"
        }
    }
};

// Current language state
let currentLang = 'ru';
let selectedOptions = new Set();

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    initializeLanguageSwitcher();
    initializeCards();
    initializeButtons();
    updateLanguage(currentLang);
});

// Language switcher functionality
function initializeLanguageSwitcher() {
    const langButtons = document.querySelectorAll('.lang-btn');
    
    langButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const lang = this.getAttribute('data-lang');
            switchLanguage(lang);
        });
    });
}

function switchLanguage(lang) {
    if (lang === currentLang) return;
    
    currentLang = lang;
    
    // Update active button
    document.querySelectorAll('.lang-btn').forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('data-lang') === lang);
    });
    
    // Update content
    updateLanguage(lang);
}

function updateLanguage(lang) {
    const t = translations[lang];
    
    // Update title and subtitle
    document.querySelector('.main-title').textContent = t.title;
    document.querySelector('.subtitle').textContent = t.subtitle;
    
    // Update buttons
    document.getElementById('startBtn').textContent = t.buttons.start;
    document.getElementById('settingsBtn').textContent = t.buttons.settings;
    
    // Update cards
    const cards = document.querySelectorAll('.accessibility-card');
    cards.forEach(card => {
        const option = card.getAttribute('data-option');
        const optionData = t.options[option];
        
        card.querySelector('h3').textContent = optionData.title;
        card.querySelector('p').textContent = optionData.description;
    });
}

// Card selection functionality
function initializeCards() {
    const cards = document.querySelectorAll('.accessibility-card');
    
    cards.forEach(card => {
        card.addEventListener('click', function() {
            toggleCardSelection(this);
        });
        
        // Keyboard support
        card.setAttribute('tabindex', '0');
        card.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                toggleCardSelection(this);
            }
        });
    });
}

function toggleCardSelection(card) {
    const option = card.getAttribute('data-option');
    
    if (card.classList.contains('selected')) {
        card.classList.remove('selected');
        selectedOptions.delete(option);
    } else {
        card.classList.add('selected');
        selectedOptions.add(option);
    }
    
    updateStartButton();
}

function updateStartButton() {
    const startBtn = document.getElementById('startBtn');
    if (selectedOptions.size > 0) {
        startBtn.disabled = false;
        startBtn.style.opacity = '1';
    } else {
        startBtn.disabled = true;
        startBtn.style.opacity = '0.6';
    }
}

// Button functionality
function initializeButtons() {
    const startBtn = document.getElementById('startBtn');
    const settingsBtn = document.getElementById('settingsBtn');
    
    // Initially disable start button
    startBtn.disabled = true;
    startBtn.style.opacity = '0.6';
    
    startBtn.addEventListener('click', function() {
        if (selectedOptions.size === 0) {
            alert(currentLang === 'ru' 
                ? 'Пожалуйста, выберите хотя бы одну опцию' 
                : 'Кем дегенде бір нұсқаны таңдаңыз');
            return;
        }
        
        handleStartLearning();
    });
    
    settingsBtn.addEventListener('click', function() {
        handleSettings();
    });
}

function handleStartLearning() {
    const options = Array.from(selectedOptions);
    console.log('Starting learning with options:', options);
    
    // Here you would typically navigate to the learning page
    // or send the selected options to the server
    const message = currentLang === 'ru'
        ? `Начинаем обучение с выбранными опциями: ${options.join(', ')}`
        : `Таңдалған нұсқалармен оқуды бастау: ${options.join(', ')}`;
    
    alert(message);
    
    // Example: Save to localStorage
    localStorage.setItem('selectedOptions', JSON.stringify(options));
    localStorage.setItem('language', currentLang);
    
    // You can redirect to learning page here
    // window.location.href = 'learning.html';
}

function handleSettings() {
    console.log('Opening additional settings');
    
    // Here you would open a settings modal or navigate to settings page
    const message = currentLang === 'ru'
        ? 'Открываем дополнительные настройки'
        : 'Қосымша параметрлерді ашу';
    
    alert(message);
    
    // Example: Open settings modal
    // openSettingsModal();
}

// Load saved preferences on page load
function loadSavedPreferences() {
    const savedOptions = localStorage.getItem('selectedOptions');
    const savedLang = localStorage.getItem('language');
    
    if (savedLang && savedLang !== currentLang) {
        switchLanguage(savedLang);
    }
    
    if (savedOptions) {
        try {
            const options = JSON.parse(savedOptions);
            options.forEach(option => {
                const card = document.querySelector(`[data-option="${option}"]`);
                if (card) {
                    card.classList.add('selected');
                    selectedOptions.add(option);
                }
            });
            updateStartButton();
        } catch (e) {
            console.error('Error loading saved options:', e);
        }
    }
}

// Call on page load
window.addEventListener('load', loadSavedPreferences);
