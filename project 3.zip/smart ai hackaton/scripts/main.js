// Language switching functionality
document.addEventListener('DOMContentLoaded', function() {
    const langButtons = document.querySelectorAll('.lang-btn');
    
    langButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            langButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            // Here you can add language switching logic
            const lang = this.dataset.lang;
            console.log('Language switched to:', lang);
        });
    });

    // Start learning button
    const startLearningBtn = document.getElementById('startLearning');
    if (startLearningBtn) {
        startLearningBtn.addEventListener('click', function() {
            // Get selected cards
            const selectedCards = document.querySelectorAll('.card.selected');
            if (selectedCards.length === 0) {
                alert('Пожалуйста, выберите хотя бы одну опцию обучения');
                return;
            }
            // Navigate to first selected card or default page
            window.location.href = selectedCards[0].href || 'pages/home-learning/index.html';
        });
    }

    // Additional settings button
    const additionalSettingsBtn = document.getElementById('additionalSettings');
    if (additionalSettingsBtn) {
        additionalSettingsBtn.addEventListener('click', function() {
            // Add settings modal or navigation logic
            console.log('Additional settings clicked');
        });
    }

    // Help button
    const helpBtn = document.getElementById('helpBtn');
    if (helpBtn) {
        helpBtn.addEventListener('click', function() {
            alert('Добро пожаловать в Smart AI! Выберите особенности обучения, которые подходят вам, и нажмите "Начать обучение".');
        });
    }

    // Card selection (optional - for multi-select)
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        card.addEventListener('click', function(e) {
            // Allow navigation, but also toggle selection
            // Uncomment below if you want multi-select functionality
            // e.preventDefault();
            // this.classList.toggle('selected');
        });
    });
});
